/**
 * The framework-neutral design RUNTIME.
 *
 * `contract.js` owns the closed vocabulary and `preferences.js` the account
 * payload plus the device/account precedence. Everything a product still had
 * to write itself — reading the device choice from storage, reading a host's
 * URL parameters, the host-to-embed message, stamping the document, and the
 * pre-paint bootstrap in app.html — was re-implemented per consumer
 * (Techstack `theme.ts` ~290 lines, CMO `preferences.ts`, the Companion
 * Studio `appearance.ts` / `finish.ts`), each with the same trap documented
 * three times: stamp the class but not the attribute and every material
 * variable is undefined. This module is that logic, once (owner review
 * 2026-09-05, KOMBIFY-DESIGN-SYSTEM-STANDARD §4 and §5.2).
 *
 * No framework and no DOM at import time. Storage keys, the account transport
 * and change events stay consumer parameters; the precedence does not.
 */

import { DEFAULT_FINISH, FINISHES, isAppearance, isFinish } from './contract.js';
import { BASELINE_DESIGN, isAppearancePreference } from './preferences.js';

/** @typedef {import('./contract.js').Finish} Finish */
/** @typedef {import('./contract.js').Appearance} Appearance */
/** @typedef {import('./preferences.js').AppearancePreference} AppearancePreference */

/**
 * The package's storage convention: one key per axis, plain strings. A product
 * that already has its own keys passes them in; the shape is the same.
 */
export const DESIGN_STORAGE_KEYS = Object.freeze({
	appearance: 'kombify-appearance',
	finish: 'kombify-finish'
});

/** The `postMessage` type an embedding host sends its embeds (§4 tier 1). */
export const HOST_DESIGN_MESSAGE_TYPE = 'kombify:design';

/**
 * Read the device's stored choice. Tolerant: a missing key, an unavailable
 * storage or an unknown value all read as "no choice" — never as a value.
 *
 * @param {Pick<Storage, 'getItem'> | null | undefined} storage
 * @param {{ appearance: string, finish: string }} [keys]
 * @returns {{ appearance: AppearancePreference | null, finish: Finish | null }}
 */
export function readDeviceDesign(storage, keys = DESIGN_STORAGE_KEYS) {
	let appearance = null;
	let finish = null;
	try {
		const storedAppearance = storage?.getItem(keys.appearance);
		const storedFinish = storage?.getItem(keys.finish);
		appearance = isAppearancePreference(storedAppearance) ? storedAppearance : null;
		finish = isFinish(storedFinish) ? storedFinish : null;
	} catch {
		// Storage can throw (privacy mode, sandboxed frame): no choice, not an error.
	}
	return { appearance, finish };
}

/**
 * Persist a device choice. `null` removes the key (follow the account again).
 * An unknown value is neither stored nor forwarded (§5.2).
 *
 * @param {Pick<Storage, 'setItem' | 'removeItem'> | null | undefined} storage
 * @param {{ appearance?: AppearancePreference | null, finish?: Finish | null }} choice
 * @param {{ appearance: string, finish: string }} [keys]
 */
export function writeDeviceDesign(storage, choice, keys = DESIGN_STORAGE_KEYS) {
	if (!storage) return;
	try {
		if (choice.appearance === null) storage.removeItem(keys.appearance);
		else if (isAppearancePreference(choice.appearance)) storage.setItem(keys.appearance, choice.appearance);
		if (choice.finish === null) storage.removeItem(keys.finish);
		else if (isFinish(choice.finish)) storage.setItem(keys.finish, choice.finish);
	} catch {
		// Device storage is optional.
	}
}

/**
 * Host design context carried on an embed URL: `?appearance=` and `?finish=`,
 * plus `?theme=` as the retired name for appearance (kombify Cloud seeds its
 * tool iframes with it). Present and valid, or absent — never invalid.
 *
 * @param {string | URLSearchParams | null | undefined} search
 * @returns {{ appearance?: Appearance, finish?: Finish }}
 */
export function readHostDesignParams(search) {
	const params = search instanceof URLSearchParams ? search : new URLSearchParams(search ?? '');
	/** @type {{ appearance?: Appearance, finish?: Finish }} */
	const context = {};
	const appearance = params.get('appearance') ?? params.get('theme');
	if (isAppearance(appearance)) context.appearance = appearance;
	const finish = params.get('finish');
	if (isFinish(finish)) context.finish = finish;
	return context;
}

/**
 * The message a host posts to an embedded product when its design changes.
 * Only valid axis values travel; an unknown value is dropped, not forwarded.
 *
 * @param {{ appearance?: unknown, finish?: unknown }} design
 * @returns {{ type: typeof HOST_DESIGN_MESSAGE_TYPE, appearance?: Appearance, finish?: Finish }}
 */
export function hostDesignMessage(design) {
	/** @type {{ type: typeof HOST_DESIGN_MESSAGE_TYPE, appearance?: Appearance, finish?: Finish }} */
	const message = { type: HOST_DESIGN_MESSAGE_TYPE };
	if (isAppearance(design.appearance)) message.appearance = design.appearance;
	if (isFinish(design.finish)) message.finish = design.finish;
	return message;
}

/**
 * The embed side of the same boundary: true only for a message of the design
 * type whose every present axis carries a valid value.
 *
 * @param {unknown} data
 * @returns {data is { type: typeof HOST_DESIGN_MESSAGE_TYPE, appearance?: Appearance, finish?: Finish }}
 */
export function isHostDesignMessage(data) {
	if (!data || typeof data !== 'object') return false;
	const message = /** @type {Record<string, unknown>} */ (data);
	if (message.type !== HOST_DESIGN_MESSAGE_TYPE) return false;
	if (message.appearance !== undefined && !isAppearance(message.appearance)) return false;
	if (message.finish !== undefined && !isFinish(message.finish)) return false;
	return message.appearance !== undefined || message.finish !== undefined;
}

/**
 * The §4 precedence, highest first: host context (this embedding only), the
 * device's explicit choice, the account default, the kombify baseline. Each
 * axis resolves independently, so a host that sends only a finish leaves the
 * appearance to the device. `system` resolves through `prefersDark`.
 *
 * @param {{
 *   host?: { appearance?: Appearance | null, finish?: Finish | null } | null,
 *   device?: { appearance?: AppearancePreference | null, finish?: Finish | null } | null,
 *   account?: { appearance?: AppearancePreference | null, finish?: Finish | null } | null,
 *   prefersDark?: boolean
 * }} input
 * @returns {{
 *   appearance: Appearance,
 *   appearancePreference: AppearancePreference,
 *   finish: Finish,
 *   source: { appearance: 'host' | 'device' | 'account' | 'baseline', finish: 'host' | 'device' | 'account' | 'baseline' }
 * }}
 */
export function resolveDesignAxes({ host, device, account, prefersDark = false } = {}) {
	const appearanceTier = pick([
		['host', host?.appearance, isAppearancePreference],
		['device', device?.appearance, isAppearancePreference],
		['account', account?.appearance, isAppearancePreference],
		['baseline', BASELINE_DESIGN.appearance, isAppearancePreference]
	]);
	const finishTier = pick([
		['host', host?.finish, isFinish],
		['device', device?.finish, isFinish],
		['account', account?.finish, isFinish],
		['baseline', DEFAULT_FINISH, isFinish]
	]);
	const appearancePreference = /** @type {AppearancePreference} */ (appearanceTier.value);
	return {
		appearance: appearancePreference === 'system' ? (prefersDark ? 'dark' : 'light') : appearancePreference,
		appearancePreference,
		finish: /** @type {Finish} */ (finishTier.value),
		source: { appearance: appearanceTier.source, finish: finishTier.source }
	};
}

/**
 * Stamp the resolved axes on a document root. Static CSS keyed by these
 * attributes does the rest — nothing here writes a style attribute (§5.4).
 * The legacy `dark` class rides along until every consumer's stylesheet keys
 * on the attribute alone; pass `legacyClass: false` once it does.
 *
 * @param {{ dataset: DOMStringMap, classList: DOMTokenList } | null | undefined} root
 * @param {{ appearance: Appearance, finish: Finish }} resolved
 * @param {{ legacyClass?: boolean }} [options]
 */
export function applyDesign(root, resolved, { legacyClass = true } = {}) {
	if (!root) return;
	const appearance = isAppearance(resolved.appearance) ? resolved.appearance : 'light';
	const finish = isFinish(resolved.finish) ? resolved.finish : DEFAULT_FINISH;
	root.dataset.appearance = appearance;
	root.dataset.finish = finish;
	if (legacyClass) {
		root.classList.toggle('dark', appearance === 'dark');
		root.classList.toggle('light', appearance === 'light');
	}
}

/**
 * The pre-paint bootstrap for a product's app.html: a self-contained script
 * body (no `<script>` tags, no imports) that applies the synchronous tiers —
 * host URL parameters, the device's stored choice, the baseline — before
 * first paint, so a stored dark choice never flashes light. The account tier
 * is asynchronous and belongs to the product's post-mount code, which then
 * calls `applyDesign` with `resolveDesignAxes`. The finish list is inlined
 * from the contract, so the script cannot drift from it.
 *
 * @param {{
 *   keys?: { appearance: string, finish: string },
 *   defaults?: { appearance?: AppearancePreference, finish?: Finish },
 *   hostParams?: boolean,
 *   legacyClass?: boolean
 * }} [options]
 * @returns {string}
 */
export function designBootstrapScript({
	keys = DESIGN_STORAGE_KEYS,
	defaults = {},
	hostParams = true,
	legacyClass = true
} = {}) {
	const defaultAppearance = isAppearancePreference(defaults.appearance)
		? defaults.appearance
		: BASELINE_DESIGN.appearance;
	const defaultFinish = isFinish(defaults.finish) ? defaults.finish : DEFAULT_FINISH;
	const json = (value) => JSON.stringify(value);
	return [
		'(function () {',
		'  try {',
		`    var finishes = ${json([...FINISHES])};`,
		`    var appearances = ["system", "light", "dark"];`,
		`    var root = document.documentElement;`,
		`    var params = ${hostParams ? 'new URLSearchParams(window.location.search)' : 'null'};`,
		`    var hostAppearance = params ? (params.get("appearance") || params.get("theme")) : null;`,
		`    var hostFinish = params ? params.get("finish") : null;`,
		`    var stored = null;`,
		`    var storedFinish = null;`,
		`    try { stored = localStorage.getItem(${json(keys.appearance)}); storedFinish = localStorage.getItem(${json(keys.finish)}); } catch (e) {}`,
		`    var preference = hostAppearance === "light" || hostAppearance === "dark" ? hostAppearance : appearances.indexOf(stored) >= 0 ? stored : ${json(defaultAppearance)};`,
		`    var dark = preference === "system" ? matchMedia("(prefers-color-scheme: dark)").matches : preference === "dark";`,
		`    var finish = finishes.indexOf(hostFinish) >= 0 ? hostFinish : finishes.indexOf(storedFinish) >= 0 ? storedFinish : ${json(defaultFinish)};`,
		`    root.setAttribute("data-appearance", dark ? "dark" : "light");`,
		`    root.setAttribute("data-finish", finish);`,
		legacyClass ? `    root.classList.toggle("dark", dark); root.classList.toggle("light", !dark);` : '',
		'  } catch (e) {',
		'    /* Keep the server-rendered attributes. */',
		'  }',
		'})();'
	]
		.filter((line) => line !== '')
		.join('\n');
}

/**
 * @template T
 * @param {Array<[ 'host' | 'device' | 'account' | 'baseline', unknown, (value: unknown) => value is T ]>} tiers
 * @returns {{ source: 'host' | 'device' | 'account' | 'baseline', value: T }}
 */
function pick(tiers) {
	for (const [source, value, valid] of tiers) {
		if (valid(value)) return { source, value };
	}
	// The baseline tier is always valid; this line is unreachable by construction.
	throw new Error('design runtime: no valid tier');
}
