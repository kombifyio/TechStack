export type StackIdentityCatalogVersion = "1";
export type CharacterCategory = "playful" | "futuristic";
export type IconStyleId = "filled" | "glass" | "gradient" | "outlined";
export type Appearance = "light" | "dark";
export type MotionPreference = "full" | "reduced";
export type Direction = "ltr" | "rtl";
export type Layout = "wide" | "narrow";
export type CompanionAppearanceRole = "default" | "explicit_choice";

export interface CatalogCharacter {
  readonly id: string;
  readonly label_id: string;
  readonly label: string;
  readonly category: CharacterCategory;
  readonly emoji?: string;
  readonly svg_path?: string;
  readonly matching_animation: string;
  readonly matching_glow: string;
}

export interface CatalogAnimation {
  readonly id: string;
  readonly label_id: string;
  readonly character_id: string;
}

export interface CatalogIconStyle {
  readonly id: IconStyleId;
  readonly label_id: string;
  readonly label: string;
}

export interface CatalogGlowPreset {
  readonly id: string;
  readonly label_id: string;
  readonly label: string;
  readonly color: string;
}

export interface CompanionAppearance {
  readonly id: "kubi" | "spark";
  readonly label_id: string;
  readonly label: string;
  readonly role: CompanionAppearanceRole;
  readonly provenance: "companion_launcher";
}

export interface StackIdentitySnapshot {
  readonly version: "stack_identity.v1";
  readonly character_id: string;
  readonly animation_style: string;
  readonly animation_enabled: boolean;
  readonly icon_style: IconStyleId;
  readonly glow_color_override: string | null;
}

export interface StackIdentityRenderFixture {
  readonly id: string;
  readonly kind: "positive" | "negative";
  readonly appearance: Appearance;
  readonly motion: MotionPreference;
  readonly direction: Direction;
  readonly layout: Layout;
  readonly identity: StackIdentitySnapshot;
  readonly badge_ids?: readonly string[];
  readonly effect_ids?: readonly string[];
  readonly reason?: string;
}

export interface StackIdentityCatalog {
  readonly version: StackIdentityCatalogVersion;
  readonly characters: readonly CatalogCharacter[];
  readonly animations: readonly CatalogAnimation[];
  readonly icon_styles: readonly CatalogIconStyle[];
  readonly glow_presets: readonly CatalogGlowPreset[];
  readonly badges: readonly [];
  readonly effects: readonly [];
  readonly tokens: typeof STACK_IDENTITY_TOKENS;
  readonly companion_appearances: readonly CompanionAppearance[];
  readonly default_identity: typeof DEFAULT_IDENTITY;
}

export declare const STACK_IDENTITY_CATALOG_VERSION: StackIdentityCatalogVersion;
export declare const CHARACTERS: readonly CatalogCharacter[];
export declare const ANIMATIONS: readonly CatalogAnimation[];
export declare const ICON_STYLES: readonly CatalogIconStyle[];
export declare const GLOW_PRESETS: readonly CatalogGlowPreset[];
export declare const BADGES: readonly [];
export declare const EFFECTS: readonly [];
export declare const COMPANION_APPEARANCES: readonly CompanionAppearance[];
export declare const STACK_IDENTITY_TOKENS: {
  readonly color: { readonly glow: Readonly<Record<string, string>> };
  readonly motion: { readonly reduced: "reduce"; readonly full: "full" };
  readonly size: { readonly icon: { readonly sm: string; readonly md: string; readonly lg: string } };
  readonly appearance: readonly Appearance[];
  readonly direction: readonly Direction[];
  readonly layout: readonly Layout[];
};
export declare const DEFAULT_IDENTITY: {
  readonly name: string;
  readonly character_id: string;
  readonly animation_style: string;
  readonly animation_enabled: boolean;
  readonly icon_style: IconStyleId;
  readonly glow_color_override: null;
};
export declare const STACK_IDENTITY_CATALOG: StackIdentityCatalog;
export declare const STACK_IDENTITY_RENDER_FIXTURES: readonly StackIdentityRenderFixture[];

export declare function getCharacter(id: string): CatalogCharacter | undefined;
export declare function getCharactersByCategory(category: CharacterCategory): CatalogCharacter[];
export declare function getAnimation(id: string): CatalogAnimation | undefined;
export declare function isCatalogId(id: unknown): boolean;
export declare function compatibleAnimation(characterId: string, animationId: string): boolean;
export declare function compatibleIconStyle(iconStyle: unknown): iconStyle is IconStyleId;
export declare function compatibleBadge(id: string): boolean;
export declare function compatibleEffect(id: string): boolean;
export declare function validateRenderFixture(fixture: StackIdentityRenderFixture): string[];

export interface UiCharacter {
  readonly id: string;
  readonly label: string;
  readonly category: CharacterCategory;
  readonly emoji?: string;
  readonly svgPath?: string;
  readonly matchingAnimation: string;
  readonly matchingGlow: string;
}

export declare const characters: readonly UiCharacter[];
export declare const glowColorPresets: readonly { id: string; label: string; color: string }[];
export declare const iconStyles: readonly { id: IconStyleId; label: string }[];
export declare const defaultIdentity: {
  name: string;
  characterId: string;
  animationStyle: string;
  savedAt: null;
  animationEnabled: boolean;
  iconStyle: IconStyleId;
  glowColorOverride: null;
};
export declare function toUiCharacter(character: CatalogCharacter): UiCharacter;
