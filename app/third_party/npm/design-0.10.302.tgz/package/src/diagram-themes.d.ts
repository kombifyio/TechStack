export type DiagramTint = "cloud" | "ai" | "sim" | "stackkits" | "techstack" | "umbrella";
export type DiagramMode = "light" | "dark";
export type D2ColorSlot = "n1" | "n2" | "n3" | "n4" | "n5" | "n6" | "n7"
  | "b1" | "b2" | "b3" | "b4" | "b5" | "b6" | "aa2" | "aa4" | "aa5" | "ab4" | "ab5";

export interface DiagramTheme {
  readonly mermaid: {
    readonly darkMode: boolean;
    readonly primaryColor: string;
    readonly primaryTextColor: string;
    readonly primaryBorderColor: string;
    readonly lineColor: string;
    readonly secondaryColor: string;
    readonly secondaryTextColor: string;
    readonly tertiaryColor: string;
    readonly tertiaryTextColor: string;
    readonly background: string;
    readonly mainBkg: string;
    readonly textColor: string;
    readonly fontFamily: string;
  };
  readonly d2: Readonly<Record<D2ColorSlot, string>>;
}

export declare const DIAGRAM_THEMES: {
  readonly schema_version: 1;
  readonly source: string;
  readonly source_sha256: string;
  readonly version: `sha256:${string}`;
  readonly themes: Readonly<Record<DiagramMode, Readonly<Record<DiagramTint, DiagramTheme>>>>;
};
