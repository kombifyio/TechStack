import type { Appearance, Finish } from './contract.js';
import type { AppearancePreference } from './preferences.js';

export interface DesignStorageKeys {
	appearance: string;
	finish: string;
}

export interface DeviceDesign {
	appearance: AppearancePreference | null;
	finish: Finish | null;
}

export interface HostDesignContext {
	appearance?: Appearance;
	finish?: Finish;
}

export type HostDesignMessage = HostDesignContext & { type: typeof HOST_DESIGN_MESSAGE_TYPE };

export type DesignTier = 'host' | 'device' | 'account' | 'baseline';

export interface ResolvedDesignAxes {
	appearance: Appearance;
	appearancePreference: AppearancePreference;
	finish: Finish;
	source: { appearance: DesignTier; finish: DesignTier };
}

export interface DesignBootstrapOptions {
	keys?: DesignStorageKeys;
	defaults?: { appearance?: AppearancePreference; finish?: Finish };
	hostParams?: boolean;
	legacyClass?: boolean;
}

export declare const DESIGN_STORAGE_KEYS: Readonly<DesignStorageKeys>;
export declare const HOST_DESIGN_MESSAGE_TYPE: 'kombify:design';

export declare function readDeviceDesign(
	storage: Pick<Storage, 'getItem'> | null | undefined,
	keys?: DesignStorageKeys
): DeviceDesign;
export declare function writeDeviceDesign(
	storage: Pick<Storage, 'setItem' | 'removeItem'> | null | undefined,
	choice: { appearance?: AppearancePreference | null; finish?: Finish | null },
	keys?: DesignStorageKeys
): void;
export declare function readHostDesignParams(
	search: string | URLSearchParams | null | undefined
): HostDesignContext;
export declare function hostDesignMessage(design: { appearance?: unknown; finish?: unknown }): HostDesignMessage;
export declare function isHostDesignMessage(data: unknown): data is HostDesignMessage;
export declare function resolveDesignAxes(input?: {
	host?: { appearance?: Appearance | null; finish?: Finish | null } | null;
	device?: { appearance?: AppearancePreference | null; finish?: Finish | null } | null;
	account?: { appearance?: AppearancePreference | null; finish?: Finish | null } | null;
	prefersDark?: boolean;
}): ResolvedDesignAxes;
export declare function applyDesign(
	root: { dataset: DOMStringMap; classList: DOMTokenList } | null | undefined,
	resolved: { appearance: Appearance; finish: Finish },
	options?: { legacyClass?: boolean }
): void;
export declare function designBootstrapScript(options?: DesignBootstrapOptions): string;
