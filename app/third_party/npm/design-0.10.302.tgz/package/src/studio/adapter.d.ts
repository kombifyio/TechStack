import type { StudioDraft, StudioKeySpecs } from './keys.js';

/**
 * Why an account write did not land. `conflict` is the ETag/If-Match 412 the
 * settings document answers with when another surface wrote first; the
 * canvas re-reads the baseline and keeps the draft. `unauthorized` and
 * `unavailable` are surfaced as notices; nothing is retried automatically.
 */
export type StudioWriteFailure = 'conflict' | 'unauthorized' | 'unavailable';
export type StudioWriteResult = { ok: true } | { ok: false; reason: StudioWriteFailure };

/**
 * What a product plugs into the canvas. The adapter owns the two storage
 * tiers and knows nothing about tiles or stages; the canvas owns the draft
 * and knows nothing about localStorage keys or HTTP.
 *
 * `readAccount` may be synchronous (a cached settings document) or a promise;
 * `writeAccount` receives ONLY the changed account keys, in one call, so the
 * changes travel together or not at all.
 */
export interface StudioAdapter {
	readonly keys: StudioKeySpecs;
	readDevice(): StudioDraft;
	writeDevice(patch: StudioDraft): void;
	readAccount(): StudioDraft | Promise<StudioDraft>;
	writeAccount(patch: StudioDraft): Promise<StudioWriteResult>;
}
