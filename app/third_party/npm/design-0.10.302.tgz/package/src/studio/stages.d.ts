import type { StudioDraft, StudioKey } from './keys.js';

export type StageId = 'workbench' | 'panel' | 'dashboard';

export interface StageSpec {
	/** Pointer anchor ids the stage carries; a tile points at one by `data-tile`. */
	readonly spots: readonly string[];
	/** Draft keys the stage reacts to. */
	readonly keys: readonly StudioKey[];
}

export type StageLabelKey =
	| 'frameTitle'
	| 'panelTitle'
	| 'dashboardTitle'
	| 'anyPage'
	| 'companion'
	| 'greeting'
	| 'greetingBody'
	| 'chip1'
	| 'chip2'
	| 'chip3'
	| 'placeholder'
	| 'placeholderClassic'
	| 'foot'
	| 'sessions'
	| 'you'
	| 'sampleQuestion'
	| 'sampleAnswer'
	| 'bullet1'
	| 'bullet2'
	| 'navHome'
	| 'navWorkbench'
	| 'navAgentops'
	| 'navDesign'
	| 'navOverview'
	| 'navTools'
	| 'navSettings'
	| 'cardOne'
	| 'cardTwo'
	| 'cardThree'
	| 'cardMetric';

export type StageLabels = Record<StageLabelKey, string>;

export declare const STAGES: Readonly<Record<StageId, StageSpec>>;
export declare const STAGE_LABEL_KEYS: readonly StageLabelKey[];
export declare function defaultStageLabels(): StageLabels;
export declare function buildStage(id: StageId, labels?: StageLabels): HTMLElement;
export declare function updateStage(stage: HTMLElement, draft: StudioDraft, options?: { prefersDark?: boolean }): void;
