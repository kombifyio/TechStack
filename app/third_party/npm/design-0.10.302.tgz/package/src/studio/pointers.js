/**
 * Pointer leads from a tile to the spot it changes — measured, never
 * authored. Tiles are placed by CSS slots and the stage scales with the
 * page, so authored coordinates would be right at exactly one width.
 *
 * Framework-neutral: `measureStagePointers` is a pure function of the DOM
 * it is handed; `observeStagePointers` is the scheduling around it (one
 * animation frame per burst, re-measured on resize). A Svelte or React view
 * calls one or the other and draws the returned curves.
 */

function centre(rect, origin) {
  return { x: rect.left + rect.width / 2 - origin.left, y: rect.top + rect.height / 2 - origin.top };
}

/**
 * The curve from the tile's nearest edge to the spot, in stage pixels.
 * Exported on its own so the geometry can be pinned without a DOM.
 */
export function pointerCurve(tileRect, spotRect, origin) {
  const { x, y } = centre(spotRect, origin);
  const t = tileRect;
  const edges = [
    { ax: t.right - origin.left, ay: t.top + t.height / 2 - origin.top, dx: 1, dy: 0 },
    { ax: t.left - origin.left, ay: t.top + t.height / 2 - origin.top, dx: -1, dy: 0 },
    { ax: t.left + t.width / 2 - origin.left, ay: t.top - origin.top, dx: 0, dy: -1 },
    { ax: t.left + t.width / 2 - origin.left, ay: t.bottom - origin.top, dx: 0, dy: 1 },
  ];
  const edge = edges.reduce((best, candidate) =>
    Math.hypot(candidate.ax - x, candidate.ay - y) < Math.hypot(best.ax - x, best.ay - y) ? candidate : best,
  );
  const reach = Math.max(40, Math.hypot(x - edge.ax, y - edge.ay) / 2);
  const c1x = edge.ax + edge.dx * reach;
  const c1y = edge.ay + edge.dy * reach;
  const c2x = edge.dx !== 0 ? x - edge.dx * reach : x;
  const c2y = edge.dy !== 0 ? y - edge.dy * reach : y;
  return { x, y, d: `M${edge.ax} ${edge.ay} C ${c1x} ${c1y}, ${c2x} ${c2y}, ${x} ${y}` };
}

/**
 * One pointer per id that has both a `[data-tile]` and a visible
 * `[data-spot]` inside `root`. A spot inside a hidden element (the launcher
 * while the panel is docked) reports a zero rect at the document origin and
 * the line would shoot across the page to nothing, so it is skipped.
 */
export function measureStagePointers(root, ids) {
  if (!root) return [];
  const origin = root.getBoundingClientRect();
  const pointers = [];
  for (const id of ids) {
    const tile = root.querySelector(`[data-tile="${id}"]`);
    const spot = root.querySelector(`[data-spot="${id}"]`);
    if (!tile || !spot || spot.hidden || spot.offsetParent === null) continue;
    pointers.push({ id, ...pointerCurve(tile.getBoundingClientRect(), spot.getBoundingClientRect(), origin) });
  }
  return pointers;
}

/**
 * Keeps `onChange` fed with fresh pointers: once now, then on every resize of
 * the stage or the window, and whenever the view calls `schedule()` (after a
 * draft change moved a spot). Coalesced to one measurement per frame.
 */
export function observeStagePointers(root, ids, onChange) {
  let frame = 0;
  const measure = () => {
    frame = 0;
    onChange(measureStagePointers(root, ids));
  };
  const schedule = () => {
    if (!frame) frame = requestAnimationFrame(measure);
  };
  schedule();
  const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(schedule);
  observer?.observe(root);
  window.addEventListener("resize", schedule);
  return {
    schedule,
    dispose() {
      if (frame) cancelAnimationFrame(frame);
      observer?.disconnect();
      window.removeEventListener("resize", schedule);
    },
  };
}
