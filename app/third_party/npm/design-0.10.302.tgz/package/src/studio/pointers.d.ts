export interface StagePointer {
	id: string;
	/** SVG path from the tile's nearest edge to the spot, in stage pixels. */
	d: string;
	x: number;
	y: number;
}

export interface PointerRect {
	left: number;
	top: number;
	right: number;
	bottom: number;
	width: number;
	height: number;
}

export declare function pointerCurve(
	tileRect: PointerRect,
	spotRect: PointerRect,
	origin: { left: number; top: number }
): Omit<StagePointer, 'id'>;
export declare function measureStagePointers(root: Element | null | undefined, ids: readonly string[]): StagePointer[];
export declare function observeStagePointers(
	root: Element,
	ids: readonly string[],
	onChange: (pointers: StagePointer[]) => void
): { schedule(): void; dispose(): void };
