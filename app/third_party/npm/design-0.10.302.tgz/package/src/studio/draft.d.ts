import type { StudioAdapter, StudioWriteFailure } from './adapter.js';
import type { StudioDraft, StudioKey, StudioKeySpecs } from './keys.js';

export type StudioApplyResult =
	| { ok: true; changed: StudioKey[] }
	| { ok: false; reason: StudioWriteFailure; changed: StudioKey[] };

export declare function studioBaseline(adapter: StudioAdapter): Promise<StudioDraft>;
export declare function studioChanges(specs: StudioKeySpecs, base: StudioDraft, draft: StudioDraft): StudioKey[];
export declare function rebaseDraft(
	specs: StudioKeySpecs,
	previousBase: StudioDraft,
	nextBase: StudioDraft,
	draft: StudioDraft
): StudioDraft;
export declare function applyStudioDraft(
	adapter: StudioAdapter,
	base: StudioDraft,
	draft: StudioDraft
): Promise<StudioApplyResult>;
