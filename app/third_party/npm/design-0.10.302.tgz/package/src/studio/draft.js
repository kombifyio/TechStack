/**
 * The Design Studio draft: what the stage shows, against what is applied.
 *
 * Pure. The view (Svelte or React) owns the draft state; this module reads
 * the baseline through the adapter, diffs, rebases, and turns an accepted
 * draft into the exact writes the adapter knows how to make — device keys
 * first, then every changed account key in ONE `writeAccount` call, because
 * the settings document is replaced whole on save and the account changes
 * must travel together or not at all.
 */
import { isStudioValue } from "./keys.js";

function keysOf(adapter) {
  return Object.keys(adapter.keys);
}

/**
 * What is applied right now, one closed value per declared key. Device reads
 * win over account reads (the device is the override tier); a value the
 * vocabulary does not know falls back to the key's first value, so a stale
 * or tampered store can never put an unknown value on a stage.
 */
export async function studioBaseline(adapter) {
  const account = (await adapter.readAccount()) ?? {};
  const device = adapter.readDevice() ?? {};
  const base = {};
  for (const key of keysOf(adapter)) {
    const spec = adapter.keys[key];
    const candidate = device[key] ?? account[key];
    base[key] = isStudioValue(adapter.keys, key, candidate) ? candidate : spec.values[0];
  }
  return base;
}

/** Every key whose draft value differs from the baseline and is a closed value. */
export function studioChanges(specs, base, draft) {
  const changed = [];
  for (const key of Object.keys(specs)) {
    if (base[key] === draft[key]) continue;
    if (!isStudioValue(specs, key, draft[key])) continue;
    changed.push(key);
  }
  return changed;
}

/**
 * A save elsewhere (or our own Apply) moves the baseline. Keys the user has
 * not touched follow the new baseline; keys the user changed keep the draft.
 */
export function rebaseDraft(specs, previousBase, nextBase, draft) {
  const next = {};
  for (const key of Object.keys(specs)) {
    const touched = draft[key] !== undefined && draft[key] !== previousBase[key];
    next[key] = touched ? draft[key] : nextBase[key];
  }
  return next;
}

/**
 * Writes an accepted draft through the adapter and reports what happened.
 * Nothing is written when nothing changed; device keys go first and never
 * depend on the account write; the account write is one call with only the
 * changed account keys.
 */
export async function applyStudioDraft(adapter, base, draft) {
  const changed = studioChanges(adapter.keys, base, draft);
  if (changed.length === 0) return { ok: true, changed };
  const devicePatch = {};
  const accountPatch = {};
  for (const key of changed) {
    const target = adapter.keys[key].tier === "device" ? devicePatch : accountPatch;
    target[key] = draft[key];
  }
  if (Object.keys(devicePatch).length > 0) adapter.writeDevice(devicePatch);
  if (Object.keys(accountPatch).length === 0) return { ok: true, changed };
  const result = await adapter.writeAccount(accountPatch);
  return result.ok ? { ok: true, changed } : { ok: false, reason: result.reason, changed };
}
