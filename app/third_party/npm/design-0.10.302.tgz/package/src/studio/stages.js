/**
 * The stages — what the Design Studio draws in the middle of the canvas.
 *
 * Deliberately NOT the running application and not an iframe of it. A frame
 * of the live app shows what is SAVED, navigates away from its own preview
 * parameters, and cannot represent a draft; mounting the real Companion cost
 * a Gateway request per change (owner direction 2026-08-21, Companion
 * Studio). Each stage is a reduced shell built once from plain DOM and then
 * re-stamped with the draft's axes as data attributes, so the package's own
 * palette, material and role recipes paint it — a stage never authors a
 * material value and never writes an inline style from a runtime value
 * (KOMBIFY-DESIGN-SYSTEM-STANDARD §5.4, §6).
 *
 * Every pointer anchor is a real element inside the markup (`data-spot`), so
 * a lead always lands on the thing it names even when the stage reflows.
 *
 * Three stages, one per surface family:
 *   workbench  — the Companion Studio shell (rail, sessions, a thread, composer)
 *   panel      — the floating Companion panel and its launcher on any page
 *   dashboard  — a product dashboard (rail, header, cards) with the launcher;
 *                kombify Cloud and Techstack stand here
 */

export const STAGES = Object.freeze({
  workbench: Object.freeze({
    spots: Object.freeze(["appearance", "finish", "chatStyle", "composerStyle", "aura", "density"]),
    keys: Object.freeze(["appearance", "finish", "aura", "chatStyle", "composerStyle", "density"]),
  }),
  panel: Object.freeze({
    spots: Object.freeze(["panelFinish", "panelTheme", "composerStyle", "launcher", "density", "aura"]),
    keys: Object.freeze([
      "panelFinish",
      "panelTheme",
      "aura",
      "composerStyle",
      "density",
      "launcher.position",
      "launcher.size",
      "launcher.tracer",
    ]),
  }),
  dashboard: Object.freeze({
    spots: Object.freeze(["appearance", "finish", "systemCardShape", "companion", "launcher"]),
    keys: Object.freeze(["appearance", "finish", "systemCardShape", "launcher.position", "launcher.size", "launcher.tracer"]),
  }),
});

/** Every text a stage shows, by label key. Consumers pass localized values. */
export const STAGE_LABEL_KEYS = Object.freeze([
  "frameTitle",
  "panelTitle",
  "dashboardTitle",
  "anyPage",
  "companion",
  "greeting",
  "greetingBody",
  "chip1",
  "chip2",
  "chip3",
  "placeholder",
  "placeholderClassic",
  "foot",
  "sessions",
  "you",
  "sampleQuestion",
  "sampleAnswer",
  "bullet1",
  "bullet2",
  "navHome",
  "navWorkbench",
  "navAgentops",
  "navDesign",
  "navOverview",
  "navTools",
  "navSettings",
  "cardOne",
  "cardTwo",
  "cardThree",
  "cardMetric",
]);

/** English defaults for the lab and for tests; a product supplies message ids. */
export function defaultStageLabels() {
  return {
    frameTitle: "The Companion Studio, as the draft would show it",
    panelTitle: "The Companion panel, as the draft would show it",
    dashboardTitle: "Your dashboard, as the draft would show it",
    anyPage: "any page",
    companion: "Companion",
    greeting: "Hi, what are we working on?",
    greetingBody: "Ask, paste, or pick a starting point.",
    chip1: "Summarise this page",
    chip2: "Draft a reply",
    chip3: "What changed?",
    placeholder: "Ask anything…",
    placeholderClassic: "Type a message",
    foot: "Answers can be wrong. Check what matters.",
    sessions: "Sessions",
    you: "You",
    sampleQuestion: "Which factories ran overnight?",
    sampleAnswer: "Three ran; one is waiting for your approval.",
    bullet1: "Mail Office finished the inbox sweep",
    bullet2: "Server Office needs a yes on the reboot",
    navHome: "Home",
    navWorkbench: "Workbench",
    navAgentops: "AgentOps",
    navDesign: "Design",
    navOverview: "Overview",
    navTools: "Tools",
    navSettings: "Settings",
    cardOne: "postgres-main",
    cardTwo: "grafana",
    cardThree: "vaultwarden",
    cardMetric: "healthy",
  };
}

const SESSIONS = Object.freeze([
  { title: "Which factories ran overnight?", meta: "AI · 2 min" },
  { title: "Staging preview for the pricing page", meta: "Cloud · 18 min" },
  { title: "Rotate the Render DB credentials", meta: "Techstack · 1 h" },
  { title: "Postgres kit: PG 18 variant", meta: "StackKits · 3 h" },
  { title: "Load test for the checkout flow", meta: "Sim · yesterday" },
]);

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [name, value] of Object.entries(attrs)) {
    if (value === undefined || value === null || value === false) continue;
    node.setAttribute(name, value === true ? "" : String(value));
  }
  for (const child of children) {
    if (child === null || child === undefined) continue;
    node.append(typeof child === "string" ? document.createTextNode(child) : child);
  }
  return node;
}

const spot = (id) => el("span", { class: "kx-stage-spot", "data-spot": id, "aria-hidden": "true" });
const glyph = (cls = "") => el("i", { class: cls || undefined, "aria-hidden": "true" });

function mascot() {
  // A stand-in silhouette, not the mascot: the stage answers "where does the
  // launcher sit and how big is it", never "what does Kubi look like" — that
  // is Kubi Lab's question.
  return el("span", { class: "kx-stage-mascot", "aria-hidden": "true" }, [
    el("span", { class: "ear left" }),
    el("span", { class: "ear right" }),
    el("span", { class: "body" }, [el("span", { class: "eye left" }), el("span", { class: "eye right" })]),
  ]);
}

function bubble() {
  return el("div", { class: "kx-stage-bubble", "aria-hidden": "true" }, [spot("launcher"), mascot()]);
}

function composer(labels, withAura) {
  return el("div", { class: "kx-stage-composer", "data-kx": "composer" }, [
    withAura ? spot("aura") : null,
    el("div", { class: "field" }, [
      el("span", { class: "text-morph" }, [labels.placeholder]),
      el("span", { class: "text-classic" }, [labels.placeholderClassic]),
    ]),
    el("div", { class: "ctl" }, [
      spot("composerStyle"),
      glyph("rb plus"),
      el("span", { class: "pill" }, ["Auto"]),
      glyph("rb think on"),
      glyph("rb web"),
      el("span", { class: "sp" }),
      glyph("send"),
    ]),
  ]);
}

function workbenchStage(labels) {
  const skin = el("div", { class: "kx-stage", "data-stage": "workbench", role: "img", "aria-label": labels.frameTitle });
  const rail = el("div", { class: "rail", "data-kx": "navigation" }, [
    el("div", { class: "brand" }, [
      spot("appearance"),
      el("span", { class: "mark" }),
      el("div", {}, [el("b", {}, ["kombify"]), el("span", {}, ["AI"])]),
    ]),
    el("div", { class: "nav", "data-kx": "control" }, [glyph(), labels.navHome]),
    el("div", { class: "nav", "data-kx": "control selection" }, [spot("finish"), glyph(), labels.navWorkbench, el("span", { class: "count" }, ["3"])]),
    el("div", { class: "nav", "data-kx": "control" }, [glyph(), labels.navAgentops, el("span", { class: "count" }, ["5"])]),
    el("div", { class: "nav", "data-kx": "control" }, [glyph(), labels.navDesign]),
    el("div", { class: "foot" }, [
      el("div", { class: "user" }, [el("span", { class: "av" }, ["M"]), el("div", {}, [el("b", {}, ["Marcel"]), el("small", {}, ["Owner"])])]),
    ]),
  ]);
  const inbox = el("div", { class: "inbox" }, [
    el("div", { class: "inboxhead" }, [el("span", {}, [labels.sessions]), el("span", { class: "newbtn" }, ["+"])]),
    el(
      "div",
      { class: "list" },
      SESSIONS.map((session, index) =>
        el("div", { class: "row", "data-kx": index === 0 ? "menu-item selection" : "menu-item" }, [
          index === 0 ? spot("density") : null,
          el("b", {}, [session.title]),
          el("small", {}, [glyph("dot"), session.meta]),
        ]),
      ),
    ),
  ]);
  const chat = el("div", { class: "chat" }, [
    el("div", { class: "chathead" }, [el("b", {}, [SESSIONS[0].title]), el("span", {}, [SESSIONS[0].meta])]),
    el("div", { class: "body" }, [
      spot("chatStyle"),
      el("div", { class: "msg user" }, [el("span", { class: "who" }, [labels.you]), el("p", {}, [labels.sampleQuestion])]),
      el("div", { class: "msg ai" }, [
        el("span", { class: "who" }, ["kombify AI"]),
        el("p", {}, [labels.sampleAnswer]),
        el("ul", {}, [el("li", {}, [labels.bullet1]), el("li", {}, [labels.bullet2])]),
      ]),
    ]),
    composer(labels, true),
  ]);
  skin.append(rail, inbox, chat);
  return skin;
}

function panelStage(labels) {
  const skin = el("div", { class: "kx-stage", "data-stage": "panel", role: "img", "aria-label": labels.panelTitle });
  skin.append(
    el("span", { class: "pagelabel" }, [labels.anyPage]),
    el("div", { class: "panel", "data-kx": "plate" }, [
      el("div", { class: "khead" }, [
        spot("panelTheme"),
        el("span", { class: "kmark" }),
        el("span", { class: "ktitle" }, [el("b", {}, ["kombify AI"]), el("small", {}, [labels.companion])]),
        el("span", { class: "kacts" }, [el("span"), el("span")]),
      ]),
      el("div", { class: "kbody" }, [
        spot("panelFinish"),
        el("div", { class: "kgreet" }, [el("b", {}, [labels.greeting]), labels.greetingBody]),
        el("div", { class: "kchips" }, [
          el("span", { "data-kx": "control" }, [spot("density"), labels.chip1]),
          el("span", { "data-kx": "control" }, [labels.chip2]),
          el("span", { "data-kx": "control" }, [labels.chip3]),
        ]),
      ]),
      composer(labels, true),
      el("div", { class: "kfoot" }, [labels.foot]),
    ]),
    bubble(),
  );
  return skin;
}

function dashboardStage(labels) {
  // A product dashboard with the Companion as a user meets it: the launcher in
  // its corner and the panel open above it. Closed and open state are one
  // thing, so they are shown together rather than on two stages.
  const skin = el("div", { class: "kx-stage", "data-stage": "dashboard", role: "img", "aria-label": labels.dashboardTitle });
  const rail = el("div", { class: "rail", "data-kx": "navigation" }, [
    el("div", { class: "brand" }, [el("span", { class: "mark" }), el("div", {}, [el("b", {}, ["kombify"]), el("span", {}, ["Cloud"])])]),
    el("div", { class: "nav", "data-kx": "control selection" }, [spot("finish"), glyph(), labels.navOverview]),
    el("div", { class: "nav", "data-kx": "control" }, [glyph(), labels.navTools]),
    el("div", { class: "nav", "data-kx": "control" }, [glyph(), labels.navSettings]),
  ]);
  const card = (title, anchor) =>
    el("div", { class: "card", "data-kx": "plate" }, [
      anchor ? spot("systemCardShape") : null,
      el("span", { class: "led" }),
      el("b", {}, [title]),
      el("small", {}, [labels.cardMetric]),
      el("span", { class: "meter" }, [el("i", { class: "fill" })]),
    ]);
  const panel = el("div", { class: "panel panel--docked", "data-kx": "plate" }, [
    el("div", { class: "khead" }, [
      spot("companion"),
      el("span", { class: "kmark" }),
      el("span", { class: "ktitle" }, [el("b", {}, ["kombify AI"]), el("small", {}, [labels.companion])]),
    ]),
    el("div", { class: "kbody" }, [el("div", { class: "kgreet" }, [el("b", {}, [labels.greeting]), labels.greetingBody])]),
    composer(labels, false),
  ]);
  const main = el("div", { class: "main" }, [
    el("div", { class: "header", "data-kx": "header" }, [spot("appearance"), el("b", {}, [labels.navOverview]), el("span", { class: "av" }, ["M"])]),
    el("div", { class: "cards" }, [card(labels.cardOne, false), card(labels.cardTwo, false), card(labels.cardThree, true)]),
    panel,
    bubble(),
  ]);
  skin.append(rail, main);
  return skin;
}

/** Builds the stage DOM once. Text comes from `labels`; the draft comes later. */
export function buildStage(id, labels = defaultStageLabels()) {
  switch (id) {
    case "workbench":
      return workbenchStage(labels);
    case "panel":
      return panelStage(labels);
    case "dashboard":
      return dashboardStage(labels);
    default:
      throw new Error(`Unknown stage: ${String(id)}`);
  }
}

function resolveAppearance(value, prefersDark) {
  if (value === "light" || value === "dark") return value;
  return prefersDark ? "dark" : "light";
}

/**
 * Re-stamps a built stage with the draft. Attributes only — the recipes do
 * the painting. Keys the stage does not carry are ignored, so one draft can
 * feed every stage.
 */
export function updateStage(stage, draft, options = {}) {
  const prefersDark = Boolean(options.prefersDark);
  const id = stage.getAttribute("data-stage");
  const panel = id === "panel";
  // The panel has its own pair only where a product edits it separately
  // (the Companion Studio). Everywhere else — and while the panel theme
  // follows the host — the panel wears the account's one design.
  const panelTheme = draft.panelTheme === "light" || draft.panelTheme === "dark" ? draft.panelTheme : undefined;
  const appearanceKey = panel ? (panelTheme ?? draft.appearance) : draft.appearance;
  const finishKey = panel ? (draft.panelFinish ?? draft.finish) : draft.finish;
  const stamps = {
    "data-appearance": resolveAppearance(appearanceKey, prefersDark),
    "data-finish": finishKey ?? "kombify",
    "data-aura": draft.aura ?? "soft",
    "data-layout": draft.chatStyle ?? "document",
    "data-composer": draft.composerStyle ?? "morph",
    "data-density": draft.density ?? "comfortable",
    "data-pos": draft["launcher.position"] ?? "bottom-right",
    "data-launcher-size": draft["launcher.size"] ?? "medium",
    "data-launcher-tracer": draft["launcher.tracer"] ?? "off",
    "data-system-card-shape": draft.systemCardShape ?? "square",
    "data-design-scope": "",
  };
  for (const [name, value] of Object.entries(stamps)) stage.setAttribute(name, value);
}
