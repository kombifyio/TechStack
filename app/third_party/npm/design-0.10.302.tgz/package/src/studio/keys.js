/**
 * The Design Studio vocabulary — every key a canvas tile may edit, the closed
 * set of values each accepts, and which storage tier it belongs to.
 *
 * The canvas promises one thing above all: nothing is written until Apply,
 * and only closed values are ever written (KOMBIFY-DESIGN-SYSTEM-STANDARD
 * §5.1, §5.2). That promise is checkable only if the vocabulary is data, so
 * it lives here as data and every view — Svelte in kombify Cloud, React in
 * the Companion Studio — reads it rather than restating it.
 *
 * Tiers (DESIGN-AXIS-STANDARD §3): a DEVICE key is the machine in front of
 * you (local storage, stamped on the document root); an ACCOUNT key is the
 * account default that reaches every product through `/v1/ai/settings`. A
 * product adapter may re-tier a key for its own surface — kombify Cloud
 * writes `appearance` and `finish` as the account default, the Companion
 * Studio keeps them on the device — but it may never widen a value list.
 */
import { FINISHES } from "../contract.js";

export const STUDIO_KEYS = Object.freeze({
  appearance: Object.freeze(["light", "dark", "system"]),
  finish: FINISHES,
  aura: Object.freeze(["soft", "neon", "inset"]),
  systemCardShape: Object.freeze(["square", "app"]),
  chatStyle: Object.freeze(["document", "messenger"]),
  composerStyle: Object.freeze(["morph", "classic"]),
  density: Object.freeze(["comfortable", "compact"]),
  panelTheme: Object.freeze(["follow-host", "light", "dark"]),
  panelFinish: FINISHES,
  "launcher.position": Object.freeze(["bottom-right", "bottom-left"]),
  "launcher.size": Object.freeze(["small", "medium", "large"]),
  "launcher.tracer": Object.freeze(["off", "halo", "comet", "helix"]),
});

export const STUDIO_TIER = Object.freeze({
  appearance: "device",
  finish: "device",
  aura: "device",
  systemCardShape: "device",
  chatStyle: "account",
  composerStyle: "account",
  density: "account",
  panelTheme: "account",
  panelFinish: "account",
  "launcher.position": "account",
  "launcher.size": "account",
  "launcher.tracer": "account",
});

/**
 * Launcher geometry per size — the fact the stage needs to draw the
 * Companion bubble at the size the account chose. Restated from the host
 * SDK (`@kombify/embed` COMPANION_LAUNCHER_METRICS) so Brand publishes the
 * fact and both the SDK and the stages consume it.
 */
export const LAUNCHER_METRICS = Object.freeze({
  small: Object.freeze({ control: 48, mascot: 42 }),
  medium: Object.freeze({ control: 58, mascot: 50 }),
  large: Object.freeze({ control: 70, mascot: 60 }),
});

export function isStudioKey(key) {
  return typeof key === "string" && Object.prototype.hasOwnProperty.call(STUDIO_KEYS, key);
}

/**
 * Builds the key specs an adapter hands to the canvas: the closed value list
 * from the vocabulary plus the tier, with per-adapter tier overrides. An
 * unknown key throws — a product cannot invent an axis at an adapter
 * (DESIGN-AXIS-STANDARD §7: a new axis is introduced here, in the Studio).
 */
export function studioKeySpecs(keys, tiers = {}) {
  const specs = {};
  for (const key of keys) {
    if (!isStudioKey(key)) throw new Error(`Unknown studio key: ${String(key)}`);
    const tier = tiers[key] ?? STUDIO_TIER[key];
    if (tier !== "device" && tier !== "account") throw new Error(`Unknown studio tier for ${key}: ${String(tier)}`);
    specs[key] = Object.freeze({ tier, values: STUDIO_KEYS[key] });
  }
  return Object.freeze(specs);
}

/** True when `value` is one of the closed values `specs` allows for `key`. */
export function isStudioValue(specs, key, value) {
  const spec = specs[key];
  return Boolean(spec) && typeof value === "string" && spec.values.includes(value);
}
