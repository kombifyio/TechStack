import type { Finish } from '../contract.js';

export type StudioAppearance = 'light' | 'dark' | 'system';
export type StudioAura = 'soft' | 'neon' | 'inset';
export type StudioSystemCardShape = 'square' | 'app';
export type StudioChatStyle = 'document' | 'messenger';
export type StudioComposerStyle = 'morph' | 'classic';
export type StudioDensity = 'comfortable' | 'compact';
export type StudioPanelTheme = 'follow-host' | 'light' | 'dark';
export type StudioLauncherPosition = 'bottom-right' | 'bottom-left';
export type StudioLauncherSize = 'small' | 'medium' | 'large';
export type StudioLauncherTracer = 'off' | 'halo' | 'comet' | 'helix';

export interface StudioVocabulary {
	appearance: StudioAppearance;
	finish: Finish;
	aura: StudioAura;
	systemCardShape: StudioSystemCardShape;
	chatStyle: StudioChatStyle;
	composerStyle: StudioComposerStyle;
	density: StudioDensity;
	panelTheme: StudioPanelTheme;
	panelFinish: Finish;
	'launcher.position': StudioLauncherPosition;
	'launcher.size': StudioLauncherSize;
	'launcher.tracer': StudioLauncherTracer;
}

export type StudioKey = keyof StudioVocabulary;
export type StudioTier = 'device' | 'account';

/** A draft is flat: one closed string per key the adapter declared. */
export type StudioDraft = Partial<{ [K in StudioKey]: StudioVocabulary[K] }>;

export interface StudioKeySpec {
	readonly tier: StudioTier;
	readonly values: readonly string[];
}
export type StudioKeySpecs = Readonly<Partial<Record<StudioKey, StudioKeySpec>>>;

export interface LauncherMetrics {
	readonly control: number;
	readonly mascot: number;
}

export declare const STUDIO_KEYS: Readonly<{ [K in StudioKey]: readonly StudioVocabulary[K][] }>;
export declare const STUDIO_TIER: Readonly<Record<StudioKey, StudioTier>>;
export declare const LAUNCHER_METRICS: Readonly<Record<StudioLauncherSize, LauncherMetrics>>;

export declare function isStudioKey(key: unknown): key is StudioKey;
export declare function studioKeySpecs(
	keys: readonly StudioKey[],
	tiers?: Partial<Record<StudioKey, StudioTier>>
): StudioKeySpecs;
export declare function isStudioValue(specs: StudioKeySpecs, key: string, value: unknown): boolean;
