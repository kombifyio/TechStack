/**
 * `@kombiverselabs/design/studio` — the framework-neutral core of the Design
 * Studio: the closed key vocabulary, the draft model (baseline, diff, rebase,
 * apply through an adapter), measured pointer leads, and the drawn stages.
 * A Svelte view lives in `@kombiverselabs/ui/studio`; the React view in the
 * Companion Studio wraps the same core. Neither restates any of this.
 */
export { STUDIO_KEYS, STUDIO_TIER, LAUNCHER_METRICS, isStudioKey, isStudioValue, studioKeySpecs } from "./keys.js";
export { applyStudioDraft, rebaseDraft, studioBaseline, studioChanges } from "./draft.js";
export { measureStagePointers, observeStagePointers, pointerCurve } from "./pointers.js";
export { STAGES, STAGE_LABEL_KEYS, buildStage, defaultStageLabels, updateStage } from "./stages.js";
