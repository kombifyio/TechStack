/**
 * Framework-neutral Stack Identity catalog (platform-x645f.3).
 *
 * Brand publishes these facts. Product renderers consume them natively.
 * This module must not import a UI framework.
 */
export const STACK_IDENTITY_CATALOG_VERSION = "1";

const freeze = (value) => {
  if (Array.isArray(value)) return Object.freeze(value.map(freeze));
  if (value && typeof value === "object") {
    return Object.freeze(
      Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, freeze(entry)])),
    );
  }
  return value;
};

const idPattern = /^[a-z][a-z0-9._-]{0,127}$/;

export const CHARACTERS = freeze([
  { id: "rocket", label_id: "stack_identity.character.rocket", label: "Rocket", category: "playful", emoji: "\u{1F680}", matching_animation: "identity-float", matching_glow: "oklch(0.75 0.18 55)" },
  { id: "robot", label_id: "stack_identity.character.robot", label: "Robot", category: "playful", emoji: "\u{1F916}", matching_animation: "identity-glitch", matching_glow: "oklch(0.75 0.2 145)" },
  { id: "astronaut", label_id: "stack_identity.character.astronaut", label: "Astronaut", category: "playful", emoji: "\u{1F9D1}\u200D\u{1F680}", matching_animation: "identity-drift", matching_glow: "oklch(0.65 0.2 250)" },
  { id: "dragon", label_id: "stack_identity.character.dragon", label: "Dragon", category: "playful", emoji: "\u{1F409}", matching_animation: "identity-flame", matching_glow: "oklch(0.7 0.25 30)" },
  { id: "unicorn", label_id: "stack_identity.character.unicorn", label: "Unicorn", category: "playful", emoji: "\u{1F984}", matching_animation: "identity-rainbow", matching_glow: "oklch(0.75 0.2 320)" },
  { id: "phoenix", label_id: "stack_identity.character.phoenix", label: "Phoenix", category: "playful", emoji: "\u{1F985}", matching_animation: "identity-rise", matching_glow: "oklch(0.75 0.22 60)" },
  { id: "alien", label_id: "stack_identity.character.alien", label: "Alien", category: "playful", emoji: "\u{1F47E}", matching_animation: "identity-pulse", matching_glow: "oklch(0.7 0.25 145)" },
  { id: "ghost", label_id: "stack_identity.character.ghost", label: "Ghost", category: "playful", emoji: "\u{1F47B}", matching_animation: "identity-fade", matching_glow: "oklch(0.8 0.05 260)" },
  { id: "wizard", label_id: "stack_identity.character.wizard", label: "Wizard", category: "playful", emoji: "\u{1F9D9}", matching_animation: "identity-sparkle", matching_glow: "oklch(0.65 0.25 280)" },
  { id: "ninja", label_id: "stack_identity.character.ninja", label: "Ninja", category: "playful", emoji: "\u{1F977}", matching_animation: "identity-stealth", matching_glow: "oklch(0.5 0.05 0)" },
  { id: "satellite", label_id: "stack_identity.character.satellite", label: "Satellite", category: "futuristic", svg_path: "M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5", matching_animation: "identity-orbit", matching_glow: "oklch(0.7 0.18 200)" },
  { id: "hologram", label_id: "stack_identity.character.hologram", label: "Hologram", category: "futuristic", svg_path: "M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z", matching_animation: "identity-scanline", matching_glow: "oklch(0.7 0.15 180)" },
  { id: "circuit", label_id: "stack_identity.character.circuit", label: "Circuit", category: "futuristic", svg_path: "M9 3v2H5v4H3v6h2v4h4v2h6v-2h4v-4h2V9h-2V5h-4V3H9zm0 4h6v2h2v4h-2v2H9v-2H7V9h2V7z", matching_animation: "identity-trace", matching_glow: "oklch(0.65 0.22 230)" },
  { id: "nebula", label_id: "stack_identity.character.nebula", label: "Nebula", category: "futuristic", svg_path: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z", matching_animation: "identity-cosmic", matching_glow: "oklch(0.6 0.25 290)" },
  { id: "quantum", label_id: "stack_identity.character.quantum", label: "Quantum", category: "futuristic", svg_path: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 4c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zm0 12c-2.21 0-4-1.79-4-4h2c0 1.1.9 2 2 2s2-.9 2-2h2c0 2.21-1.79 4-4 4z", matching_animation: "identity-quantum", matching_glow: "oklch(0.7 0.2 170)" },
  { id: "cybershield", label_id: "stack_identity.character.cybershield", label: "Cybershield", category: "futuristic", svg_path: "M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 2.18l7 3.12v4.7c0 4.67-3.13 8.42-7 9.88-3.87-1.46-7-5.21-7-9.88V6.3l7-3.12zM12 7a2 2 0 100 4 2 2 0 000-4zm-1 6v4h2v-4h-1z", matching_animation: "identity-shield", matching_glow: "oklch(0.6 0.18 200)" },
]);

export const ANIMATIONS = freeze(
  CHARACTERS.map((character) => ({
    id: character.matching_animation,
    label_id: `stack_identity.animation.${character.matching_animation.replace(/^identity-/, "").replaceAll("-", "_")}`,
    character_id: character.id,
  })),
);

export const ICON_STYLES = freeze([
  { id: "filled", label_id: "stack_identity.icon_style.filled", label: "Filled" },
  { id: "glass", label_id: "stack_identity.icon_style.glass", label: "Glass" },
  { id: "gradient", label_id: "stack_identity.icon_style.gradient", label: "Gradient" },
  { id: "outlined", label_id: "stack_identity.icon_style.outlined", label: "Outlined" },
]);

export const GLOW_PRESETS = freeze([
  { id: "default", label_id: "stack_identity.glow.default", label: "Default", color: "" },
  { id: "ocean", label_id: "stack_identity.glow.ocean", label: "Ocean", color: "oklch(0.65 0.18 220)" },
  { id: "sunset", label_id: "stack_identity.glow.sunset", label: "Sunset", color: "oklch(0.7 0.22 35)" },
  { id: "forest", label_id: "stack_identity.glow.forest", label: "Forest", color: "oklch(0.6 0.2 145)" },
  { id: "violet", label_id: "stack_identity.glow.violet", label: "Violet", color: "oklch(0.6 0.25 290)" },
  { id: "ember", label_id: "stack_identity.glow.ember", label: "Ember", color: "oklch(0.65 0.25 25)" },
  { id: "mint", label_id: "stack_identity.glow.mint", label: "Mint", color: "oklch(0.75 0.15 170)" },
  { id: "rose", label_id: "stack_identity.glow.rose", label: "Rose", color: "oklch(0.7 0.18 350)" },
  { id: "neon", label_id: "stack_identity.glow.neon", label: "Neon", color: "oklch(0.8 0.2 130)" },
]);

// Wave 2 catalogs the slot. Unlockable cosmetics stay post-wave-2 (platform-r86me).
export const BADGES = freeze([]);
export const EFFECTS = freeze([]);

export const STACK_IDENTITY_TOKENS = freeze({
  color: {
    glow: Object.fromEntries(CHARACTERS.map((character) => [character.id, character.matching_glow])),
  },
  motion: {
    reduced: "reduce",
    full: "full",
  },
  size: {
    icon: { sm: "1.5rem", md: "2.5rem", lg: "4rem" },
  },
  appearance: ["light", "dark"],
  direction: ["ltr", "rtl"],
  layout: ["wide", "narrow"],
});

/** Companion launcher ids. These are not Stack Identity characters (CONTEXT.md). */
export const COMPANION_APPEARANCES = freeze([
  {
    id: "kubi",
    label_id: "companion.appearance.kubi",
    label: "Kubi",
    role: "default",
    provenance: "companion_launcher",
  },
  {
    id: "spark",
    label_id: "companion.appearance.spark",
    label: "Spark",
    role: "explicit_choice",
    provenance: "companion_launcher",
  },
]);

export const DEFAULT_IDENTITY = freeze({
  name: "My Homelab",
  character_id: "rocket",
  animation_style: "identity-float",
  animation_enabled: true,
  icon_style: "filled",
  glow_color_override: null,
});

export function getCharacter(id) {
  return CHARACTERS.find((character) => character.id === id);
}

export function getCharactersByCategory(category) {
  return CHARACTERS.filter((character) => character.category === category);
}

export function getAnimation(id) {
  return ANIMATIONS.find((animation) => animation.id === id);
}

export function isCatalogId(id) {
  return typeof id === "string" && idPattern.test(id);
}

export function compatibleAnimation(characterId, animationId) {
  const character = getCharacter(characterId);
  return Boolean(character) && character.matching_animation === animationId;
}

export function compatibleIconStyle(iconStyle) {
  return ICON_STYLES.some((entry) => entry.id === iconStyle);
}

export function compatibleBadge(id) {
  return BADGES.some((entry) => entry.id === id);
}

export function compatibleEffect(id) {
  return EFFECTS.some((entry) => entry.id === id);
}

function identitySnapshot(characterId, iconStyle, motion) {
  const character = getCharacter(characterId);
  return freeze({
    version: "stack_identity.v1",
    character_id: characterId,
    animation_style: character.matching_animation,
    animation_enabled: motion === "full",
    icon_style: iconStyle,
    glow_color_override: null,
  });
}

function fixture(characterId, iconStyle, appearance, motion, direction, layout) {
  return freeze({
    id: `${characterId}-${iconStyle}-${appearance}-${motion}-${direction}-${layout}`,
    kind: "positive",
    appearance,
    motion,
    direction,
    layout,
    identity: identitySnapshot(characterId, iconStyle, motion),
  });
}

export const STACK_IDENTITY_RENDER_FIXTURES = freeze([
  fixture("rocket", "filled", "light", "full", "ltr", "wide"),
  fixture("rocket", "glass", "dark", "full", "ltr", "narrow"),
  fixture("robot", "gradient", "light", "reduced", "ltr", "wide"),
  fixture("robot", "outlined", "dark", "reduced", "ltr", "narrow"),
  fixture("satellite", "filled", "light", "full", "rtl", "wide"),
  fixture("satellite", "glass", "dark", "full", "rtl", "narrow"),
  fixture("circuit", "gradient", "light", "reduced", "rtl", "wide"),
  fixture("circuit", "outlined", "dark", "reduced", "rtl", "narrow"),
  {
    id: "unknown-character",
    kind: "negative",
    appearance: "light",
    motion: "full",
    direction: "ltr",
    layout: "wide",
    identity: {
      version: "stack_identity.v1",
      character_id: "not-a-character",
      animation_style: "identity-float",
      animation_enabled: true,
      icon_style: "filled",
      glow_color_override: null,
    },
    reason: "unknown_character",
  },
  {
    id: "incompatible-animation",
    kind: "negative",
    appearance: "dark",
    motion: "full",
    direction: "ltr",
    layout: "narrow",
    identity: {
      version: "stack_identity.v1",
      character_id: "rocket",
      animation_style: "identity-glitch",
      animation_enabled: true,
      icon_style: "filled",
      glow_color_override: null,
    },
    reason: "incompatible_animation",
  },
  {
    id: "unknown-badge",
    kind: "negative",
    appearance: "light",
    motion: "reduced",
    direction: "rtl",
    layout: "wide",
    identity: {
      version: "stack_identity.v1",
      character_id: "robot",
      animation_style: "identity-glitch",
      animation_enabled: false,
      icon_style: "glass",
      glow_color_override: null,
    },
    badge_ids: ["first-stack"],
    reason: "unknown_badge",
  },
]);

export function validateRenderFixture(fixture) {
  const errors = [];
  if (!fixture || typeof fixture !== "object") return ["fixture: object required"];
  const identity = fixture.identity ?? {};
  if (!getCharacter(identity.character_id)) errors.push("unknown_character");
  if (!compatibleAnimation(identity.character_id, identity.animation_style)) {
    errors.push("incompatible_animation");
  }
  if (!compatibleIconStyle(identity.icon_style)) errors.push("unknown_icon_style");
  for (const badgeId of fixture.badge_ids ?? []) {
    if (!compatibleBadge(badgeId)) errors.push("unknown_badge");
  }
  for (const effectId of fixture.effect_ids ?? []) {
    if (!compatibleEffect(effectId)) errors.push("unknown_effect");
  }
  if (fixture.motion === "reduced" && identity.animation_enabled !== false) {
    errors.push("reduced_motion_requires_disabled_animation");
  }
  if (!["light", "dark"].includes(fixture.appearance)) errors.push("unknown_appearance");
  if (!["full", "reduced"].includes(fixture.motion)) errors.push("unknown_motion");
  if (!["ltr", "rtl"].includes(fixture.direction)) errors.push("unknown_direction");
  if (!["wide", "narrow"].includes(fixture.layout)) errors.push("unknown_layout");
  return errors;
}

export const STACK_IDENTITY_CATALOG = freeze({
  version: STACK_IDENTITY_CATALOG_VERSION,
  characters: CHARACTERS,
  animations: ANIMATIONS,
  icon_styles: ICON_STYLES,
  glow_presets: GLOW_PRESETS,
  badges: BADGES,
  effects: EFFECTS,
  tokens: STACK_IDENTITY_TOKENS,
  companion_appearances: COMPANION_APPEARANCES,
  default_identity: DEFAULT_IDENTITY,
});

/** CamelCase field names used by @kombiverselabs/ui until that package maps to snake_case. */
export function toUiCharacter(character) {
  return freeze({
    id: character.id,
    label: character.label,
    category: character.category,
    emoji: character.emoji,
    svgPath: character.svg_path,
    matchingAnimation: character.matching_animation,
    matchingGlow: character.matching_glow,
  });
}

export const characters = freeze(CHARACTERS.map(toUiCharacter));
export const glowColorPresets = freeze(
  GLOW_PRESETS.map((preset) => ({ id: preset.id, label: preset.label, color: preset.color })),
);
export const iconStyles = freeze(ICON_STYLES.map((style) => ({ id: style.id, label: style.label })));
export const defaultIdentity = freeze({
  name: DEFAULT_IDENTITY.name,
  characterId: DEFAULT_IDENTITY.character_id,
  animationStyle: DEFAULT_IDENTITY.animation_style,
  savedAt: null,
  animationEnabled: DEFAULT_IDENTITY.animation_enabled,
  iconStyle: DEFAULT_IDENTITY.icon_style,
  glowColorOverride: DEFAULT_IDENTITY.glow_color_override,
});
