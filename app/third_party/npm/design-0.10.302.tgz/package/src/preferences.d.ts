import type { Finish } from './contract.js';

export type AppearancePreference = 'system' | 'light' | 'dark';
export type DesignSelectionMode = 'inherit' | 'override';

export interface CentralDesign {
	appearance: AppearancePreference;
	finish: Finish;
}

export interface DeviceDesignSelection extends CentralDesign {
	mode: DesignSelectionMode;
}

export interface ResolvedDesign {
	appearancePreference: AppearancePreference;
	appearance: 'light' | 'dark';
	finish: Finish;
	source: 'central' | 'device';
}

export declare function isAppearancePreference(value: unknown): value is AppearancePreference;
export declare const BASELINE_DESIGN: Readonly<CentralDesign>;
export declare function parseCentralDesign(payload: unknown, fallback?: CentralDesign): CentralDesign;
export declare function resolveDesign(
	device: DeviceDesignSelection,
	central: CentralDesign,
	prefersDark: boolean
): ResolvedDesign;
