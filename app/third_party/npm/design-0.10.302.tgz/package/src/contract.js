/**
 * The framework-neutral design contract.
 *
 * CSS remains the rendering layer. This small JavaScript module keeps the
 * closed appearance/finish vocabulary available to Svelte, React, tests and
 * host SDKs without making any framework own the design state.
 */
export const DESIGN_CONTRACT_VERSION = "1";

export const APPEARANCES = Object.freeze(["light", "dark"]);
export const FINISHES = Object.freeze(["kombify", "liquid", "frost", "expressive", "aurora"]);
export const DESIGN_ROLES = Object.freeze([
  "plate",
  "menu-plate",
  "navigation",
  "control",
  "selection",
  "run-toggle",
  "protected",
  "app",
  "header",
  "footer",
  "main-panel",
  "detail-panel",
  "panel-header",
  "composer",
  "ai-thread",
  "ai-message",
  "ai-activity",
  "tag",
  "status",
  "menu-item",
  // Onboarding primitives (ONBOARDING-JOURNEY-STANDARD §6). The card is a
  // `menu-plate`, its rows are `menu-item` and its buttons are `control`;
  // these three are the shapes the existing vocabulary had no word for.
  "scrim",
  "spotlight",
  "progress",
]);

export const DEFAULT_APPEARANCE = "light";
export const DEFAULT_FINISH = "kombify";

export const DESIGN_FIXTURES = Object.freeze(
  FINISHES.flatMap((finish) =>
    APPEARANCES.map((appearance) =>
      Object.freeze({
        id: `${finish}-${appearance}`,
        finish,
        appearance,
        label: `${finish} / ${appearance}`,
      }),
    ),
  ),
);

export function isAppearance(value) {
  return typeof value === "string" && APPEARANCES.includes(value);
}

export function isFinish(value) {
  return typeof value === "string" && FINISHES.includes(value);
}

export function normalizeAppearance(value, fallback = DEFAULT_APPEARANCE) {
  return isAppearance(value) ? value : fallback;
}

export function normalizeFinish(value, fallback = DEFAULT_FINISH) {
  return isFinish(value) ? value : fallback;
}

/**
 * Returns the exact document attributes every renderer must apply. Keeping
 * this here prevents a Svelte-only preference format from becoming another
 * source of truth next to the React Workbench and the embed host.
 */
export function designAttributes(input = {}) {
  return {
    "data-appearance": normalizeAppearance(input.appearance),
    "data-finish": normalizeFinish(input.finish),
  };
}
