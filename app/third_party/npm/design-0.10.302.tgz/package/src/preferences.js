/**
 * The framework-neutral design-preference resolver.
 *
 * KOMBIFY-DESIGN-SYSTEM-STANDARD §4 fixes where a design value comes from —
 * host context, then device choice, then account default, then the kombify
 * baseline. CMO implemented that resolution first (inherit/override against
 * the account's `companionV2.panelAppearance`); this module is that logic
 * promoted into the package so every product resolves identically instead of
 * re-deriving the precedence. Storage keys, change events and DOM application
 * stay product-local — this module owns only parsing and resolution.
 *
 * The account payload shape is the AI Platform settings document served via
 * the Gateway (`/v1/ai/settings`): `companionV2.panelAppearance.{theme,finish}`.
 */

import { DEFAULT_FINISH, isFinish } from './contract.js';

/** @typedef {'system' | 'light' | 'dark'} AppearancePreference */
/** @typedef {'inherit' | 'override'} DesignSelectionMode */

/** @param {unknown} value @returns {value is AppearancePreference} */
export function isAppearancePreference(value) {
	return value === 'system' || value === 'light' || value === 'dark';
}

/** The §4 baseline: follow the OS, kombify finish. */
export const BASELINE_DESIGN = Object.freeze({
	appearance: /** @type {AppearancePreference} */ ('system'),
	finish: DEFAULT_FINISH
});

/**
 * Parse the account-level design out of an AI Platform settings payload.
 * Tolerant by construction: any missing or unknown field falls back to the
 * provided default (a product may brand its own central fallback, e.g. CMO
 * defaults to aurora), and the function never throws on foreign payloads.
 *
 * @param {unknown} payload
 * @param {{ appearance: AppearancePreference, finish: string }} [fallback]
 * @returns {{ appearance: AppearancePreference, finish: string }}
 */
export function parseCentralDesign(payload, fallback = BASELINE_DESIGN) {
	const root = record(payload);
	const companion = record(root.companionV2);
	const panel = record(companion.panelAppearance);
	return {
		appearance:
			panel.theme === 'light' || panel.theme === 'dark' ? panel.theme : fallback.appearance,
		finish: isFinish(panel.finish) ? panel.finish : fallback.finish
	};
}

/**
 * Resolve the effective design from the device selection and the account
 * default. `mode: 'override'` means the device choice wins; `'inherit'`
 * follows the account. `prefersDark` resolves the `system` appearance —
 * pass the current `matchMedia('(prefers-color-scheme: dark)')` result.
 *
 * @param {{ mode: DesignSelectionMode, appearance: AppearancePreference, finish: string }} device
 * @param {{ appearance: AppearancePreference, finish: string }} central
 * @param {boolean} prefersDark
 * @returns {{ appearancePreference: AppearancePreference, appearance: 'light' | 'dark', finish: string, source: 'central' | 'device' }}
 */
export function resolveDesign(device, central, prefersDark) {
	const selected = device.mode === 'override' ? device : central;
	return {
		appearancePreference: selected.appearance,
		appearance: selected.appearance === 'system' ? (prefersDark ? 'dark' : 'light') : selected.appearance,
		finish: isFinish(selected.finish) ? selected.finish : DEFAULT_FINISH,
		source: device.mode === 'override' ? 'device' : 'central'
	};
}

/** @param {unknown} value @returns {Record<string, unknown>} */
function record(value) {
	return value && typeof value === 'object' && !Array.isArray(value)
		? /** @type {Record<string, unknown>} */ (value)
		: {};
}
