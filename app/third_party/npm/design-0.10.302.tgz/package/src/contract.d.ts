export type Appearance = "light" | "dark";
export type Finish = "kombify" | "liquid" | "frost" | "expressive" | "aurora";
export type DesignRole =
  | "plate"
  | "menu-plate"
  | "navigation"
  | "control"
  | "selection"
  | "run-toggle"
  | "protected"
  | "app"
  | "header"
  | "footer"
  | "main-panel"
  | "detail-panel"
  | "panel-header"
  | "composer"
  | "ai-thread"
  | "ai-message"
  | "ai-activity"
  | "tag"
  | "status"
  | "menu-item"
  | "scrim"
  | "spotlight"
  | "progress";

export interface DesignFixture {
  readonly id: `${Finish}-${Appearance}`;
  readonly finish: Finish;
  readonly appearance: Appearance;
  readonly label: string;
}

export interface DesignInput {
  appearance?: unknown;
  finish?: unknown;
}

export declare const DESIGN_CONTRACT_VERSION: "1";
export declare const APPEARANCES: readonly Appearance[];
export declare const FINISHES: readonly Finish[];
export declare const DESIGN_ROLES: readonly DesignRole[];
export declare const DEFAULT_APPEARANCE: Appearance;
export declare const DEFAULT_FINISH: Finish;
export declare const DESIGN_FIXTURES: readonly DesignFixture[];

export declare function isAppearance(value: unknown): value is Appearance;
export declare function isFinish(value: unknown): value is Finish;
export declare function normalizeAppearance(value: unknown, fallback?: Appearance): Appearance;
export declare function normalizeFinish(value: unknown, fallback?: Finish): Finish;
export declare function designAttributes(input?: DesignInput): {
  "data-appearance": Appearance;
  "data-finish": Finish;
};
