# @kombiverselabs/design

Kombify materials, surface recipes, and generated diagram themes. Binding rules
live in `KOMBIFY-DESIGN-SYSTEM-STANDARD.md` in the workspace.

## Use it

Diagram renderers import the generated engine projections from the same package:

```js
import { DIAGRAM_THEMES } from "@kombiverselabs/design/diagram-themes";
const theme = DIAGRAM_THEMES.themes.dark.ai;
```

The typed contract covers `light`/`dark` and the existing renderer selectors
`cloud`, `ai`, `sim`, `stackkits`, `techstack`, and `umbrella` (Cloud's default
hue). The palette and font derive from `tokens/colors_and_type.css`; Mermaid
receives RGB hex variables because its theme calculations do not accept OKLCH.
D2 receives the complete `themeOverrides` palette, including storage and
document shapes, through its render API. Engine mappings belong in the token
generator, never in a consumer's inline palette. The export adds no font assets.

Pin an exact published package version and its lockfile integrity. Use
`DIAGRAM_THEMES.version` in SVG cache keys: it hashes the source receipt and
engine mappings, so either changing invalidates the cache. The package receipt
also hashes the generated module. `mise run tokens:check` detects drift.
Do not import a sibling checkout or fetch Brand `main` during a build.

```js
import "@kombiverselabs/design/index.css";
```

`index.css` is the generated palette (`tokens.css`: semantic colours, dark
mode, product themes — the same palette `@kombiverselabs/ui/styles.css`
carries plus the Tailwind mapping), the generated material, then the role
recipes. A consumer that loads the design package alone has every token the
recipes read.

Then stamp the axes on the document root and give your elements roles:

```html
<html data-appearance="dark" data-finish="aurora">
  <div data-kx="plate">…</div>
  <div data-kx="menu-plate">…</div>
  <aside data-kx="navigation">…</aside>
  <button data-kx="control">…</button>
  <button data-kx="control selection">…</button>
  <button data-kx="run-toggle" aria-pressed="true">Web</button>
  <div data-kx="protected">Approve this tool call?</div>
  <span data-kx="tag" style="--kx-accent: var(--kombify-stackkits)">Tool Definition</span>
  <span data-kx="status" data-status="ok">Enabled</span>
  <button data-kx="menu-item" data-danger>Delete block</button>
</html>
```

(The `style` above is illustrative shorthand: real consumers set `--kx-accent`
in their stylesheet, and only ever to a generated token — §5.4 forbids runtime
inline style, §5.1 forbids authoring a literal value.)

That is the entire integration. A consumer assigns roles and nothing else — it
writes no material values, and it adds no finish-specific rule for one of its
own elements (§3, §6).

## Stamp the axes once, from the runtime

The package resolves and stamps the design axes so a product does not write
its own precedence, storage reader, embed parameter parser or pre-paint
script (each of which three products had re-implemented, with the same trap
documented three times):

```js
import {
  applyDesign, designBootstrapScript, readDeviceDesign, readHostDesignParams,
  resolveDesignAxes, hostDesignMessage, isHostDesignMessage,
} from "@kombiverselabs/design/runtime";

// app.html, before first paint (a plain script body, no imports):
//   <script>${designBootstrapScript({ defaults: { appearance: "system", finish: "kombify" } })}</script>

// after mount, with the account tier fetched fail-soft from /v1/ai/settings:
const resolved = resolveDesignAxes({
  host: readHostDesignParams(location.search),   // §4 tier 1, this embedding only
  device: readDeviceDesign(localStorage),         // tier 2, the device's own choice
  account: parseCentralDesign(settingsPayload),   // tier 3, from ./preferences
  prefersDark: matchMedia("(prefers-color-scheme: dark)").matches,
});
applyDesign(document.documentElement, resolved);

// a host tells its embeds when it changes (closed enums at the boundary, §5.2):
iframe.contentWindow.postMessage(hostDesignMessage({ appearance, finish }), origin);
// and an embed accepts only that:
addEventListener("message", (e) => { if (isHostDesignMessage(e.data)) applyDesign(root, resolveDesignAxes({ host: e.data, device, account })); });
```

`data-appearance` is the one required stamp; the generated palette and the
Tailwind mapping in `@kombiverselabs/ui/styles.css` answer to it as well as to
the transitional `.dark` class. Storage keys, the account transport and change
events stay product parameters. `src/runtime.test.mjs` proves the precedence
and that an unknown value — a valid CSS fragment included — never passes.

## Why roles

The predecessor enumerated elements per finish: 726 lines in the Workbench,
~80 % selector lists, twelve edit sites for every new element. The failure was
not verbosity but silence — an element nobody remembered to add followed no
finish at all, and no test could see it. A role costs zero edits and cannot be
forgotten: an element without one is visibly unstyled rather than invisibly
wrong.

Two role choices are deliberate and worth knowing before you reach for them:

- **`run-toggle` does not vary by finish.** An on/off state is not a
  selection. The accent carries the meaning ("web access is on"), so it reads
  identically everywhere. This is the system declining to decorate.
- **`menu-plate` is not "a plate with more alpha".** A popover styled as a
  plate inherits the glass finishes' ~5 % fill and turns see-through over
  running text — a bug that shipped twice before the role existed.
- **`navigation` is not a vertical `plate`.** It uses a calm translucent fill
  without plate sheen or backdrop blur, so the page remains visible without
  swallowing inactive controls or capturing fixed flyouts.
- **`status` does not vary by finish either**, for the run-toggle reason: the
  hue is the state. `data-status="ok|running|warn|error|off"` picks the hue
  from values owned here; `running` pulses and stands still under reduced
  motion.
- **`tag` is the kombify signature label**: tinted fill, same-hue border,
  accent type. The hue arrives via `--kx-accent`, set only to a generated
  token. An interactive chip composes `data-kx="control tag"`.
- **`menu-item` rows are quiet at rest** — the `menu-plate` already declares
  the material. The checked row composes `selection`; destructive rows carry
  `data-danger`.

## Security

`protected` marks security-critical UI: approvals, consent prompts, the
scope-switch confirmation. The design layer may give it colour, radius,
typography, border and shadow; it may never give it geometry or visibility
(§5.3). `scripts/check-design-roles.mjs` (`mise run design:check`) parses the
shipped CSS and proves the absence — including a check that the scan matched something, so it can never
pass vacuously. The guard was verified by simulating the attack it prevents:
adding `opacity: 0` to a protected rule fails the suite.

Individualization is **selection, never authoring** (§5.1): a preset is an id
from a closed set, and the values behind it ship here. No user, tenant or host
supplies colours or CSS, which is what keeps UI redressing and CSS
exfiltration out of a surface that shows tool approvals.

## Five vocabularies, one contract

A finish is more than a fill. Each of the five owns a vocabulary along seven
dimensions — shape, optic, selection, hover, press, motion, scene — fixed in
`KOMBIFY-DESIGN-SYSTEM-STANDARD` §7 (2026-09-01): `kombify` is the flat tile,
`liquid` the lens (capsules, specular rim, a press that swells), `frost` the
pane you can see (grain, etched small-cap kickers), `expressive` the tonal
Material 3 Expressive finish (published springs, shape morph), `aurora` light
that moves (curtain scene, drifting spectral rim). All of it lands through the
roles a consumer already assigns; motion arrives through the finish's own
`--finish-*` material tokens, and the springs in `product.css` are sampled by
`scripts/spring-easing.mjs` from the physics, not approximated by a bezier.

## Material is generated, never hand-written

`src/generated/material.css` is emitted by
`scripts/generate-platform-tokens.mjs` from `tokens/material.css` and carries
the source SHA-256 as its receipt. `mise run tokens:check` fails on drift.

This exists because the values it replaces had already drifted: `finish=aurora`
resolved its border to `0.14` in the Workbench and `0.16` in the embedded
panel, hand-written in both, and nothing could notice (DESIGN-AXIS-STANDARD §4
as amended 2026-08-08).

## Test

```sh
pnpm run --dir packages/design test
```

## Stack Identity catalog

Stack Identity facts live here so Svelte, React, and Compose share one
catalog. Import the JS module, or load the JSON snapshot for a native
renderer. Kubi and Spark are Companion launcher ids in
`COMPANION_APPEARANCES`; they are not Stack Identity characters.

```js
import {
  CHARACTERS,
  COMPANION_APPEARANCES,
  STACK_IDENTITY_RENDER_FIXTURES,
  validateRenderFixture,
} from "@kombiverselabs/design/stack-identity";
```

```js
import catalog from "@kombiverselabs/design/stack-identity/catalog.json" with { type: "json" };
import fixtures from "@kombiverselabs/design/stack-identity/fixtures" with { type: "json" };
```
