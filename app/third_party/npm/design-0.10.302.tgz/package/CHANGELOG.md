# @kombiverselabs/design Changelog

> **How versions here relate to the registry.** Headings in this file are the
> authored *lines* (`0.8`, `0.9`). Delivery v2 derives the published patch from
> `.kombify/VERSION` plus the first-parent commit count since that file last
> changed, so the registry carries `0.9.0`, `0.9.1`, … within a line. The version
> line is shared with `@kombiverselabs/ui`: both packages belong to the `brand`
> product and move together, which is deliberate — a `ui` release and the
> `design` release that owns its recipes must never be resolvable apart.

## 0.10.0

### 2026-09-20 — readable native select menus

- Product appearance now sets the browser `color-scheme` on nested light and
  dark scopes. Native select options use matching system canvas ink and ground,
  preventing inherited light text from disappearing on a light OS menu.

### 2026-09-17 — list markers inside FAQ answers

- `editorial.css`: lists in an answer set their markers (`disc`, `decimal`)
  explicitly. Sites with a CSS reset such as Tailwind's preflight (kombify.io,
  stackkit.cc) rendered answer lists as indented lines without bullets.

### 2026-09-17 — FAQ search field tokens

- `editorial.css`: `.kf-faq-filter` defines the `--kf-*` tokens itself. The
  filter usually sits beside `.kf-faq-page`, not inside it, so on a site
  without the design roles the search field lost its border, surface and ink.

### 2026-09-17 — paragraph rhythm inside FAQ answers

- `editorial.css`: consecutive paragraphs of an answer keep their `0.85em`
  gap. The paragraph reset now precedes the sibling spacing rule; at equal
  specificity it used to override it, so a two-paragraph answer rendered as
  one block (seen on kombify.io).

### 2026-09-17 — editorial recipes for FAQ answers and diagrams

- New opt-in `@kombiverselabs/design/editorial.css`: the FAQ accordion on
  native `<details>` (a hairline per row, never a plate), answer prose, callout,
  figure and "read more" links, and four structured diagram recipes — `flow`
  (numbered steps, vertical by default, horizontal where the block is wide),
  `stack`, `topology` (hub over spokes on a bus line) and `arch` (grouped
  nodes). The markup contract is the `kf-` output of the content desk renderer
  (kombify-Cloud Administration `faq-render.ts`), so one stylesheet renders
  the same answer in every product and on the open-source sites.
- Tokens only, each with a fallback, so a site without the design system still
  reads well; logical properties for right-to-left; the disclosure height and
  chevron animate only under `prefers-reduced-motion: no-preference`. Filter
  chips and search are styled through `:where()`, so the `control`, `tag` and
  `selection` recipes win wherever `roles.css` is loaded.

### 2026-09-16 — finishes stay inside their own subtree

Owner report on the live Design Studio: choosing Frost or Expressive still drew
aurora rims and glows, because the page itself is aurora. Two leaks, both
closed in the package so every nested preview is correct:

- **Recipes are scoped to the nearest finish.** Every
  `[data-finish="x"] <role>` rule in `roles.css` and `product.css` now lives in
  `@scope ([data-finish="x"]) to ([data-finish]:not([data-finish="x"]))` with
  `:scope` in place of the attribute, so specificity is unchanged and an outer
  finish stops at a nested one. `scripts/scope-finish-recipes.mjs` performs the
  rewrite and `--check` is part of the package test, so a new unscoped recipe
  fails the gate.
- **Finish blocks are complete.** The generated `material.css` restates, per
  finish and per appearance, every material variable another finish declares
  (the kombify value, or `initial` so the recipe fallback applies). On the
  document root nothing changes; a nested `[data-finish]` no longer inherits
  the outer finish's rim image, fills or chrome.
- **One stage for the dashboard and its Companion.** The `dashboard` stage now
  shows the Companion panel open above its launcher, with a third card and a
  `companion` anchor, so a product edits launcher and panel in one place
  instead of switching stages.

### 2026-09-16 — the Design Studio core and scoped design previews

`@kombiverselabs/design/studio` (+ `studio.css`) is the framework-neutral core
of the Design Studio, lifted from the Companion Studio's `/design` canvas so
kombify Cloud (Svelte) and the Companion Studio (React) render one editor:

- **Vocabulary.** `STUDIO_KEYS` is the closed key→values map a tile may
  edit (`appearance`, `finish`, `aura`, `systemCardShape`, `chatStyle`,
  `composerStyle`, `density`, `panelTheme`, `panelFinish`,
  `launcher.position`, `launcher.size`, `launcher.tracer`); `STUDIO_TIER` says whether a key is
  the device's or the account's, and `studioKeySpecs` lets a product re-tier
  a key (Cloud writes `appearance`/`finish` as the account default) but never
  widen a value list. `LAUNCHER_METRICS` restates the launcher geometry so the
  stage draws the bubble at the account's size.
- **Draft model.** `studioBaseline` / `studioChanges` / `rebaseDraft` /
  `applyStudioDraft` over a `StudioAdapter` (`readDevice`, `writeDevice`,
  `readAccount`, `writeAccount`): nothing is written until Apply, device keys
  go first, every changed account key travels in ONE `writeAccount` call, and
  an unknown value — a CSS fragment included — is never a change.
- **Leads.** `measureStagePointers` / `observeStagePointers` measure a tile
  against the `[data-spot]` it changes and return the curve; hidden spots
  get no lead.
- **Stages.** `buildStage` / `updateStage` draw three reduced shells
  (`workbench`, `panel`, `dashboard`) from plain DOM and re-stamp them with
  the draft as data attributes only; the palette, material and role recipes
  paint them.

**Scoped design previews.** The generated palette now re-states the light
palette on `[data-design-scope][data-appearance="light"]`, so a light stage
or finish swatch inside a dark page resolves its own appearance (dark already
matched any element). The Studio stages and `@kombiverselabs/ui/settings`'s
`RecipeSwatch` are the consumers; a product never stamps this on chrome.

### 2026-09-08 — Stack Identity catalog

`@kombiverselabs/design/stack-identity` is the framework-neutral catalog:
character, animation, icon-style, and glow ids; empty Wave-2 badge/effect
slots; Companion launcher ids (`kubi`, `spark`); and render fixtures covering
light, dark, reduced motion, LTR, RTL, and narrow layout. Native consumers
load `stack-identity/catalog.json` and `stack-identity/fixtures`. Svelte
`@kombiverselabs/ui/identity` re-exports the same facts and no longer owns
the asset list.

### 2026-09-05 — the foundation under the recipes (fleet rollout readiness)

Owner review before the design rolls out to the remaining products (kombify
Cloud first): the recipe layer was consistent, the layers beneath it were not.
Four structural changes, no visual decision reopened; consumers change nothing
except that `data-appearance` alone now suffices as the dark stamp.

- **One dark switch.** The generated palette keys dark mode on
  `:is(.dark, [data-appearance="dark"])` and every product theme on both
  forms; `ui/styles.css`'s Tailwind variant matches both as well.
  `data-appearance` is the one required stamp; the class stays honoured.
- **One semantic bridge.** `--card`, `--popover`, `--muted`, `--secondary`,
  `--accent` and `--input` follow the finish material from ONE block per
  appearance (and the generated `:root` baseline), not from six per-finish
  copies that skipped the kombify default — under which `bg-muted` (#1b1b1b)
  and the roles' `--muted-bg` (#1f2428) were two greys for one surface.
- **One neutral ramp.** `tokens/colors_and_type.css` carries the kombify tile
  values (blue-tinted, in canonical OKLCH: dark #0b0d0e / #15181b / #1f2428,
  light #f5f7f8 / #ffffff / #eef1f3) that the material already painted;
  `product.css`'s `--kx-bg/--kx-panel/--kx-text/--kx-muted/--kx-faint` are
  aliases of the palette instead of a second ramp. Text and ground shift by a
  few units toward what the roles already showed.
- **The palette ships in this package.** `@kombiverselabs/design/tokens.css`
  (generated, receipted) is imported first by `index.css`, so a consumer that
  loads only the design package — the React Studio, the floating panel embed —
  has `--background`, `--foreground` and the rest.
- **A runtime.** `@kombiverselabs/design/runtime`: `readDeviceDesign`,
  `writeDeviceDesign`, `readHostDesignParams`, `hostDesignMessage` /
  `isHostDesignMessage`, `resolveDesignAxes` (host, device, account, baseline —
  per axis), `applyDesign`, and `designBootstrapScript` for the pre-paint
  script. Tested with `node --test`; an unknown value never passes a boundary.
- **Hygiene.** `.theme-cmo` moved from `product.css` into the token source as
  a web theme; the legacy `theme-stack` dark accent no longer resolves to the
  StackKits orange (a prefix match in the generator); `--primary-glow` reads
  the palette's glow in every product, so the composer's shadow stack is valid
  outside CMO; `contract.d.ts` lists `scrim`, `spotlight`, `progress`; the
  README names the real §5.3 gate.

### 2026-09-02 — the floating plate is the glass layer proper

- `plate` + `data-variant="floating"` (liquid): a plate that floats over the
  page as chrome — the Companion panel over a host backdrop — takes the
  chrome fill (`--chrome-bg`, 0.42 dark / 0.30 light) instead of the content
  pane's scrim, so the page shows through it as soft light. The dark
  reflection now lives in `--plate-reflection` and rides along.
- Liquid header: the hairline under it fades at both ends instead of running
  edge to edge; the composer in use blooms more quietly (1px 24 %, 22px 14 %).

### 2026-09-02 — quiet rails, and a lens that does not grow a frame

- Navigation entries rest quiet in EVERY finish: only the selection is marked,
  hover answers with a whisper of the text colour (7 % of the text). The
  rule covers any `control` in a `navigation` — a group head that wraps its
  link included — not only anchors and buttons; the liquid-only rail rule
  is folded into it (owner review 2026-09-02, Companion Studio rail).
- Liquid composer in use: a 1px accent hairline and a 24px bloom replace
  the 2px ring that read as a hard border.
- Dark liquid `--glass-border` 0.22 → 0.16: hairlines on dark glass are soft.

### 2026-09-02 — the lens reflects, and a frame blurs less than a menu

- Dark liquid plates catch the light in their top-left corner: a
  corner-anchored diagonal highlight rides above the flat scrim (owner review
  2026-09-02, "the glass has to reflect") — a reflection, not the half-plate
  band the second ruling retired.
- `--frame-backdrop` (liquid, frost, aurora; both appearances): the backdrop
  a host FRAME over the page takes — the Companion iframe via `@kombify/embed`
  — blurring less than `--menu-backdrop` so the page's text and cards still
  shimmer through as shapes.

### 2026-09-02 — detached surfaces bring their own light

The embedded Companion panel lives in an iframe, and a backdrop filter cannot
see across the frame boundary: a translucent pane there showed the host page
through it unblurred. `data-variant="detached"` on a `menu-plate` gives the
surface the ground and the finish's scene the app role would have painted
behind it, inside its own box, with the pane material on a layer above that
blurs that scene. Tonal finishes keep the plain ground. First consumer: the
floating panel renderer when it is embedded.

### 2026-09-02 — liquid: glass everywhere glass belongs

Owner review of the live light build: the node card, the flyout, the buttons
and the rail items still read as flat white, and dark hairlines framed the
panes. Glass has no frame, plays with the light behind it, and stacks — every
translucent, blurring layer makes the next one brighter — so:

- **Cards** carry their translucent fill, blur and a specular border in light
  for liquid, frost and aurora (they had the fill and blur in dark only).
- **Menus** are lenses in both appearances: `--glass-bg-menu` 0.74 light /
  0.8 dark with the lens backdrop; readability rides on blur and scrim.
- **Standalone controls** under liquid are lens capsules with no drawn frame:
  specular top and thickness line at button scale (`--control-shadow`) and a
  backdrop blur where a control stands on its own (`--control-backdrop`).
  Inside a plate or the navigation they rest transparent so the pane reads
  as one piece of glass; the navigation never blurs. Fields keep their fill.
- **Light liquid** drops its fills and sheen (surface 0.36, plate 0.34,
  muted 0.42, sheen 0.3), turns `--glass-border` into a white specular, and
  takes the approved mockup's light scene (0.38).
- **Frost** standalone controls lose their frame: milky fill, an edge of
  light, a soft drop.

### 2026-09-01 — five finish vocabularies

Owner direction (KOMBIFY-DESIGN-SYSTEM-STANDARD §7, seventh ruling): the
finishes must differ in more than a fill, liquid must be a real Liquid Glass
experience, kombify stays flat, expressive tracks Material 3 Expressive, aurora
and frost get stronger identities. Consumers change nothing — every cell of the
vocabulary lands through the roles they already assign.

#### Added

- **Motion is finish material.** `material.css` carries per finish
  `--finish-ease` / `--finish-dur-fast` (colour, border, shadow) and
  `--finish-ease-spatial` / `--finish-dur-spatial` (transform, shape), and the
  shared control transition reads them. `product.css` gains sampled springs —
  `--kx-ease-spring` (now the M3 Expressive spatial default, ζ 0.8 / k 380),
  `--kx-ease-spring-fast`, `--kx-ease-spring-slow`, `--kx-ease-effects`
  (critically damped) and `--kx-ease-liquid` — each with a `-dur` partner that
  is the settle time the curve needs. `scripts/spring-easing.mjs` generates
  them from the physics.
- `--plate-grain` (a finish's texture layer, frost's noise field) and
  `--plate-hover-glow` (now set by aurora) joined the required finish tokens;
  `--chrome-bg` / `--chrome-backdrop` give floating chrome its own material
  where a finish wants one (liquid), with the pane material as fallback.
- **Liquid**: capsule buttons, links, selections and tags; a directional
  specular rim and inner lens glow (`--plate-rim-image`, `--plate-shadow`);
  clearer header, footer and composer with the full lens optic; hover sweeps a
  highlight and lifts, press swells and brightens; menus carry the specular
  and thickness edges; cards catch a specular hairline; a stronger dark scene.
- **Aurora**: the scene is curtains that drift and shimmer; the plate rim
  drifts around the hue circle; plates glow on hover; controls answer hover
  with an accent halo; the primary action's ring is the spectrum; the card
  hairline, border and hover glow derive from the product accent.
- **Frost**: grain on plates, menus and the composer; tags set as etched
  kickers (small caps, tracked, squared); hover answers in light with an inner
  bloom rather than in accent.
- **Expressive**: containers drop their outline; hover deepens the tone and
  grows the control on the fast spatial spring; press squeezes; the selection
  morph rides the same spring; menu rows hover tonally.
- **kombify**: 120 ms cuts with no overshoot, and the leading-hairline mark
  now also names a checked menu row.
- The primary variant's ring reads `--plate-rim-image` when a finish has one.

#### Changed

- Every transform-bearing recipe (liquid swell and lift, expressive grow and
  squeeze) excludes `protected` and lives under
  `prefers-reduced-motion: no-preference`; the aurora rim drift, curtains and
  lens sweep are stilled under `reduce`.
- `scripts/check-design-roles.mjs` reads `:not([data-kx~="protected"])` as
  the exclusion it is instead of a target, and scans `product.css` alongside
  `roles.css`, so the press and hover recipes are under the same §5.3 gate.

The line moved together with `@kombiverselabs/ui` 0.10: that release changes
the shell components' visual contract (nav chrome loses its opaque color
utilities and renders the plate material), and this release ships the recipe
seam those components now rely on. Owner decision 2026-08-19,
KOMBIFY-DESIGN-SYSTEM-STANDARD §7.

### Added

- **Plate-scale ambient effects became finish material.** The `plate` recipe
  now consumes three new variables — `--plate-wash` (corner accent wash, an
  extra background layer), `--plate-hairline` (top hairline layer) and
  `--plate-hover-glow` (hover shadow, under `@media (hover: hover)`) — each
  with a `transparent` fallback. No finish sets them at launch, so every
  fixture renders byte-identically; a finish opts in via `material.css`, and a
  component never paints its own ambient effect. The card family's Beacon
  signature is the sanctioned exception and lives on `--kf-card-*` component
  tokens in `@kombiverselabs/ui` (§7, 2026-08-19).

### Fixed

- **Embedded top-bar selection matches the rail.** Under `kombify`, a
  `control selection` inside `header nav` now uses the same flat tint and
  leading hairline as the vertical `navigation` rail, instead of the generic
  bordered selection pill.
- **`kombify` is a tile finish.** The baseline still carried a metallic top
  edge (plate rim, inset highlight, primary bezel, translucent pane) after the
  sheen token went transparent. Both appearances are now opaque fills with no
  sheen, rim, inset, blur, or primary bloom; navigation selection is a flat
  tint plus a leading hairline; Beacon card wash/hairline/glow stay off. Cloud
  default cards are the origin reference (owner decision 2026-08-31, §7).
  Liquid, frost, aurora, and expressive keep their own materials.

- Dark `kombify` and `liquid` plates no longer paint a directed sheen or
  fill-image wash. That band sat on the pane and read as an old gradient:
  kombify stays flat, liquid keeps a uniform dark ground plus edge and blur.

- **Dark glass and navigation remain legible.** Liquid, frost, and aurora keep
  their blur, translucency, and finish rims while adding a dark resting ground;
  the dark ambient scene is quieter; and the new `navigation` role gives rails
  a distinct translucent surface with a stable high-contrast inactive
  foreground. This supersedes the 2026-08-19 no-fill rail / near-zero pane
  ruling after the owner comparison of Companion Studio and Techstack.
- `scripts/check-material-baseline.mjs` now whitelists
  `--kx-role-accent-text` as recipe-internal alongside `--kx-role-accent`;
  both are set and read on the same primary-variant rule, and a `:root` value
  would leak one element's accent label colour to every element. This was a
  standing red gate on `main`.

## 0.9.0

**No CSS change against `0.8.84`.** The line moved because `@kombiverselabs/ui`
had to move (it removes published tokens, and its peer on this package is a
caret range that pins the minor). Anyone already on `0.8.84` gets identical
bytes; the entries below are what changed for everyone still on `0.8.76`, which
is what the out-of-repo consumers were pinning when this line was cut.

### Added

- **`control` gained a primary-emphasis variant**:
  `[data-kx~="control"][data-variant="primary"]`. The one action on a surface
  that commits — Open, Deploy, Send, Approve — is now a *variant* of `control`
  rather than a second role, so it keeps control's radius, focus ring, shared
  transition and press dip unchanged.
  - The accent arrives through `--kx-accent` the way `tag` takes it (a generated
    token only, never a literal; unset it follows the product accent), with
    `--kx-accent-text` as its label partner so an overridden hue cannot leave the
    label unreadable.
  - The fill is **finish-invariant**, for the `run-toggle` reason (§3): the accent
    carries the meaning "this commits", and frost's clear pane or liquid's pale
    glass wash would dissolve that emphasis in three finishes out of five. Finish
    character arrives through the **edge** instead — the composer micro-bezel
    idiom, rim and inner highlight read from the finish's own material tokens —
    and `expressive` still morphs the shape through its existing control rule.
  - Hover raises the accent glow instead of repainting the fill: the label colour
    flips between light and dark, so a fill that lightened would gain contrast on
    one ground and lose it on the other. It carries no motion of its own, so
    `prefers-reduced-motion` has nothing to strip.
  - It sets no §5.3 property and is therefore legal on a `protected` element —
    an approval button is both security-critical and the primary action.
- Motion vocabulary plus the `tag`, `status` and `menu-item` roles.
- A shared sparkle recipe and the composer hover lighten (Workbench parity).

### Changed

- **`control` chrome is flat**, and the CMO surfaces are de-nested. Inside a
  `plate`, resting buttons and links go quiet and separate by spacing and type
  rather than a second frame; fields keep their fill, because an invisible input
  is an affordance bug. Hover/focus recipes in `product.css` restore the material
  on interaction.
  - The quiet-chrome recipes (plate-nested, resting, hover, composer bezel) now
    exclude `[data-variant="primary"]` the same way they already exclude
    `selection` and `run-toggle`: on a primary action the fill *is* the emphasis,
    not decoration the plate can supply.
- Micro-bezel on the composer action chrome.

### Fixed

- `scripts/check-design-roles.mjs` was not running. Its CLI entry check compared
  against `file://${process.argv[1]}`, which never matched — `argv[1]` is the path
  as typed, relative everywhere and backslashed on Windows — so `design:check`
  silently exited 0 on every platform. `pathToFileURL` makes it a real gate again,
  and `REQUIRED_ROLE_RECIPES` now asserts that the primary variant exists, is
  non-vacuous (background *and* colour), carries no animation, and sets no §5.3
  property. All four assertions were negative-tested.

## 0.8 line

`src/generated/material.css` became a generated artifact, emitted by
`scripts/generate-platform-tokens.mjs` from `tokens/material.css` and carrying the
source SHA-256 as its receipt; `mise run tokens:check` fails on drift. This exists
because the values it replaced had already drifted — `finish=aurora` resolved its
border to `0.14` in the Workbench and `0.16` in the embedded panel, hand-written in
both, with nothing able to notice.

The package also gained its publish path on this line. Before it, every consumer
outside kombify-Brand could only reach the layer by hand-copying it, which is
exactly how the material drifted in the first place
(`KOMBIFY-DESIGN-SYSTEM-STANDARD` §2, §6.1).
