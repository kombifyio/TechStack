# @kombiverselabs/onboarding-core

The framework-neutral half of the Kombify onboarding standard
(`kombify-Core/standards/ONBOARDING-JOURNEY-STANDARD.md`): the journey
descriptor and per-principal state types, and the pure functions that turn them
into something a surface can render.

- `migrate`, `reopenForVersion`, `mergeDerivedSignals`, `applySignal`,
  `markCoachSeen` — state transitions. Monotonic merges; a cost-bearing step
  refuses a reported completion; `reset` clears `seen_steps`, a version reopen
  does not.
- `resolveJourney` → `ResolvedJourney` / `ResolvedStep` — the render model.
  A blocked step has no `route`; progress excludes blocked steps from the
  denominator.
- `computeProgress`, `navBadge`, `nextCoachMark`, `isJourneyVisible`.

No Svelte, no React, no DOM, no network, no clock it does not own. Its package
manifest has no framework dependency, and the standalone TypeScript build keeps
that boundary executable without coupling tests to source formatting.

`src/contract.ts` was extracted unchanged from kombify-Cloud
(`src/lib/onboarding/contract.ts`), the first conformant implementation.
Svelte hosts bind it with runes (see `@kombiverselabs/ui/onboarding`); React
hosts bind it with `useSyncExternalStore`.

Journey descriptors contain no copy: every descriptor string is a `message_id`
the product resolves through its own localization. Availability guidance uses
the shared `client-error-envelope.v1` shape instead: required English fallback
prose plus optional semantic message IDs and bounded typed parameters. The
presenter exposes both so a renderer can localize first and fall back without
parsing or translating backend prose.
