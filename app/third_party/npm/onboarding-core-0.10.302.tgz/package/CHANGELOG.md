# @kombiverselabs/onboarding-core

## Unreleased

ONBOARDING-JOURNEY-STANDARD v1.3. Additive: every v1.2 descriptor and state
record resolves exactly as before.

- Absorbs the kombify-Cloud copy of the contract: action `finish`, product
  `simulate` removed, `isJourneyVisible` keeps a 100 % journey in the rail
  until the user finishes it.
- Stage `setup` and product `paperwork`.
- Modules (`journey.modules`, `step.requires_module`): a step whose module is
  off leaves the list and the progress denominator. Reported modules follow
  `state.selected_modules` (absent = all on); derived modules follow
  `ResolveOptions.moduleSignals` (absent = off). New `enabledModules` and
  action `select_modules` (reported modules only).
- Tips (`journey.tips`): non-completable hints resolved into
  `ResolvedJourney.tips`, never counted in progress, filtered by
  `after_step`, module, capability and `state.dismissed_tips` (survives a
  version bump). New action `dismiss_tip` and presenter `presentTips`.
- Availability guidance now consumes the canonical `client-error-envelope.v1`
  localization reference. `GuidanceView` keeps its compatibility ID fields and
  additionally exposes message IDs, typed parameters, and field-aligned English
  fallbacks for new renderers.

## 0.10.0

- Initial extraction of the onboarding journey core from kombify-Cloud,
  unchanged: descriptor and state types, `migrate`, `reopenForVersion`,
  `mergeDerivedSignals`, `applySignal`, `markCoachSeen`, `resolveJourney`,
  `computeProgress`, `navBadge`, `nextCoachMark`, `isJourneyVisible`.
