import { canonicalAuthorityDigestV2, canonicalAuthorityJsonV2 } from "../authority/contract.js";
import type { AuthorityDigestV2 } from "../authority/types.js";
import { validateSchemaDocuments } from "../schemaValidator.js";
import { paymentSchemaDocuments } from "./contract/schemas.generated.js";
import type {
  PaymentIntentV1,
  PaymentInstrumentV1,
  PaymentReceiptV1,
} from "./contract/types.generated.js";

export interface PaymentBindingV1 {
  readonly intent: PaymentIntentV1;
  readonly instrument?: PaymentInstrumentV1;
  readonly receipt?: PaymentReceiptV1;
  /** Trusted saved intent, not a caller's replacement for durable replay state. */
  readonly priorIntent?: PaymentIntentV1;
  /** Trusted saved settlement, not a caller's assertion of provider proof. */
  readonly priorReceipt?: PaymentReceiptV1;
  readonly operation?: "inspect" | "execute" | "replay_receipt";
  readonly now?: string;
}

export class PaymentContractError extends Error {
  constructor(readonly violations: readonly string[]) {
    super("Invalid payment v1 contract binding.");
    this.name = "PaymentContractError";
  }
}

export function paymentIntentDigestV1(
  intent: Omit<PaymentIntentV1, "intentDigest"> | PaymentIntentV1,
): AuthorityDigestV2 {
  const { intentDigest: _digest, ...binding } = intent as PaymentIntentV1;
  return canonicalAuthorityDigestV2("kombify.payment-intent.v1", binding);
}

export function paymentReceiptDigestV1(
  receipt: Omit<PaymentReceiptV1, "receiptDigest"> | PaymentReceiptV1,
): AuthorityDigestV2 {
  const { receiptDigest: _digest, ...binding } = receipt as PaymentReceiptV1;
  return canonicalAuthorityDigestV2("kombify.payment-receipt.v1", binding);
}

function instant(value: unknown): number {
  if (typeof value !== "string") return NaN;
  const ms = Date.parse(value);
  if (!Number.isFinite(ms) || new Date(ms).toISOString() !== value.replace("Z", ".000Z"))
    return NaN;
  return ms;
}

function reservationInstant(value: string): number {
  const parts = /^(\d{4})-(\d{2})-(\d{2})T/u.exec(value);
  if (!parts) return NaN;
  const [, year, month, day] = parts.map(Number);
  const calendar = new Date(`${parts[0].slice(0, 10)}T00:00:00Z`);
  if (
    calendar.getUTCFullYear() !== year ||
    calendar.getUTCMonth() + 1 !== month ||
    calendar.getUTCDate() !== day
  )
    return NaN;
  return Date.parse(value);
}

/** Canonical conformance only: never entitlement, custody, funding or provider admission. */
export function validatePaymentBindingV1(value: unknown): readonly string[] {
  if (!value || typeof value !== "object" || Array.isArray(value)) return ["invalid_request"];
  const request = value as PaymentBindingV1;
  const {
    intent,
    instrument,
    receipt,
    priorIntent,
    priorReceipt,
    operation = "inspect",
    now,
  } = request;
  const errors = new Set<string>();
  if (!["inspect", "execute", "replay_receipt"].includes(operation))
    errors.add("invalid_operation");
  for (const [kind, document, required] of [
    ["intent", intent, true],
    ["instrument", instrument, operation !== "inspect" || receipt !== undefined],
    ["receipt", receipt, operation === "replay_receipt"],
    ["intent", priorIntent, false],
    ["receipt", priorReceipt, operation === "replay_receipt"],
  ] as const) {
    if (document === undefined) {
      if (required) errors.add(`missing_${kind}`);
    } else if (
      validateSchemaDocuments(
        paymentSchemaDocuments,
        "payment v1",
        `payment.v1.schema.json#/$defs/${kind}`,
        document,
      ).length
    ) {
      errors.add(`invalid_${kind}`);
    }
  }
  if (errors.size) return [...errors];
  try {
    if (intent.intentDigest !== paymentIntentDigestV1(intent)) errors.add("intent_digest_mismatch");
    if (!Number.isFinite(instant(intent.expiresAt))) errors.add("invalid_intent_expiry");
    if (priorIntent && canonicalAuthorityJsonV2(intent) !== canonicalAuthorityJsonV2(priorIntent))
      errors.add("intent_replay_mismatch");
    if (instrument) {
      if (
        instrument.intentId !== intent.intentId ||
        instrument.intentDigest !== intent.intentDigest ||
        instrument.leaseId !== intent.leaseId
      )
        errors.add("instrument_binding_mismatch");
      const reservation = instrument.reservation;
      if (
        reservation.allocationId !== intent.funding.allocationId ||
        reservation.intentDigest !== intent.intentDigest ||
        reservation.currency !== intent.currency ||
        reservation.maximumMinor !== intent.maximumMinor ||
        reservation.merchantRef !== intent.merchantRef ||
        reservation.purposeRef !== intent.purposeRef ||
        !Number.isFinite(reservationInstant(reservation.expiresAt)) ||
        reservationInstant(reservation.expiresAt) > instant(intent.expiresAt)
      )
        errors.add("reservation_binding_mismatch");
    }
    if (receipt && instrument) {
      if (receipt.receiptDigest !== paymentReceiptDigestV1(receipt))
        errors.add("receipt_digest_mismatch");
      if (
        receipt.intentId !== intent.intentId ||
        receipt.intentDigest !== intent.intentDigest ||
        receipt.instrumentId !== instrument.instrumentId ||
        receipt.providerInstrumentRef !== instrument.providerInstrumentRef ||
        canonicalAuthorityJsonV2(receipt.reservation) !==
          canonicalAuthorityJsonV2(instrument.reservation)
      )
        errors.add("receipt_binding_mismatch");
      if (
        receipt.currency !== intent.currency ||
        BigInt(receipt.actualMinor) > BigInt(intent.maximumMinor)
      )
        errors.add("settlement_outside_intent");
      if (!Number.isFinite(instant(receipt.settledAt))) errors.add("invalid_settlement_time");
      if (instrument.status === "outcome_unknown" && instrument.pendingOperation !== "void")
        errors.add("settlement_still_unknown");
    }
    if (operation === "execute" && instrument) {
      if (instrument.status !== "issued") errors.add("instrument_not_usable");
      if (
        !Number.isFinite(instant(now)) ||
        instant(now) >= instant(intent.expiresAt) ||
        instant(now) >= reservationInstant(instrument.reservation.expiresAt)
      )
        errors.add("expired_execution");
      if (receipt || priorReceipt) errors.add("already_settled");
    }
    if (operation === "replay_receipt" && priorReceipt && receipt) {
      if (
        priorReceipt.receiptDigest !== paymentReceiptDigestV1(priorReceipt) ||
        canonicalAuthorityJsonV2(receipt) !== canonicalAuthorityJsonV2(priorReceipt)
      )
        errors.add("receipt_replay_mismatch");
    }
  } catch {
    errors.add("noncanonical_binding");
  }
  return [...errors];
}

/** Parses a bound evidence set; positive online authority is a separate requirement. */
export function parsePaymentBindingV1(value: unknown): PaymentBindingV1 {
  const violations = validatePaymentBindingV1(value);
  if (violations.length) throw new PaymentContractError(violations);
  return value as PaymentBindingV1;
}
