# @kombiverselabs/ui

Shared UI component library for the kombify platform. Provides shell components (navigation, footers, theme toggle) and the Stack Identity system.

## Modules

### Application logos (`@kombiverselabs/ui/applications`)

`ApplicationCluster` is the shared application-package composition. `layout` is
`cloud` by default; `stack` and `fan` are explicit per-surface alternatives.
It accepts any number of applications and sizes `sm`, `md`, and `lg`.

```svelte
<script lang="ts">
  import { ApplicationCluster, type ApplicationClusterItem } from '@kombiverselabs/ui/applications';
  const apps: ApplicationClusterItem[] = [
    { id: 'immich', name: 'Immich', logoUrl: '/logos/immich.svg' },
    { id: 'jellyfin', name: 'Jellyfin', logoUrl: '/logos/jellyfin.svg', muted: true, statusLabel: 'Paused' }
  ];
</script>

<ApplicationCluster items={apps} label="Applications on this server" />
<ApplicationCluster items={apps} layout="fan" size="sm" />
```

Import the shared design CSS in the host as usual. Tiles and tooltips inherit its
`plate` and `menu-plate` recipes; the component owns only composition and geometry.
Catalog/runtime adapters, localised labels and logo provenance belong to the host.
The `logo` snippet receives an item and can reuse a curated logo renderer; custom
renderers own their own image fallback. Otherwise a missing/failed URL becomes
`monogram` or name initials, including images that failed before hydration.

- Stable `id` values are deduplicated in source order; first occurrence wins.
- `maxVisible` includes the `+N` overflow mark. Omit it to show all; zero renders
  nothing. `overflowLabel(count)` provides a localised label; hidden names remain
  in its accessible name. Supply `onoverflow` to open details or expand the list;
  the host restores focus when expansion replaces the overflow button.
- `onselect(item)` opts into native buttons; `selected` provides `aria-pressed`
  and a visible ring. Passive marks have accessible names; no dead buttons.
- `muted: true` requires an explicit `statusLabel`. Grayscale is accompanied by
  a minus badge. The component never infers installed, available or healthy state.
- Set `decorative` only when surrounding content already names the applications;
  it disables callbacks and removes duplicate screen-reader output.
- Layout and visible items are deterministic during SSR. CSS wraps on narrow
  surfaces, reserves image dimensions and leaves logo artwork upright. There is
  no measurement, random placement or automatic motion.

UI Lab: `/kombify-ui/applications` exercises the three layouts, 0–15 items,
overflow, selection, muted states and broken-image fallback.

### Shell (`@kombiverselabs/ui/shell`)

Layout and navigation primitives for consistent app shells.

| Component | Description |
|-----------|-------------|
| `SidebarNav` | Controlled, collapsible and drag-resizable primary rail with seam toggle, active states and snippets |
| `AppRail` | Self-contained product rail with the same optional controlled resize/collapse contract |
| `InlineTabNav` | Horizontal tab-style navigation |
| `FooterModern` | Full-featured footer with `'full'` and `'compact'` variants, social links, legal links, dark mode logo |
| `FooterCompact` | Simple prop-driven footer (logo + copyright + custom links) |
| `ThemeToggle` | Dark/light mode toggle with localStorage persistence |

```svelte
<script>
  import { SidebarNav, FooterModern, ThemeToggle } from '@kombiverselabs/ui/shell';
</script>

<SidebarNav
  items={navItems}
  currentPath={$page.url.pathname}
  collapsed={railCollapsed}
  onCollapsedChange={(collapsed) => (railCollapsed = collapsed)}
  width={railWidth}
  onResize={(width) => persistRailWidth(width)}
  resizeControls="app-content"
/>
<FooterModern variant="compact" />
<ThemeToggle />
```

The desktop separator is available in both states. Dragging 36 px beyond the
expanded minimum collapses the rail; dragging a compact rail 36 px back toward
content expands it and restores the consumer-owned width. Products persist the
width and collapse state at their own device-preference boundary and supply
localized `collapseLabel`, `expandLabel`, `resizeLabel`, and
`collapsedValueLabel` strings. Mobile navigation remains a separate primitive.

### Identity (`@kombiverselabs/ui/identity`)

The Stack Identity system lets users personalize their kombify instance with a character, name, animation style, and glow color.

| Export | Type | Description |
|--------|------|-------------|
| `StackIdentityIcon` | Component | Renders the character emoji/SVG with glow and animation |
| `StackIdentityName` | Component | Displays the identity name with themed styling |
| `StackIdentityDisplay` | Component | Icon + name combined |
| `StackIdentityBadge` | Component | Compact badge for headers/sidebars |
| `StackIdentityCard` | Component | Full identity card with all details |
| `StackIdentityEditor` | Component | Interactive editor for choosing character, name, colors |
| `StackIdentityAvatar` | Component | Avatar-sized identity display |
| `StackIdentityGreeting` | Component | Welcome message with identity |
| `StackIdentityHeader` | Component | Header bar with identity branding |
| `StackIdentityWatermark` | Component | Background watermark effect |
| `resolveIdentityTheme` | Function | Resolves `StackIdentity` into CSS tokens and classes |
| `normalizeStackIdentity` | Function | Normalizes partial identity (e.g. from localStorage) |
| `characters` | Constant | Full character catalog |
| `getCharacter` | Function | Lookup character by ID |

```svelte
<script>
  import { StackIdentityDisplay, resolveIdentityTheme } from '@kombiverselabs/ui/identity';

  const theme = resolveIdentityTheme(userIdentity);
</script>

<StackIdentityDisplay identity={userIdentity} />
<div style={themeCssVarsString(theme)}>Themed content</div>
```

## Exports Map

| Subpath | Contents |
|---------|----------|
| `@kombiverselabs/ui` | Everything (shell + identity) |
| `@kombiverselabs/ui/shell` | Shell components + NavItem type |
| `@kombiverselabs/ui/identity` | Identity components, catalog, types |
| `@kombiverselabs/ui/styles.css` | Base styles |
| `@kombiverselabs/ui/identity.css` | Identity animation styles |

## Requirements

- Svelte 5 (runes)
- TailwindCSS 4
- `lucide-svelte` (peer icons)

## License

MIT
