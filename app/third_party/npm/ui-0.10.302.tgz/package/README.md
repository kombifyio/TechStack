# @kombiverselabs/ui

Shared UI component library for the kombify platform. Provides shell components (navigation, footers, theme toggle) and the Stack Identity system.

## Modules

### Shell (`@kombiverselabs/ui/shell`)

Layout and navigation primitives for consistent app shells.

| Component | Description |
|-----------|-------------|
| `SidebarNav` | Collapsible sidebar with active-state highlighting, badges, header/footer snippets |
| `InlineTabNav` | Horizontal tab-style navigation |
| `FooterModern` | Full-featured footer with `'full'` and `'compact'` variants, social links, legal links, dark mode logo |
| `FooterCompact` | Simple prop-driven footer (logo + copyright + custom links) |
| `ThemeToggle` | Dark/light mode toggle with localStorage persistence |

```svelte
<script>
  import { SidebarNav, FooterModern, ThemeToggle } from '@kombiverselabs/ui/shell';
</script>

<SidebarNav items={navItems} currentPath={$page.url.pathname} />
<FooterModern variant="compact" />
<ThemeToggle />
```

### Identity (`@kombiverselabs/ui/identity`)

The Stack Identity system lets users personalize their kombify instance with a character, name, animation style, and glow color.

| Export | Type | Description |
|--------|------|-------------|
| `StackIdentityIcon` | Component | Renders the character emoji/SVG with glow and animation |
| `StackIdentityName` | Component | Displays the identity name with themed styling |
| `StackIdentityDisplay` | Component | Icon + name combined |
| `StackIdentityBadge` | Component | Compact badge for headers/sidebars |
| `StackIdentityCard` | Component | Full identity card with all details |
| `StackIdentityEditor` | Component | Interactive editor for choosing character, name, colors |
| `StackIdentityAvatar` | Component | Avatar-sized identity display |
| `StackIdentityGreeting` | Component | Welcome message with identity |
| `StackIdentityHeader` | Component | Header bar with identity branding |
| `StackIdentityWatermark` | Component | Background watermark effect |
| `resolveIdentityTheme` | Function | Resolves `StackIdentity` into CSS tokens and classes |
| `normalizeStackIdentity` | Function | Normalizes partial identity (e.g. from localStorage) |
| `characters` | Constant | Full character catalog |
| `getCharacter` | Function | Lookup character by ID |

```svelte
<script>
  import { StackIdentityDisplay, resolveIdentityTheme } from '@kombiverselabs/ui/identity';

  const theme = resolveIdentityTheme(userIdentity);
</script>

<StackIdentityDisplay identity={userIdentity} />
<div style={themeCssVarsString(theme)}>Themed content</div>
```

## Exports Map

| Subpath | Contents |
|---------|----------|
| `@kombiverselabs/ui` | Everything (shell + identity) |
| `@kombiverselabs/ui/shell` | Shell components + NavItem type |
| `@kombiverselabs/ui/identity` | Identity components, catalog, types |
| `@kombiverselabs/ui/styles.css` | Base styles |
| `@kombiverselabs/ui/identity.css` | Identity animation styles |

## Requirements

- Svelte 5 (runes)
- TailwindCSS 4
- `lucide-svelte` (peer icons)

## License

MIT
