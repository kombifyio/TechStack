# @kombiverselabs/ui Changelog

> **How versions here relate to the registry.** Headings in this file are the
> authored *lines* (`0.8`, `0.9`). Delivery v2 derives the published patch from
> `.kombify/VERSION` plus the first-parent commit count since that file last
> changed, so the registry carries `0.9.0`, `0.9.1`, … within a line. A new
> heading therefore means "the line moved", and the entries under it cover
> everything published on the previous line since the previous heading.

## 0.10.0

### 2026-09-20 — localized onboarding denial guidance

- `GettingStarted` resolves the canonical onboarding guidance message IDs with
  typed parameters and renders the required English title, body, and next-step
  fallbacks when a catalog reference is absent or cannot be formatted.

### 2026-09-20 — advanced use-case settings tabs

- `UseCaseAdvanced` has an opt-in tabs presentation for one-at-a-time advanced
  settings groups. It keeps the outer progressive disclosure, supports concise
  group orientation, and follows the tab keyboard pattern while preserving the
  existing accordion API by default.

### 2026-09-17 — FAQ blocks

- New `@kombiverselabs/ui/faq`: `FaqSection` (featured questions at the bottom
  of a landing or product page, `variant="inline"` beside billing or settings
  views, renders nothing without items), `FaqItem` (native disclosure with
  `id={slug}`; `#slug` opens it on load and on hash changes), `FaqLinks`,
  `FaqGroups` (full FAQ page: topic rail and one section per topic, filtered by
  search words and product) and `FaqFilter` (search plus product chips). The
  props mirror the public FAQ read API (`/v1/content/faq`), so a site passes
  the payload straight through; strings arrive through `labels`.
- Helpers `filterFaqItems`, `visibleFaqGroups`, `faqPlainText` and `faqJsonLd`
  (schema.org FAQPage JSON with every `<` escaped). Styling comes from
  `@kombiverselabs/design/editorial.css`.

### 2026-09-16 — Stack Identity preview shows the text effect again

- `StackIdentitySettings`: the preview name renders through
  `StackIdentityName`, so it carries the character's text effect and glow
  (the settings rows had dropped both).

### 2026-09-16 — Stack Identity as settings, clearer picture tiles

- `StackIdentitySettings` (identity): every Stack Identity choice as settings
  rows — preview, name, character, icon style, glow, animation — with Save and
  Reset under the values. No collapsed card and no "Customize" step. Labels
  come from the consumer's catalog.
- `OptionTiles`: the checked tile carries a solid accent ring in every finish
  (its state must read the same everywhere), hint text follows the tile's own
  colour so it stays legible on an accent-filled selection.
- `SettingsRow` with `align="start"` gives its control the whole value column,
  so wide pickers line up with every other value instead of stacking under the
  label.
- `StudioTile`: a tile with a single row no longer repeats its title as the
  row label.

### 2026-09-16 — settings rows keep label and value together

`SettingsRow` puts the control directly beside a fixed label column
(`--kx-settings-label-width`, default 16rem) instead of flush right, and a row
stops at a readable measure (`--kx-settings-row-max`, default 56rem). Owner
review of the live Cloud settings: a label on the far left and its value on
the far right of a wide page forced the eye across the whole screen for every
row. Stacked rows (tiles) keep the full width.

### 2026-09-16 — settings structure and the Design Studio view

`@kombiverselabs/ui/settings` is the settings page structure every product
composes (SETTINGS-STANDARD): `SettingsShell` (page header + tab strip +
body), `SettingsTabs` (shared tabs first in the fixed order, tool tabs after,
exact slug match, no plate, no flyout), `SettingsSection` (heading + lead +
rows; `tone="danger"` for the section that owns destructive actions),
`SettingsRow` (label and description left, control right, stacks under
40rem), `OptionTiles` (a picture radio — one tile per option, only the chosen
one carries `selection`; an unavailable option stays visible with its
guidance), `RecipeSwatch` (the real plate and selection recipes at half
scale in a `data-design-scope` subtree, lifted from Techstack's finish
swatch) and `ThumbFrame` (the fixed-aspect frame a product draws its own
layout thumbnail into, lifted from Paperwork's settings previews). A settings
page carries no `plate` outside dialogs and object rows.

`@kombiverselabs/ui/studio` is the Svelte view of the Design Studio over
`@kombiverselabs/design/studio`: `DesignCanvas` (draft state, stage tablist,
measured leads, Apply/Discard bar, conflict notice; rebases when the
baseline moves), `StudioTile` (`menu-plate` with segment / switch / tiles /
note / action / preview rows) and `Stage`. A product supplies the adapter,
the stages and the tiles with its own message ids. The boundary test pins
the contract: nothing reaches the adapter before Apply, then one account
write with only the changed keys.

### 2026-09-08 — Stack Identity catalog source

`@kombiverselabs/ui/identity` reads characters, glow presets, and icon styles
from `@kombiverselabs/design/stack-identity`. Theme resolution stays in this
package because it emits CSS class names for `identity.css`.

Identity surfaces take closed design roles: the badge is `tag` with catalog
`--kx-accent` tokens, the card is `plate`, and the editor's rows are
`control` / `control selection`. Author-supplied glow overrides never reach
`--kx-accent`. `identity.css` keeps animation hues on `var(--glow-color)`
instead of hex literals.

### 2026-09-05 — the account menu

- `AccountMenu` (shell): one account pane for every shell, after the Companion
  Studio's user pane. The identity card (rail foot) or the avatar alone
  (top bar, folded rail) is the trigger; the panel opens as a portaled fixed
  `menu-plate` with an identity hero on top — name, email, labels as tags —
  then the product's entries (`AccountMenuItem[]`: Settings, Domains,
  Billing, Docs), an `extra` slot (appearance switch, version line) and Sign
  out last. Settings and account entries leave the main navigation for this
  pane (owner direction 2026-09-05).

### 2026-09-05 — the current rail entry is the most specific match

- `SidebarNav` lights only the longest matching href: an overview entry
  whose href is a prefix of every other route no longer reads as current on
  those routes (kombify Cloud: Overview and Settings were both selected), and
  a prefix only matches at a path segment boundary.

### 2026-09-05 — two kinds of rail entry, compact labels, groups

- `NavItem.kicker`: a quiet line above the label in the expanded rail ("run your"
  over "Techstack"); an entry without one stays icon and label. Two kinds
  of main entry, decided per item (owner direction 2026-09-05, the kombify
  Cloud navigation).
- `SidebarNav collapsedLabels`: the folded rail shows `NavItem.compactLabel`
  (or the label) under each icon — "run", "find", "Home" — so it reads
  without a tooltip.
- `SidebarNav groups`: named sections (`NavGroup`) read as small headings
  expanded and fold to a short inset rule collapsed. `items` stays the
  single-group form.

### 2026-09-05 — styles.css answers to data-appearance

- The generated palette keys dark mode on `:is(.dark, [data-appearance="dark"])`
  and the Tailwind `dark:` variant on either form, so a consumer stamps
  `data-appearance` once and the utilities, the product themes and the design
  package's material agree. The `.dark` class keeps working through the
  transition.
- The neutral ramp is the kombify tile ramp the design package paints on its
  roles (see the design changelog): `bg-background`, `bg-card`, `bg-muted`,
  `text-foreground`, `text-muted-foreground` and the sidebar family shift by a
  few units toward what `plate` and `app` already showed, and the same value
  now reaches a utility and a role.
- `theme-cmo` is emitted here as a web theme (it lived in the design
  package's product.css); `theme-stack` dark no longer carries the StackKits
  accent.

Minor, not patch — the shell components' visual contract changes: navigation
chrome stops painting its own opaque background and renders the design
package's plate material instead (owner decision 2026-08-19,
KOMBIFY-DESIGN-SYSTEM-STANDARD §7). Pairs with `@kombiverselabs/design` 0.10,
which ships the `--plate-*` effect seam.

### Changed

- **The large use-case card selects like the tile.** With `onToggle`, the
  pitch is the click target and a checkbox mark sits top-right (plus = not in
  the kit, check on the accent = in the kit); clicks on controls inside the
  card never toggle it, and the mark carries the keyboard handling. The former
  add/remove CTA is gone. New props: `selectable`, `infoHref`/`infoLabel` (an
  info affordance that opens the use case's guide), and `decisions`/
  `decisionsLabel` (the operator's current choices summarised on the pitch —
  level two of the depth model; the drawer is where they change).
- **The use-case card's advanced drawer spans the whole card.** `UseCaseAdvanced`
  gains `variant: 'boxed' | 'band'`. In the split layout `UseCaseCard` renders the
  drawer as a flush band under both columns, on the card's own hairline, and an
  open drawer lays its groups out as tiles in an auto-fit grid — side by side on
  a wide card, stacked on a narrow one. The dossier layout keeps the boxed panel.
  Below the split's own 640px container query the stacked card also tightens its
  insets, because stacked is its compact face: the same card two abreast in a
  wizard grid (owner direction 2026-09-05).
- **Embedded tabs drop the bottom underline and the full-height tile.**
  `InlineTabNav` keeps header geometry only: a compact 32px chip. The
  `kombify` header recipe owns the leading hairline, so the component no
  longer paints a second accent under the active tab.
- **Sidebar navigation now owns the shared `navigation` role.** Dark rails keep
  a distinct translucent ground and readable inactive controls while preserving
  the fixed flyout behavior and the package's compact 76px rail.
- **Server severity no longer conflates reachability with warnings.** The shared
  `ServerCard` renders `degraded` with warning semantics and reserves the
  destructive treatment for `offline`; pending and unknown states remain
  neutral. The shared status badge vocabulary now includes `degraded`.
- **Service cards expose product navigation and access evidence.** Consumers can
  provide a keyboard-accessible `detailsHref` for the card body independently
  from action buttons, plus either an address or an honest unavailability reason
  directly below the service display name.
- **Installer contract follows the authored 0.10 line.** The package metadata
  now requires `@kombiverselabs/design` `^0.10.0` and reports source version
  `0.10.0`, matching `.kombify/VERSION` and the Design package. The first 0.10
  deliveries accidentally retained the authored 0.9 peer even though the
  changelog and runtime recipes had already moved together; consumers must not
  combine UI 0.10 with Design 0.8/0.9.
- **Shell nav chrome follows the PlatformHeader pattern.** `SidebarNav` drops
  `bg-sidebar`/`border-sidebar-border`/`hover:bg-sidebar-accent` and the
  active row's `bg-primary/10` (the `selection` role paints it); `InlineTabNav`
  drops `bg-background`/`border-border` and is promoted to
  `data-kx="header plate"`; `FooterCompact` drops `bg-background/95` and gains
  `data-kx="footer plate"`. Components keep geometry only: edge components
  square their radius and keep a single rim hairline in scoped CSS. In a
  consumer with the design layer loaded the nav now reads as translucent
  glass — the utility-vs-role specificity coin flip that rendered the same nav
  opaque in Techstack and glass in CMO is gone.
- **Card Beacon signature is finish-adaptive.** `ServerCard`, `ServiceCard`
  and `ServiceCardCompact` keep their signature (accent wash, top hairline,
  hover glow/lift, glyph glow) as the card family's own default standard —
  §7 sanctions cards as the accent surface — but every effect now reads a
  `--kf-card-*` custom property (`wash`, `hairline`, `hover-border`,
  `hover-glow`, `hover-lift`, `selected-border`, `selected-glow`,
  `glyph-glow`) whose fallback is the shipped kombify baseline. A finish
  adapts the signature by overriding the inherited properties; rendered
  output is unchanged while nothing overrides. `prefers-reduced-motion` now
  also stills the glyph scale/rotate answer in the detailed cards.

### Added

- **`styles.css` ships zero-specificity shell fallbacks**: `:where()` rules
  give `plate`/`header`/`footer`/`menu-plate` carriers a plain opaque surface
  in consumers that have not loaded `@kombiverselabs/design`, and lose to
  every role recipe the moment it loads.
- **Rail foot owns onboarding, notifications, and account.** `SidebarNav`
  stacks those three in one foot with a dedicated `notifications` snippet;
  collapsed controls are 40px and centred. Compact getting-started uses the
  same horizontal progress recipe as the detailed row, and compacting is
  reversible (`onboarding.ui.getting_started.expand`). The `NotificationBell`
  glyph matches that 40px square instead of sitting off-centre against the
  avatar.

## 0.9.0

Minor, not patch — this release *removes* published tokens. Under 0.x SemVer a
removal is signalled by the minor position, which is the whole reason the line
moved (see "Removed" below and the versioning note at the end).

### Removed

- **Retired unused tokens from `styles.css`**: `--chart-1` … `--chart-5` and
  their Tailwind `@theme` mappings, `--corner-color-light`, and
  `--btn-secondary-shadow`. Verified unused before removal — zero utility uses
  and zero component reads across the Administration, Cloud, Techstack, cmo and
  ui-lab trees; each of Cloud, Techstack and ui-lab already defines its own
  `chart-*` values locally in `app.css`, so nothing resolved these through this
  package.
- These bytes physically left the package in the derived patch `0.8.83`, which
  understated the change. `0.9.0` is the correction, and it is being made
  *before* any consumer bumps: at the time of writing no repository outside
  kombify-Brand had resolved `0.8.83`, so no caret range ever picked up a silent
  removal. A consumer that did define one of these names locally is unaffected;
  a consumer that read them from here must define them itself.

### Changed

- **BREAKING for installers — the `@kombiverselabs/design` peer moved to
  `^0.9.0`** (was `^0.8.0`). A caret range on a 0.x version pins the minor, so
  this is not satisfied by `0.8.x`; the design and ui packages ship as one line
  and are bumped together.
- **Primary CTAs are now roles, not local accent CSS.** `Button` emits
  `data-kx="control"` plus `data-variant="primary"` for the primary variant only
  (the other three stay plain controls — `primary` is the sole variant the design
  contract defines). `ServiceCard`'s Open CTA carries the same pair. The local
  accent recipes those elements used to own — fill, glow, hover, brightness — are
  gone; `@kombiverselabs/design` ≥ 0.9.0 owns them.
  - `.kx-button--primary` keeps a **token floor** on purpose: `@kombiverselabs/design`
    is a peer, not a hard dependency, and a primary action must never be invisible
    when only `styles.css` is loaded. It cannot compete with the recipe — Svelte 5
    scopes with `:where()`, so the floor stays at specificity 0,1,0 against the
    recipe's 0,2,0.
  - The `brightness(.96)` hover now excludes the primary variant, where the
    recipe's accent glow answers instead.
- **`styles.css` is a generated artifact**, emitted from `tokens/colors_and_type.css`
  with a source SHA-256 receipt; `mise run tokens:check` fails on drift. It is no
  longer hand-maintained, which is what made the retirements above provable.

### Added

- **Token extras promoted into the generated source** and therefore into the
  published surface: the sidebar family (`SidebarNav`/`AppRail`, Techstack's
  `bg-sidebar` utilities), the corner/glow and button effect tokens
  (Administration's `style-kombify-line`, Cloud's `style-kombify-gradient`), the
  legacy `showcase`/`stack`/`admin` themes, and `--kf-system-card-radius`.
- `--corner-line-length` now has a definition. Every `style-kombify-line` alert
  rule read it and nothing defined it, so that accent rendered zero-width.
- Design roles adopted across the shipped components — service and server cards,
  `ServiceStatusBadge` (closed status vocabulary), `PlacementPath`, `StatusState`.

### Previously published on the 0.8 line

These shipped as derived `0.8.x` patches and had no heading of their own:

- Canonical service and server cards are square by default through the shared
  `--kf-system-card-radius` token, with a `data-system-card-shape="app"` opt-in for
  the normal app/window radius and a persistent `selected` state with stronger
  full-edge hover/focus illumination.
- `ServiceCard` and `ServiceCardCompact` gained unknown and pending runtime
  states, optional consumer labels, neutral status details, and a detailed-card
  footer, so products can adapt their data without a second service-card renderer.
- `ServerCard` gained optional labeled product facts, keeping runtime evidence
  inside the shared card instead of requiring a product-local renderer.
- The design peer was realigned from an impossible `0.1` range onto the published
  `0.8` line.

## 0.8.0

### Added

- **New `./server` export: `ServerCard`** (Beacon design server card; status badge mapping, facts line, metrics chips, consumer-owned actions snippet)
  - Status model: `healthy | degraded | offline | pending | unknown`, mapped onto the shared `ServiceStatusBadge` with per-state labels and a `statusLabel` override
  - Mono facts line: `address · domain (+N) · kit`, each segment optional
  - Up to 3 `.kf-metric` chips (e.g. CPU/RAM/Disk) and an optional tone-able note strip (`info | warning | error`)
  - `actions` snippet renders a consumer-owned action row after a separator — no hardcoded buttons
  - `detailsHref` links the header identity block; HTML attribute passthrough on the root element
  - Showcase: ui-lab `/kombify-ui/server`

## 0.5.1

### Patch Changes

- Warnungs-Cleanup und Release-Härtung:

  - reduziert Svelte-Warnings in `ui-lab` (A11y, veraltete dynamische Komponenten, implizite DOM-Schließung, reaktive Initialisierung)
  - reduziert Svelte-Warnings in `@kombiverselabs/ui` und `@kombify/auth`
  - stabilisiert UI-Lab-Demos ohne blockierende Typecheck-Fehler
  - bereitet Workspace-Packages für den nächsten Versions-Release vor

## 0.6.0 (unreleased)

### Breaking Changes

- **Removed `./auth` export** — Auth components (`LoginCloud`, `LoginSelfHosted`) moved to `@kombify/auth`. Import from `@kombify/auth` instead.

### Added

- **New `./service` export — ecosystem-wide Service Cards (Beacon design):**
  - `ServiceCard` — detailed card with status badge, placement path, metrics row, status strips (migration/update/frozen/error) and on-demand action callbacks
  - `ServiceCardCompact` — wide compact density for drag & drop boards (grip, path widget, quick actions, HTML attribute passthrough for `draggable`)
  - `ServiceStatusBadge`, `PlacementPath` — shared building blocks
  - Status model: `running | stopped | migrating | update | frozen | error`; placements `local | cloud | serverless`
  - Tool theming via existing `--primary` token (theme-stack/sim/cloud/stackkits), semantic states stay stable; uses `--frozen` token with built-in fallback
  - Showcase: ui-lab `/kombify-ui/service`

### Changed

- **Migrated to `@lucide/svelte`** — Replaced `lucide-svelte` with the official `@lucide/svelte` package (^0.562.0).
- **TypeScript** — Aligned to `^5.8.0` across all kombify packages.

## 0.5.0

### Components

- Shell: `SidebarNav`, `FooterModern`, `FooterCompact`, `InlineTabNav`, `ThemeToggle`
- Identity: `StackIdentityIcon`, `StackIdentityName`, `StackIdentityDisplay`, `StackIdentityBadge`, `StackIdentityCard`, `StackIdentityEditor`, `StackIdentityWatermark`, `StackIdentityGreeting`, `StackIdentityHeader`, `StackIdentityAvatar`
- Auth: `LoginCloud`, `LoginSelfHosted` (deprecated — moved to `@kombify/auth`)
- Character catalog with 16 characters (10 playful, 6 futuristic)
- OKLch-based glow color presets
- `resolveIdentityTheme()` API for cross-tool reuse
