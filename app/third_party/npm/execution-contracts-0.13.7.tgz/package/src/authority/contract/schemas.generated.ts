// Generated from kombify-Core authority contract merge 33cca9c1a86212de74b288785046d46daba2a84c. Do not edit.
// Regenerate: node scripts/generate-authority-contract.mjs (KOMBIFY_AUTHORITY_SOURCE_REPO points to workspace Git repository).
// oxlint-disable unicorn/no-thenable -- JSON Schema keyword.

export const AGENT_AUTHORITY_CORE_COMMIT = "33cca9c1a86212de74b288785046d46daba2a84c" as const;

export const agentAuthoritySchemaDocuments: Readonly<Record<string, unknown>> = {
  "agent-authority.v2.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v2/agent-authority.schema.json",
    title: "Kombify AgentAuthorityGrantV2",
    description:
      "One append-only Cloud-owned standing-grant generation. Current Cloud status and the matching FGA tuple are both required; this document alone grants nothing.",
    type: "object",
    additionalProperties: false,
    required: ["schemaVersion", "binding", "grantDigest", "status"],
    properties: {
      schemaVersion: {
        const: "kombify.agent-authority-grant.v2",
      },
      binding: {
        $ref: "#/$defs/grantBinding",
      },
      grantDigest: {
        $ref: "#/$defs/digest",
      },
      status: {
        enum: ["pending", "active", "revoking", "revoked"],
      },
      revokedAt: {
        type: "string",
        format: "date-time",
      },
    },
    allOf: [
      {
        if: {
          properties: {
            status: {
              const: "revoked",
            },
          },
          required: ["status"],
        },
        then: {
          required: ["revokedAt"],
        },
      },
    ],
    $defs: {
      digest: {
        type: "string",
        pattern: "^sha256:[0-9a-f]{64}$",
      },
      actor: {
        oneOf: [
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "id"],
            properties: {
              kind: {
                const: "user",
              },
              id: {
                type: "string",
                minLength: 1,
              },
            },
          },
          {
            $ref: "#/$defs/agentActor",
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "id"],
            properties: {
              kind: {
                const: "service",
              },
              id: {
                type: "string",
                minLength: 1,
              },
            },
          },
        ],
      },
      agentActor: {
        type: "object",
        additionalProperties: false,
        required: ["kind", "id", "agentClass", "templateDigest"],
        properties: {
          kind: {
            const: "agent",
          },
          id: {
            type: "string",
            minLength: 1,
            description:
              "The authenticated ai_agent_instances.id, never a shared class, client id, or OBO subject.",
          },
          agentClass: {
            type: "string",
            minLength: 1,
          },
          templateDigest: {
            $ref: "#/$defs/digest",
          },
        },
      },
      facet: {
        enum: ["use", "self_activate", "issue", "delegate", "approve", "revoke"],
      },
      basis: {
        type: "object",
        additionalProperties: false,
        required: ["grantId", "generation", "facet", "grantDigest"],
        properties: {
          grantId: {
            type: "string",
            minLength: 1,
          },
          generation: {
            type: "integer",
            minimum: 1,
            maximum: 9007199254740991,
          },
          facet: {
            $ref: "#/$defs/facet",
          },
          grantDigest: {
            $ref: "#/$defs/digest",
          },
        },
        description:
          "A leaf reference only. Consumers resolve the exact active Cloud generation and matching FGA tuple before relying on it.",
      },
      authorityChainLink: {
        type: "object",
        additionalProperties: false,
        required: ["basis", "issuer", "grantee", "issuedAt"],
        properties: {
          basis: {
            $ref: "#/$defs/basis",
          },
          issuer: {
            $ref: "#/$defs/actor",
          },
          grantee: {
            $ref: "#/$defs/agentActor",
          },
          issuedAt: {
            type: "string",
            format: "date-time",
          },
        },
      },
      resource: {
        oneOf: [
          {
            $ref: "#/$defs/legacyResource",
          },
          {
            $ref: "#/$defs/walletResourceV1",
          },
          {
            $ref: "#/$defs/walletResourceV2",
          },
          {
            $ref: "#/$defs/walletResourceV3",
          },
        ],
      },
      legacyResource: {
        type: "object",
        additionalProperties: false,
        required: ["definitionId", "resource", "bindings"],
        properties: {
          definitionId: {
            type: "string",
            minLength: 1,
          },
          resource: {
            type: "string",
            minLength: 1,
          },
          bindings: {
            type: "object",
            additionalProperties: {
              type: "string",
              minLength: 1,
            },
          },
        },
      },
      envelope: {
        type: "object",
        additionalProperties: false,
        required: ["definitionIds", "resources", "shapes", "maxTtlSeconds", "budget"],
        properties: {
          definitionIds: {
            type: "array",
            items: {
              type: "string",
              minLength: 1,
            },
            minItems: 1,
            uniqueItems: true,
          },
          resources: {
            type: "array",
            items: {
              $ref: "#/$defs/resource",
            },
            minItems: 1,
            uniqueItems: true,
          },
          shapes: {
            type: "array",
            items: {
              enum: ["durable", "short-ttl", "one-shot"],
            },
            minItems: 1,
            uniqueItems: true,
          },
          maxTtlSeconds: {
            type: "integer",
            minimum: 1,
            maximum: 9007199254740991,
          },
          budget: {
            $ref: "activation-request.v1.schema.json#/$defs/capabilityBudget",
          },
          delegatedFacets: {
            type: "array",
            items: {
              $ref: "#/$defs/facet",
            },
            uniqueItems: true,
          },
          maxDelegationDepth: {
            type: "integer",
            minimum: 0,
            maximum: 9007199254740991,
          },
          maxChildren: {
            type: "integer",
            minimum: 0,
            maximum: 9007199254740991,
          },
        },
      },
      grantBinding: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "grantId",
          "generation",
          "tenantId",
          "subject",
          "grantee",
          "facet",
          "envelope",
          "issuer",
          "policyRevision",
          "issuedAt",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.agent-authority-binding.v2",
          },
          grantId: {
            type: "string",
            minLength: 1,
          },
          generation: {
            type: "integer",
            minimum: 1,
            maximum: 9007199254740991,
          },
          tenantId: {
            type: "string",
            minLength: 1,
          },
          subject: {
            type: "string",
            minLength: 1,
          },
          grantee: {
            $ref: "#/$defs/agentActor",
          },
          facet: {
            $ref: "#/$defs/facet",
          },
          envelope: {
            $ref: "#/$defs/envelope",
          },
          issuer: {
            $ref: "#/$defs/actor",
          },
          parentBasis: {
            $ref: "#/$defs/basis",
          },
          policyRevision: {
            $ref: "#/$defs/digest",
          },
          issuedAt: {
            type: "string",
            format: "date-time",
            description:
              "Immutable creation time of this exact generation, included in grantDigest.",
          },
          expiresAt: {
            type: "string",
            format: "date-time",
          },
        },
        allOf: [
          {
            if: {
              properties: {
                facet: {
                  const: "delegate",
                },
              },
              required: ["facet"],
            },
            then: {
              properties: {
                envelope: {
                  required: ["delegatedFacets", "maxDelegationDepth", "maxChildren"],
                },
              },
            },
          },
        ],
      },
      policy: {
        type: "object",
        additionalProperties: false,
        required: ["schemaVersion", "revision", "mode"],
        properties: {
          schemaVersion: {
            const: "kombify.activation-policy.v2",
          },
          revision: {
            $ref: "#/$defs/digest",
          },
          mode: {
            const: "agent",
            description:
              "The only v2 decision mode admitted by this contract. Legacy human, step-up, two-person, and operator policies remain on v1.",
          },
        },
      },
      intent: {
        oneOf: [
          {
            $ref: "#/$defs/legacyIntent",
          },
          {
            $ref: "#/$defs/walletOperationIntentV1",
          },
          {
            $ref: "#/$defs/walletOperationIntentV2",
          },
          {
            $ref: "#/$defs/walletOperationIntentV3",
          },
        ],
      },
      legacyIntent: {
        type: "object",
        additionalProperties: false,
        required: ["intentId", "action", "intentDigest", "idempotencyKey"],
        properties: {
          intentId: {
            type: "string",
            minLength: 1,
          },
          action: {
            type: "string",
            minLength: 1,
          },
          intentDigest: {
            $ref: "#/$defs/digest",
          },
          idempotencyKey: {
            type: "string",
            minLength: 1,
          },
        },
      },
      monetaryReservation: {
        type: "object",
        additionalProperties: false,
        required: [
          "allocationId",
          "reservationId",
          "reservationDigest",
          "intentDigest",
          "currency",
          "maximumMinor",
          "merchantRef",
          "purposeRef",
          "expiresAt",
        ],
        properties: {
          allocationId: {
            type: "string",
            minLength: 1,
          },
          reservationId: {
            type: "string",
            minLength: 1,
          },
          reservationDigest: {
            $ref: "#/$defs/digest",
            description:
              "The immutable commerce reservation request_digest, exposed on the wire as reservationDigest; no second payment-proof digest is accepted.",
          },
          intentDigest: {
            $ref: "#/$defs/digest",
          },
          currency: {
            type: "string",
            pattern: "^[A-Z]{3}$",
          },
          maximumMinor: {
            type: "string",
            pattern: "^(0|[1-9][0-9]*)$",
          },
          merchantRef: {
            type: "string",
            minLength: 1,
          },
          purposeRef: {
            type: "string",
            minLength: 1,
          },
          expiresAt: {
            type: "string",
            format: "date-time",
          },
        },
      },
      walletIdentityV1: {
        type: "object",
        additionalProperties: false,
        required: ["owner", "custodyNamespace", "itemId", "resourceType", "version"],
        properties: {
          owner: {
            type: "string",
            minLength: 1,
          },
          custodyNamespace: {
            type: "string",
            minLength: 1,
          },
          itemId: {
            type: "string",
            minLength: 1,
          },
          resourceType: {
            enum: [
              "generic_secret",
              "oauth_connection",
              "node_access_profile",
              "ai_credential",
              "device_key",
            ],
          },
          version: {
            type: "string",
            pattern: "^[1-9][0-9]{0,18}$",
          },
        },
        description:
          "Immutable custody identity. The authenticated owner and stored namespace/type must match; version resolves exactly and never means latest.",
      },
      walletScopeV1: {
        oneOf: [
          {
            type: "object",
            additionalProperties: false,
            required: ["kind"],
            properties: {
              kind: {
                const: "account",
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "projectId", "environment"],
            properties: {
              kind: {
                const: "project_environment",
              },
              projectId: {
                type: "string",
                minLength: 1,
              },
              environment: {
                type: "string",
                minLength: 1,
              },
            },
          },
        ],
      },
      walletCustodianV1: {
        oneOf: [
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "serviceId"],
            properties: {
              kind: {
                const: "wallet_store",
              },
              serviceId: {
                type: "string",
                minLength: 1,
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "connectionId", "provider", "accountRef"],
            properties: {
              kind: {
                const: "auth0_token_vault",
              },
              connectionId: {
                type: "string",
                minLength: 1,
              },
              provider: {
                type: "string",
                minLength: 1,
              },
              accountRef: {
                type: "string",
                minLength: 1,
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "serviceId", "custodyRef"],
            properties: {
              kind: {
                const: "product",
              },
              serviceId: {
                type: "string",
                minLength: 1,
              },
              custodyRef: {
                type: "string",
                minLength: 1,
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "installationId", "installationGeneration"],
            properties: {
              kind: {
                const: "device",
              },
              installationId: {
                type: "string",
                minLength: 1,
              },
              installationGeneration: {
                type: "integer",
                minimum: 1,
                maximum: 9007199254740991,
              },
            },
          },
        ],
      },
      walletProtectionV1: {
        oneOf: [
          {
            type: "object",
            additionalProperties: false,
            required: ["kind"],
            properties: {
              kind: {
                const: "service_managed",
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind"],
            properties: {
              kind: {
                const: "user_unlocked",
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "ownerPresence"],
            properties: {
              kind: {
                const: "custodian_managed",
              },
              ownerPresence: {
                enum: ["required", "not_required"],
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind"],
            properties: {
              kind: {
                const: "product_native",
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind"],
            properties: {
              kind: {
                const: "non_exportable",
              },
            },
          },
        ],
      },
      walletDisclosureV1: {
        oneOf: [
          {
            type: "object",
            additionalProperties: false,
            required: ["kind"],
            properties: {
              kind: {
                const: "use_only",
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "actions"],
            properties: {
              kind: {
                const: "owner_authorized",
              },
              actions: {
                type: "array",
                items: {
                  enum: ["reveal", "export", "process_injection"],
                },
                minItems: 1,
                uniqueItems: true,
              },
            },
          },
        ],
      },
      walletResourceV1: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "definitionId",
          "resource",
          "bindings",
          "identity",
          "scope",
          "custodian",
          "protection",
          "disclosure",
          "supportedActions",
          "classification",
          "lifecycle",
          "metadataRevision",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.wallet-resource.v1",
          },
          definitionId: {
            type: "string",
            minLength: 1,
          },
          resource: {
            type: "string",
            minLength: 1,
          },
          bindings: {
            type: "object",
            additionalProperties: {
              type: "string",
              minLength: 1,
            },
          },
          identity: {
            $ref: "#/$defs/walletIdentityV1",
          },
          scope: {
            $ref: "#/$defs/walletScopeV1",
          },
          custodian: {
            $ref: "#/$defs/walletCustodianV1",
          },
          protection: {
            $ref: "#/$defs/walletProtectionV1",
          },
          disclosure: {
            $ref: "#/$defs/walletDisclosureV1",
          },
          supportedActions: {
            type: "array",
            items: {
              enum: [
                "capture",
                "rotate",
                "brokered_use",
                "delete",
                "restore",
                "reveal",
                "export",
                "process_injection",
                "disconnect",
              ],
            },
            minItems: 1,
            uniqueItems: true,
          },
          classification: {
            enum: ["synthetic", "real"],
          },
          lifecycle: {
            enum: ["pending", "active", "revoked", "deleted", "compromised"],
          },
          metadataRevision: {
            type: "integer",
            minimum: 1,
            maximum: 9007199254740991,
          },
        },
        allOf: [
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "wallet_store",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "generic_secret",
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      enum: ["service_managed", "user_unlocked"],
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "auth0_token_vault",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "oauth_connection",
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      const: "custodian_managed",
                    },
                  },
                },
                disclosure: {
                  properties: {
                    kind: {
                      const: "use_only",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "product",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      enum: ["oauth_connection", "node_access_profile", "ai_credential"],
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      const: "product_native",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "device",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "device_key",
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      const: "non_exportable",
                    },
                  },
                },
                disclosure: {
                  properties: {
                    kind: {
                      const: "use_only",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "ai_credential",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                disclosure: {
                  properties: {
                    kind: {
                      const: "use_only",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                protection: {
                  properties: {
                    kind: {
                      const: "user_unlocked",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["protection"],
            },
            then: {
              properties: {
                disclosure: {
                  properties: {
                    kind: {
                      const: "owner_authorized",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                disclosure: {
                  properties: {
                    kind: {
                      const: "use_only",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["disclosure"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: ["capture", "rotate", "brokered_use", "delete", "restore", "disconnect"],
                  },
                },
              },
            },
          },
        ],
        description:
          "Reference projection only, no reusable credential or crypto material. Custodian/protection/disclosure are independent and enforced, not annotations. supportedActions is intersected with disclosure policy and current authority.",
      },
      walletRecipientV1: {
        type: "object",
        additionalProperties: false,
        required: ["keyId", "keyGeneration", "recipientKeyThumbprint"],
        properties: {
          keyId: {
            type: "string",
            minLength: 1,
          },
          keyGeneration: {
            type: "string",
            pattern: "^[1-9][0-9]{0,18}$",
          },
          recipientKeyThumbprint: {
            type: "string",
            pattern: "^[A-Za-z0-9_-]{43}$",
            description:
              "RFC 7638 SHA-256 JWK thumbprint in unpadded base64url; not a sha256:hex Core digest.",
          },
        },
      },
      walletExecutionContextV1: {
        oneOf: [
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "clientSessionId"],
            properties: {
              kind: {
                const: "owner_client",
              },
              clientSessionId: {
                type: "string",
                minLength: 1,
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "agentInstanceId", "runId"],
            properties: {
              kind: {
                const: "agent_run",
              },
              agentInstanceId: {
                type: "string",
                minLength: 1,
              },
              runId: {
                type: "string",
                minLength: 1,
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: [
              "kind",
              "workSessionId",
              "threadId",
              "projectId",
              "environment",
              "runtimeSessionId",
              "installationId",
              "installationGeneration",
              "providerSessionId",
            ],
            properties: {
              kind: {
                const: "owner_process",
              },
              workSessionId: {
                type: "string",
                minLength: 1,
              },
              threadId: {
                type: "string",
                minLength: 1,
              },
              projectId: {
                type: "string",
                minLength: 1,
              },
              environment: {
                type: "string",
                minLength: 1,
              },
              runtimeSessionId: {
                type: "string",
                minLength: 1,
              },
              installationId: {
                type: "string",
                minLength: 1,
              },
              installationGeneration: {
                type: "integer",
                minimum: 1,
                maximum: 9007199254740991,
              },
              providerSessionId: {
                type: "string",
                minLength: 1,
              },
            },
          },
        ],
      },
      walletExecutionContextV3: {
        oneOf: [
          {
            $ref: "#/$defs/walletExecutionContextV1",
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "serviceId", "recipientGeneration"],
            properties: {
              kind: {
                const: "product_service",
              },
              serviceId: {
                type: "string",
                pattern: "^[a-z][a-z0-9-]{0,62}$",
              },
              recipientGeneration: {
                type: "string",
                pattern: "^[1-9][0-9]{0,18}$",
              },
            },
          },
        ],
        description:
          "v3 execution contexts: the v1 contexts plus product_service, a kombify product backend (actor kind service, id serviceId) acting without a person present on the owner's standing assignment to that service. Its results are sealed to the service's enrolled recipient service:<serviceId> at recipientGeneration, a key the executor pins itself.",
      },
      walletOperationBindingV1: {
        type: "object",
        additionalProperties: false,
        required: [
          "operationId",
          "resource",
          "executionTenantId",
          "subject",
          "actor",
          "authenticationProfile",
          "audience",
          "executor",
          "target",
          "argumentsDigest",
          "context",
          "nonce",
          "expiresAt",
        ],
        properties: {
          operationId: {
            type: "string",
            minLength: 1,
          },
          resource: {
            $ref: "#/$defs/walletResourceV1",
          },
          executionTenantId: {
            type: "string",
            minLength: 1,
          },
          subject: {
            type: "string",
            minLength: 1,
          },
          actor: {
            $ref: "#/$defs/actor",
          },
          authenticationProfile: {
            enum: ["owner_interactive", "delegated_user"],
          },
          audience: {
            type: "string",
            minLength: 1,
          },
          executor: {
            type: "object",
            additionalProperties: false,
            required: ["id", "recipient"],
            properties: {
              id: {
                type: "string",
                minLength: 1,
              },
              recipient: {
                $ref: "#/$defs/walletRecipientV1",
              },
            },
          },
          target: {
            type: "object",
            additionalProperties: false,
            required: ["id", "revision"],
            properties: {
              id: {
                type: "string",
                minLength: 1,
              },
              revision: {
                type: "string",
                minLength: 1,
              },
            },
          },
          argumentsDigest: {
            $ref: "#/$defs/digest",
          },
          transfer: {
            $ref: "#/$defs/walletTransferBindingV1",
          },
          context: {
            $ref: "#/$defs/walletExecutionContextV1",
          },
          nonce: {
            type: "string",
            minLength: 1,
          },
          expiresAt: {
            type: "string",
            format: "date-time",
          },
        },
        description:
          "Exact normalized nonsecret effect context; execution tenant is independent of custody namespace. argumentsDigest never hashes a secret value. Transfer digest binds the exact finalized compact JWE UTF8 bytes. Proof and authority are independently verified at admission/effect time.",
        allOf: [
          {
            if: {
              properties: {
                context: {
                  properties: {
                    kind: {
                      const: "agent_run",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["context"],
            },
            then: {
              properties: {
                actor: {
                  properties: {
                    kind: {
                      const: "agent",
                    },
                  },
                },
                authenticationProfile: {
                  const: "delegated_user",
                },
              },
            },
            else: {
              properties: {
                actor: {
                  properties: {
                    kind: {
                      const: "user",
                    },
                  },
                },
                authenticationProfile: {
                  const: "owner_interactive",
                },
              },
            },
          },
        ],
      },
      walletOperationIntentV1: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "intentId",
          "action",
          "intentDigest",
          "idempotencyKey",
          "operation",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.wallet-operation-intent.v1",
          },
          intentId: {
            type: "string",
            minLength: 1,
          },
          action: {
            enum: [
              "capture",
              "rotate",
              "brokered_use",
              "delete",
              "restore",
              "reveal",
              "export",
              "process_injection",
              "disconnect",
            ],
          },
          intentDigest: {
            $ref: "#/$defs/digest",
          },
          idempotencyKey: {
            type: "string",
            minLength: 1,
          },
          operation: {
            $ref: "#/$defs/walletOperationBindingV1",
          },
        },
        allOf: [
          {
            if: {
              properties: {
                action: {
                  enum: ["capture", "rotate", "reveal", "export", "process_injection"],
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  required: ["transfer"],
                },
              },
            },
            else: {
              properties: {
                operation: {
                  not: {
                    required: ["transfer"],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                action: {
                  const: "process_injection",
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  properties: {
                    context: {
                      properties: {
                        kind: {
                          const: "owner_process",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                action: {
                  enum: ["reveal", "export", "process_injection"],
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  properties: {
                    authenticationProfile: {
                      const: "owner_interactive",
                    },
                    resource: {
                      properties: {
                        disclosure: {
                          properties: {
                            kind: {
                              const: "owner_authorized",
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        ],
        description:
          "Intent digest domain kombify.wallet-operation-intent.digest.v1 binds every member except intentDigest using Core canonical JSON. Existing v2 request/decision/grant digest domains and JWS type remain unchanged. No proof of permission from schema acceptance.",
      },
      walletTransferBindingV1: {
        type: "object",
        additionalProperties: false,
        required: ["schemaVersion", "ciphertextDigest", "serialization"],
        properties: {
          schemaVersion: {
            const: "kombify.wallet-transfer-binding.v1",
          },
          ciphertextDigest: {
            $ref: "#/$defs/digest",
          },
          serialization: {
            const: "compact_jwe_utf8",
          },
        },
        description:
          "sha256 of exact finalized compact JWE UTF8 bytes, not canonical JSON and not plaintext. Finalize encryption before computing the containing intent digest and independent owner proof; do not embed that resulting digest in the same ciphertext.",
      },
      walletOwnerApprovalProtectedHeaderV1: {
        type: "object",
        additionalProperties: false,
        required: ["alg", "typ", "kid"],
        properties: {
          alg: {
            const: "RS256",
          },
          typ: {
            const: "kombify.wallet-owner-approval.v1+jwt",
          },
          kid: {
            type: "string",
            minLength: 1,
            maxLength: 128,
            pattern: "^[A-Za-z0-9._:-]+$",
          },
        },
        description:
          "Verifier boundary profile for the independently verified Cloud JWS. Schema acceptance does not verify a signature. No caller-selected jku/jwk/x5u or alternate algorithm is admitted.",
      },
      walletOwnerApprovalReceiptV1: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "iss",
          "aud",
          "jti",
          "keyGeneration",
          "iat",
          "exp",
          "ownerPin",
          "approval",
          "authentication",
          "audit",
          "intent",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.wallet-owner-approval-receipt.v1",
          },
          iss: {
            const: "urn:kombify:wallet:owner-approval:cloud",
          },
          aud: {
            const: "urn:kombify:wallet-store:owner-approval",
          },
          jti: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          keyGeneration: {
            type: "string",
            pattern: "^[1-9][0-9]{0,18}$",
          },
          iat: {
            type: "integer",
            minimum: 0,
            maximum: 9007199254740991,
          },
          exp: {
            type: "integer",
            minimum: 0,
            maximum: 9007199254740991,
          },
          ownerPin: {
            type: "object",
            additionalProperties: false,
            required: ["accountId", "issuer", "subject", "custodyNamespace"],
            properties: {
              accountId: {
                type: "string",
                minLength: 1,
                maxLength: 256,
                pattern: "^[^\\u0000-\\u001f\\u007f]+$",
              },
              issuer: {
                type: "string",
                maxLength: 256,
                format: "uri",
                pattern: "^https://[A-Za-z0-9.-]+/$",
              },
              subject: {
                type: "string",
                minLength: 1,
                maxLength: 256,
                pattern: "^[^\\u0000-\\u001f\\u007f]+$",
              },
              custodyNamespace: {
                type: "string",
                minLength: 1,
                maxLength: 256,
                pattern: "^[^\\u0000-\\u001f\\u007f]+$",
              },
            },
          },
          approval: {
            type: "object",
            additionalProperties: false,
            required: ["id", "revision", "createdAt", "decidedAt"],
            properties: {
              id: {
                type: "string",
                minLength: 1,
                maxLength: 256,
                pattern: "^[^\\u0000-\\u001f\\u007f]+$",
              },
              revision: {
                type: "integer",
                minimum: 2,
                maximum: 9007199254740991,
              },
              createdAt: {
                type: "string",
                format: "date-time",
              },
              decidedAt: {
                type: "string",
                format: "date-time",
              },
            },
          },
          authentication: {
            type: "object",
            additionalProperties: false,
            required: ["profile", "mfa", "authTime"],
            properties: {
              profile: {
                const: "owner_interactive",
              },
              mfa: {
                const: true,
              },
              authTime: {
                type: "integer",
                minimum: 0,
                maximum: 9007199254740991,
              },
            },
          },
          audit: {
            type: "object",
            additionalProperties: false,
            required: ["eventId", "eventDigest", "confirmedAt"],
            properties: {
              eventId: {
                type: "string",
                minLength: 1,
                maxLength: 256,
                pattern: "^[^\\u0000-\\u001f\\u007f]+$",
              },
              eventDigest: {
                $ref: "#/$defs/digest",
              },
              confirmedAt: {
                type: "string",
                format: "date-time",
                description:
                  "When the issuer observed the exact retained approval audit event through its authenticated delivery reader; not when delivery occurred.",
              },
            },
          },
          intent: {
            $ref: "#/$defs/walletOperationIntentV1",
          },
        },
        description:
          "Closed Cloud-signed human intent proof, not an AgentAuthorityGrant, ActivationDecision, eligibility/entitlement, current revocation or recipient-manifest authority. Semantics require exact retained owner/approved-row/audit binding, recomputed v1 intent digest, fresh post-creation MFA, and a positive lifetime of at most 60 seconds bounded by intent expiry. Verifiers independently pin the protected header/key generation and apply current policy plus atomic replay/effect gates.",
      },
      walletIdentityV2: {
        type: "object",
        additionalProperties: false,
        required: ["owner", "custodyNamespace", "itemId", "resourceType"],
        properties: {
          owner: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          custodyNamespace: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          itemId: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          resourceType: {
            enum: [
              "generic_secret",
              "oauth_connection",
              "node_access_profile",
              "ai_credential",
              "device_key",
            ],
          },
        },
        description:
          "Immutable stable item identity, independently resolved from existing custody authority. Version belongs to the exact operation.",
      },
      walletReferenceV1: {
        oneOf: [
          {
            type: "object",
            additionalProperties: false,
            required: ["schemaVersion", "kind", "vaultRef"],
            properties: {
              schemaVersion: {
                const: "kombify.wallet-reference.v1",
              },
              kind: {
                const: "secret",
              },
              vaultRef: {
                type: "string",
                pattern: "^(?!workloads$)[a-z0-9][a-z0-9._-]{0,127}$",
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["schemaVersion", "kind", "vaultRef"],
            properties: {
              schemaVersion: {
                const: "kombify.wallet-reference.v1",
              },
              kind: {
                const: "vault_ref",
              },
              vaultRef: {
                type: "string",
                minLength: 1,
                maxLength: 256,
                pattern: "^[^\\u0000-\\u001f\\u007f]+$",
              },
            },
          },
        ],
        description:
          "Mapping of existing authorities, never a resolver: secret://<vaultRef>/<itemId>, or opaque product vaultRef plus independently resolved existing resource.",
      },
      walletVersionConstraintV1: {
        oneOf: [
          {
            type: "object",
            additionalProperties: false,
            required: ["kind"],
            properties: {
              kind: {
                const: "item",
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "version"],
            properties: {
              kind: {
                const: "exact",
              },
              version: {
                type: "string",
                pattern: "^[1-9][0-9]{0,18}$",
              },
            },
          },
        ],
      },
      walletResourceV2: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "definitionId",
          "resource",
          "bindings",
          "identity",
          "scope",
          "custodian",
          "protection",
          "disclosure",
          "supportedActions",
          "classification",
          "reference",
          "versionConstraint",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.wallet-resource.v2",
          },
          definitionId: {
            type: "string",
            minLength: 1,
          },
          resource: {
            type: "string",
            minLength: 1,
            maxLength: 512,
          },
          bindings: {
            type: "object",
            additionalProperties: {
              type: "string",
              minLength: 1,
            },
          },
          identity: {
            $ref: "#/$defs/walletIdentityV2",
          },
          scope: {
            $ref: "#/$defs/walletScopeV1",
          },
          custodian: {
            $ref: "#/$defs/walletCustodianV1",
          },
          protection: {
            $ref: "#/$defs/walletProtectionV1",
          },
          disclosure: {
            $ref: "#/$defs/walletDisclosureV1",
          },
          supportedActions: {
            type: "array",
            items: {
              enum: [
                "capture",
                "rotate",
                "brokered_use",
                "delete",
                "restore",
                "reveal",
                "export",
                "process_injection",
                "disconnect",
              ],
            },
            minItems: 1,
            uniqueItems: true,
          },
          classification: {
            enum: ["synthetic", "real"],
          },
          reference: {
            $ref: "#/$defs/walletReferenceV1",
          },
          versionConstraint: {
            $ref: "#/$defs/walletVersionConstraintV1",
          },
        },
        allOf: [
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "wallet_store",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "generic_secret",
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      enum: ["service_managed", "user_unlocked"],
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "auth0_token_vault",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "oauth_connection",
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      const: "custodian_managed",
                    },
                  },
                },
                disclosure: {
                  properties: {
                    kind: {
                      const: "use_only",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "product",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      enum: ["oauth_connection", "node_access_profile", "ai_credential"],
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      const: "product_native",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "device",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "device_key",
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      const: "non_exportable",
                    },
                  },
                },
                disclosure: {
                  properties: {
                    kind: {
                      const: "use_only",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "ai_credential",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                disclosure: {
                  properties: {
                    kind: {
                      const: "use_only",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                protection: {
                  properties: {
                    kind: {
                      const: "user_unlocked",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["protection"],
            },
            then: {
              properties: {
                disclosure: {
                  properties: {
                    kind: {
                      const: "owner_authorized",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                disclosure: {
                  properties: {
                    kind: {
                      const: "use_only",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["disclosure"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: ["capture", "rotate", "brokered_use", "delete", "restore", "disconnect"],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                classification: {
                  const: "synthetic",
                },
              },
              required: ["classification"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    custodyNamespace: {
                      pattern: "^synthetic:",
                    },
                  },
                  required: ["custodyNamespace"],
                },
              },
              required: ["identity"],
            },
            else: {
              properties: {
                identity: {
                  properties: {
                    custodyNamespace: {
                      not: {
                        pattern: "^synthetic:",
                      },
                    },
                  },
                  required: ["custodyNamespace"],
                },
              },
              required: ["identity"],
            },
          },
          {
            if: {
              properties: {
                reference: {
                  properties: {
                    kind: {
                      const: "secret",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["reference"],
            },
            then: {
              allOf: [
                {
                  properties: {
                    resource: {
                      pattern:
                        "^secret://(?!workloads/)[a-z0-9][a-z0-9._-]{0,127}/[A-Za-z0-9][A-Za-z0-9._-]{0,255}$",
                    },
                  },
                  required: ["resource"],
                },
                {
                  properties: {
                    identity: {
                      properties: {
                        itemId: {
                          pattern: "^[A-Za-z0-9][A-Za-z0-9._-]{0,255}$",
                        },
                      },
                      required: ["itemId"],
                    },
                  },
                  required: ["identity"],
                },
              ],
            },
          },
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "wallet_store",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                reference: {
                  properties: {
                    kind: {
                      const: "secret",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["reference"],
            },
            else: {
              properties: {
                reference: {
                  properties: {
                    kind: {
                      const: "vault_ref",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["reference"],
            },
          },
        ],
        description:
          "Stable eligibility and exact policy projection. Full equality remains mandatory. Current lifecycle/metadata revision are operation facts. Item-wide eligibility survives ordinary version changes; exact eligibility pins versionConstraint. All namespaces require independently registered owner/custodian/classification evidence; synthetic: is reserved.",
      },
      walletOperationBindingV2: {
        type: "object",
        additionalProperties: false,
        required: [
          "operationId",
          "resource",
          "executionTenantId",
          "subject",
          "actor",
          "authenticationProfile",
          "admissionAudience",
          "executor",
          "target",
          "argumentsDigest",
          "context",
          "nonce",
          "expiresAt",
          "version",
          "versionRef",
          "lifecycle",
          "metadataRevision",
        ],
        properties: {
          operationId: {
            type: "string",
            minLength: 1,
          },
          resource: {
            $ref: "#/$defs/walletResourceV2",
          },
          executionTenantId: {
            type: "string",
            minLength: 1,
          },
          subject: {
            type: "string",
            minLength: 1,
          },
          actor: {
            $ref: "#/$defs/actor",
          },
          authenticationProfile: {
            enum: ["owner_interactive", "delegated_user"],
          },
          executor: {
            type: "object",
            additionalProperties: false,
            required: ["id", "recipient", "audience"],
            properties: {
              id: {
                type: "string",
                minLength: 1,
              },
              recipient: {
                $ref: "#/$defs/walletRecipientV1",
              },
              audience: {
                type: "string",
                minLength: 1,
                maxLength: 2048,
                format: "uri",
              },
            },
          },
          target: {
            type: "object",
            additionalProperties: false,
            required: ["id", "revision"],
            properties: {
              id: {
                type: "string",
                minLength: 1,
              },
              revision: {
                type: "string",
                minLength: 1,
              },
            },
          },
          argumentsDigest: {
            $ref: "#/$defs/digest",
          },
          transfer: {
            $ref: "#/$defs/walletTransferBindingV1",
          },
          context: {
            $ref: "#/$defs/walletExecutionContextV1",
          },
          nonce: {
            type: "string",
            minLength: 1,
          },
          expiresAt: {
            type: "string",
            format: "date-time",
          },
          admissionAudience: {
            type: "string",
            minLength: 1,
            maxLength: 2048,
            format: "uri",
          },
          version: {
            type: "string",
            pattern: "^[1-9][0-9]{0,18}$",
          },
          versionRef: {
            type: "string",
            minLength: 1,
            maxLength: 1024,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          lifecycle: {
            enum: ["pending", "active", "revoked", "deleted", "compromised"],
          },
          metadataRevision: {
            type: "integer",
            minimum: 1,
            maximum: 9007199254740991,
          },
        },
        description:
          "Exact immutable version, current lifecycle and metadata revision. Public admission and separately registered private executor audiences must differ. secret versionRef equals stable resource + /versions/ + exact decimal version; product versionRef comes from its existing resolver. No latest, implicit retry rotation or inferred authority.",
        allOf: [
          {
            if: {
              properties: {
                context: {
                  properties: {
                    kind: {
                      const: "agent_run",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["context"],
            },
            then: {
              properties: {
                actor: {
                  properties: {
                    kind: {
                      const: "agent",
                    },
                  },
                },
                authenticationProfile: {
                  const: "delegated_user",
                },
              },
            },
            else: {
              properties: {
                actor: {
                  properties: {
                    kind: {
                      const: "user",
                    },
                  },
                },
                authenticationProfile: {
                  const: "owner_interactive",
                },
              },
            },
          },
        ],
      },
      walletOperationIntentV2: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "intentId",
          "action",
          "intentDigest",
          "idempotencyKey",
          "operation",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.wallet-operation-intent.v2",
          },
          intentId: {
            type: "string",
            minLength: 1,
          },
          action: {
            enum: [
              "capture",
              "rotate",
              "brokered_use",
              "delete",
              "restore",
              "reveal",
              "export",
              "process_injection",
              "disconnect",
            ],
          },
          intentDigest: {
            $ref: "#/$defs/digest",
          },
          idempotencyKey: {
            type: "string",
            minLength: 1,
          },
          operation: {
            $ref: "#/$defs/walletOperationBindingV2",
          },
        },
        allOf: [
          {
            if: {
              properties: {
                action: {
                  enum: ["capture", "rotate", "reveal", "export", "process_injection"],
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  required: ["transfer"],
                },
              },
            },
            else: {
              properties: {
                operation: {
                  not: {
                    required: ["transfer"],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                action: {
                  const: "process_injection",
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  properties: {
                    context: {
                      properties: {
                        kind: {
                          const: "owner_process",
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                action: {
                  enum: ["reveal", "export", "process_injection"],
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  properties: {
                    authenticationProfile: {
                      const: "owner_interactive",
                    },
                    resource: {
                      properties: {
                        disclosure: {
                          properties: {
                            kind: {
                              const: "owner_authorized",
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        ],
        description:
          "Domain kombify.wallet-operation-intent.digest.v2 binds all members except intentDigest using Core canonical JSON. Requires schema plus semantic checks and independent current authority. No v1 reinterpretation or admission from representation.",
      },
      walletDenialReasonV1: {
        enum: [
          "wallet_admission_not_qualified",
          "wallet_unsupported_version",
          "wallet_reference_mismatch",
          "wallet_identity_mismatch",
          "wallet_namespace_classification_mismatch",
          "wallet_resource_policy_mismatch",
          "wallet_version_not_eligible",
          "wallet_resource_inactive",
          "wallet_audience_mismatch",
          "wallet_owner_proof_required",
          "wallet_recipient_unqualified",
          "wallet_key_generation_stale",
          "wallet_authority_revoked",
          "wallet_custody_unavailable",
          "wallet_audit_unavailable",
          "wallet_contract_invalid",
          "wallet_intent_digest_mismatch",
          "wallet_arguments_mismatch",
        ],
      },
      walletDenialV1: {
        allOf: [
          {
            $ref: "client-error-envelope.v1.schema.json",
          },
          {
            required: ["capability"],
            properties: {
              error_code: {
                const: "wallet_denied",
              },
              reason_code: {
                $ref: "#/$defs/walletDenialReasonV1",
              },
            },
          },
        ],
        description:
          "Profile of the existing client error envelope; existing APIs retain their transport error mappings. Guidance contains references only.",
      },
      walletRevocationEventV1: {
        type: "object",
        additionalProperties: false,
        required: ["schemaVersion", "eventId", "occurredAt", "identity", "trigger", "scope"],
        properties: {
          schemaVersion: {
            const: "kombify.wallet-revocation-event.v1",
          },
          eventId: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          occurredAt: {
            type: "string",
            format: "date-time",
          },
          identity: {
            $ref: "#/$defs/walletIdentityV2",
          },
          trigger: {
            enum: [
              "item_revoked",
              "item_deleted",
              "version_compromised",
              "owner_disabled",
              "owner_locked",
              "grant_revoked",
              "recipient_key_revoked",
              "custody_key_revoked",
              "organization_use_removed",
              "policy_changed",
            ],
          },
          scope: {
            oneOf: [
              {
                type: "object",
                additionalProperties: false,
                required: ["kind"],
                properties: {
                  kind: {
                    const: "item",
                  },
                },
              },
              {
                type: "object",
                additionalProperties: false,
                required: ["kind", "version"],
                properties: {
                  kind: {
                    const: "version",
                  },
                  version: {
                    type: "string",
                    pattern: "^[1-9][0-9]{0,18}$",
                  },
                },
              },
              {
                type: "object",
                additionalProperties: false,
                required: ["kind", "keyId", "keyGeneration"],
                properties: {
                  kind: {
                    const: "recipient_key",
                  },
                  keyId: {
                    type: "string",
                    minLength: 1,
                    maxLength: 256,
                    pattern: "^[^\\u0000-\\u001f\\u007f]+$",
                  },
                  keyGeneration: {
                    type: "string",
                    pattern: "^[1-9][0-9]{0,18}$",
                  },
                },
              },
              {
                type: "object",
                additionalProperties: false,
                required: ["kind", "keyGeneration"],
                properties: {
                  kind: {
                    const: "custody_key",
                  },
                  keyGeneration: {
                    type: "string",
                    pattern: "^[1-9][0-9]{0,18}$",
                  },
                },
              },
              {
                type: "object",
                additionalProperties: false,
                required: ["kind", "grantId", "generation"],
                properties: {
                  kind: {
                    const: "grant",
                  },
                  grantId: {
                    type: "string",
                    minLength: 1,
                    maxLength: 256,
                    pattern: "^[^\\u0000-\\u001f\\u007f]+$",
                  },
                  generation: {
                    type: "integer",
                    minimum: 1,
                    maximum: 9007199254740991,
                  },
                },
              },
            ],
          },
        },
        allOf: [
          {
            if: {
              properties: {
                trigger: {
                  const: "item_revoked",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "item",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "item_deleted",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "item",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "version_compromised",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "version",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "owner_disabled",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "item",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "owner_locked",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "item",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "grant_revoked",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "grant",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "recipient_key_revoked",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "recipient_key",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "custody_key_revoked",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "custody_key",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "organization_use_removed",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "grant",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "policy_changed",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "item",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
        ],
        description:
          "Reference-only projection of existing owning outbox events, not another revocation authority. Commit deny state and reconcile in-flight outcomes; copied plaintext cannot be recalled.",
      },
      walletCompatibilityV2: {
        const: {
          resourceVersions: ["kombify.wallet-resource.v1", "kombify.wallet-resource.v2"],
          intentVersions: [
            "kombify.wallet-operation-intent.v1",
            "kombify.wallet-operation-intent.v2",
          ],
          referenceVersion: "kombify.wallet-reference.v1",
          v1Semantics: "exact_version_snapshot",
          v2Semantics: "stable_item_exact_operation",
          unknownVersion: "deny",
          mixedVersions: "deny",
          legacyFallback: false,
          resourceEquality: "full_projection",
          productionAdmission: "denied_until_qualified",
        },
        description:
          "Generator/reader compatibility declaration. Recognition grants nothing. Schema regeneration requires restrictive-marker guards and semantic readers to migrate atomically.",
      },
      walletDenialMappingsV1: {
        const: {
          wallet_admission_not_qualified: {
            httpStatus: 503,
            retryable: false,
          },
          wallet_unsupported_version: {
            httpStatus: 400,
            retryable: false,
          },
          wallet_reference_mismatch: {
            httpStatus: 409,
            retryable: false,
          },
          wallet_identity_mismatch: {
            httpStatus: 403,
            retryable: false,
          },
          wallet_namespace_classification_mismatch: {
            httpStatus: 403,
            retryable: false,
          },
          wallet_resource_policy_mismatch: {
            httpStatus: 403,
            retryable: false,
          },
          wallet_version_not_eligible: {
            httpStatus: 403,
            retryable: false,
          },
          wallet_resource_inactive: {
            httpStatus: 409,
            retryable: false,
          },
          wallet_audience_mismatch: {
            httpStatus: 403,
            retryable: false,
          },
          wallet_owner_proof_required: {
            httpStatus: 403,
            retryable: false,
          },
          wallet_recipient_unqualified: {
            httpStatus: 403,
            retryable: false,
          },
          wallet_key_generation_stale: {
            httpStatus: 409,
            retryable: false,
          },
          wallet_authority_revoked: {
            httpStatus: 403,
            retryable: false,
          },
          wallet_custody_unavailable: {
            httpStatus: 503,
            retryable: true,
          },
          wallet_audit_unavailable: {
            httpStatus: 503,
            retryable: true,
          },
          wallet_contract_invalid: {
            httpStatus: 400,
            retryable: false,
          },
          wallet_intent_digest_mismatch: {
            httpStatus: 400,
            retryable: false,
          },
          wallet_arguments_mismatch: {
            httpStatus: 400,
            retryable: false,
          },
        },
      },
      walletRevocationMappingsV1: {
        const: {
          item_revoked: {
            scope: "item",
            denyNewEffects: true,
            reconcileInFlight: true,
            purgeCiphertext: false,
            retainedDenyFloor: true,
          },
          item_deleted: {
            scope: "item",
            denyNewEffects: true,
            reconcileInFlight: true,
            purgeCiphertext: true,
            retainedDenyFloor: true,
          },
          version_compromised: {
            scope: "version",
            denyNewEffects: true,
            reconcileInFlight: true,
            purgeCiphertext: false,
            retainedDenyFloor: true,
          },
          owner_disabled: {
            scope: "item",
            denyNewEffects: true,
            reconcileInFlight: true,
            purgeCiphertext: false,
            retainedDenyFloor: true,
          },
          owner_locked: {
            scope: "item",
            denyNewEffects: true,
            reconcileInFlight: true,
            purgeCiphertext: false,
            retainedDenyFloor: true,
          },
          grant_revoked: {
            scope: "grant",
            denyNewEffects: true,
            reconcileInFlight: true,
            purgeCiphertext: false,
            retainedDenyFloor: true,
          },
          recipient_key_revoked: {
            scope: "recipient_key",
            denyNewEffects: true,
            reconcileInFlight: true,
            purgeCiphertext: false,
            retainedDenyFloor: true,
          },
          custody_key_revoked: {
            scope: "custody_key",
            denyNewEffects: true,
            reconcileInFlight: true,
            purgeCiphertext: false,
            retainedDenyFloor: true,
          },
          organization_use_removed: {
            scope: "grant",
            denyNewEffects: true,
            reconcileInFlight: true,
            purgeCiphertext: false,
            retainedDenyFloor: true,
          },
          policy_changed: {
            scope: "item",
            denyNewEffects: true,
            reconcileInFlight: true,
            purgeCiphertext: false,
            retainedDenyFloor: true,
          },
        },
      },
      walletActionV3: {
        enum: [
          "brokered_use",
          "process_injection",
          "mint_child_credential",
          "sign",
          "host_delivery",
          "reveal",
          "export",
          "capture",
          "rotate",
          "delete",
          "restore",
          "revoke",
          "configure",
          "disconnect",
        ],
        description:
          "Wallet actions in three right classes. use: brokered_use, process_injection, mint_child_credential, sign, host_delivery. read: reveal, export. manage: capture, rotate, delete, restore, revoke, configure, disconnect. revoke denies every later use of the item and keeps its versions until delete. configure changes the item's metadata, value policy or use targets and releases no value. walletActionProfilesV3 maps each action to its right, value release and transfer rule.",
      },
      walletRightV3: {
        enum: ["use", "read", "manage"],
        description:
          "Rights on one item. use acts with the item without making the requester its reader; read receives the value (reveal, export); manage changes the item's lifecycle. Using and reading are separate rights: holding one never implies the other.",
      },
      walletActionProfilesV3: {
        const: {
          brokered_use: {
            right: "use",
            valueRelease: "brokered",
            transfer: false,
          },
          process_injection: {
            right: "use",
            valueRelease: "disclosed",
            transfer: true,
          },
          mint_child_credential: {
            right: "use",
            valueRelease: "brokered",
            transfer: false,
          },
          sign: {
            right: "use",
            valueRelease: "brokered",
            transfer: false,
          },
          host_delivery: {
            right: "use",
            valueRelease: "disclosed",
            transfer: true,
          },
          reveal: {
            right: "read",
            valueRelease: "disclosed",
            transfer: true,
          },
          export: {
            right: "read",
            valueRelease: "disclosed",
            transfer: true,
          },
          capture: {
            right: "manage",
            valueRelease: "none",
            transfer: true,
          },
          rotate: {
            right: "manage",
            valueRelease: "none",
            transfer: true,
          },
          delete: {
            right: "manage",
            valueRelease: "none",
            transfer: false,
          },
          restore: {
            right: "manage",
            valueRelease: "none",
            transfer: false,
          },
          revoke: {
            right: "manage",
            valueRelease: "none",
            transfer: false,
          },
          configure: {
            right: "manage",
            valueRelease: "none",
            transfer: false,
          },
          disconnect: {
            right: "manage",
            valueRelease: "none",
            transfer: false,
          },
        },
        description:
          "Per action: right, valueRelease and transfer. brokered: the value stays in custody and is used there (the caller receives a result, a signature or a minted child credential). disclosed: the value leaves custody sealed to an enrolled recipient, so valueAccess use_only never supports it. none: no value leaves custody. transfer: the operation carries a finalized compact JWE binding. Audit valueReleased and valueAccess enforcement derive from this table.",
      },
      walletItemTypeProfilesV3: {
        const: {
          generic_secret: {
            custodians: ["wallet_store"],
            actions: [
              "brokered_use",
              "process_injection",
              "sign",
              "host_delivery",
              "reveal",
              "export",
              "capture",
              "rotate",
              "delete",
              "restore",
              "revoke",
              "configure",
            ],
          },
          login: {
            custodians: ["wallet_store"],
            actions: [
              "brokered_use",
              "process_injection",
              "reveal",
              "export",
              "capture",
              "rotate",
              "delete",
              "restore",
              "revoke",
              "configure",
            ],
          },
          variable: {
            custodians: ["wallet_store"],
            actions: [
              "process_injection",
              "host_delivery",
              "reveal",
              "export",
              "capture",
              "rotate",
              "delete",
              "restore",
              "revoke",
              "configure",
            ],
          },
          configuration: {
            custodians: ["wallet_store"],
            actions: [
              "process_injection",
              "host_delivery",
              "reveal",
              "export",
              "capture",
              "rotate",
              "delete",
              "restore",
              "revoke",
              "configure",
            ],
          },
          oauth_connection: {
            custodians: ["wallet_store", "auth0_token_vault", "product"],
            actions: [
              "brokered_use",
              "process_injection",
              "mint_child_credential",
              "reveal",
              "export",
              "capture",
              "rotate",
              "delete",
              "restore",
              "revoke",
              "configure",
              "disconnect",
            ],
          },
          node_access_profile: {
            custodians: ["wallet_store", "product"],
            actions: [
              "brokered_use",
              "process_injection",
              "host_delivery",
              "reveal",
              "export",
              "capture",
              "rotate",
              "delete",
              "restore",
              "revoke",
              "configure",
              "disconnect",
            ],
          },
          parent_credential: {
            custodians: ["wallet_store"],
            actions: [
              "brokered_use",
              "mint_child_credential",
              "reveal",
              "export",
              "capture",
              "rotate",
              "delete",
              "restore",
              "revoke",
              "configure",
            ],
          },
          ssh_ca: {
            custodians: ["wallet_store"],
            actions: ["sign", "capture", "delete", "restore", "revoke", "configure"],
          },
          ai_credential: {
            custodians: ["wallet_store", "product"],
            actions: [
              "brokered_use",
              "process_injection",
              "reveal",
              "export",
              "capture",
              "rotate",
              "delete",
              "restore",
              "revoke",
              "configure",
            ],
          },
          device_key: {
            custodians: ["device"],
            actions: [
              "brokered_use",
              "sign",
              "capture",
              "rotate",
              "delete",
              "restore",
              "revoke",
              "configure",
              "disconnect",
            ],
          },
        },
        description:
          "Per item type: the valid custodians and the largest action set. wallet_store holds every stored type; auth0_token_vault only oauth_connection; device only device_key; product is migration-only and admits no new item type. Custodian, protection, valueAccess and rights narrow the action set further in walletResourceV3.",
      },
      walletIdentityV3: {
        type: "object",
        additionalProperties: false,
        required: ["owner", "custodyNamespace", "itemId", "resourceType"],
        properties: {
          owner: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          custodyNamespace: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          itemId: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          resourceType: {
            enum: [
              "generic_secret",
              "login",
              "variable",
              "configuration",
              "oauth_connection",
              "node_access_profile",
              "parent_credential",
              "ssh_ca",
              "ai_credential",
              "device_key",
            ],
          },
        },
        description:
          "Immutable stable item identity, independently resolved from existing custody authority. Version belongs to the exact operation. resourceType selects the item type from walletItemTypeProfilesV3.",
      },
      walletScopeV3: {
        oneOf: [
          {
            type: "object",
            additionalProperties: false,
            required: ["kind"],
            properties: {
              kind: {
                const: "account",
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "projectId"],
            properties: {
              kind: {
                const: "project",
              },
              projectId: {
                type: "string",
                minLength: 1,
              },
            },
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "projectId", "environment"],
            properties: {
              kind: {
                const: "project_environment",
              },
              projectId: {
                type: "string",
                minLength: 1,
              },
              environment: {
                type: "string",
                minLength: 1,
              },
            },
          },
        ],
        description:
          "Account, one project, or one project environment. Variables resolve environment over project over account.",
      },
      walletItemPolicyV3: {
        type: "object",
        additionalProperties: false,
        required: ["valueAccess"],
        properties: {
          valueAccess: {
            enum: ["read_right_holders", "use_only"],
          },
          ownerProof: {
            enum: ["none", "fresh_owner_proof"],
          },
        },
        description:
          "Item policy that replaces the fixed disclosure rule. valueAccess read_right_holders (the default a writer applies when the owner chooses nothing): a holder of the read right may receive the value, and a holder of the use right may cause its delivery to an enrolled process or server. valueAccess use_only: the value never leaves custody, so reveal, export, process_injection and host_delivery are unsupported for everyone. ownerProof fresh_owner_proof: every operation on the item needs a custody-verifiable owner approval receipt over its exact intent; absent means none, and absence and none are different spellings of one effect that full-projection equality does not normalize.",
      },
      walletResourceV3: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "definitionId",
          "resource",
          "bindings",
          "identity",
          "scope",
          "custodian",
          "protection",
          "policy",
          "supportedActions",
          "rights",
          "classification",
          "reference",
          "versionConstraint",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.wallet-resource.v3",
          },
          definitionId: {
            type: "string",
            minLength: 1,
          },
          resource: {
            type: "string",
            minLength: 1,
            maxLength: 512,
          },
          bindings: {
            type: "object",
            additionalProperties: {
              type: "string",
              minLength: 1,
            },
          },
          identity: {
            $ref: "#/$defs/walletIdentityV3",
          },
          scope: {
            $ref: "#/$defs/walletScopeV3",
          },
          custodian: {
            $ref: "#/$defs/walletCustodianV1",
          },
          protection: {
            $ref: "#/$defs/walletProtectionV1",
          },
          policy: {
            $ref: "#/$defs/walletItemPolicyV3",
          },
          supportedActions: {
            type: "array",
            items: {
              $ref: "#/$defs/walletActionV3",
            },
            minItems: 1,
            uniqueItems: true,
          },
          rights: {
            type: "array",
            items: {
              $ref: "#/$defs/walletRightV3",
            },
            minItems: 1,
            uniqueItems: true,
          },
          classification: {
            enum: ["synthetic", "real"],
          },
          reference: {
            $ref: "#/$defs/walletReferenceV1",
          },
          versionConstraint: {
            $ref: "#/$defs/walletVersionConstraintV1",
          },
        },
        allOf: [
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "wallet_store",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      enum: [
                        "generic_secret",
                        "login",
                        "variable",
                        "configuration",
                        "oauth_connection",
                        "node_access_profile",
                        "parent_credential",
                        "ssh_ca",
                        "ai_credential",
                      ],
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      enum: ["service_managed", "user_unlocked"],
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "auth0_token_vault",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "oauth_connection",
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      const: "custodian_managed",
                    },
                  },
                },
                policy: {
                  properties: {
                    valueAccess: {
                      const: "use_only",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "product",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      enum: ["oauth_connection", "node_access_profile", "ai_credential"],
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      const: "product_native",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "device",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "device_key",
                    },
                  },
                },
                protection: {
                  properties: {
                    kind: {
                      const: "non_exportable",
                    },
                  },
                },
                policy: {
                  properties: {
                    valueAccess: {
                      const: "use_only",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "device_key",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "device",
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "generic_secret",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: [
                      "brokered_use",
                      "process_injection",
                      "sign",
                      "host_delivery",
                      "reveal",
                      "export",
                      "capture",
                      "rotate",
                      "delete",
                      "restore",
                      "revoke",
                      "configure",
                    ],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "login",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: [
                      "brokered_use",
                      "process_injection",
                      "reveal",
                      "export",
                      "capture",
                      "rotate",
                      "delete",
                      "restore",
                      "revoke",
                      "configure",
                    ],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "variable",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: [
                      "process_injection",
                      "host_delivery",
                      "reveal",
                      "export",
                      "capture",
                      "rotate",
                      "delete",
                      "restore",
                      "revoke",
                      "configure",
                    ],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "configuration",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: [
                      "process_injection",
                      "host_delivery",
                      "reveal",
                      "export",
                      "capture",
                      "rotate",
                      "delete",
                      "restore",
                      "revoke",
                      "configure",
                    ],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "oauth_connection",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: [
                      "brokered_use",
                      "process_injection",
                      "mint_child_credential",
                      "reveal",
                      "export",
                      "capture",
                      "rotate",
                      "delete",
                      "restore",
                      "revoke",
                      "configure",
                      "disconnect",
                    ],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "node_access_profile",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: [
                      "brokered_use",
                      "process_injection",
                      "host_delivery",
                      "reveal",
                      "export",
                      "capture",
                      "rotate",
                      "delete",
                      "restore",
                      "revoke",
                      "configure",
                      "disconnect",
                    ],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "parent_credential",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: [
                      "brokered_use",
                      "mint_child_credential",
                      "reveal",
                      "export",
                      "capture",
                      "rotate",
                      "delete",
                      "restore",
                      "revoke",
                      "configure",
                    ],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "ssh_ca",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: ["sign", "capture", "delete", "restore", "revoke", "configure"],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "ai_credential",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: [
                      "brokered_use",
                      "process_injection",
                      "reveal",
                      "export",
                      "capture",
                      "rotate",
                      "delete",
                      "restore",
                      "revoke",
                      "configure",
                    ],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                identity: {
                  properties: {
                    resourceType: {
                      const: "device_key",
                    },
                  },
                  required: ["resourceType"],
                },
              },
              required: ["identity"],
            },
            then: {
              properties: {
                supportedActions: {
                  items: {
                    enum: [
                      "brokered_use",
                      "sign",
                      "capture",
                      "rotate",
                      "delete",
                      "restore",
                      "revoke",
                      "configure",
                      "disconnect",
                    ],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                policy: {
                  properties: {
                    valueAccess: {
                      const: "use_only",
                    },
                  },
                  required: ["valueAccess"],
                },
              },
              required: ["policy"],
            },
            then: {
              allOf: [
                {
                  properties: {
                    supportedActions: {
                      items: {
                        enum: [
                          "brokered_use",
                          "mint_child_credential",
                          "sign",
                          "capture",
                          "rotate",
                          "delete",
                          "restore",
                          "revoke",
                          "configure",
                          "disconnect",
                        ],
                      },
                    },
                  },
                },
                {
                  properties: {
                    supportedActions: {
                      not: {
                        items: {
                          not: {
                            enum: ["brokered_use", "mint_child_credential", "sign"],
                          },
                        },
                      },
                    },
                  },
                  required: ["supportedActions"],
                },
              ],
            },
          },
          {
            if: {
              properties: {
                protection: {
                  properties: {
                    kind: {
                      const: "user_unlocked",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["protection"],
            },
            then: {
              allOf: [
                {
                  properties: {
                    policy: {
                      properties: {
                        valueAccess: {
                          const: "read_right_holders",
                        },
                      },
                    },
                  },
                },
                {
                  properties: {
                    supportedActions: {
                      items: {
                        enum: [
                          "process_injection",
                          "reveal",
                          "export",
                          "capture",
                          "rotate",
                          "delete",
                          "restore",
                          "revoke",
                          "configure",
                        ],
                      },
                    },
                  },
                },
              ],
            },
          },
          {
            if: {
              properties: {
                rights: {
                  not: {
                    items: {
                      not: {
                        const: "use",
                      },
                    },
                  },
                },
              },
              required: ["rights"],
            },
            then: {
              properties: {
                supportedActions: {
                  not: {
                    items: {
                      not: {
                        enum: [
                          "brokered_use",
                          "process_injection",
                          "mint_child_credential",
                          "sign",
                          "host_delivery",
                        ],
                      },
                    },
                  },
                },
              },
              required: ["supportedActions"],
            },
          },
          {
            if: {
              properties: {
                rights: {
                  not: {
                    items: {
                      not: {
                        const: "read",
                      },
                    },
                  },
                },
              },
              required: ["rights"],
            },
            then: {
              properties: {
                supportedActions: {
                  not: {
                    items: {
                      not: {
                        enum: ["reveal", "export"],
                      },
                    },
                  },
                },
              },
              required: ["supportedActions"],
            },
          },
          {
            if: {
              properties: {
                rights: {
                  not: {
                    items: {
                      not: {
                        const: "manage",
                      },
                    },
                  },
                },
              },
              required: ["rights"],
            },
            then: {
              properties: {
                supportedActions: {
                  not: {
                    items: {
                      not: {
                        enum: [
                          "capture",
                          "rotate",
                          "delete",
                          "restore",
                          "revoke",
                          "configure",
                          "disconnect",
                        ],
                      },
                    },
                  },
                },
              },
              required: ["supportedActions"],
            },
          },
          {
            if: {
              properties: {
                classification: {
                  const: "synthetic",
                },
              },
              required: ["classification"],
            },
            then: {
              properties: {
                identity: {
                  properties: {
                    custodyNamespace: {
                      pattern: "^synthetic:",
                    },
                  },
                  required: ["custodyNamespace"],
                },
              },
              required: ["identity"],
            },
            else: {
              properties: {
                identity: {
                  properties: {
                    custodyNamespace: {
                      not: {
                        pattern: "^synthetic:",
                      },
                    },
                  },
                  required: ["custodyNamespace"],
                },
              },
              required: ["identity"],
            },
          },
          {
            if: {
              properties: {
                reference: {
                  properties: {
                    kind: {
                      const: "secret",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["reference"],
            },
            then: {
              allOf: [
                {
                  properties: {
                    resource: {
                      pattern:
                        "^secret://(?!workloads/)[a-z0-9][a-z0-9._-]{0,127}/[A-Za-z0-9][A-Za-z0-9._-]{0,255}$",
                    },
                  },
                  required: ["resource"],
                },
                {
                  properties: {
                    identity: {
                      properties: {
                        itemId: {
                          pattern: "^[A-Za-z0-9][A-Za-z0-9._-]{0,255}$",
                        },
                      },
                      required: ["itemId"],
                    },
                  },
                  required: ["identity"],
                },
              ],
            },
          },
          {
            if: {
              properties: {
                custodian: {
                  properties: {
                    kind: {
                      const: "wallet_store",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["custodian"],
            },
            then: {
              properties: {
                reference: {
                  properties: {
                    kind: {
                      const: "secret",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["reference"],
            },
            else: {
              properties: {
                reference: {
                  properties: {
                    kind: {
                      const: "vault_ref",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["reference"],
            },
          },
        ],
        description:
          "Stable eligibility and exact policy projection of one item, nested version kombify.wallet-resource.v3. policy replaces the fixed disclosure rule; supportedActions is limited by item type, custodian, protection and valueAccess (walletItemTypeProfilesV3); rights is the grant-specific attenuation to use, read and manage, and each listed right needs a supported action of its class. Like versionConstraint, rights is not an item-intrinsic member: a grant's rights must be a subset of the registered item's rights, and every other member stays under full-projection equality. A read grant on a use_only item conveys nothing and is rejected. No ciphertext, key, token or reusable secret belongs here.",
      },
      walletOperationBindingV3: {
        type: "object",
        additionalProperties: false,
        required: [
          "operationId",
          "resource",
          "executionTenantId",
          "subject",
          "actor",
          "authenticationProfile",
          "admissionAudience",
          "executor",
          "target",
          "argumentsDigest",
          "context",
          "nonce",
          "expiresAt",
          "version",
          "versionRef",
          "lifecycle",
          "metadataRevision",
        ],
        properties: {
          operationId: {
            type: "string",
            minLength: 1,
          },
          resource: {
            $ref: "#/$defs/walletResourceV3",
          },
          executionTenantId: {
            type: "string",
            minLength: 1,
          },
          subject: {
            type: "string",
            minLength: 1,
          },
          actor: {
            $ref: "#/$defs/actor",
          },
          authenticationProfile: {
            enum: ["owner_interactive", "delegated_user", "service_standing"],
          },
          executor: {
            type: "object",
            additionalProperties: false,
            required: ["id", "recipient", "audience"],
            properties: {
              id: {
                type: "string",
                minLength: 1,
              },
              recipient: {
                $ref: "#/$defs/walletRecipientV1",
              },
              audience: {
                type: "string",
                minLength: 1,
                maxLength: 2048,
                format: "uri",
              },
            },
          },
          target: {
            type: "object",
            additionalProperties: false,
            required: ["id", "revision"],
            properties: {
              id: {
                type: "string",
                minLength: 1,
              },
              revision: {
                type: "string",
                minLength: 1,
              },
            },
          },
          argumentsDigest: {
            $ref: "#/$defs/digest",
          },
          transfer: {
            $ref: "#/$defs/walletTransferBindingV1",
          },
          context: {
            $ref: "#/$defs/walletExecutionContextV3",
          },
          nonce: {
            type: "string",
            minLength: 1,
          },
          expiresAt: {
            type: "string",
            format: "date-time",
          },
          admissionAudience: {
            type: "string",
            minLength: 1,
            maxLength: 2048,
            format: "uri",
          },
          version: {
            type: "string",
            pattern: "^[1-9][0-9]{0,18}$",
          },
          versionRef: {
            type: "string",
            minLength: 1,
            maxLength: 1024,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          lifecycle: {
            enum: ["pending", "active", "revoked", "deleted", "compromised"],
          },
          metadataRevision: {
            type: "integer",
            minimum: 1,
            maximum: 9007199254740991,
          },
        },
        description:
          "Exact immutable version, current lifecycle and metadata revision, as in nested v2, over a v3 resource. Public admission and separately registered private executor audiences must differ. secret versionRef equals stable resource + /versions/ + exact decimal version; product versionRef comes from its existing resolver. host_delivery binds the server as target.id and its binding generation as target.revision; mint_child_credential and sign bind their provider target and normalized arguments. No latest, implicit retry rotation or inferred authority.",
        allOf: [
          {
            if: {
              properties: {
                context: {
                  properties: {
                    kind: {
                      const: "product_service",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["context"],
            },
            then: {
              properties: {
                actor: {
                  properties: {
                    kind: {
                      const: "service",
                    },
                  },
                },
                authenticationProfile: {
                  const: "service_standing",
                },
              },
            },
          },
          {
            if: {
              properties: {
                authenticationProfile: {
                  const: "service_standing",
                },
              },
              required: ["authenticationProfile"],
            },
            then: {
              properties: {
                context: {
                  properties: {
                    kind: {
                      const: "product_service",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["context"],
            },
          },
          {
            if: {
              properties: {
                context: {
                  properties: {
                    kind: {
                      const: "agent_run",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["context"],
            },
            then: {
              properties: {
                actor: {
                  properties: {
                    kind: {
                      const: "agent",
                    },
                  },
                },
                authenticationProfile: {
                  const: "delegated_user",
                },
              },
            },
          },
          {
            if: {
              properties: {
                context: {
                  properties: {
                    kind: {
                      enum: ["owner_client", "owner_process"],
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["context"],
            },
            then: {
              properties: {
                actor: {
                  properties: {
                    kind: {
                      const: "user",
                    },
                  },
                },
                authenticationProfile: {
                  const: "owner_interactive",
                },
              },
            },
          },
        ],
      },
      walletOperationIntentV3: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "intentId",
          "action",
          "intentDigest",
          "idempotencyKey",
          "operation",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.wallet-operation-intent.v3",
          },
          intentId: {
            type: "string",
            minLength: 1,
          },
          action: {
            $ref: "#/$defs/walletActionV3",
          },
          intentDigest: {
            $ref: "#/$defs/digest",
          },
          idempotencyKey: {
            type: "string",
            minLength: 1,
          },
          operation: {
            $ref: "#/$defs/walletOperationBindingV3",
          },
        },
        allOf: [
          {
            if: {
              properties: {
                action: {
                  enum: [
                    "process_injection",
                    "host_delivery",
                    "reveal",
                    "export",
                    "capture",
                    "rotate",
                  ],
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  required: ["transfer"],
                },
              },
            },
            else: {
              properties: {
                operation: {
                  not: {
                    required: ["transfer"],
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                action: {
                  const: "process_injection",
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  properties: {
                    context: {
                      properties: {
                        kind: {
                          enum: ["owner_process", "product_service"],
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                action: {
                  enum: ["process_injection", "host_delivery", "reveal", "export"],
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  properties: {
                    resource: {
                      properties: {
                        policy: {
                          properties: {
                            valueAccess: {
                              const: "read_right_holders",
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          {
            if: {
              properties: {
                action: {
                  enum: [
                    "brokered_use",
                    "process_injection",
                    "mint_child_credential",
                    "sign",
                    "host_delivery",
                  ],
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  properties: {
                    resource: {
                      properties: {
                        rights: {
                          not: {
                            items: {
                              not: {
                                const: "use",
                              },
                            },
                          },
                        },
                      },
                      required: ["rights"],
                    },
                  },
                  required: ["resource"],
                },
              },
              required: ["operation"],
            },
          },
          {
            if: {
              properties: {
                action: {
                  enum: ["reveal", "export"],
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  properties: {
                    resource: {
                      properties: {
                        rights: {
                          not: {
                            items: {
                              not: {
                                const: "read",
                              },
                            },
                          },
                        },
                      },
                      required: ["rights"],
                    },
                  },
                  required: ["resource"],
                },
              },
              required: ["operation"],
            },
          },
          {
            if: {
              properties: {
                action: {
                  enum: [
                    "capture",
                    "rotate",
                    "delete",
                    "restore",
                    "revoke",
                    "configure",
                    "disconnect",
                  ],
                },
              },
              required: ["action"],
            },
            then: {
              properties: {
                operation: {
                  properties: {
                    resource: {
                      properties: {
                        rights: {
                          not: {
                            items: {
                              not: {
                                const: "manage",
                              },
                            },
                          },
                        },
                      },
                      required: ["rights"],
                    },
                  },
                  required: ["resource"],
                },
              },
              required: ["operation"],
            },
          },
        ],
        description:
          "Domain kombify.wallet-operation-intent.digest.v3 binds all members except intentDigest using Core canonical JSON. The action's right must be in the resource's rights; a disclosed action needs valueAccess read_right_holders; a transfer binding is required exactly for the actions marked transfer in walletActionProfilesV3; process_injection runs only in an owner_process context or in a product_service context (a kombify product backend acting on the owner's standing assignment, sealed to its enrolled key). reveal and export are admitted for a delegated agent run that holds the read right. Requires schema plus semantic checks and independent current authority. No v1 or v2 reinterpretation or admission from representation.",
      },
      walletOwnerApprovalReceiptV2: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "iss",
          "aud",
          "jti",
          "keyGeneration",
          "iat",
          "exp",
          "ownerPin",
          "approval",
          "authentication",
          "audit",
          "intent",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.wallet-owner-approval-receipt.v2",
          },
          iss: {
            const: "urn:kombify:wallet:owner-approval:cloud",
          },
          aud: {
            const: "urn:kombify:wallet-store:owner-approval",
          },
          jti: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          keyGeneration: {
            type: "string",
            pattern: "^[1-9][0-9]{0,18}$",
          },
          iat: {
            type: "integer",
            minimum: 0,
            maximum: 9007199254740991,
          },
          exp: {
            type: "integer",
            minimum: 0,
            maximum: 9007199254740991,
          },
          ownerPin: {
            type: "object",
            additionalProperties: false,
            required: ["accountId", "issuer", "subject", "custodyNamespace"],
            properties: {
              accountId: {
                type: "string",
                minLength: 1,
                maxLength: 256,
                pattern: "^[^\\u0000-\\u001f\\u007f]+$",
              },
              issuer: {
                type: "string",
                maxLength: 256,
                format: "uri",
                pattern: "^https://[A-Za-z0-9.-]+/$",
              },
              subject: {
                type: "string",
                minLength: 1,
                maxLength: 256,
                pattern: "^[^\\u0000-\\u001f\\u007f]+$",
              },
              custodyNamespace: {
                type: "string",
                minLength: 1,
                maxLength: 256,
                pattern: "^[^\\u0000-\\u001f\\u007f]+$",
              },
            },
          },
          approval: {
            type: "object",
            additionalProperties: false,
            required: ["id", "revision", "createdAt", "decidedAt"],
            properties: {
              id: {
                type: "string",
                minLength: 1,
                maxLength: 256,
                pattern: "^[^\\u0000-\\u001f\\u007f]+$",
              },
              revision: {
                type: "integer",
                minimum: 2,
                maximum: 9007199254740991,
              },
              createdAt: {
                type: "string",
                format: "date-time",
              },
              decidedAt: {
                type: "string",
                format: "date-time",
              },
            },
          },
          authentication: {
            type: "object",
            additionalProperties: false,
            required: ["profile", "mfa", "authTime"],
            properties: {
              profile: {
                const: "owner_interactive",
              },
              mfa: {
                const: true,
              },
              authTime: {
                type: "integer",
                minimum: 0,
                maximum: 9007199254740991,
              },
            },
          },
          audit: {
            type: "object",
            additionalProperties: false,
            required: ["eventId", "eventDigest", "confirmedAt"],
            properties: {
              eventId: {
                type: "string",
                minLength: 1,
                maxLength: 256,
                pattern: "^[^\\u0000-\\u001f\\u007f]+$",
              },
              eventDigest: {
                $ref: "#/$defs/digest",
              },
              confirmedAt: {
                type: "string",
                format: "date-time",
                description:
                  "When the issuer observed the exact retained approval audit event through its authenticated delivery reader; not when delivery occurred.",
              },
            },
          },
          intent: {
            $ref: "#/$defs/walletOperationIntentV3",
          },
        },
        description:
          "Closed Cloud-signed human intent proof for a v3 item that requires fresh_owner_proof: the unchanged receipt rules over the full WalletOperationIntentV3, whose digest domain is kombify.wallet-operation-intent.digest.v3. The intent is an owner client or owner process operation; an agent-run intent never matches it, so an agent cannot use an item with ownerProof fresh_owner_proof until a later receipt version binds delegated runs. The protected header profile walletOwnerApprovalProtectedHeaderV1, issuer, audience, freshness and lifetime rules are those of receipt v1. Not an AgentAuthorityGrant, ActivationDecision, eligibility or entitlement proof.",
      },
      walletRevocationEventV2: {
        type: "object",
        additionalProperties: false,
        required: ["schemaVersion", "eventId", "occurredAt", "identity", "trigger", "scope"],
        properties: {
          schemaVersion: {
            const: "kombify.wallet-revocation-event.v2",
          },
          eventId: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          occurredAt: {
            type: "string",
            format: "date-time",
          },
          identity: {
            $ref: "#/$defs/walletIdentityV3",
          },
          trigger: {
            enum: [
              "item_revoked",
              "item_deleted",
              "version_compromised",
              "owner_disabled",
              "owner_locked",
              "grant_revoked",
              "recipient_key_revoked",
              "custody_key_revoked",
              "organization_use_removed",
              "policy_changed",
            ],
          },
          scope: {
            oneOf: [
              {
                type: "object",
                additionalProperties: false,
                required: ["kind"],
                properties: {
                  kind: {
                    const: "item",
                  },
                },
              },
              {
                type: "object",
                additionalProperties: false,
                required: ["kind", "version"],
                properties: {
                  kind: {
                    const: "version",
                  },
                  version: {
                    type: "string",
                    pattern: "^[1-9][0-9]{0,18}$",
                  },
                },
              },
              {
                type: "object",
                additionalProperties: false,
                required: ["kind", "keyId", "keyGeneration"],
                properties: {
                  kind: {
                    const: "recipient_key",
                  },
                  keyId: {
                    type: "string",
                    minLength: 1,
                    maxLength: 256,
                    pattern: "^[^\\u0000-\\u001f\\u007f]+$",
                  },
                  keyGeneration: {
                    type: "string",
                    pattern: "^[1-9][0-9]{0,18}$",
                  },
                },
              },
              {
                type: "object",
                additionalProperties: false,
                required: ["kind", "keyGeneration"],
                properties: {
                  kind: {
                    const: "custody_key",
                  },
                  keyGeneration: {
                    type: "string",
                    pattern: "^[1-9][0-9]{0,18}$",
                  },
                },
              },
              {
                type: "object",
                additionalProperties: false,
                required: ["kind", "grantId", "generation"],
                properties: {
                  kind: {
                    const: "grant",
                  },
                  grantId: {
                    type: "string",
                    minLength: 1,
                    maxLength: 256,
                    pattern: "^[^\\u0000-\\u001f\\u007f]+$",
                  },
                  generation: {
                    type: "integer",
                    minimum: 1,
                    maximum: 9007199254740991,
                  },
                },
              },
            ],
          },
        },
        allOf: [
          {
            if: {
              properties: {
                trigger: {
                  const: "item_revoked",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "item",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "item_deleted",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "item",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "version_compromised",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "version",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "owner_disabled",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "item",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "owner_locked",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "item",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "grant_revoked",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "grant",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "recipient_key_revoked",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "recipient_key",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "custody_key_revoked",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "custody_key",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "organization_use_removed",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "grant",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
          {
            if: {
              properties: {
                trigger: {
                  const: "policy_changed",
                },
              },
              required: ["trigger"],
            },
            then: {
              properties: {
                scope: {
                  properties: {
                    kind: {
                      const: "item",
                    },
                  },
                  required: ["kind"],
                },
              },
              required: ["scope"],
            },
          },
        ],
        description:
          "Reference-only projection of existing owning outbox events for any v3 item type: the triggers, scopes and walletRevocationMappingsV1 mapping are those of kombify.wallet-revocation-event.v1, over walletIdentityV3. Commit deny state and reconcile in-flight outcomes; copied plaintext cannot be recalled.",
      },
      walletCompatibilityV3: {
        const: {
          resourceVersions: [
            "kombify.wallet-resource.v1",
            "kombify.wallet-resource.v2",
            "kombify.wallet-resource.v3",
          ],
          intentVersions: [
            "kombify.wallet-operation-intent.v1",
            "kombify.wallet-operation-intent.v2",
            "kombify.wallet-operation-intent.v3",
          ],
          receiptVersions: [
            "kombify.wallet-owner-approval-receipt.v1",
            "kombify.wallet-owner-approval-receipt.v2",
          ],
          revocationEventVersions: [
            "kombify.wallet-revocation-event.v1",
            "kombify.wallet-revocation-event.v2",
          ],
          referenceVersion: "kombify.wallet-reference.v1",
          v1Semantics: "exact_version_snapshot",
          v2Semantics: "stable_item_exact_operation",
          v3Semantics: "stable_item_use_read_rights",
          unknownVersion: "deny",
          mixedVersions: "deny",
          legacyFallback: false,
          resourceEquality: "full_projection",
          productionAdmission: "denied_until_qualified",
        },
        description:
          "Generator/reader compatibility declaration for v3. Recognition grants nothing. v1 and v2 readers deny v3 documents; v3 readers keep parsing v1 and v2 under their original semantics and never reinterpret one version as another. Schema regeneration requires restrictive-marker guards and semantic readers to migrate atomically.",
      },
    },
  },
  "client-error-envelope.v1.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/client/v1/error-envelope.schema.json",
    title: "Kombify Client Error Envelope v1",
    type: "object",
    additionalProperties: false,
    required: ["error_code", "reason_code", "retryable", "user_guidance"],
    properties: {
      error_code: {
        type: "string",
        pattern: "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$",
      },
      reason_code: {
        type: "string",
        pattern: "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)*$",
      },
      request_id: {
        type: "string",
        minLength: 1,
        maxLength: 256,
      },
      capability: {
        type: "string",
        pattern: "^[a-z][a-z0-9.-]*$",
      },
      provider_id: {
        type: "string",
        minLength: 1,
        maxLength: 256,
      },
      required_features: {
        type: "array",
        uniqueItems: true,
        items: {
          type: "string",
          pattern: "^[a-z][a-z0-9._-]*$",
        },
      },
      missing_features: {
        type: "array",
        uniqueItems: true,
        items: {
          type: "string",
          pattern: "^[a-z][a-z0-9._-]*$",
        },
      },
      retryable: {
        type: "boolean",
      },
      user_guidance: {
        type: "object",
        additionalProperties: false,
        required: ["title", "body", "next_steps"],
        properties: {
          title: {
            type: "string",
            minLength: 1,
            maxLength: 160,
          },
          body: {
            type: "string",
            minLength: 1,
            maxLength: 2000,
          },
          next_steps: {
            type: "array",
            minItems: 1,
            maxItems: 8,
            items: {
              type: "string",
              minLength: 1,
              maxLength: 500,
            },
          },
          localization: {
            type: "object",
            additionalProperties: false,
            required: ["title_message_id", "body_message_id", "next_step_message_ids"],
            properties: {
              title_message_id: {
                type: "string",
                minLength: 3,
                maxLength: 160,
                pattern: "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)+$",
              },
              body_message_id: {
                type: "string",
                minLength: 3,
                maxLength: 160,
                pattern: "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)+$",
              },
              next_step_message_ids: {
                type: "array",
                minItems: 1,
                maxItems: 8,
                items: {
                  type: "string",
                  minLength: 3,
                  maxLength: 160,
                  pattern: "^[a-z][a-z0-9]*(?:[._-][a-z0-9]+)+$",
                },
              },
              message_params: {
                type: "object",
                additionalProperties: {
                  oneOf: [
                    {
                      type: "string",
                      maxLength: 512,
                    },
                    {
                      type: "number",
                    },
                    {
                      type: "boolean",
                    },
                  ],
                },
                maxProperties: 32,
                propertyNames: {
                  pattern: "^[a-z][a-zA-Z0-9_]*$",
                },
              },
            },
          },
        },
      },
      remediation: {
        type: "string",
        minLength: 1,
        maxLength: 2000,
      },
      support_context: {
        type: "object",
        additionalProperties: true,
      },
    },
  },
  "activation-request.v2.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v2/activation-request.schema.json",
    title: "Kombify ActivationRequestV2",
    description:
      "An agent request or explicit owner-equipment assignment. Unmarked human-reserved policies remain on v1; representation alone admits no runtime profile.",
    type: "object",
    additionalProperties: false,
    required: ["schemaVersion", "id", "binding", "requestDigest", "state", "createdAt"],
    properties: {
      schemaVersion: {
        const: "kombify.activation-request.v2",
      },
      id: {
        type: "string",
        minLength: 1,
      },
      binding: {
        $ref: "#/$defs/binding",
      },
      requestDigest: {
        $ref: "agent-authority.v2.schema.json#/$defs/digest",
      },
      state: {
        enum: ["pending", "approved", "denied", "expired", "withdrawn"],
      },
      createdAt: {
        type: "string",
        format: "date-time",
      },
      decisionId: {
        type: "string",
        minLength: 1,
      },
      decisionDigest: {
        $ref: "agent-authority.v2.schema.json#/$defs/digest",
      },
      leaseId: {
        type: "string",
        minLength: 1,
      },
    },
    allOf: [
      {
        if: {
          properties: {
            state: {
              const: "approved",
            },
          },
          required: ["state"],
        },
        then: {
          required: ["decisionId", "decisionDigest", "leaseId"],
        },
      },
      {
        if: {
          properties: {
            state: {
              const: "denied",
            },
          },
          required: ["state"],
        },
        then: {
          required: ["decisionId", "decisionDigest"],
        },
      },
    ],
    $defs: {
      ownerActor: {
        type: "object",
        additionalProperties: false,
        required: ["kind", "id"],
        properties: {
          kind: {
            const: "user",
          },
          id: {
            type: "string",
            minLength: 1,
          },
        },
      },
      ownerEquipment: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "sourceKind",
          "targetRevision",
          "targetSpecDigest",
          "profileRevision",
          "resourceRevision",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.owner-equipment.v1",
          },
          sourceKind: {
            const: "harness",
          },
          targetRevision: {
            type: "string",
            format: "date-time",
          },
          targetSpecDigest: {
            $ref: "agent-authority.v2.schema.json#/$defs/digest",
          },
          profileRevision: {
            type: "string",
            minLength: 1,
            maxLength: 128,
          },
          resourceRevision: {
            type: "string",
            minLength: 1,
            maxLength: 128,
          },
        },
        description:
          "Issuance preconditions matched to independently read current owner-scoped root, profile and resource facts. Caller values authenticate nothing.",
      },
      ownerEquipmentPolicy: {
        type: "object",
        additionalProperties: false,
        required: ["schemaVersion", "revision", "mode"],
        properties: {
          schemaVersion: {
            const: "kombify.activation-policy.v2",
          },
          revision: {
            $ref: "agent-authority.v2.schema.json#/$defs/digest",
          },
          mode: {
            const: "owner_equipment",
          },
        },
      },
      taskRef: {
        type: "object",
        additionalProperties: false,
        required: ["schemaVersion", "owner", "id", "revision"],
        properties: {
          schemaVersion: {
            const: "kombify.task-ref.v1",
          },
          owner: {
            const: "paperwork",
          },
          id: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[A-Za-z0-9._:-]{1,256}$",
          },
          revision: {
            type: "string",
            pattern: "^[1-9][0-9]{0,18}$",
            description:
              "Positive decimal Paperwork row_version, without ETag quoting. Runtime rejects values above PostgreSQL signed bigint maximum.",
          },
        },
      },
      target: {
        type: "object",
        additionalProperties: false,
        required: ["agentInstanceId", "agentClass", "templateDigest"],
        properties: {
          agentInstanceId: {
            type: "string",
            minLength: 1,
          },
          agentClass: {
            type: "string",
            minLength: 1,
          },
          templateDigest: {
            $ref: "agent-authority.v2.schema.json#/$defs/digest",
          },
        },
      },
      binding: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "tenantId",
          "subject",
          "requester",
          "target",
          "definitionIds",
          "resources",
          "requestedShape",
          "authorityBasis",
          "policy",
          "budget",
          "catalogRevision",
          "audience",
          "intent",
          "expiresAt",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.activation-request-binding.v2",
          },
          tenantId: {
            type: "string",
            minLength: 1,
          },
          subject: {
            type: "string",
            minLength: 1,
          },
          requester: {
            oneOf: [
              {
                $ref: "agent-authority.v2.schema.json#/$defs/agentActor",
              },
              {
                $ref: "#/$defs/ownerActor",
              },
            ],
          },
          ownerEquipment: {
            $ref: "#/$defs/ownerEquipment",
          },
          target: {
            $ref: "#/$defs/target",
          },
          definitionIds: {
            type: "array",
            items: {
              type: "string",
              minLength: 1,
            },
            minItems: 1,
            uniqueItems: true,
          },
          resources: {
            type: "array",
            items: {
              $ref: "agent-authority.v2.schema.json#/$defs/resource",
            },
            minItems: 1,
            uniqueItems: true,
          },
          requestedShape: {
            enum: ["durable", "short-ttl", "one-shot"],
          },
          officeScope: {
            type: "string",
            minLength: 1,
          },
          taskRef: {
            $ref: "#/$defs/taskRef",
          },
          parentLeaseId: {
            type: "string",
            minLength: 1,
            description: "Activation lineage only; never a standing-authority basis.",
          },
          authorityBasis: {
            allOf: [
              {
                $ref: "agent-authority.v2.schema.json#/$defs/basis",
              },
              {
                properties: {
                  facet: {
                    enum: ["use", "self_activate"],
                  },
                },
              },
            ],
          },
          policy: {
            oneOf: [
              {
                $ref: "agent-authority.v2.schema.json#/$defs/policy",
              },
              {
                $ref: "#/$defs/ownerEquipmentPolicy",
              },
            ],
          },
          budget: {
            $ref: "activation-request.v1.schema.json#/$defs/capabilityBudget",
          },
          catalogRevision: {
            type: "string",
            minLength: 1,
          },
          audience: {
            type: "string",
            minLength: 1,
          },
          intent: {
            $ref: "agent-authority.v2.schema.json#/$defs/intent",
          },
          monetaryReservation: {
            $ref: "agent-authority.v2.schema.json#/$defs/monetaryReservation",
          },
          expiresAt: {
            type: "string",
            format: "date-time",
          },
        },
        allOf: [
          {
            if: {
              required: ["ownerEquipment"],
            },
            then: {
              properties: {
                requester: {
                  $ref: "#/$defs/ownerActor",
                },
                target: {
                  properties: {
                    agentInstanceId: {
                      pattern: "^hi_(?!default_)[A-Za-z0-9_-]{1,125}$",
                    },
                    agentClass: {
                      const: "workbench-orchestrator",
                    },
                  },
                },
                policy: {
                  $ref: "#/$defs/ownerEquipmentPolicy",
                },
                requestedShape: {
                  const: "durable",
                },
                authorityBasis: {
                  properties: {
                    facet: {
                      const: "use",
                    },
                  },
                },
                definitionIds: {
                  maxItems: 1,
                },
                resources: {
                  maxItems: 1,
                  items: {
                    $ref: "agent-authority.v2.schema.json#/$defs/legacyResource",
                  },
                },
                intent: {
                  allOf: [
                    {
                      $ref: "agent-authority.v2.schema.json#/$defs/legacyIntent",
                    },
                    {
                      properties: {
                        action: {
                          const: "capability.equip",
                        },
                      },
                    },
                  ],
                },
              },
              not: {
                anyOf: [
                  {
                    required: ["officeScope"],
                  },
                  {
                    required: ["parentLeaseId"],
                  },
                  {
                    required: ["taskRef"],
                  },
                  {
                    required: ["monetaryReservation"],
                  },
                ],
              },
            },
            else: {
              properties: {
                requester: {
                  $ref: "agent-authority.v2.schema.json#/$defs/agentActor",
                },
                policy: {
                  $ref: "agent-authority.v2.schema.json#/$defs/policy",
                },
              },
            },
          },
        ],
      },
    },
  },
  "activation-decision.v2.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v2/activation-decision.schema.json",
    title: "Kombify ActivationDecisionV2",
    description:
      "A persisted agent decision or explicit owner-equipment settlement. Standing use records only an operation. Every authority-chain link is Cloud-resolved evidence, never grant authority.",
    type: "object",
    additionalProperties: false,
    required: ["schemaVersion", "id", "binding", "decisionDigest"],
    properties: {
      schemaVersion: {
        const: "kombify.activation-decision.v2",
      },
      id: {
        type: "string",
        minLength: 1,
      },
      binding: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "requestId",
          "requestDigest",
          "tenantId",
          "subject",
          "actor",
          "kind",
          "verdict",
          "policy",
          "authorityBasis",
          "authorityChain",
          "decidedAt",
          "intent",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.activation-decision-binding.v2",
          },
          requestId: {
            type: "string",
            minLength: 1,
          },
          requestDigest: {
            $ref: "agent-authority.v2.schema.json#/$defs/digest",
          },
          tenantId: {
            type: "string",
            minLength: 1,
          },
          subject: {
            type: "string",
            minLength: 1,
          },
          actor: {
            oneOf: [
              {
                $ref: "agent-authority.v2.schema.json#/$defs/agentActor",
              },
              {
                $ref: "activation-request.v2.schema.json#/$defs/ownerActor",
              },
            ],
          },
          kind: {
            enum: ["agent", "self_activate", "owner_equip"],
          },
          ownerEquipment: {
            $ref: "activation-request.v2.schema.json#/$defs/ownerEquipment",
          },
          verdict: {
            enum: ["approved", "denied"],
          },
          policy: {
            oneOf: [
              {
                $ref: "agent-authority.v2.schema.json#/$defs/policy",
              },
              {
                $ref: "activation-request.v2.schema.json#/$defs/ownerEquipmentPolicy",
              },
            ],
          },
          authorityBasis: {
            $ref: "agent-authority.v2.schema.json#/$defs/basis",
          },
          authorityChain: {
            type: "array",
            items: {
              $ref: "agent-authority.v2.schema.json#/$defs/authorityChainLink",
            },
            minItems: 1,
            uniqueItems: true,
            description:
              "Complete Cloud-resolved evidence. Agent decisions bind the leaf grantee to the actor; owner_equip binds one user issuer to the exact agent target.",
          },
          decidedAt: {
            type: "string",
            format: "date-time",
          },
          intent: {
            $ref: "agent-authority.v2.schema.json#/$defs/intent",
          },
          monetaryReservation: {
            $ref: "agent-authority.v2.schema.json#/$defs/monetaryReservation",
          },
        },
        allOf: [
          {
            if: {
              properties: {
                kind: {
                  const: "owner_equip",
                },
              },
              required: ["kind"],
            },
            then: {
              required: ["ownerEquipment"],
              properties: {
                actor: {
                  $ref: "activation-request.v2.schema.json#/$defs/ownerActor",
                },
                verdict: {
                  const: "approved",
                },
                policy: {
                  $ref: "activation-request.v2.schema.json#/$defs/ownerEquipmentPolicy",
                },
                authorityBasis: {
                  properties: {
                    facet: {
                      const: "use",
                    },
                  },
                },
                authorityChain: {
                  maxItems: 1,
                },
                intent: {
                  allOf: [
                    {
                      $ref: "agent-authority.v2.schema.json#/$defs/legacyIntent",
                    },
                    {
                      properties: {
                        action: {
                          const: "capability.equip",
                        },
                      },
                    },
                  ],
                },
              },
              not: {
                required: ["monetaryReservation"],
              },
            },
            else: {
              properties: {
                actor: {
                  $ref: "agent-authority.v2.schema.json#/$defs/agentActor",
                },
                policy: {
                  $ref: "agent-authority.v2.schema.json#/$defs/policy",
                },
              },
              not: {
                required: ["ownerEquipment"],
              },
            },
          },
          {
            if: {
              properties: {
                kind: {
                  const: "agent",
                },
              },
            },
            then: {
              oneOf: [
                {
                  properties: {
                    authorityBasis: {
                      properties: {
                        facet: {
                          const: "approve",
                        },
                      },
                    },
                  },
                },
                {
                  properties: {
                    verdict: {
                      const: "approved",
                    },
                    authorityBasis: {
                      properties: {
                        facet: {
                          const: "use",
                        },
                      },
                    },
                  },
                },
              ],
            },
          },
          {
            if: {
              properties: {
                kind: {
                  const: "self_activate",
                },
              },
            },
            then: {
              properties: {
                verdict: {
                  const: "approved",
                },
                authorityBasis: {
                  properties: {
                    facet: {
                      const: "self_activate",
                    },
                  },
                },
              },
            },
          },
        ],
      },
      decisionDigest: {
        $ref: "agent-authority.v2.schema.json#/$defs/digest",
      },
    },
  },
  "capability-lease.v2.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v2/capability-lease.schema.json",
    title: "Kombify CapabilityLeaseV2",
    description:
      "AI-owned activation record. Gateway JWS typ kombify.capability-lease.v2 binds this request and decision; v1 verifiers reject it.",
    type: "object",
    additionalProperties: false,
    required: [
      "schemaVersion",
      "id",
      "activationRequestId",
      "binding",
      "requestDigest",
      "decisionId",
      "decisionDigest",
      "epoch",
      "status",
      "issuedAt",
      "expiresAt",
    ],
    properties: {
      schemaVersion: {
        const: "kombify.capability-lease.v2",
      },
      id: {
        type: "string",
        minLength: 1,
      },
      activationRequestId: {
        type: "string",
        minLength: 1,
      },
      binding: {
        $ref: "activation-request.v2.schema.json#/$defs/binding",
      },
      requestDigest: {
        $ref: "agent-authority.v2.schema.json#/$defs/digest",
      },
      decisionId: {
        type: "string",
        minLength: 1,
      },
      decisionDigest: {
        $ref: "agent-authority.v2.schema.json#/$defs/digest",
      },
      epoch: {
        type: "integer",
        minimum: 0,
        maximum: 9007199254740991,
      },
      status: {
        enum: ["active", "expired", "revoked", "consumed"],
      },
      issuedAt: {
        type: "string",
        format: "date-time",
      },
      expiresAt: {
        type: "string",
        format: "date-time",
      },
      revokedAt: {
        type: "string",
        format: "date-time",
      },
      consumedAt: {
        type: "string",
        format: "date-time",
      },
    },
    allOf: [
      {
        if: {
          properties: {
            status: {
              const: "revoked",
            },
          },
          required: ["status"],
        },
        then: {
          required: ["revokedAt"],
        },
      },
      {
        if: {
          properties: {
            status: {
              const: "consumed",
            },
          },
          required: ["status"],
        },
        then: {
          required: ["consumedAt"],
          properties: {
            binding: {
              properties: {
                requestedShape: {
                  const: "one-shot",
                },
              },
            },
          },
        },
      },
    ],
  },
  "agent-role-template.v2.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v2/agent-role-template.schema.json",
    title: "Kombify AgentRoleTemplate v2",
    description:
      "Curated Factory equipment and authority defaults. Enrollment resolves these defaults against current owner eligibility and exact resources through Cloud; catalog contents never grant authority by themselves.",
    type: "object",
    additionalProperties: false,
    required: [
      "schemaVersion",
      "id",
      "version",
      "digest",
      "lifecycle",
      "trustClass",
      "publisher",
      "factoryId",
      "officeDefinitionIds",
      "agentType",
      "label",
      "description",
      "baseAgentId",
      "defaults",
      "budget",
      "durableTtlSeconds",
      "knowledgeTier",
      "spawnDepth",
      "maxChildren",
      "executionClass",
      "authorityDefaults",
    ],
    properties: {
      schemaVersion: {
        const: "kombify.agent-role-template.v2",
      },
      id: {
        type: "string",
        minLength: 1,
        description:
          "The template id. The Supply Dock sells the role under the same id as its template product.",
      },
      version: {
        type: "string",
        minLength: 1,
      },
      digest: {
        type: "string",
        pattern: "^sha256:[0-9a-f]{64}$",
        description:
          "SHA-256 under the kombify.agent-role-template.digest.v2 domain over the canonical authored projection defined by AGENT-CAPABILITY-PROVISIONING-STANDARD.md section 4.2b. The projection excludes digest, lifecycle and trustClass; a spec names the digest it was composed against, so authored changes cannot silently redefine a pending spawn.",
      },
      lifecycle: {
        enum: ["draft", "preview", "active", "revoked"],
        description:
          "The plugin registry's lifecycle, because a template is catalog content. Customers are listed active records only; preview is staff.",
      },
      trustClass: {
        type: "string",
        enum: ["catalog-verified", "broker-listed", "user-attached"],
        description:
          "What Kombify vouches for, not who published it. An unrecognised claim reads as user-attached (SUPPLY-DOCK-SHOP-STANDARD.md section 2a), never as the most convenient class.",
      },
      publisher: {
        type: "object",
        additionalProperties: false,
        required: ["name", "firstParty"],
        properties: {
          name: {
            type: "string",
            minLength: 1,
          },
          firstParty: {
            type: "boolean",
          },
        },
      },
      factoryId: {
        type: "string",
        minLength: 1,
        description: "The provided Factory in which this role runs.",
      },
      officeDefinitionIds: {
        type: "array",
        uniqueItems: true,
        items: {
          type: "string",
          minLength: 1,
        },
        description:
          "Office definitions of that Factory the role may be assigned to. Empty means any office of the Factory, never no office.",
      },
      agentType: {
        $ref: "agent-spawn-spec.v1.schema.json#/$defs/creatableAgentType",
      },
      label: {
        type: "string",
        minLength: 1,
      },
      description: {
        type: "string",
      },
      baseAgentId: {
        type: "string",
        minLength: 1,
        description:
          "The registered runtime agent class used by this role; never an independently authenticated instance.",
      },
      defaults: {
        type: "array",
        items: {
          $ref: "agent-spawn-spec.v1.schema.json#/$defs/equipmentEntry",
        },
        description:
          "Pre-selected equipment at spawn. A person may deselect from it or add beyond it within their own reach; the divergence is recorded, not refused.",
      },
      budget: {
        $ref: "activation-request.v1.schema.json#/$defs/capabilityBudget",
        description:
          "Default resource budget narrowed by enrollment and current grants. It is not a monetary allocation.",
      },
      durableTtlSeconds: {
        type: "integer",
        minimum: 0,
        description:
          "The durable lease TTL for this role (standard section 4.1). The origin's per-agent-type fallback applies only until a template owns the value, and is then deleted rather than re-tuned.",
      },
      maxTtlSeconds: {
        type: "integer",
        minimum: 0,
        description:
          "Upper bound for an ad-hoc instance's lifetime. Absent for standing roles; a spec's ttlSeconds never exceeds it and never exceeds the parent's remainder.",
      },
      knowledgeTier: {
        enum: ["KT0", "KT1", "KT2", "KT3"],
        description:
          "The knowledge capability profile sold with the role. A profile selector, never a knowledge grant of its own.",
      },
      spawnDepth: {
        type: "integer",
        minimum: 0,
        description:
          "How deep this role may spawn: 0 for a leaf, 1 for a parent. A role-template budget property; launch ships depth 1.",
      },
      maxChildren: {
        type: "integer",
        minimum: 0,
        description:
          "Concurrent children an instance of this role may hold. Enforced at admission, not at use.",
      },
      executionClass: {
        enum: ["kombify-generic-host", "remote-environment", "external-harness", "execution-node"],
        description:
          "Where an instance of this role runs. A Supply Dock class, not ExecutionEnvironmentV1.kind (target section 7): the generic host is the agent-host Worker, a remote environment is a K1 sandbox, an external harness is equipped by lease issuance only, and an execution node is post-v1.",
      },
      authorityDefaults: {
        type: "object",
        additionalProperties: false,
        required: ["use", "selfActivate", "issue", "delegate", "approve", "revoke"],
        properties: {
          use: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
          selfActivate: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
          issue: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
          delegate: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
          approve: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
          revoke: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
        },
        description:
          "Six independent definition-set proposals at enrollment. Empty means no default grant for that facet. A role default never grants authority or caps an owner's explicit grant, and no facet implies another.",
      },
    },
  },
  "activation-request.v1.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v1/activation-request.schema.json",
    title: "Kombify ActivationRequest v1",
    description:
      "A request to activate capabilities. Never itself an authorization. Shapes are owned by kombify-Core/standards/AGENT-CAPABILITY-PROVISIONING-STANDARD.md section 3; decisions by AI-CAPABILITY-PROVISIONING-TARGET.md.",
    type: "object",
    additionalProperties: false,
    required: [
      "schemaVersion",
      "id",
      "requester",
      "definitionIds",
      "requestedShape",
      "state",
      "createdAt",
    ],
    properties: {
      schemaVersion: {
        const: "kombify.activation-request.v1",
      },
      id: {
        type: "string",
        minLength: 1,
      },
      tenantId: {
        type: "string",
        description:
          "The organization. Derived from the authenticated envelope, never from the request body.",
      },
      requester: {
        type: "object",
        additionalProperties: false,
        required: ["subject", "principal", "agentInstanceId", "agentType"],
        description:
          "subject is the user whose authority is delegated and caps eligibility. principal is the authenticated actor that filed the request: the agent instance for agent-initiated and equip flows. The approver must differ from principal, not from subject.",
        properties: {
          subject: {
            type: "string",
            minLength: 1,
          },
          principal: {
            type: "string",
            minLength: 1,
          },
          agentInstanceId: {
            type: "string",
            minLength: 1,
          },
          agentType: {
            enum: ["companion", "orchestrator", "permanent", "expert", "ad-hoc"],
            description:
              "Governance ceiling, never inferred from a name. orchestrator is the primary may_issue holder and is never resolved to permanent.",
          },
        },
      },
      definitionIds: {
        type: "array",
        minItems: 1,
        uniqueItems: true,
        items: {
          type: "string",
          minLength: 1,
        },
        description:
          "Catalog definition ids. Never inline policy: the signed catalog is the only definition authority.",
      },
      resourceScope: {
        type: "object",
        description:
          "Definition-specific narrowing. Persisted and bound into the lease token; instance-level enforcement arrives with the resourceBinding contract.",
      },
      requestedShape: {
        enum: ["durable", "short-ttl", "one-shot"],
      },
      approvalRequirement: {
        enum: ["none", "step_up", "human", "two_person", "operator"],
        description:
          "The approval class the minting Gateway read from the signed catalog. Absent or unknown reads as operator, so a catalog gap can only make an activation stricter.",
      },
      officeScope: {
        type: "string",
        description:
          "Pure attenuation. An office never widens anything and is never a synthetic job label.",
      },
      parentLeaseId: {
        type: "string",
        description:
          "Lineage and revocation anchor, never capability subsetting: a child is bounded by its parent's issuance envelope and its own eligibility.",
      },
      budget: {
        $ref: "#/$defs/capabilityBudget",
      },
      justification: {
        type: "string",
      },
      state: {
        enum: ["pending", "self_activated", "approved", "denied", "expired"],
        description:
          "self_activated is policy-auto-approval inside the eligibility ceiling: no principal decides it, so decidedBy stays absent.",
      },
      createdAt: {
        type: "string",
        format: "date-time",
      },
      decidedAt: {
        type: "string",
        format: "date-time",
      },
      decidedBy: {
        type: "string",
        description:
          "MUST differ from requester.principal when state is approved. Absent for self_activated.",
      },
    },
    allOf: [
      {
        if: {
          properties: {
            state: {
              const: "approved",
            },
          },
          required: ["state"],
        },
        then: {
          required: ["decidedBy"],
        },
      },
      {
        if: {
          properties: {
            state: {
              const: "self_activated",
            },
          },
          required: ["state"],
        },
        then: {
          not: {
            required: ["decidedBy"],
          },
        },
      },
    ],
    $defs: {
      capabilityBudget: {
        type: "object",
        additionalProperties: false,
        description:
          "The granted envelope, enforced at minting and never widened at runtime. Zero means the minting Gateway did not bound that dimension.",
        properties: {
          tokens: {
            type: "integer",
            minimum: 0,
          },
          maxActiveLeases: {
            type: "integer",
            minimum: 0,
          },
          maxEquippedDefinitions: {
            type: "integer",
            minimum: 0,
            description:
              "The loadout budget: the cap on simultaneously equipped definitions, and thereby on the projected tool surface.",
          },
        },
      },
    },
  },
  "agent-spawn-spec.v1.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v1/agent-spawn-spec.schema.json",
    title: "Kombify AgentSpawnSpec v1",
    description:
      "One instantiation of a role template. A request for admission, never an admission: admission meets the spec against the template and the granting principal's own reach and refuses with a structured denial rather than silently narrowing it. Shapes are owned by kombify-Core/standards/AGENT-CAPABILITY-PROVISIONING-STANDARD.md section 3a; decisions by AI-CAPABILITY-PROVISIONING-TARGET.md.",
    type: "object",
    additionalProperties: false,
    required: [
      "schemaVersion",
      "templateId",
      "displayName",
      "agentType",
      "factoryId",
      "officeId",
      "equipment",
      "budget",
    ],
    properties: {
      schemaVersion: {
        const: "kombify.agent-spawn-spec.v1",
      },
      templateId: {
        type: "string",
        minLength: 1,
        description:
          "The role template this spec instantiates. The template supplies the defaults and the two ceilings; it is never the cap on the granting human.",
      },
      templateDigest: {
        type: "string",
        pattern: "^sha256:[0-9a-f]{64}$",
        description:
          "The template document the spec was composed against. Admission refuses a stale digest rather than spawning against a template nobody read.",
      },
      displayName: {
        type: "string",
        minLength: 1,
        description:
          "What the owner calls this agent. A label, never an identity: the instance id and agentId are the identity.",
      },
      agentType: {
        $ref: "#/$defs/creatableAgentType",
      },
      factoryId: {
        type: "string",
        minLength: 1,
        description:
          "The Factory (harness id) the instance is employed in. It matches the template's Factory; a spec never moves a role to another one.",
      },
      officeId: {
        type: "string",
        minLength: 1,
        description:
          "The Office the instance is employed in. Mandatory: factory children always carry an office (standard section 6). Pure attenuation, and always a real office, never a synthetic job label.",
      },
      projectId: {
        type: "string",
        minLength: 1,
        description:
          "Owned project for a Project agent; admission verifies its accountable Office.",
      },
      sessionId: {
        type: "string",
        minLength: 1,
        description: "Owned complete task session, retained through archive/resume.",
      },
      sessionSource: {
        enum: ["ai", "workbench"],
        description: "Owning session API; never infer ownership from an opaque identifier.",
      },
      task: {
        type: "string",
        description:
          "The one job of an ad-hoc instance, in the owner's words. Prose for the run, never a capability and never read as one.",
      },
      equipment: {
        type: "array",
        items: {
          $ref: "#/$defs/equipmentEntry",
        },
        description:
          "What the spec asks to be equipped with, product by product. Requests, never grants: every definition still passes per-definition admission.",
      },
      excludedDefinitionIds: {
        type: "array",
        uniqueItems: true,
        items: {
          type: "string",
          minLength: 1,
        },
        description:
          "Suggested functional equipment deliberately omitted by the owner in role-based creation. Admission validates against the composed suggestions and retains this choice for audit. Technical runtime prerequisites stay separate.",
      },
      budget: {
        $ref: "activation-request.v1.schema.json#/$defs/capabilityBudget",
        description:
          "Carved from the granting principal's remainder at admission. Enforced at minting, never widened at runtime.",
      },
      ttlSeconds: {
        type: "integer",
        minimum: 0,
        description:
          "Legacy definition deadline input. Scope-bound Project/Task definitions retain identity; bounded execution leases and runtime invocation deadlines are separate.",
      },
      parentInstanceId: {
        type: "string",
        minLength: 1,
        description:
          "Set when an agent spawns a child. Lineage and revocation anchor, never capability subsetting: the child is bounded by the parent's issuance envelope and its own eligibility.",
      },
    },
    $defs: {
      creatableAgentType: {
        enum: ["permanent", "expert", "ad-hoc"],
        description:
          "Technical scope and lifecycle profile, independent of role defaults and current grants.",
      },
      equipmentResourceBinding: {
        type: "object",
        additionalProperties: false,
        required: ["dimension", "value"],
        description:
          "Narrows one entry to a single resource: the Office cursor's dimension and the exact instance id (techstack.server with a server id, paperwork.mailbox with an account id). Enforced through the lease's resourceBinding (standard section 4.2b). Absent means the product's whole scope, never a wildcard a client invented.",
        properties: {
          dimension: {
            type: "string",
            minLength: 1,
          },
          value: {
            type: "string",
            minLength: 1,
          },
        },
      },
      equipmentEntry: {
        type: "object",
        additionalProperties: false,
        required: ["productId", "definitionIds"],
        description:
          "One product with the definitions the agent asks for from it. The same shape a project's equipment list carries, so a spawn can request a project default without translation. Requests, never grants.",
        properties: {
          productId: {
            type: "string",
            pattern: "^(plugin|skill|integration|knowledge-pack|device|template):.+$",
            description:
              "A Supply Dock product id (SUPPLY-DOCK-SHOP-STANDARD.md section 3), not a capability id: a capability is what a product requests.",
          },
          definitionIds: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
            description:
              "Catalog definition ids drawn from that product's own requests. Never inline policy: the signed capability catalog is the only definition authority.",
          },
          resourceBinding: {
            $ref: "#/$defs/equipmentResourceBinding",
          },
        },
      },
    },
  },
  "wallet-lease.v1.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v1/wallet-lease.schema.json",
    title: "Kombify WalletLeaseV1",
    description:
      "Decoded form of the compact JWS the Gateway signs for exactly one Wallet operation: the protected header and the claims. Header typ kombify.wallet-lease.v1 and alg ES256 are pinned; the verifier selects the key by kid from its own JWKS, never from the token. The Gateway signing key is separate from the Wallet root key and rotates by kid. authorization_details name the exact item operation (kombify_wallet_item), the exact host, method and path prefix of a brokered call (kombify_wallet_broker; a brokered call is never authorized without a host), or an operation on a whole custody namespace (kombify_wallet_partition), which never releases a value. The lease is issued only for a right the caller holds, grants nothing by itself, and the Wallet Store checks it again: signature, kid, aud, jti replay, the exp - iat limit of 300 seconds (executed by scripts/check-agent-authority-contract.mjs, not expressible in JSON Schema), the current grantGeneration and the exact operation. A pathPrefix matches whole path segments. A kombify_wallet_item without version authorizes the item's current version at execution time; the executor records the resolved version in the audit event.",
    type: "object",
    additionalProperties: false,
    required: ["header", "claims"],
    properties: {
      header: {
        $ref: "#/$defs/header",
      },
      claims: {
        $ref: "#/$defs/claims",
      },
    },
    $defs: {
      text: {
        type: "string",
        minLength: 1,
        maxLength: 256,
        pattern: "^[^\\u0000-\\u001f\\u007f]+$",
      },
      decimal: {
        type: "string",
        pattern: "^[1-9][0-9]{0,18}$",
      },
      header: {
        type: "object",
        additionalProperties: false,
        required: ["alg", "typ", "kid"],
        properties: {
          alg: {
            const: "ES256",
          },
          typ: {
            const: "kombify.wallet-lease.v1",
          },
          kid: {
            type: "string",
            minLength: 1,
            maxLength: 128,
            pattern: "^[A-Za-z0-9._:-]+$",
          },
        },
        description:
          "Verifier boundary profile. No caller-selected jku/jwk/x5u/x5c and no alternate algorithm is admitted.",
      },
      claims: {
        type: "object",
        additionalProperties: false,
        required: [
          "iss",
          "sub",
          "act",
          "aud",
          "authorization_details",
          "jti",
          "iat",
          "exp",
          "grantGeneration",
        ],
        properties: {
          iss: {
            const: "urn:kombify:wallet:lease:gateway",
          },
          sub: {
            $ref: "#/$defs/text",
            description: "The Wallet owner whose item the lease operates on.",
          },
          act: {
            type: "object",
            additionalProperties: false,
            required: ["sub"],
            properties: {
              sub: {
                $ref: "#/$defs/text",
              },
            },
            description:
              "The acting party (RFC 8693): the agent instance id for an agent run, the owner's subject for a person, service:<serviceId> for a kombify product backend acting on the owner's standing assignment. A run id correlates through jti and the audit operation_id.",
          },
          aud: {
            type: "string",
            minLength: 1,
            maxLength: 2048,
            format: "uri",
            description:
              "The registered private executor audience; no lease issued for another audience is valid here.",
          },
          authorization_details: {
            type: "array",
            minItems: 1,
            maxItems: 32,
            uniqueItems: true,
            items: {
              oneOf: [
                {
                  $ref: "#/$defs/itemDetail",
                },
                {
                  $ref: "#/$defs/brokerDetail",
                },
                {
                  $ref: "#/$defs/partitionDetail",
                },
              ],
            },
          },
          jti: {
            $ref: "#/$defs/text",
            description:
              "Unique lease id; the Wallet Store consumes it atomically and rejects replay.",
          },
          iat: {
            type: "integer",
            minimum: 0,
            maximum: 9007199254740991,
          },
          exp: {
            type: "integer",
            minimum: 0,
            maximum: 9007199254740991,
            description: "Strictly after iat and at most 300 seconds after it.",
          },
          grantGeneration: {
            type: "integer",
            minimum: 1,
            maximum: 9007199254740991,
            description:
              "The Cloud grant generation of the right exercised; a later generation or a revocation invalidates the lease.",
          },
          taskRef: {
            $ref: "activation-request.v2.schema.json#/$defs/taskRef",
          },
          projectRef: {
            $ref: "decision-request.v1.schema.json#/$defs/projectRef",
          },
        },
      },
      itemDetail: {
        type: "object",
        additionalProperties: false,
        required: [
          "type",
          "custodyNamespace",
          "itemId",
          "action",
          "recipientRef",
          "recipientGeneration",
        ],
        properties: {
          type: {
            const: "kombify_wallet_item",
          },
          custodyNamespace: {
            $ref: "#/$defs/text",
          },
          itemId: {
            $ref: "#/$defs/text",
          },
          version: {
            $ref: "#/$defs/decimal",
          },
          action: {
            allOf: [
              {
                $ref: "agent-authority.v2.schema.json#/$defs/walletActionV3",
              },
              {
                not: {
                  const: "brokered_use",
                },
              },
            ],
            description:
              "Any Wallet action except brokered_use, which is authorized only by a kombify_wallet_broker detail that pins host, method and path.",
          },
          recipientRef: {
            $ref: "#/$defs/text",
            description: "Key id of the enrolled recipient the result is sealed to.",
          },
          recipientGeneration: {
            $ref: "#/$defs/decimal",
            description:
              "Generation of that recipient key; the Wallet Store resolves the thumbprint from its own authenticated key statement.",
          },
        },
      },
      partitionDetail: {
        type: "object",
        additionalProperties: false,
        required: ["type", "custodyNamespace", "operation", "recipientRef", "recipientGeneration"],
        properties: {
          type: {
            const: "kombify_wallet_partition",
          },
          custodyNamespace: {
            $ref: "#/$defs/text",
          },
          operation: {
            enum: ["list_items", "capture_key", "resolve_variables"],
            description:
              "list_items: list the namespace's items as references and metadata. capture_key: obtain the namespace's key for capturing values. Neither releases a stored value. resolve_variables: resolve the namespace's variables and configurations for one scope (environment over project over account), including the items their secret:// references name; every value in the result is read as an audited per-item operation that needs the read right on that item, and the result is sealed to the recipient.",
          },
          recipientRef: {
            $ref: "#/$defs/text",
            description: "Key id of the enrolled recipient the result is sealed to.",
          },
          recipientGeneration: {
            $ref: "#/$defs/decimal",
            description: "Generation of that recipient key.",
          },
        },
      },
      brokerDetail: {
        type: "object",
        additionalProperties: false,
        required: ["type", "itemId", "host", "method", "pathPrefix"],
        properties: {
          type: {
            const: "kombify_wallet_broker",
          },
          itemId: {
            $ref: "#/$defs/text",
          },
          host: {
            type: "string",
            minLength: 3,
            maxLength: 260,
            pattern:
              "^(?![0-9.:]+$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+(:[0-9]{1,5})?$",
            description:
              "Exact lowercase ASCII host name with at least two labels and an optional port. No wildcard, no IP literal, no single-label name.",
          },
          method: {
            enum: ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE"],
          },
          pathPrefix: {
            type: "string",
            minLength: 1,
            maxLength: 1024,
            pattern:
              "^(?!.*%(?![0-9A-Fa-f]{2}))(?!.*%(?:2[eEfF]|5[cC]|25|0[0-9A-Fa-f]|1[0-9A-Fa-f]|7[fF]))(?!.*/\\.{1,2}(?:/|$))/[A-Za-z0-9._~!$&'()*+,;=:@%/-]*$",
            description:
              "Absolute path prefix matched on whole segments. No query, fragment or dot segment, and no encoded dot, slash, backslash, percent sign or control character, so nothing depends on how many times a path is decoded.",
          },
        },
      },
    },
  },
  "audit-event.v2.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/audit/v2/audit-event.schema.json",
    title: "Kombify AuditEventV2",
    description:
      "AuditEventV1 plus the optional closed wallet member for Wallet custody events: every decryption, brokered use, disclosure, delivery and refusal of a Wallet item. All v1 members, their closed metadata vocabulary and the privacy rules are unchanged (pseudonymous HMAC keys, no free-form payload); event_version is 2 so a v1 reader rejects the document instead of dropping the member. The record carries no value, ciphertext, key or token. Mapping of the Wallet event facts: owner is subject_key, the actor (act.sub of the lease) is actor_key, the operation is operation_id, and the lease is wallet.leaseJti. Convention: action wallet.<wallet.action>, resource wallet.item. The Wallet Store writes the event before it uses or releases a value, with outcome pending, and a later event states the outcome; a pending disclosed event counts as a disclosure for rotation even if no completion follows. valueReleased brokered: the value was used inside custody. disclosed: it left custody sealed to wallet.recipientRef. none: no value was used or released. Consistency of valueReleased with the action (walletActionProfilesV3) and the outcome is part of this schema. leaseJti is absent only for Wallet-internal operations that run without a caller, such as scheduled rotation. Retention is authority, as for every authority-plane record. Cloud adoption (codec, writers, retention lifecycle) is pending; producers must not send event_version 2 until Cloud accepts it. Semantic invariants of the shared authority members are executed by scripts/check-decision-contract.mjs auditSemantics, and the Wallet rules by scripts/check-agent-authority-contract.mjs.",
    type: "object",
    additionalProperties: false,
    required: [
      "event_version",
      "event_id",
      "occurred_at",
      "event_class",
      "actor_key",
      "tenant_key",
      "subject_key",
      "action",
      "resource",
      "outcome",
      "source_service",
    ],
    properties: {
      event_version: {
        const: 2,
      },
      event_id: {
        type: "string",
        minLength: 1,
        maxLength: 128,
      },
      occurred_at: {
        type: "string",
        format: "date-time",
      },
      event_class: {
        enum: ["security", "business", "user", "system"],
      },
      actor_key: {
        type: "string",
        minLength: 1,
        maxLength: 256,
        description: "Domain-separated HMAC of the actor; never a raw identifier.",
      },
      tenant_key: {
        type: "string",
        minLength: 1,
        maxLength: 256,
      },
      subject_key: {
        type: "string",
        minLength: 1,
        maxLength: 256,
      },
      action: {
        type: "string",
        minLength: 1,
        maxLength: 128,
      },
      resource: {
        type: "string",
        minLength: 1,
        maxLength: 256,
      },
      outcome: {
        enum: ["success", "failure", "denied", "error", "pending", "unknown"],
      },
      source_service: {
        type: "string",
        minLength: 1,
        maxLength: 128,
      },
      correlation_id: {
        type: "string",
        minLength: 1,
        maxLength: 128,
      },
      trace_id: {
        type: "string",
        minLength: 1,
        maxLength: 128,
      },
      client_class: {
        enum: ["browser", "mobile_browser", "native_app", "api_client", "bot", "unknown"],
      },
      ip_token: {
        type: "string",
        minLength: 1,
        maxLength: 128,
        description: "A daily HMAC of the source IP; never a raw IP address.",
      },
      metadata: {
        type: "object",
        propertyNames: {
          enum: [
            "activity",
            "amount",
            "attempts",
            "cancelAtPeriodEnd",
            "code",
            "connection",
            "country",
            "created",
            "currency",
            "duration",
            "errorName",
            "eventType",
            "feature",
            "fieldCount",
            "limit",
            "legacyIdentityAdopted",
            "method",
            "plan",
            "planChanged",
            "reason",
            "resource_id",
            "role",
            "roleCount",
            "severity",
            "source",
            "status",
            "statusCode",
            "success",
            "taxType",
            "timeWindowMs",
            "timestamp",
            "sessionType",
            "tool",
            "toolId",
            "type",
            "windowMs",
          ],
        },
        additionalProperties: {
          type: ["string", "number", "boolean", "null"],
        },
        description:
          "Closed scalar vocabulary (Cloud AUDIT_METADATA_KEYS); free-form descriptions, request details and user input do not belong in the audit stream.",
      },
      operation_id: {
        $ref: "decision-request.v1.schema.json#/$defs/id",
        description: "Correlation id of the operation (DecisionRequestV1.operationId).",
      },
      decision_id: {
        $ref: "decision-request.v1.schema.json#/$defs/id",
        description: "DecisionRequestV1.decisionId the event belongs to.",
      },
      grant_id: {
        $ref: "decision-request.v1.schema.json#/$defs/id",
        description: "Grant revision id written or used.",
      },
      lease_id: {
        $ref: "decision-request.v1.schema.json#/$defs/id",
        description: "Capability lease id minted or used.",
      },
      retention_class: {
        enum: ["standard", "authority"],
        description:
          "standard: 90 days. authority: at least 365 days in the separately administered append-only anchor. Absent means standard.",
      },
      wallet: {
        $ref: "#/$defs/walletCustody",
      },
    },
    $defs: {
      walletCustody: {
        type: "object",
        additionalProperties: false,
        required: ["custodyNamespace", "itemId", "action", "valueReleased"],
        properties: {
          custodyNamespace: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          itemId: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
          version: {
            type: "string",
            pattern: "^[1-9][0-9]{0,18}$",
            description:
              "The exact version used or released; absent only before a first version exists.",
          },
          action: {
            $ref: "agent-authority.v2.schema.json#/$defs/walletActionV3",
          },
          recipientRef: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
            description: "Key id of the enrolled recipient a disclosed value was sealed to.",
          },
          valueReleased: {
            enum: ["brokered", "disclosed", "none"],
          },
          leaseJti: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[^\\u0000-\\u001f\\u007f]+$",
          },
        },
      },
    },
    allOf: [
      {
        if: {
          required: ["wallet"],
        },
        then: {
          required: ["operation_id", "retention_class"],
          properties: {
            retention_class: {
              const: "authority",
            },
            event_class: {
              const: "security",
            },
          },
        },
      },
      {
        if: {
          properties: {
            outcome: {
              enum: ["denied"],
            },
          },
          required: ["outcome"],
        },
        then: {
          properties: {
            wallet: {
              properties: {
                valueReleased: {
                  enum: ["none"],
                },
              },
            },
          },
        },
      },
      {
        if: {
          properties: {
            wallet: {
              properties: {
                action: {
                  enum: ["brokered_use", "mint_child_credential", "sign"],
                },
              },
              required: ["action"],
            },
          },
          required: ["wallet"],
        },
        then: {
          allOf: [
            {
              properties: {
                wallet: {
                  properties: {
                    valueReleased: {
                      enum: ["brokered", "none"],
                    },
                  },
                },
              },
            },
            {
              if: {
                properties: {
                  outcome: {
                    enum: ["success", "pending"],
                  },
                },
                required: ["outcome"],
              },
              then: {
                properties: {
                  wallet: {
                    properties: {
                      valueReleased: {
                        enum: ["brokered"],
                      },
                    },
                  },
                },
              },
            },
          ],
        },
      },
      {
        if: {
          properties: {
            wallet: {
              properties: {
                action: {
                  enum: ["process_injection", "host_delivery", "reveal", "export"],
                },
              },
              required: ["action"],
            },
          },
          required: ["wallet"],
        },
        then: {
          allOf: [
            {
              properties: {
                wallet: {
                  properties: {
                    valueReleased: {
                      enum: ["disclosed", "none"],
                    },
                  },
                },
              },
            },
            {
              if: {
                properties: {
                  outcome: {
                    enum: ["success", "pending"],
                  },
                },
                required: ["outcome"],
              },
              then: {
                properties: {
                  wallet: {
                    properties: {
                      valueReleased: {
                        enum: ["disclosed"],
                      },
                    },
                  },
                },
              },
            },
          ],
        },
      },
      {
        if: {
          properties: {
            wallet: {
              properties: {
                action: {
                  enum: [
                    "capture",
                    "rotate",
                    "delete",
                    "restore",
                    "revoke",
                    "configure",
                    "disconnect",
                  ],
                },
              },
              required: ["action"],
            },
          },
          required: ["wallet"],
        },
        then: {
          properties: {
            wallet: {
              properties: {
                valueReleased: {
                  enum: ["none", "brokered"],
                },
              },
            },
          },
        },
      },
      {
        if: {
          properties: {
            wallet: {
              properties: {
                valueReleased: {
                  const: "disclosed",
                },
              },
              required: ["valueReleased"],
            },
          },
          required: ["wallet"],
        },
        then: {
          properties: {
            wallet: {
              required: ["recipientRef"],
            },
          },
        },
      },
    ],
  },
  "decision-request.v1.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/decision/v1/decision-request.schema.json",
    title: "Kombify DecisionRequestV1",
    description:
      "One decision the platform needs from an approver, written once at creation into the Gateway decision ledger (DECISION-RECORD-2026-10-01 decisions A.1 and A.3). The source stores (AI activation requests, orchestrator approvals, Gateway execution approvals) keep their execution state and reference decisionId through subjectRef; GET /v1/decisions reads this record instead of projecting three stores. InteractionCardV1 is its rendering: card.id is decisionId and card.trusted.intentDigest is intentDigest. Answer options follow decision B.6 with the lifetimes of DECISION-RECORD-2026-10-07-permission-scope-lifetimes (Task, Project, Permanent; no hours-based or 30-day defaults). InteractionCardV1 renders them as the option kinds allow_task (scope.taskRef) and allow_project (scope.projectRef). A request is never a grant: the answer endpoint verifies option, assurance and intent digest and writes exactly one DecisionReceiptV1. No schemaVersion member: the $id is the version. Semantic invariants (approver differs from requester, deny is always offered, standing answers per risk class, task/project bindings, digest vector) are executed by scripts/check-decision-contract.mjs against decision-request.v1.conformance.json.",
    type: "object",
    additionalProperties: false,
    required: [
      "decisionId",
      "operationId",
      "createdAt",
      "expiresAt",
      "requester",
      "onBehalfOf",
      "approver",
      "intent",
      "intentDigest",
      "assuranceRequired",
      "singleUse",
      "defaultOutcome",
      "answerOptions",
    ],
    properties: {
      decisionId: {
        $ref: "#/$defs/id",
        description: "Ledger id; the card id and the {id} of POST /v1/decisions/{id}/answer.",
      },
      operationId: {
        $ref: "#/$defs/id",
        description:
          "Correlation id shared with every grant, lease, self-activation, effect and AuditEventV1 of the same operation.",
      },
      createdAt: {
        type: "string",
        format: "date-time",
      },
      expiresAt: {
        type: "string",
        format: "date-time",
        description: "After this instant the request resolves to defaultOutcome; it never allows.",
      },
      requester: {
        $ref: "#/$defs/principal",
        description:
          "Who asks: the agent instance or run that lacks authority, an automation definition, a service or a person.",
      },
      onBehalfOf: {
        type: "object",
        additionalProperties: false,
        required: ["subject"],
        properties: {
          subject: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            description: "The owner subject whose authority the decision extends.",
          },
          tenant: {
            type: "string",
            minLength: 1,
            maxLength: 256,
          },
        },
      },
      approver: {
        $ref: "#/$defs/principal",
        description: "The first approver of the route. Never the requester.",
      },
      route: {
        type: "array",
        maxItems: 4,
        items: {
          $ref: "#/$defs/principal",
        },
        description:
          "Further approvers in escalation order (policy, approver agent within its envelope, owner; decision B.5).",
      },
      intent: {
        $ref: "#/$defs/intent",
      },
      intentDigest: {
        type: "string",
        pattern: "^sha256:[0-9a-f]{64}$",
        description:
          "Domain-separated SHA-256 (domain kombify.decision-intent.digest.v1) over the RFC 8785 canonical JSON of intent. The receipt and the answer bind this exact digest.",
      },
      assuranceRequired: {
        $ref: "interaction-card.v1.schema.json#/$defs/assurance",
      },
      singleUse: {
        const: true,
        description:
          "One answer resolves the request; a replay returns the recorded receipt and never mints a second one.",
      },
      defaultOutcome: {
        enum: ["deny", "park", "escalate"],
        description:
          "Applied at expiry. A timeout denies, parks or escalates one route step, and never allows.",
      },
      answerOptions: {
        type: "array",
        minItems: 1,
        maxItems: 7,
        uniqueItems: true,
        items: {
          $ref: "#/$defs/answerOption",
        },
      },
      context: {
        type: "object",
        additionalProperties: false,
        properties: {
          taskRef: {
            $ref: "#/$defs/taskRef",
          },
          projectRef: {
            $ref: "#/$defs/projectRef",
          },
        },
        description:
          "Existing lifecycle bindings. allow_task requires taskRef and allow_project requires projectRef; a binding is never manufactured.",
      },
      subjectRef: {
        type: "object",
        additionalProperties: false,
        required: ["store", "id"],
        properties: {
          store: {
            enum: [
              "ai_activation_request",
              "orchestrator_approval",
              "gateway_execution_approval",
              "governed_tool_approval",
            ],
          },
          id: {
            $ref: "#/$defs/id",
          },
        },
        description: "The execution-state record that waits on this decision.",
      },
      supersedes: {
        type: "array",
        maxItems: 20,
        uniqueItems: true,
        items: {
          $ref: "#/$defs/id",
        },
      },
    },
    $defs: {
      id: {
        type: "string",
        pattern: "^[A-Za-z0-9][A-Za-z0-9._:-]{3,127}$",
      },
      principal: {
        type: "object",
        additionalProperties: false,
        required: ["kind", "id"],
        properties: {
          kind: {
            enum: ["person", "agent_instance", "run", "automation", "service", "policy"],
          },
          id: {
            type: "string",
            minLength: 1,
            maxLength: 256,
          },
        },
      },
      answerOption: {
        enum: [
          "allow_once",
          "allow_task",
          "allow_project",
          "allow_always",
          "never",
          "send_to",
          "deny",
        ],
        description:
          "allow_once: one exact effect. allow_task: until the bound task completes, is cancelled or the grant is revoked. allow_project: while the bound project is active. allow_always: a permanent grant revision until revocation or loss of the authorizing authority. never: an exclusion for this agent. send_to: forward to another approver inside their delegated envelope. deny: refuse this request.",
      },
      taskRef: {
        type: "object",
        additionalProperties: false,
        required: ["id", "revision"],
        properties: {
          id: {
            $ref: "#/$defs/id",
          },
          revision: {
            type: "integer",
            minimum: 1,
          },
        },
      },
      projectRef: {
        type: "object",
        additionalProperties: false,
        required: ["id"],
        properties: {
          id: {
            $ref: "#/$defs/id",
          },
        },
      },
      intent: {
        type: "object",
        additionalProperties: false,
        required: ["operation", "resource", "risk"],
        properties: {
          operation: {
            type: "string",
            pattern: "^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$",
            description: "Catalog operation, for example mail.send or techstack.servers.reboot.",
          },
          resource: {
            type: "string",
            minLength: 1,
            maxLength: 300,
          },
          risk: {
            $ref: "interaction-card.v1.schema.json#/$defs/risk",
          },
          entitlementKey: {
            type: "string",
            pattern: "^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$",
            description:
              "Registered key of entitlements.v1.json the effect needs, when one applies.",
          },
          effect: {
            $ref: "interaction-card.v1.schema.json#/$defs/effect",
          },
          parameters: {
            $ref: "interaction-card.v1.schema.json#/$defs/params",
          },
        },
        description:
          "Exactly what would be authorized. Built by the Gateway from validated facts, never from an agent payload.",
      },
    },
  },
};
