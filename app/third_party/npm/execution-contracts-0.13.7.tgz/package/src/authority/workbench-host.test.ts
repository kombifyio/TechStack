import { expect, it } from "vitest";
import {
  activationRequestDigestV2,
  canonicalAuthorityJsonV2,
  type CapabilityLeaseV2,
} from "./index.js";
import { agentAuthorityV2Conformance } from "./contract/conformance.generated.js";
import {
  createWorkbenchHostResourceV1,
  callGptJobCancellationCommandIdV1,
  callGptProviderContinuationDigestV1,
  validateWorkbenchHostLeaseV1,
  workbenchHostCommandDigestV1,
  workbenchHostReadDigestV1,
  workbenchHostReadPermissionKeyV1,
  parseWorkbenchHostReadPermissionKeyV1,
} from "./workbench-host.js";

it("admits only the exact host use intent, requester and environment generation", () => {
  const bindings = {
    environmentId: "env-1",
    workspaceId: "project-1",
    hostGeneration: "1",
    profile: "full-environment",
  } as const;
  const command = { type: "thread.turn.start", commandId: "command-1", text: "Read the workspace" };
  const source = structuredClone(agentAuthorityV2Conformance.lease) as CapabilityLeaseV2;
  if (source.binding.ownerEquipment || source.binding.requester.kind !== "agent")
    throw new Error("fixture requires agent standing equipment");
  const sourceBinding = source.binding;
  const binding: typeof sourceBinding = {
    ...sourceBinding,
    definitionIds: ["workbench.host.use"],
    resources: [createWorkbenchHostResourceV1(bindings)],
    requestedShape: "short-ttl",
    audience: "t3-env:env-1",
    intent: {
      intentId: "run-1",
      idempotencyKey: command.commandId,
      action: "workbench.host.dispatch",
      intentDigest: workbenchHostCommandDigestV1({
        runId: "run-1",
        workspaceId: bindings.workspaceId,
        command,
      }),
    },
  };
  const lease = { ...source, binding, requestDigest: activationRequestDigestV2(binding) };
  const expected = {
    bindings,
    runId: "run-1",
    commandId: command.commandId,
    command,
    audience: binding.audience,
    now: Date.parse(source.issuedAt) + 1_000,
  };
  expect(validateWorkbenchHostLeaseV1(lease, expected).binding.target.agentInstanceId).toBe(
    binding.requester.id,
  );
  for (const changed of [
    { ...binding, resources: [...binding.resources, source.binding.resources[0]!] },
    { ...binding, definitionIds: [...binding.definitionIds, "techstack.inventory.read"] },
    { ...binding, requester: { ...binding.requester, id: "foreign-instance" } },
    { ...binding, authorityBasis: { ...binding.authorityBasis, facet: "self_activate" as const } },
  ]) {
    const substituted = {
      ...lease,
      binding: changed,
      requestDigest: activationRequestDigestV2(changed),
    };
    expect(() => validateWorkbenchHostLeaseV1(substituted, expected)).toThrow();
  }
  expect(() =>
    validateWorkbenchHostLeaseV1(lease, {
      ...expected,
      command: { ...command, text: "Write the workspace" },
    }),
  ).toThrow();
  expect(() =>
    createWorkbenchHostResourceV1({ ...bindings, hostGeneration: "9007199254740992" }),
  ).toThrow();
  expect(() =>
    validateWorkbenchHostLeaseV1({ ...lease, expiresAt: "invalid" }, expected),
  ).toThrow();
});

it("binds personal Codex account and payer to the signed host dispatch", () => {
  const source = structuredClone(agentAuthorityV2Conformance.lease) as CapabilityLeaseV2;
  if (source.binding.ownerEquipment || source.binding.requester.kind !== "agent")
    throw new Error("fixture requires agent standing equipment");
  const sourceBinding = source.binding;
  const command = {
    type: "thread.turn.start",
    commandId: "personal-command",
    modelSelection: { instanceId: "personal-codex", model: "gpt-5.4" },
    callGpt: {
      schemaVersion: "kombify.callgpt-workbench-binding.v1",
      providerInstanceId: "personal-codex",
      continuationDigest: callGptProviderContinuationDigestV1({
        driverKind: "codex",
        continuationKey: "isolated-personal-home",
      }),
      accountEmail: "owner@example.test",
      payer: "user-subscription",
    },
  } as const;
  const bindings = {
    environmentId: "env-1",
    workspaceId: "project-1",
    hostGeneration: "1",
    profile: "full-environment",
    callGpt: canonicalAuthorityJsonV2(command.callGpt),
  } as const;
  const binding: typeof sourceBinding = {
    ...sourceBinding,
    definitionIds: ["workbench.host.use"],
    resources: [createWorkbenchHostResourceV1(bindings)],
    requestedShape: "short-ttl",
    audience: "t3-env:env-1",
    intent: {
      intentId: "personal-run",
      idempotencyKey: command.commandId,
      action: "workbench.host.dispatch",
      intentDigest: workbenchHostCommandDigestV1({
        runId: "personal-run",
        workspaceId: "project-1",
        command,
      }),
    },
  };
  const lease = { ...source, binding, requestDigest: activationRequestDigestV2(binding) };
  const expected = {
    bindings,
    runId: "personal-run",
    commandId: command.commandId,
    command,
    audience: binding.audience,
    now: Date.parse(source.issuedAt) + 1_000,
  };
  expect(validateWorkbenchHostLeaseV1(lease, expected).status).toBe("active");
  for (const type of ["thread.turn.start", "thread.turn.interrupt"]) {
    const continuation = { ...command, type, commandId: `${type}:current`, threadId: "retained-thread",
      callGptJob: { activationRequestId: "ar_original", commandId: command.commandId, runId: expected.runId } };
    if (type === "thread.turn.interrupt") {
      continuation.commandId = callGptJobCancellationCommandIdV1(continuation.callGptJob, continuation.threadId);
      expect(callGptJobCancellationCommandIdV1({ ...continuation.callGptJob, activationRequestId: "ar_resumed", commandId: "resumed-command" }, continuation.threadId)).toBe(continuation.commandId);
    }
    const currentBinding = { ...binding, intent: { ...binding.intent, idempotencyKey: continuation.commandId,
      intentDigest: workbenchHostCommandDigestV1({ runId: expected.runId, workspaceId: bindings.workspaceId, command: continuation }) } };
    const currentLease = { ...lease, binding: currentBinding, requestDigest: activationRequestDigestV2(currentBinding) };
    expect(validateWorkbenchHostLeaseV1(currentLease, { ...expected, commandId: continuation.commandId, command: continuation }).status).toBe("active");
    for (const changed of [
      { ...continuation, callGptJob: { ...continuation.callGptJob, commandId: "another-job" } },
      { ...continuation, callGptJob: { ...continuation.callGptJob, runId: "another-run" } },
      { ...continuation, callGpt: { ...continuation.callGpt, accountEmail: "neighbor@example.test" } },
    ]) expect(() => validateWorkbenchHostLeaseV1(currentLease, { ...expected, commandId: continuation.commandId, command: changed })).toThrow();
    expect(() => workbenchHostCommandDigestV1({ runId: expected.runId, workspaceId: bindings.workspaceId,
      command: { ...continuation, bootstrap: { createThread: {} } } })).toThrow();
  }
  expect(() => workbenchHostCommandDigestV1({ runId: expected.runId, workspaceId: bindings.workspaceId,
    command: { ...command, type: "thread.turn.interrupt" } })).toThrow();
  const readKey = workbenchHostReadPermissionKeyV1(command.commandId, "a".repeat(64));
  const readBinding: CapabilityLeaseV2["binding"] = {
    ...binding,
    intent: {
      ...binding.intent,
      action: "workbench.host.read",
      idempotencyKey: readKey,
      intentDigest: workbenchHostReadDigestV1(
        { runId: expected.runId, workspaceId: bindings.workspaceId, command },
        readKey,
      ),
    },
  };
  expect(() =>
    validateWorkbenchHostLeaseV1(
      { ...lease, binding: readBinding, requestDigest: activationRequestDigestV2(readBinding) },
      expected,
    ),
  ).toThrow();
  expect(
    parseWorkbenchHostReadPermissionKeyV1(
      workbenchHostReadPermissionKeyV1("original:colon:command", "b".repeat(64)),
    ).commandId,
  ).toBe("original:colon:command");
  expect(() =>
    workbenchHostReadDigestV1(
      {
        runId: expected.runId,
        workspaceId: bindings.workspaceId,
        command: { ...command, commandId: "another-command" },
      },
      readKey,
    ),
  ).toThrow();
  for (const changed of [
    { ...command, callGpt: { ...command.callGpt, accountEmail: "neighbor@example.test" } },
    { ...command, callGpt: { ...command.callGpt, payer: "hosted-api" } },
    { ...command, modelSelection: { ...command.modelSelection, instanceId: "work-codex" } },
  ])
    expect(() => validateWorkbenchHostLeaseV1(lease, { ...expected, command: changed })).toThrow();
  // Even a newly signed command cannot switch the account assigned by the user.
  const anotherAccount = {
    ...command,
    callGpt: { ...command.callGpt, accountEmail: "neighbor@example.test" },
  };
  const changedBinding = {
    ...binding,
    intent: {
      ...binding.intent,
      intentDigest: workbenchHostCommandDigestV1({
        runId: expected.runId,
        workspaceId: bindings.workspaceId,
        command: anotherAccount,
      }),
    },
  };
  expect(() =>
    validateWorkbenchHostLeaseV1(
      {
        ...lease,
        binding: changedBinding,
        requestDigest: activationRequestDigestV2(changedBinding),
      },
      { ...expected, command: anotherAccount },
    ),
  ).toThrow();
});
