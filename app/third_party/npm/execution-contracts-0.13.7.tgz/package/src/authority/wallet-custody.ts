import { validateSchemaDocuments } from "../schemaValidator.js";
import {
  AuthorityContractError,
  canonicalAuthorityJsonV2,
  isWalletOperationIntentV3,
  type AuthorityContractViolation,
} from "./contract.js";
import { agentAuthoritySchemaDocuments } from "./contract/schemas.generated.js";
import type {
  WalletAuditEventV2,
  WalletLeaseBrokerDetailV1,
  WalletLeaseItemDetailV1,
  WalletLeasePartitionDetailV1,
  WalletLeaseTrustedFactsV1,
  WalletLeaseV1,
} from "./types.js";

/** The Gateway issues a Wallet lease for at most this long. */
export const WALLET_LEASE_MAX_SECONDS = 300;

function schemaViolations(
  contract: string,
  ref: string,
  value: unknown,
): AuthorityContractViolation[] {
  canonicalAuthorityJsonV2(value);
  return validateSchemaDocuments(agentAuthoritySchemaDocuments, contract, ref, value).map(
    (entry) => ({ path: entry.path, message: entry.message, code: "schema_invalid" as const }),
  );
}

/**
 * Structural and lifetime checks of a decoded Wallet lease. It verifies neither the
 * signature nor the key, and the lease grants nothing: the Wallet Store still checks
 * jti replay, the current grant generation and revocation.
 */
export function parseWalletLeaseV1(value: unknown): WalletLeaseV1 {
  const violations = schemaViolations("wallet lease", "wallet-lease.v1.schema.json", value);
  if (violations.length === 0) {
    const { claims } = value as WalletLeaseV1;
    const lifetime = claims.exp - claims.iat;
    if (lifetime <= 0 || lifetime > WALLET_LEASE_MAX_SECONDS)
      violations.push({
        code: "binding_mismatch",
        path: "/claims/exp",
        message: `lease must expire after issue and within ${WALLET_LEASE_MAX_SECONDS} seconds`,
      });
  }
  if (violations.length) throw new AuthorityContractError("Invalid wallet lease.", violations);
  return value as WalletLeaseV1;
}

// A brokered call stays inside its lease: same host and method, and a path equal to
// the prefix or below it on a segment boundary.
function pathWithin(path: string, prefix: string): boolean {
  return (
    path === prefix ||
    (path.startsWith(prefix) && (prefix.endsWith("/") || path[prefix.length] === "/"))
  );
}

// iat and exp are whole-second NumericDates, so whole seconds decide validity:
// exp > floor(expiresAt) is exactly exp * 1e9 ns > expiresAt. The fraction is
// stripped before parsing because Date.parse accepts milliseconds only.
function wholeSeconds(date: string): bigint {
  return BigInt(Date.parse(date.replace(/\.\d+/u, ""))) / 1000n;
}

function sameJson(left: unknown, right: unknown): boolean {
  if (left === undefined || right === undefined) return left === right;
  return canonicalAuthorityJsonV2(left) === canonicalAuthorityJsonV2(right);
}

/**
 * Compare a parsed lease with independently authenticated facts. With `trusted.intent`
 * it also proves the lease authorizes exactly that one operation and nothing wider.
 */
export function validateWalletLeaseBindingsV1(
  lease: WalletLeaseV1,
  trusted: WalletLeaseTrustedFactsV1,
): readonly AuthorityContractViolation[] {
  const violations: AuthorityContractViolation[] = [];
  const mismatch = (path: string, message: string) =>
    violations.push({ code: "binding_mismatch", path, message });
  try {
    parseWalletLeaseV1(lease);
  } catch (error) {
    if (error instanceof AuthorityContractError) return error.violations;
    throw error;
  }
  const { header, claims } = lease;
  if (header.kid !== trusted.signingKey.kid) mismatch("/header/kid", "lease key is not trusted");
  const nowViolations = schemaViolations(
    "wallet lease",
    "agent-authority.v2.schema.json#/$defs/walletOwnerApprovalReceiptV1/properties/audit/properties/confirmedAt",
    trusted.now,
  );
  if (nowViolations.length) return [...violations, ...nowViolations];
  // A lease is valid from iat (inclusive) to exp (exclusive).
  const now = wholeSeconds(trusted.now);
  if (now < BigInt(claims.iat) || now >= BigInt(claims.exp))
    mismatch("/claims/exp", "lease is not valid at this time");
  if (claims.grantGeneration !== trusted.currentGrantGeneration)
    mismatch("/claims/grantGeneration", "lease names a superseded grant generation");
  if (
    !sameJson(claims.taskRef, trusted.taskRef) ||
    !sameJson(claims.projectRef, trusted.projectRef)
  )
    mismatch("/claims/taskRef", "lease task or project binding differs from the request");
  const partition = trusted.partition;
  if (partition && trusted.intent) {
    mismatch("/trusted", "a lease binds an item intent or a namespace operation, not both");
    return violations;
  }
  if (partition) {
    // A namespace operation has no item intent: it binds owner, actor, namespace,
    // operation and recipient instead.
    if (claims.sub !== partition.owner || claims.act.sub !== partition.actor)
      mismatch("/claims/sub", "lease owner or actor differs from the operation");
    if (claims.aud !== partition.executorAudience)
      mismatch("/claims/aud", "lease audience differs from the executor audience");
    const scope = claims.authorization_details[0] as WalletLeasePartitionDetailV1;
    if (
      claims.authorization_details.length !== 1 ||
      scope.type !== "kombify_wallet_partition" ||
      scope.custodyNamespace !== partition.custodyNamespace ||
      scope.operation !== partition.operation
    )
      mismatch(
        "/claims/authorization_details",
        "lease does not authorize this namespace operation",
      );
    else if (
      scope.recipientRef !== partition.recipient.keyId ||
      scope.recipientGeneration !== partition.recipient.keyGeneration
    )
      mismatch("/claims/authorization_details/0/recipientRef", "lease recipient differs");
    return violations;
  }
  const intent = trusted.intent;
  if (!intent) return violations;
  if (!isWalletOperationIntentV3(intent)) {
    mismatch("/intent", "a Wallet lease binds a v3 operation");
    return violations;
  }
  const op = intent.operation;
  const identity = op.resource.identity;
  if (claims.sub !== op.subject || claims.sub !== identity.owner)
    mismatch("/claims/sub", "lease owner differs from the operation");
  if (
    claims.act.sub !== (op.context.kind === "agent_run" ? op.context.agentInstanceId : op.subject)
  )
    mismatch("/claims/act", "lease actor differs from the operation");
  if (claims.aud !== op.executor.audience)
    mismatch("/claims/aud", "lease audience differs from the executor audience");
  if (BigInt(claims.exp) > wholeSeconds(op.expiresAt))
    mismatch("/claims/exp", "lease outlives the operation");
  if (claims.authorization_details.length !== 1) {
    mismatch("/claims/authorization_details", "a lease authorizes exactly one operation");
    return violations;
  }
  const detail = claims.authorization_details[0]!;
  if (intent.action === "brokered_use") {
    const call = trusted.normalizedArguments;
    const broker = detail as WalletLeaseBrokerDetailV1;
    if (detail.type !== "kombify_wallet_broker" || detail.itemId !== identity.itemId || !call)
      mismatch("/claims/authorization_details/0", "lease does not authorize this brokered call");
    else if (
      schemaViolations("wallet lease", "wallet-lease.v1.schema.json#/$defs/brokerDetail", {
        ...broker,
        host: call.host,
        method: call.method,
        pathPrefix: call.path,
      }).length > 0 ||
      call.host !== broker.host ||
      call.method !== broker.method ||
      !pathWithin(call.path, broker.pathPrefix)
    )
      mismatch("/claims/authorization_details/0", "call is outside the lease host, method or path");
  } else {
    const item = detail as WalletLeaseItemDetailV1;
    if (
      detail.type !== "kombify_wallet_item" ||
      item.custodyNamespace !== identity.custodyNamespace ||
      item.itemId !== identity.itemId ||
      item.action !== intent.action ||
      (item.version !== undefined && item.version !== op.version)
    )
      mismatch("/claims/authorization_details/0", "lease does not authorize this item operation");
    else if (
      item.recipientRef !== op.executor.recipient.keyId ||
      item.recipientGeneration !== op.executor.recipient.keyGeneration
    )
      mismatch("/claims/authorization_details/0/recipientRef", "lease recipient differs");
  }
  return violations;
}

/** Custody audit event: the closed wallet member and its action/outcome/value-release rules. */
export function parseWalletAuditEventV2(value: unknown): WalletAuditEventV2 {
  const violations = schemaViolations("wallet audit", "audit-event.v2.schema.json", value);
  if (violations.length)
    throw new AuthorityContractError("Invalid wallet audit event.", violations);
  return value as WalletAuditEventV2;
}
