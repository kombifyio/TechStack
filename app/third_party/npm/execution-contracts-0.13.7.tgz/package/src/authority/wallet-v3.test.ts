import { expect, it } from "vitest";
import { agentAuthorityV2Conformance } from "./contract/conformance.generated.js";
import {
  AuthorityContractError,
  WALLET_ACTION_PROFILES_V3,
  WALLET_ITEM_TYPE_PROFILES_V3,
  activationRequestDigestV2,
  agentAuthorityGrantDigestV2,
  hasWalletIntentMarker,
  hasWalletResourceMarker,
  parseActivationRequestV2,
  parseAgentAuthorityGrantV2,
  parseWalletOperationIntentV1,
  parseWalletOperationIntentV2,
  parseWalletOperationIntentV3,
  parseWalletOwnerApprovalReceiptV1,
  parseWalletOwnerApprovalReceiptV2,
  parseWalletAuditEventV2,
  parseWalletLeaseV1,
  validateWalletLeaseBindingsV1,
  validateWalletOwnerApprovalBindingsV2,
  walletOperationIntentDigestV3,
} from "./index.js";
import type {
  ActivationRequestV2,
  AgentAuthorityGrantV2,
  WalletLeaseTrustedFactsV1,
  WalletLeaseV1,
  WalletOperationIntentV1,
  WalletOperationIntentV2,
  WalletOperationIntentV3,
  WalletOwnerApprovalReceiptV1,
  WalletOwnerApprovalReceiptV2,
  WalletOwnerApprovalTrustedFactsV1,
  WalletResourceV3,
} from "./index.js";

type Mutable<T> = { -readonly [K in keyof T]: Mutable<T[K]> };
const vector = agentAuthorityV2Conformance as unknown as {
  wallet: { intent: WalletOperationIntentV1 };
  walletOwnerApproval: { receipt: WalletOwnerApprovalReceiptV1 };
  walletV2: { intent: WalletOperationIntentV2 };
  walletV3: {
    tables: { actions: unknown; itemTypes: unknown };
    resource: WalletResourceV3;
    intent: WalletOperationIntentV3;
    request: ActivationRequestV2;
    grant: AgentAuthorityGrantV2;
    reveal: { intent: WalletOperationIntentV3 };
    ownerApproval: {
      receipt: WalletOwnerApprovalReceiptV2;
      trusted: WalletOwnerApprovalTrustedFactsV1;
    };
    lease: {
      trusted: WalletLeaseTrustedFactsV1;
      broker: WalletLeaseV1;
      item: WalletLeaseV1;
      partition: WalletLeaseV1;
      invalid: { name: string; document: unknown }[];
    };
    audit: {
      valid: { name: string; event: unknown }[];
      invalid: { name: string; event: unknown }[];
    };
  };
};
const v3 = vector.walletV3;
const resign = (intent: Mutable<WalletOperationIntentV3>) => {
  intent.intentDigest = walletOperationIntentDigestV3(intent);
  return intent;
};

const refused = (lease: WalletLeaseV1, facts: WalletLeaseTrustedFactsV1) =>
  validateWalletLeaseBindingsV1(lease, facts).length > 0;
const changed = (base: WalletLeaseV1, mutate: (value: Mutable<WalletLeaseV1>) => void) => {
  const copy = structuredClone(base) as Mutable<WalletLeaseV1>;
  mutate(copy);
  return copy as WalletLeaseV1;
};

it("admits v3 items and keeps use and read rights, value policy and older readers apart", () => {
  expect(parseWalletOperationIntentV3(v3.intent).operation.resource.rights).toEqual(["use"]);
  expect(parseActivationRequestV2(v3.request).requestDigest).toBe(v3.request.requestDigest);
  expect(parseAgentAuthorityGrantV2(v3.grant).grantDigest).toBe(
    agentAuthorityGrantDigestV2(v3.grant.binding),
  );
  // The read right lets a delegated run reveal; the use right alone does not.
  expect(parseWalletOperationIntentV3(v3.reveal.intent).action).toBe("reveal");
  const useOnly = structuredClone(v3.reveal.intent) as Mutable<WalletOperationIntentV3>;
  useOnly.operation.resource.rights = ["use"];
  expect(() => parseWalletOperationIntentV3(resign(useOnly))).toThrow(AuthorityContractError);
  const readOnlyBrokered = structuredClone(v3.intent) as Mutable<WalletOperationIntentV3>;
  readOnlyBrokered.operation.resource.rights = ["read"];
  expect(() => parseWalletOperationIntentV3(resign(readOnlyBrokered))).toThrow(
    AuthorityContractError,
  );
  // use_only keeps the value in custody: no disclosing action for anyone.
  const sealed = structuredClone(v3.reveal.intent) as Mutable<WalletOperationIntentV3>;
  sealed.operation.resource.policy = { valueAccess: "use_only" };
  expect(() => parseWalletOperationIntentV3(resign(sealed))).toThrow(AuthorityContractError);
  // A transfer binding exists exactly where the action profile says so.
  const bare = structuredClone(v3.reveal.intent) as Mutable<WalletOperationIntentV3>;
  delete bare.operation.transfer;
  expect(() => parseWalletOperationIntentV3(resign(bare))).toThrow(AuthorityContractError);
  const hostDelivery = structuredClone(v3.intent) as Mutable<WalletOperationIntentV3>;
  hostDelivery.action = "host_delivery";
  expect(() => parseWalletOperationIntentV3(resign(hostDelivery))).toThrow(AuthorityContractError);
  // Revoke denies later use of the item and is a manage action: only a manage grant holds it.
  const revoke = structuredClone(v3.intent) as Mutable<WalletOperationIntentV3>;
  revoke.action = "revoke";
  revoke.operation.resource.rights = ["manage"];
  expect(parseWalletOperationIntentV3(resign(revoke)).action).toBe("revoke");
  revoke.operation.resource.rights = ["use", "read"];
  expect(() => parseWalletOperationIntentV3(resign(revoke))).toThrow(AuthorityContractError);
  expect(WALLET_ACTION_PROFILES_V3.revoke).toEqual({
    right: "manage",
    valueRelease: "none",
    transfer: false,
  });
  for (const profile of Object.values(WALLET_ITEM_TYPE_PROFILES_V3)) {
    if (profile.actions.includes("delete")) expect(profile.actions).toContain("revoke");
  }
  // The item types come from one table: a login cannot mint child credentials, a parent can.
  expect(WALLET_ITEM_TYPE_PROFILES_V3.login.actions).not.toContain("mint_child_credential");
  expect(WALLET_ITEM_TYPE_PROFILES_V3.parent_credential.actions).toContain("mint_child_credential");
  expect(WALLET_ACTION_PROFILES_V3.reveal.right).toBe("read");
  expect(WALLET_ACTION_PROFILES_V3.process_injection).toMatchObject({
    right: "use",
    valueRelease: "disclosed",
  });
  expect(v3.tables).toEqual({
    actions: WALLET_ACTION_PROFILES_V3,
    itemTypes: WALLET_ITEM_TYPE_PROFILES_V3,
  });
  // Older readers deny a v3 document, the v3 reader denies older versions, and every
  // nested marker still blocks admission in readers that do not know the version.
  expect(() => parseWalletOperationIntentV2(v3.intent)).toThrow(AuthorityContractError);
  expect(() => parseWalletOperationIntentV1(v3.intent)).toThrow(AuthorityContractError);
  expect(() => parseWalletOperationIntentV3(vector.walletV2.intent)).toThrow(
    AuthorityContractError,
  );
  expect(() => parseWalletOperationIntentV3(vector.wallet.intent)).toThrow(AuthorityContractError);
  expect(hasWalletResourceMarker(v3.resource)).toBe(true);
  expect(hasWalletIntentMarker(v3.intent)).toBe(true);
  // The digest, the item's supported actions and the request all bind the exact operation.
  const unlisted = structuredClone(v3.intent) as Mutable<WalletOperationIntentV3>;
  unlisted.action = "sign";
  unlisted.operation.resource.supportedActions = ["brokered_use", "capture"];
  expect(() => parseWalletOperationIntentV3(resign(unlisted))).toThrow(AuthorityContractError);
  const forged = structuredClone(v3.request) as Mutable<ActivationRequestV2>;
  (forged.binding.intent as Mutable<WalletOperationIntentV3>).operation.nonce = "forged";
  forged.requestDigest = activationRequestDigestV2(forged.binding);
  expect(() => parseActivationRequestV2(forged)).toThrow(AuthorityContractError);
  // A v3 intent cannot ride on a v2 resource inside one request.
  const mixed = structuredClone(v3.request) as Mutable<ActivationRequestV2>;
  mixed.binding.intent = structuredClone(vector.walletV2.intent) as never;
  mixed.requestDigest = activationRequestDigestV2(mixed.binding);
  expect(() => parseActivationRequestV2(mixed)).toThrow(AuthorityContractError);
});

it("lets a product service act only as itself and only for its own recipient", () => {
  const service = structuredClone(v3.reveal.intent) as Mutable<WalletOperationIntentV3>;
  service.action = "process_injection";
  service.operation.resource.rights = ["use"];
  service.operation.actor = { kind: "service", id: "paperwork" };
  service.operation.authenticationProfile = "service_standing";
  service.operation.context = {
    kind: "product_service",
    serviceId: "paperwork",
    recipientGeneration: "2",
  };
  service.operation.executor.recipient = {
    ...service.operation.executor.recipient,
    keyId: "service:paperwork",
    keyGeneration: "2",
  };
  expect(parseWalletOperationIntentV3(resign(service)).operation.context.kind).toBe(
    "product_service",
  );
  const mutations: ((value: Mutable<WalletOperationIntentV3>) => void)[] = [
    (value) => {
      value.operation.actor = { kind: "service", id: "techstack" };
    },
    (value) => {
      value.operation.actor = { kind: "user", id: value.operation.subject };
    },
    (value) => {
      value.operation.executor.recipient.keyId = "service:techstack";
    },
    (value) => {
      value.operation.executor.recipient.keyGeneration = "1";
    },
    (value) => {
      value.action = "reveal";
    },
  ];
  for (const mutate of mutations) {
    const copy = structuredClone(service);
    mutate(copy);
    expect(() => parseWalletOperationIntentV3(resign(copy))).toThrow(AuthorityContractError);
  }
});

it("takes a fresh owner proof only from the owner's v2 receipt over the exact v3 intent", () => {
  const { receipt, trusted } = v3.ownerApproval;
  expect(parseWalletOwnerApprovalReceiptV2(receipt).intent.action).toBe("reveal");
  expect(validateWalletOwnerApprovalBindingsV2(receipt, trusted)).toEqual([]);
  expect(() => parseWalletOwnerApprovalReceiptV1(receipt)).toThrow(AuthorityContractError);
  expect(() => parseWalletOwnerApprovalReceiptV2(vector.walletOwnerApproval.receipt)).toThrow(
    AuthorityContractError,
  );
  const substituted = structuredClone(receipt) as Mutable<WalletOwnerApprovalReceiptV2>;
  substituted.intent.operation.executor.recipient.keyId = "substituted-recipient";
  expect(() => parseWalletOwnerApprovalReceiptV2(substituted)).toThrow(AuthorityContractError);
  resign(substituted.intent);
  expect(validateWalletOwnerApprovalBindingsV2(substituted, trusted).length).toBeGreaterThan(0);
  // A delegated agent run cannot be the intent a receipt proves.
  const delegated = structuredClone(receipt) as Mutable<WalletOwnerApprovalReceiptV2>;
  Object.assign(delegated.intent.operation, {
    actor: {
      kind: "agent",
      id: "instance-requester",
      agentClass: "agent-host",
      templateDigest: `sha256:${"b".repeat(64)}`,
    },
    authenticationProfile: "delegated_user",
    context: { kind: "agent_run", agentInstanceId: "instance-requester", runId: "run-9" },
  });
  resign(delegated.intent);
  expect(() => parseWalletOwnerApprovalReceiptV2(delegated)).toThrow(AuthorityContractError);
  expect(
    validateWalletOwnerApprovalBindingsV2(receipt, { ...trusted, now: "2026-10-01T12:00:45Z" })
      .length,
  ).toBeGreaterThan(0);
});

it("authorizes exactly one operation by a short Wallet lease and refuses anything wider", () => {
  const { trusted, broker, item, partition, invalid } = v3.lease;
  expect(parseWalletLeaseV1(broker).claims.exp - broker.claims.iat).toBeLessThanOrEqual(300);
  const brokerFacts: WalletLeaseTrustedFactsV1 = {
    ...trusted,
    intent: v3.intent,
    normalizedArguments: { host: "api.example.com", method: "GET", path: "/v1/status" },
  };
  const itemFacts: WalletLeaseTrustedFactsV1 = {
    ...trusted,
    intent: v3.reveal.intent,
    projectRef: { id: "project-1000" },
  };
  expect(validateWalletLeaseBindingsV1(broker, brokerFacts)).toEqual([]);
  expect(validateWalletLeaseBindingsV1(item, itemFacts)).toEqual([]);
  // A namespace operation names no item and binds owner, actor, namespace, operation and recipient.
  expect(parseWalletLeaseV1(partition).claims.authorization_details[0]?.type).toBe(
    "kombify_wallet_partition",
  );
  const partitionFacts: WalletLeaseTrustedFactsV1 = {
    ...trusted,
    partition: {
      owner: "auth0|owner",
      actor: "instance-requester",
      custodyNamespace: "synthetic:wallet:owner-1",
      operation: "list_items",
      recipient: { keyId: "executor-key-1", keyGeneration: "1" },
      executorAudience: "https://wallet-store.internal.kombify.dev",
    },
  };
  expect(validateWalletLeaseBindingsV1(partition, partitionFacts)).toEqual([]);
  for (const { document } of invalid) {
    expect(() => parseWalletLeaseV1(document)).toThrow(AuthorityContractError);
  }
  expect(refused(broker, { ...brokerFacts, now: "2026-10-01T12:01:00Z" })).toBe(true);
  expect(refused(broker, { ...brokerFacts, now: "2026-10-01T11:59:59Z" })).toBe(true);
  expect(refused(broker, { ...brokerFacts, currentGrantGeneration: 2 })).toBe(true);
  expect(refused(broker, { ...brokerFacts, signingKey: { kid: "other-key" } })).toBe(true);
  expect(
    refused(broker, {
      ...brokerFacts,
      normalizedArguments: { host: "api.example.com", method: "GET", path: "/v10/status" },
    }),
  ).toBe(true);
  expect(
    refused(broker, {
      ...brokerFacts,
      normalizedArguments: { host: "api.example.com", method: "GET", path: "/v1/../admin" },
    }),
  ).toBe(true);
  expect(
    refused(broker, {
      ...brokerFacts,
      normalizedArguments: { host: "other.example.com", method: "GET", path: "/v1" },
    }),
  ).toBe(true);
  expect(
    refused(
      changed(broker, (v) => {
        v.claims.exp += 1;
      }),
      brokerFacts,
    ),
  ).toBe(true);
  expect(
    refused(
      changed(broker, (v) => {
        v.claims.act.sub = "instance-other";
      }),
      brokerFacts,
    ),
  ).toBe(true);
  expect(
    refused(
      changed(item, (v) => {
        (v.claims.authorization_details[0] as { recipientRef: string }).recipientRef = "other-key";
      }),
      itemFacts,
    ),
  ).toBe(true);
  expect(
    refused(
      changed(item, (v) => {
        (v.claims.authorization_details[0] as { action: string }).action = "export";
      }),
      itemFacts,
    ),
  ).toBe(true);
  expect(refused(item, { ...itemFacts, intent: v3.intent })).toBe(true);
  expect(refused(partition, itemFacts)).toBe(true);
  expect(refused(partition, brokerFacts)).toBe(true);
  expect(refused(item, { ...partitionFacts, projectRef: { id: "project-1000" } })).toBe(true);
  expect(refused(broker, partitionFacts)).toBe(true);
  expect(refused(partition, { ...partitionFacts, intent: v3.intent })).toBe(true);
  for (const wrong of [
    { operation: "capture_key" as const },
    { custodyNamespace: "synthetic:wallet:other" },
    { owner: "auth0|other" },
    { actor: "instance-other" },
    { recipient: { keyId: "executor-key-1", keyGeneration: "2" } },
    { executorAudience: "https://wallet-store.internal.invalid" },
  ]) {
    expect(
      refused(partition, {
        ...partitionFacts,
        partition: { ...partitionFacts.partition!, ...wrong },
      }),
    ).toBe(true);
  }
});

it("records custody events with the released-value mode and no value", () => {
  for (const { event } of v3.audit.valid) {
    expect(parseWalletAuditEventV2(event).wallet.itemId).toBe("item-1");
  }
  for (const { event } of v3.audit.invalid) {
    expect(() => parseWalletAuditEventV2(event)).toThrow(AuthorityContractError);
  }
});
