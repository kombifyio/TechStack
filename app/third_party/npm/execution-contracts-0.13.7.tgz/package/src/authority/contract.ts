import { sha256 } from "@noble/hashes/sha2";

import { validateSchemaDocuments, type SchemaViolation } from "../schemaValidator.js";
import { agentAuthoritySchemaDocuments } from "./contract/schemas.generated.js";
import type {
  ActivationDecisionV2,
  ActivationRequestV2,
  AgentAuthorityGrantV2,
  AgentRoleTemplateAuthoredV2,
  AgentRoleTemplateV2,
  AuthorityActorV2,
  AuthorityResourceV2,
  ActivationIntentV2,
  WalletResourceV1,
  WalletResourceV2,
  WalletOperationIntentV1,
  WalletOperationIntentV2,
  WalletOperationIntentV3,
  WalletOwnerApprovalReceiptV1,
  WalletOwnerApprovalReceiptV2,
  WalletResourceV3,
  WalletActionV3,
  WalletActionProfileV3,
  WalletItemTypeProfileV3,
  WalletResourceTypeV3,
  WalletOwnerApprovalProtectedHeaderV1,
  WalletOwnerApprovalTrustedFactsV1,
  AuthorityDigestV2,
  AuthorityDocumentSchemaVersionV2,
  AuthorityDocumentV2,
  CapabilityLeaseV2,
} from "./types.js";

export const AGENT_AUTHORITY_GRANT_DIGEST_DOMAIN_V2 =
  "kombify.agent-authority-grant.digest.v2" as const;
export const ACTIVATION_REQUEST_DIGEST_DOMAIN_V2 = "kombify.activation-request.digest.v2" as const;
export const ACTIVATION_DECISION_DIGEST_DOMAIN_V2 =
  "kombify.activation-decision.digest.v2" as const;
export const AGENT_ROLE_TEMPLATE_DIGEST_DOMAIN_V2 =
  "kombify.agent-role-template.digest.v2" as const;

export type AuthorityDigestDomainV2 =
  | typeof AGENT_AUTHORITY_GRANT_DIGEST_DOMAIN_V2
  | typeof ACTIVATION_REQUEST_DIGEST_DOMAIN_V2
  | typeof ACTIVATION_DECISION_DIGEST_DOMAIN_V2
  | typeof AGENT_ROLE_TEMPLATE_DIGEST_DOMAIN_V2;

export interface AuthorityContractViolation extends SchemaViolation {
  readonly code: "invalid_json_value" | "schema_invalid" | "digest_mismatch" | "binding_mismatch";
}

export class AuthorityContractError extends Error {
  readonly violations: readonly AuthorityContractViolation[];

  constructor(message: string, violations: readonly AuthorityContractViolation[]) {
    super(message);
    this.name = "AuthorityContractError";
    this.violations = violations;
  }
}

const textEncoder = new TextEncoder();

export const WALLET_OPERATION_INTENT_DIGEST_DOMAIN_V1 =
  "kombify.wallet-operation-intent.digest.v1" as const;
export const WALLET_OPERATION_INTENT_DIGEST_DOMAIN_V2 =
  "kombify.wallet-operation-intent.digest.v2" as const;
export const WALLET_OPERATION_INTENT_DIGEST_DOMAIN_V3 =
  "kombify.wallet-operation-intent.digest.v3" as const;
export const WALLET_NORMALIZED_ARGUMENTS_DIGEST_DOMAIN_V1 =
  "kombify.wallet-normalized-arguments.digest.v1" as const;

const authorityDefinitions = (
  agentAuthoritySchemaDocuments["agent-authority.v2.schema.json"] as {
    readonly $defs: Readonly<Record<string, { readonly const?: unknown }>>;
  }
).$defs;
/** Per action: right (use, read, manage), value release and transfer rule; read from the pinned Core schema. */
export const WALLET_ACTION_PROFILES_V3 = authorityDefinitions.walletActionProfilesV3!
  .const as Readonly<Record<WalletActionV3, WalletActionProfileV3>>;
/** Per item type: valid custodians and the largest action set; read from the pinned Core schema. */
export const WALLET_ITEM_TYPE_PROFILES_V3 = authorityDefinitions.walletItemTypeProfilesV3!
  .const as Readonly<Record<WalletResourceTypeV3, WalletItemTypeProfileV3>>;

export function isWalletResourceV1(value: AuthorityResourceV2): value is WalletResourceV1 {
  return "schemaVersion" in value && value.schemaVersion === "kombify.wallet-resource.v1";
}
export function isWalletOperationIntentV1(
  value: ActivationIntentV2,
): value is WalletOperationIntentV1 {
  return "schemaVersion" in value && value.schemaVersion === "kombify.wallet-operation-intent.v1";
}

/** Restrictive recognition only: unsupported markers also block admission. */
export function hasWalletResourceMarker(value: unknown): boolean {
  return (
    value !== null &&
    typeof value === "object" &&
    [
      "schemaVersion",
      "identity",
      "custodian",
      "scope",
      "protection",
      "disclosure",
      "supportedActions",
      "classification",
      "lifecycle",
      "metadataRevision",
      "reference",
      "versionConstraint",
    ].some((key) => key in value)
  );
}
export function hasWalletIntentMarker(value: unknown): boolean {
  return (
    value !== null &&
    typeof value === "object" &&
    ("schemaVersion" in value || "operation" in value)
  );
}
export function isWalletResourceV2(value: AuthorityResourceV2): value is WalletResourceV2 {
  return "schemaVersion" in value && value.schemaVersion === "kombify.wallet-resource.v2";
}
export function isWalletResourceV3(value: AuthorityResourceV2): value is WalletResourceV3 {
  return "schemaVersion" in value && value.schemaVersion === "kombify.wallet-resource.v3";
}
export function isWalletOperationIntentV3(
  value: ActivationIntentV2,
): value is WalletOperationIntentV3 {
  return "schemaVersion" in value && value.schemaVersion === "kombify.wallet-operation-intent.v3";
}
export function walletOperationIntentDigestV3(
  intent: Omit<WalletOperationIntentV3, "intentDigest"> | WalletOperationIntentV3,
): AuthorityDigestV2 {
  const { intentDigest: _digest, ...projection } = intent as WalletOperationIntentV3;
  return canonicalAuthorityDigestV2(WALLET_OPERATION_INTENT_DIGEST_DOMAIN_V3, projection);
}
export function isWalletOperationIntentV2(
  value: ActivationIntentV2,
): value is WalletOperationIntentV2 {
  return "schemaVersion" in value && value.schemaVersion === "kombify.wallet-operation-intent.v2";
}
export function walletOperationIntentDigestV2(
  intent: Omit<WalletOperationIntentV2, "intentDigest"> | WalletOperationIntentV2,
): AuthorityDigestV2 {
  const { intentDigest: _digest, ...projection } = intent as WalletOperationIntentV2;
  return canonicalAuthorityDigestV2(WALLET_OPERATION_INTENT_DIGEST_DOMAIN_V2, projection);
}

export function walletOperationIntentDigestV1(
  intent: Omit<WalletOperationIntentV1, "intentDigest"> | WalletOperationIntentV1,
): AuthorityDigestV2 {
  const { intentDigest: _digest, ...projection } = intent as WalletOperationIntentV1;
  return canonicalAuthorityDigestV2(WALLET_OPERATION_INTENT_DIGEST_DOMAIN_V1, projection);
}

/** Compare all policy and identity members; matching legacy fields alone cannot attenuate a Wallet. */
export function sameAuthorityResourceV2(
  left: AuthorityResourceV2,
  right: AuthorityResourceV2,
): boolean {
  return sameCanonical(left, right);
}

function walletResourceV2Violations(
  resource: WalletResourceV2 | WalletResourceV3,
): AuthorityContractViolation[] {
  const violations: AuthorityContractViolation[] = [];
  if (
    resource.reference.kind === "secret" &&
    resource.resource !== `secret://${resource.reference.vaultRef}/${resource.identity.itemId}`
  )
    violations.push({
      code: "binding_mismatch",
      path: "/resource",
      message: "wallet reference differs from vault/item identity",
    });
  return violations;
}

// Both existing authority readers reject precision beyond nine fractional
// digits. Schema validation precedes this comparison; retain all accepted
// nanoseconds instead of Date.parse's millisecond truncation, including offsets.
function walletDateNanoseconds(value: string): bigint {
  const match = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d{1,9}))?(Z|[+-]\d{2}:\d{2})$/u.exec(
    value,
  )!;
  return (
    BigInt(Date.parse(`${match[1]}${match[3]}`)) * 1_000_000n +
    BigInt((match[2] ?? "").padEnd(9, "0"))
  );
}

function walletIntentViolations(
  intent: WalletOperationIntentV1 | WalletOperationIntentV2,
): AuthorityContractViolation[] {
  const violations: AuthorityContractViolation[] = [];
  const mismatch = (path: string, message: string) =>
    violations.push({ code: "binding_mismatch" as const, path, message });
  const op = intent.operation;
  if (isWalletOperationIntentV2(intent)) {
    const exact = intent.operation;
    violations.push(...walletResourceV2Violations(exact.resource));
    if (exact.admissionAudience === exact.executor.audience)
      mismatch("/operation/executor/audience", "admission and executor audiences must differ");
    if (
      exact.resource.reference.kind === "secret" &&
      exact.versionRef !== `${exact.resource.resource}/versions/${exact.version}`
    )
      mismatch("/operation/versionRef", "wallet version reference differs from exact version");
    if (
      exact.resource.versionConstraint.kind === "exact" &&
      exact.resource.versionConstraint.version !== exact.version
    )
      mismatch("/operation/version", "wallet version exceeds exact eligibility");
  }
  if (
    intent.intentDigest !==
    (isWalletOperationIntentV2(intent)
      ? walletOperationIntentDigestV2(intent)
      : walletOperationIntentDigestV1(intent))
  )
    violations.push({
      code: "digest_mismatch",
      path: "/intentDigest",
      message: "wallet intent digest mismatch",
    });
  if (op.operationId !== intent.idempotencyKey)
    mismatch("/operation/operationId", "operation correlation differs from idempotency key");
  if (op.subject !== op.resource.identity.owner)
    mismatch("/operation/subject", "wallet owner differs from subject");
  if (!op.resource.supportedActions.includes(intent.action))
    mismatch("/action", "wallet action is unsupported");
  if (
    ["reveal", "export", "process_injection"].includes(intent.action) &&
    (op.resource.disclosure.kind !== "owner_authorized" ||
      !op.resource.disclosure.actions.some((action) => action === intent.action))
  )
    mismatch("/action", "wallet disclosure action is not admitted");
  if (
    op.context.kind === "agent_run" &&
    (op.actor.kind !== "agent" || op.context.agentInstanceId !== op.actor.id)
  )
    mismatch("/operation/context", "agent context differs from actor");
  if (op.context.kind !== "agent_run" && (op.actor.kind !== "user" || op.actor.id !== op.subject))
    mismatch("/operation/actor", "owner actor differs from subject");
  if (
    op.context.kind === "owner_process" &&
    op.resource.scope.kind === "project_environment" &&
    (op.context.projectId !== op.resource.scope.projectId ||
      op.context.environment !== op.resource.scope.environment)
  )
    mismatch("/operation/context", "process scope differs from resource");
  return violations;
}

// Exact-operation rules of nested v3. The schema already ties the action to the
// resource's rights and value policy; they are repeated here so a reader that
// parses without the schema still denies a right of the wrong class.
function walletIntentViolationsV3(intent: WalletOperationIntentV3): AuthorityContractViolation[] {
  const violations: AuthorityContractViolation[] = [];
  const mismatch = (path: string, message: string) =>
    violations.push({ code: "binding_mismatch" as const, path, message });
  const op = intent.operation;
  violations.push(...walletResourceV2Violations(op.resource));
  if (op.admissionAudience === op.executor.audience)
    mismatch("/operation/executor/audience", "admission and executor audiences must differ");
  if (
    op.resource.reference.kind === "secret" &&
    op.versionRef !== `${op.resource.resource}/versions/${op.version}`
  )
    mismatch("/operation/versionRef", "wallet version reference differs from exact version");
  if (
    op.resource.versionConstraint.kind === "exact" &&
    op.resource.versionConstraint.version !== op.version
  )
    mismatch("/operation/version", "wallet version exceeds exact eligibility");
  if (intent.intentDigest !== walletOperationIntentDigestV3(intent))
    violations.push({
      code: "digest_mismatch",
      path: "/intentDigest",
      message: "wallet intent digest mismatch",
    });
  if (op.operationId !== intent.idempotencyKey)
    mismatch("/operation/operationId", "operation correlation differs from idempotency key");
  if (op.subject !== op.resource.identity.owner)
    mismatch("/operation/subject", "wallet owner differs from subject");
  const profile = WALLET_ACTION_PROFILES_V3[intent.action];
  if (!op.resource.supportedActions.includes(intent.action))
    mismatch("/action", "wallet action is unsupported");
  if (!op.resource.rights.includes(profile.right))
    mismatch("/action", "wallet right does not cover the action");
  if (
    profile.valueRelease === "disclosed" &&
    op.resource.policy.valueAccess !== "read_right_holders"
  )
    mismatch("/action", "wallet value policy does not release the value");
  if (
    op.context.kind === "agent_run" &&
    (op.actor.kind !== "agent" || op.context.agentInstanceId !== op.actor.id)
  )
    mismatch("/operation/context", "agent context differs from actor");
  if (op.context.kind === "product_service") {
    if (op.actor.kind !== "service" || op.actor.id !== op.context.serviceId)
      mismatch("/operation/actor", "service actor differs from context");
    if (
      op.executor.recipient.keyId !== `service:${op.context.serviceId}` ||
      op.executor.recipient.keyGeneration !== op.context.recipientGeneration
    )
      mismatch(
        "/operation/executor/recipient",
        "service result is not sealed to its own recipient",
      );
  }
  if (
    op.context.kind !== "agent_run" &&
    op.context.kind !== "product_service" &&
    (op.actor.kind !== "user" || op.actor.id !== op.subject)
  )
    mismatch("/operation/actor", "owner actor differs from subject");
  const scope = op.resource.scope;
  if (
    op.context.kind === "owner_process" &&
    scope.kind !== "account" &&
    (op.context.projectId !== scope.projectId ||
      (scope.kind === "project_environment" && op.context.environment !== scope.environment))
  )
    mismatch("/operation/context", "process scope differs from resource");
  return violations;
}

/** Nested owner intents may be parsed here; this never admits them to agent-only v2 decisions. */
export function parseWalletOperationIntentV1(value: unknown): WalletOperationIntentV1 {
  canonicalAuthorityJsonV2(value);
  const violations: AuthorityContractViolation[] = validateSchemaDocuments(
    agentAuthoritySchemaDocuments,
    "wallet intent",
    "agent-authority.v2.schema.json#/$defs/walletOperationIntentV1",
    value,
  ).map((entry) => ({ path: entry.path, message: entry.message, code: "schema_invalid" }));
  if (violations.length === 0)
    violations.push(...walletIntentViolations(value as WalletOperationIntentV1));
  if (violations.length > 0)
    throw new AuthorityContractError("Invalid wallet operation intent.", violations);
  return value as WalletOperationIntentV1;
}

/** Parsing grants nothing; registered custody/current state remain independently qualified. */
export function parseWalletOperationIntentV2(value: unknown): WalletOperationIntentV2 {
  canonicalAuthorityJsonV2(value);
  const violations: AuthorityContractViolation[] = validateSchemaDocuments(
    agentAuthoritySchemaDocuments,
    "wallet intent",
    "agent-authority.v2.schema.json#/$defs/walletOperationIntentV2",
    value,
  ).map((entry) => ({ path: entry.path, message: entry.message, code: "schema_invalid" }));
  if (violations.length === 0)
    violations.push(...walletIntentViolations(value as WalletOperationIntentV2));
  if (violations.length)
    throw new AuthorityContractError("Invalid wallet operation intent.", violations);
  return value as WalletOperationIntentV2;
}

/** Parsing grants nothing; registered custody, current rights and owner proof remain independent. */
export function parseWalletOperationIntentV3(value: unknown): WalletOperationIntentV3 {
  canonicalAuthorityJsonV2(value);
  const violations: AuthorityContractViolation[] = validateSchemaDocuments(
    agentAuthoritySchemaDocuments,
    "wallet intent",
    "agent-authority.v2.schema.json#/$defs/walletOperationIntentV3",
    value,
  ).map((entry) => ({ path: entry.path, message: entry.message, code: "schema_invalid" }));
  if (violations.length === 0)
    violations.push(...walletIntentViolationsV3(value as WalletOperationIntentV3));
  if (violations.length)
    throw new AuthorityContractError("Invalid wallet operation intent.", violations);
  return value as WalletOperationIntentV3;
}

function walletOwnerSchemaViolations(definition: string, value: unknown) {
  canonicalAuthorityJsonV2(value);
  return validateSchemaDocuments(
    agentAuthoritySchemaDocuments,
    "wallet owner approval",
    `agent-authority.v2.schema.json#/$defs/${definition}`,
    value,
  ).map((entry) => ({ path: entry.path, message: entry.message, code: "schema_invalid" as const }));
}

/** Closed JWS header profile only; no signature or key authenticity is verified. */
export function parseWalletOwnerApprovalProtectedHeaderV1(
  value: unknown,
): WalletOwnerApprovalProtectedHeaderV1 {
  const violations = walletOwnerSchemaViolations("walletOwnerApprovalProtectedHeaderV1", value);
  if (violations.length)
    throw new AuthorityContractError("Invalid wallet owner approval header.", violations);
  return value as WalletOwnerApprovalProtectedHeaderV1;
}

type WalletOwnerApprovalReceipt = WalletOwnerApprovalReceiptV1 | WalletOwnerApprovalReceiptV2;

function parseOwnerReceipt(
  value: unknown,
  definition: "walletOwnerApprovalReceiptV1" | "walletOwnerApprovalReceiptV2",
): WalletOwnerApprovalReceipt {
  const violations: AuthorityContractViolation[] = walletOwnerSchemaViolations(definition, value);
  if (violations.length === 0) {
    const receipt = value as WalletOwnerApprovalReceipt;
    const exact = receipt.schemaVersion === "kombify.wallet-owner-approval-receipt.v2";
    violations.push(
      ...(exact
        ? walletIntentViolationsV3(receipt.intent as WalletOperationIntentV3)
        : walletIntentViolations(receipt.intent as WalletOperationIntentV1)),
    );
    const op = receipt.intent.operation;
    const mismatch = (path: string, message: string) =>
      violations.push({ code: "binding_mismatch", path, message });
    if (
      receipt.ownerPin.subject !== op.subject ||
      receipt.ownerPin.custodyNamespace !== op.resource.identity.custodyNamespace ||
      op.actor.kind !== "user" ||
      op.actor.id !== op.subject ||
      op.authenticationProfile !== "owner_interactive" ||
      (op.context as WalletOperationIntentV1["operation"]["context"]).kind === "agent_run"
    )
      mismatch("/ownerPin", "receipt requires the exact human owner and custody namespace");
    const audiences = exact
      ? [
          (op as WalletOperationIntentV3["operation"]).admissionAudience,
          (op as WalletOperationIntentV3["operation"]).executor.audience,
        ]
      : [(op as WalletOperationIntentV1["operation"]).audience];
    if (audiences.includes(receipt.aud))
      mismatch("/intent/operation/audience", "operation and receipt audiences must differ");
    const second = 1_000_000_000n;
    const issued = BigInt(receipt.iat) * second;
    const expires = BigInt(receipt.exp) * second;
    const auth = BigInt(receipt.authentication.authTime) * second;
    const created = walletDateNanoseconds(receipt.approval.createdAt);
    const decided = walletDateNanoseconds(receipt.approval.decidedAt);
    const confirmed = walletDateNanoseconds(receipt.audit.confirmedAt);
    if (
      expires <= issued ||
      expires - issued > 60n * second ||
      expires > walletDateNanoseconds(op.expiresAt) ||
      created > decided ||
      decided > confirmed ||
      confirmed >= issued + second
    )
      mismatch("/approval", "receipt lifetime or retained event chronology is invalid");
    const minimumAuthSecond = created / second + (created % second > 0n ? 1n : 0n);
    if (
      BigInt(receipt.authentication.authTime) < minimumAuthSecond ||
      auth > decided ||
      auth > issued ||
      issued - auth >= 300n * second
    )
      mismatch("/authentication/authTime", "MFA must follow creation and be fresh at issuance");
  }
  if (violations.length)
    throw new AuthorityContractError("Invalid wallet owner approval receipt.", violations);
  return value as WalletOwnerApprovalReceipt;
}

/** Structural and intrinsic checks only; retained facts and JWS verification are external. */
export function parseWalletOwnerApprovalReceiptV1(value: unknown): WalletOwnerApprovalReceiptV1 {
  return parseOwnerReceipt(value, "walletOwnerApprovalReceiptV1") as WalletOwnerApprovalReceiptV1;
}

/**
 * The receipt for a v3 item with ownerProof fresh_owner_proof: the v1 rules over the full
 * v3 intent. It binds owner contexts only, so a delegated agent run never satisfies it.
 */
export function parseWalletOwnerApprovalReceiptV2(value: unknown): WalletOwnerApprovalReceiptV2 {
  return parseOwnerReceipt(value, "walletOwnerApprovalReceiptV2") as WalletOwnerApprovalReceiptV2;
}

function ownerReceiptBindingViolations(
  receipt: WalletOwnerApprovalReceipt,
  trusted: WalletOwnerApprovalTrustedFactsV1,
  parseReceipt: (value: unknown) => WalletOwnerApprovalReceipt,
): readonly AuthorityContractViolation[] {
  const violations: AuthorityContractViolation[] = [];
  const mismatch = (path: string, message: string) =>
    violations.push({ code: "binding_mismatch", path, message });
  try {
    parseReceipt(receipt);
    canonicalAuthorityJsonV2(trusted);
    parseWalletOwnerApprovalProtectedHeaderV1(trusted.protectedHeader);
    if (
      !trusted.signingKey ||
      !trusted.ownerPin ||
      !trusted.approval ||
      !trusted.authentication ||
      !trusted.audit
    ) {
      mismatch("/trusted", "independently authenticated retained facts are required");
      return violations;
    }
    if (
      trusted.protectedHeader.kid !== trusted.signingKey.kid ||
      receipt.keyGeneration !== trusted.signingKey.keyGeneration
    )
      mismatch("/keyGeneration", "receipt differs from pinned signing key");
    if (!sameCanonical(receipt.ownerPin, trusted.ownerPin))
      mismatch("/ownerPin", "receipt differs from retained owner pin");
    const { state, intentDigest, ...approval } = trusted.approval;
    if (
      state !== "approved" ||
      intentDigest !== receipt.intent.intentDigest ||
      !sameCanonical(receipt.approval, approval)
    )
      mismatch("/approval", "receipt differs from retained approved intent revision");
    if (!sameCanonical(receipt.authentication, trusted.authentication))
      mismatch("/authentication", "receipt differs from authenticated MFA evidence");
    if (!sameCanonical(receipt.audit, trusted.audit))
      mismatch("/audit", "receipt differs from retained audit confirmation");
    const nowViolations = walletOwnerSchemaViolations(
      "walletOwnerApprovalReceiptV1/properties/audit/properties/confirmedAt",
      trusted.now,
    );
    if (nowViolations.length) return [...violations, ...nowViolations];
    const second = 1_000_000_000n;
    const now = walletDateNanoseconds(trusted.now);
    if (
      BigInt(receipt.iat) * second > now ||
      BigInt(receipt.exp) * second <= now ||
      walletDateNanoseconds(receipt.audit.confirmedAt) > now ||
      now - BigInt(receipt.authentication.authTime) * second > 300n * second
    )
      mismatch("/trusted/now", "receipt or MFA is not current at consumption");
  } catch (error) {
    if (error instanceof AuthorityContractError) return [...violations, ...error.violations];
    mismatch("/trusted", "independently authenticated retained facts are required");
  }
  return violations;
}

/**
 * Compare independently authenticated facts after external JWS verification.
 * This helper authenticates neither the facts nor the signature and grants no admission.
 */
export function validateWalletOwnerApprovalBindingsV1(
  receipt: WalletOwnerApprovalReceiptV1,
  trusted: WalletOwnerApprovalTrustedFactsV1,
): readonly AuthorityContractViolation[] {
  return ownerReceiptBindingViolations(receipt, trusted, parseWalletOwnerApprovalReceiptV1);
}

/** The same comparison for the v2 receipt over a v3 intent. */
export function validateWalletOwnerApprovalBindingsV2(
  receipt: WalletOwnerApprovalReceiptV2,
  trusted: WalletOwnerApprovalTrustedFactsV1,
): readonly AuthorityContractViolation[] {
  return ownerReceiptBindingViolations(receipt, trusted, parseWalletOwnerApprovalReceiptV2);
}

function walletDocumentViolations(document: AuthorityDocumentV2): AuthorityContractViolation[] {
  if (document.schemaVersion === "kombify.agent-role-template.v2") return [];
  const violations: AuthorityContractViolation[] = [];
  const mismatch = (path: string, message: string) =>
    violations.push({ code: "binding_mismatch" as const, path, message });
  const resources =
    document.schemaVersion === "kombify.agent-authority-grant.v2"
      ? document.binding.envelope.resources
      : document.schemaVersion === "kombify.activation-decision.v2"
        ? []
        : document.binding.resources;
  const wallets = resources.filter(
    (resource): resource is WalletResourceV1 | WalletResourceV2 | WalletResourceV3 =>
      isWalletResourceV1(resource) || isWalletResourceV2(resource) || isWalletResourceV3(resource),
  );
  for (const resource of wallets)
    if (isWalletResourceV2(resource) || isWalletResourceV3(resource))
      violations.push(...walletResourceV2Violations(resource));
  for (const resource of wallets)
    if (resource.identity.owner !== document.binding.subject)
      mismatch("/binding/resources", "wallet owner differs from binding subject");
  if (document.schemaVersion === "kombify.agent-authority-grant.v2") return violations;
  const b = document.binding;
  if (
    !isWalletOperationIntentV1(b.intent) &&
    !isWalletOperationIntentV2(b.intent) &&
    !isWalletOperationIntentV3(b.intent)
  ) {
    if (wallets.length > 0) mismatch("/binding/intent", "wallet resource requires wallet intent");
    return violations;
  }
  violations.push(
    ...(isWalletOperationIntentV3(b.intent)
      ? walletIntentViolationsV3(b.intent)
      : walletIntentViolations(b.intent)),
  );
  const op = b.intent.operation;
  // Nested v2 and v3 bind an exact version: admission audience, operation expiry inside the request.
  const exact = isWalletOperationIntentV2(b.intent) || isWalletOperationIntentV3(b.intent);
  if (
    exact &&
    document.schemaVersion === "kombify.capability-lease.v2" &&
    (walletDateNanoseconds(document.expiresAt) >
      walletDateNanoseconds(document.binding.expiresAt) ||
      walletDateNanoseconds(document.expiresAt) > walletDateNanoseconds(op.expiresAt) ||
      walletDateNanoseconds(document.issuedAt) >= walletDateNanoseconds(document.expiresAt))
  )
    mismatch(
      "/expiresAt",
      "wallet lease must be issued before expiry and cannot outlive binding or operation",
    );
  if (op.subject !== b.subject || op.executionTenantId !== b.tenantId)
    mismatch("/binding/intent/operation", "wallet subject or tenant differs from binding");
  if (op.authenticationProfile !== "delegated_user" || op.context.kind !== "agent_run")
    mismatch("/binding/intent/operation", "owner intent cannot enter agent-only v2 activation");
  if (document.schemaVersion !== "kombify.activation-decision.v2") {
    const request = document.binding;
    if (
      request.resources.length !== 1 ||
      wallets.length !== 1 ||
      !sameAuthorityResourceV2(wallets[0]!, op.resource)
    )
      mismatch("/binding/resources", "wallet operation must bind one exact resource projection");
    if (
      !sameCanonical(op.actor, request.requester) ||
      op.context.kind !== "agent_run" ||
      op.context.agentInstanceId !== request.target.agentInstanceId
    )
      mismatch("/binding/intent/operation/actor", "wallet actor differs from requester or target");
    if (
      (isWalletOperationIntentV1(b.intent)
        ? b.intent.operation.audience
        : b.intent.operation.admissionAudience) !== request.audience ||
      (exact
        ? walletDateNanoseconds(op.expiresAt) > walletDateNanoseconds(request.expiresAt)
        : Date.parse(request.expiresAt) > Date.parse(op.expiresAt))
    )
      mismatch("/binding/intent/operation", "wallet audience or expiry differs from request");
    if (!request.definitionIds.includes(op.resource.definitionId))
      mismatch("/binding/definitionIds", "wallet definition is not requested");
  }
  return violations;
}

function wellFormedString(value: string, path: string): string {
  for (let index = 0; index < value.length; index += 1) {
    const unit = value.charCodeAt(index);
    if (unit >= 0xd800 && unit <= 0xdbff) {
      const next = value.charCodeAt(index + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) {
        throw new AuthorityContractError("Authority JSON contains invalid Unicode.", [
          { code: "invalid_json_value", path, message: "lone high surrogate" },
        ]);
      }
      index += 1;
    } else if (unit >= 0xdc00 && unit <= 0xdfff) {
      throw new AuthorityContractError("Authority JSON contains invalid Unicode.", [
        { code: "invalid_json_value", path, message: "lone low surrogate" },
      ]);
    }
  }
  return value;
}

function pointer(path: string, segment: string | number): string {
  const escaped = String(segment).replaceAll("~", "~0").replaceAll("/", "~1");
  return `${path}/${escaped}`;
}

function canonicalize(value: unknown, path: string, ancestors: Set<object>): string {
  if (value === null || typeof value === "boolean") return JSON.stringify(value);
  if (typeof value === "string") return JSON.stringify(wellFormedString(value, path || "/"));
  if (typeof value === "number") {
    if (!Number.isSafeInteger(value)) {
      throw new AuthorityContractError("Authority JSON accepts safe integers only.", [
        { code: "invalid_json_value", path: path || "/", message: "not a safe integer" },
      ]);
    }
    return JSON.stringify(value);
  }
  if (typeof value !== "object" || value === undefined) {
    throw new AuthorityContractError("Authority value is not JSON.", [
      { code: "invalid_json_value", path: path || "/", message: "not a JSON value" },
    ]);
  }
  if (ancestors.has(value)) {
    throw new AuthorityContractError("Authority JSON cannot contain cycles.", [
      { code: "invalid_json_value", path: path || "/", message: "cyclic value" },
    ]);
  }
  ancestors.add(value);
  try {
    if (Array.isArray(value)) {
      return `[${Array.from(value, (entry, index) =>
        canonicalize(entry, pointer(path, index), ancestors),
      ).join(",")}]`;
    }
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record)
      // Object.keys returns a fresh array; UTF-16 ordering is required by RFC 8785.
      // oxlint-disable-next-line unicorn/no-array-sort
      .sort()
      .map((key) => {
        const childPath = pointer(path, key);
        return `${JSON.stringify(wellFormedString(key, childPath))}:${canonicalize(record[key], childPath, ancestors)}`;
      })
      .join(",")}}`;
  } finally {
    ancestors.delete(value);
  }
}

/** RFC 8785-compatible canonical JSON for schema-bounded authority values. */
export function canonicalAuthorityJsonV2(value: unknown): string {
  return canonicalize(value, "", new Set());
}

function bytesToLowerHex(bytes: Uint8Array): string {
  let result = "";
  for (const byte of bytes) result += byte.toString(16).padStart(2, "0");
  return result;
}

/** SHA-256 of `<domain>\\n<canonical JSON>\\n`. */
export function canonicalAuthorityDigestV2(domain: string, binding: unknown): AuthorityDigestV2 {
  wellFormedString(domain, "/domain");
  if (domain.length === 0 || domain.includes("\n") || domain.includes("\r")) {
    throw new AuthorityContractError("Authority digest domain is invalid.", [
      { code: "invalid_json_value", path: "/domain", message: "invalid digest domain" },
    ]);
  }
  const bytes = textEncoder.encode(`${domain}\n${canonicalAuthorityJsonV2(binding)}\n`);
  return `sha256:${bytesToLowerHex(sha256(bytes))}`;
}

export function agentAuthorityGrantDigestV2(
  binding: AgentAuthorityGrantV2["binding"],
): AuthorityDigestV2 {
  return canonicalAuthorityDigestV2(AGENT_AUTHORITY_GRANT_DIGEST_DOMAIN_V2, binding);
}

export function activationRequestDigestV2(
  binding: ActivationRequestV2["binding"],
): AuthorityDigestV2 {
  return canonicalAuthorityDigestV2(ACTIVATION_REQUEST_DIGEST_DOMAIN_V2, binding);
}

export function activationDecisionDigestV2(
  binding: ActivationDecisionV2["binding"],
): AuthorityDigestV2 {
  return canonicalAuthorityDigestV2(ACTIVATION_DECISION_DIGEST_DOMAIN_V2, binding);
}

/** Remove self-referential and server-owned registry facts from a v2 template. */
export function agentRoleTemplateAuthoredProjectionV2(
  template: AgentRoleTemplateV2,
): AgentRoleTemplateAuthoredV2 {
  const { digest: _digest, lifecycle: _lifecycle, trustClass: _trustClass, ...authored } = template;
  return authored;
}

export function agentRoleTemplateDigestV2(
  authored: AgentRoleTemplateAuthoredV2,
): AuthorityDigestV2 {
  return canonicalAuthorityDigestV2(AGENT_ROLE_TEMPLATE_DIGEST_DOMAIN_V2, authored);
}

const SCHEMA_BY_VERSION = {
  "kombify.agent-authority-grant.v2": "agent-authority.v2.schema.json",
  "kombify.activation-request.v2": "activation-request.v2.schema.json",
  "kombify.activation-decision.v2": "activation-decision.v2.schema.json",
  "kombify.capability-lease.v2": "capability-lease.v2.schema.json",
  "kombify.agent-role-template.v2": "agent-role-template.v2.schema.json",
} as const satisfies Record<AuthorityDocumentSchemaVersionV2, string>;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function schemaVersion(value: unknown): AuthorityDocumentSchemaVersionV2 | null {
  if (
    !isRecord(value) ||
    !Object.hasOwn(value, "schemaVersion") ||
    typeof value.schemaVersion !== "string"
  )
    return null;
  return Object.hasOwn(SCHEMA_BY_VERSION, value.schemaVersion)
    ? (value.schemaVersion as AuthorityDocumentSchemaVersionV2)
    : null;
}

function schemaViolations(version: AuthorityDocumentSchemaVersionV2, value: unknown) {
  return validateSchemaDocuments(
    agentAuthoritySchemaDocuments,
    "agent authority v2",
    SCHEMA_BY_VERSION[version],
    value,
  ).map((violation) => ({
    code: "schema_invalid" as const,
    path: violation.path,
    message: violation.message,
  }));
}

function sameCanonical(left: unknown, right: unknown): boolean {
  if (left === undefined || right === undefined) return left === right;
  return canonicalAuthorityJsonV2(left) === canonicalAuthorityJsonV2(right);
}

function actorIdentity(actor: AuthorityActorV2): string {
  return `${actor.kind}:${actor.id}`;
}

function immutableViolations(document: AuthorityDocumentV2): AuthorityContractViolation[] {
  const violations: AuthorityContractViolation[] = [];
  const mismatch = (path: string, message: string) =>
    violations.push({ code: "binding_mismatch", path, message });
  if (document.schemaVersion === "kombify.agent-authority-grant.v2") {
    if (document.grantDigest !== agentAuthorityGrantDigestV2(document.binding)) {
      violations.push({
        code: "digest_mismatch",
        path: "/grantDigest",
        message: "grant digest mismatch",
      });
    }
  } else if (document.schemaVersion === "kombify.activation-request.v2") {
    if (document.requestDigest !== activationRequestDigestV2(document.binding)) {
      violations.push({
        code: "digest_mismatch",
        path: "/requestDigest",
        message: "request digest mismatch",
      });
    }
  } else if (document.schemaVersion === "kombify.activation-decision.v2") {
    if (document.decisionDigest !== activationDecisionDigestV2(document.binding)) {
      violations.push({
        code: "digest_mismatch",
        path: "/decisionDigest",
        message: "decision digest mismatch",
      });
    }
    if (document.binding.authorityBasis.facet === "use") {
      const chain = document.binding.authorityChain;
      const root = chain[0]?.issuer;
      if (
        (document.binding.kind !== "agent" && document.binding.kind !== "owner_equip") ||
        document.binding.verdict !== "approved" ||
        root?.kind !== "user" ||
        root.id !== document.binding.subject ||
        chain.slice(0, -1).some((link) => link.basis.facet !== "delegate")
      ) {
        mismatch(
          "/binding/authorityChain",
          "standing use requires exact owner root, delegate ancestry and approved agent leaf",
        );
      }
    }
    if (document.binding.kind === "owner_equip") {
      const b = document.binding;
      if (
        b.actor.id !== b.subject ||
        b.authorityChain.length !== 1 ||
        !sameCanonical(b.authorityChain[0]?.issuer, b.actor)
      )
        mismatch("/binding/authorityChain", "owner equipment requires the exact owner issuer");
    }
    const leaf = document.binding.authorityChain.at(-1);
    if (!leaf || !sameCanonical(leaf.basis, document.binding.authorityBasis)) {
      mismatch("/binding/authorityChain", "authority basis is not the chain leaf");
    }
    if (
      document.binding.kind !== "owner_equip" &&
      (!leaf || !sameCanonical(leaf.grantee, document.binding.actor))
    ) {
      mismatch("/binding/actor", "decision actor is not the chain leaf grantee");
    }
    for (let index = 1; index < document.binding.authorityChain.length; index += 1) {
      const previous = document.binding.authorityChain[index - 1];
      const current = document.binding.authorityChain[index];
      if (previous && current && !sameCanonical(current.issuer, previous.grantee)) {
        mismatch(
          `/binding/authorityChain/${index}/issuer`,
          "authority chain is not ordered root to leaf",
        );
      }
    }
    const generations = new Set<string>();
    const agentIdentities = new Set<string>();
    for (const [index, link] of document.binding.authorityChain.entries()) {
      const generation = `${link.basis.grantId}:${link.basis.generation}`;
      if (generations.has(generation)) {
        mismatch(`/binding/authorityChain/${index}/basis`, "authority generation is repeated");
      }
      generations.add(generation);
      if (index === 0 && link.issuer.kind === "agent") {
        agentIdentities.add(actorIdentity(link.issuer));
      }
      const grantee = actorIdentity(link.grantee);
      if (agentIdentities.has(grantee)) {
        mismatch(
          `/binding/authorityChain/${index}/grantee`,
          "agent identity cycle in authority chain",
        );
      }
      agentIdentities.add(grantee);
    }
  } else if (document.schemaVersion === "kombify.capability-lease.v2") {
    if (document.requestDigest !== activationRequestDigestV2(document.binding)) {
      violations.push({
        code: "digest_mismatch",
        path: "/requestDigest",
        message: "lease request digest mismatch",
      });
    }
  } else if (document.schemaVersion === "kombify.agent-role-template.v2") {
    if (
      document.digest !== agentRoleTemplateDigestV2(agentRoleTemplateAuthoredProjectionV2(document))
    ) {
      violations.push({
        code: "digest_mismatch",
        path: "/digest",
        message: "role-template digest mismatch",
      });
    }
  }
  return violations;
}

/**
 * Validate schema and immutable digests only. Success is not proof that a Cloud
 * grant is active or that its FGA tuple is current.
 */
export function validateAuthorityDocumentV2(value: unknown): readonly AuthorityContractViolation[] {
  try {
    canonicalAuthorityJsonV2(value);
  } catch (error) {
    if (error instanceof AuthorityContractError) return error.violations;
    throw error;
  }
  const version = schemaVersion(value);
  if (!version) {
    return [
      {
        code: "schema_invalid",
        path: "/schemaVersion",
        message: "unsupported authority schema version",
      },
    ];
  }
  const violations = schemaViolations(version, value);
  if (violations.length > 0) return violations;
  if (version === "kombify.activation-request.v2" || version === "kombify.capability-lease.v2") {
    const task = (value as ActivationRequestV2 | CapabilityLeaseV2).binding.taskRef;
    if (task && BigInt(task.revision) > 9223372036854775807n) {
      return [
        {
          code: "schema_invalid",
          path: "/binding/taskRef/revision",
          message: "task revision exceeds signed bigint",
        },
      ];
    }
  }
  return [
    ...immutableViolations(value as AuthorityDocumentV2),
    ...walletDocumentViolations(value as AuthorityDocumentV2),
  ];
}

export function parseAuthorityDocumentV2(value: unknown): AuthorityDocumentV2 {
  const violations = validateAuthorityDocumentV2(value);
  if (violations.length > 0) {
    throw new AuthorityContractError("Invalid agent authority v2 document.", violations);
  }
  return value as AuthorityDocumentV2;
}

export function parseAuthorityJsonV2(json: string): AuthorityDocumentV2 {
  let value: unknown;
  try {
    value = JSON.parse(wellFormedString(json, "/"));
  } catch (error) {
    if (error instanceof AuthorityContractError) throw error;
    throw new AuthorityContractError("Invalid authority JSON text.", [
      { code: "invalid_json_value", path: "/", message: "invalid JSON text" },
    ]);
  }
  return parseAuthorityDocumentV2(value);
}

function parseVersion<T extends AuthorityDocumentV2>(
  value: unknown,
  version: T["schemaVersion"],
): T {
  const document = parseAuthorityDocumentV2(value);
  if (document.schemaVersion !== version) {
    throw new AuthorityContractError("Unexpected agent authority document version.", [
      { code: "schema_invalid", path: "/schemaVersion", message: `expected ${version}` },
    ]);
  }
  return document as T;
}

export const parseAgentAuthorityGrantV2 = (value: unknown): AgentAuthorityGrantV2 =>
  parseVersion<AgentAuthorityGrantV2>(value, "kombify.agent-authority-grant.v2");
export const parseActivationRequestV2 = (value: unknown): ActivationRequestV2 =>
  parseVersion<ActivationRequestV2>(value, "kombify.activation-request.v2");
export const parseActivationDecisionV2 = (value: unknown): ActivationDecisionV2 =>
  parseVersion<ActivationDecisionV2>(value, "kombify.activation-decision.v2");
export const parseCapabilityLeaseV2 = (value: unknown): CapabilityLeaseV2 =>
  parseVersion<CapabilityLeaseV2>(value, "kombify.capability-lease.v2");
export const parseAgentRoleTemplateV2 = (value: unknown): AgentRoleTemplateV2 =>
  parseVersion<AgentRoleTemplateV2>(value, "kombify.agent-role-template.v2");

/** Verify cross-record immutable references without evaluating online authority. */
export function validateAuthorityBindingSetV2(input: {
  readonly request: ActivationRequestV2;
  readonly decision: ActivationDecisionV2;
  readonly lease?: CapabilityLeaseV2;
}): readonly AuthorityContractViolation[] {
  const violations: AuthorityContractViolation[] = [];
  const mismatch = (path: string, message: string) =>
    violations.push({ code: "binding_mismatch", path, message });
  const { request, decision, lease } = input;
  for (const document of [request, decision, ...(lease ? [lease] : [])])
    violations.push(...validateAuthorityDocumentV2(document));
  if (
    decision.binding.requestId !== request.id ||
    decision.binding.requestDigest !== request.requestDigest
  ) {
    mismatch("/decision/binding/requestDigest", "decision does not bind the request");
  }
  if (
    decision.binding.tenantId !== request.binding.tenantId ||
    decision.binding.subject !== request.binding.subject
  ) {
    mismatch("/decision/binding/subject", "decision tenant or subject differs from the request");
  }
  if (!sameCanonical(decision.binding.policy, request.binding.policy)) {
    mismatch("/decision/binding/policy", "decision policy differs from the request");
  }
  if (!sameCanonical(decision.binding.intent, request.binding.intent)) {
    mismatch("/decision/binding/intent", "decision intent differs from the request");
  }
  if (!sameCanonical(decision.binding.monetaryReservation, request.binding.monetaryReservation)) {
    mismatch(
      "/decision/binding/monetaryReservation",
      "decision monetary reference differs from the request",
    );
  }
  const ownerEquipment = request.binding.ownerEquipment;
  if (ownerEquipment) {
    const target = request.binding.target;
    if (
      decision.binding.kind !== "owner_equip" ||
      !sameCanonical(decision.binding.ownerEquipment, ownerEquipment) ||
      !sameCanonical(decision.binding.actor, request.binding.requester) ||
      !sameCanonical(decision.binding.authorityBasis, request.binding.authorityBasis) ||
      !sameCanonical(decision.binding.authorityChain[0]?.grantee, {
        kind: "agent",
        id: target.agentInstanceId,
        agentClass: target.agentClass,
        templateDigest: target.templateDigest,
      })
    )
      mismatch("/decision/binding/actor", "owner equipment must bind its exact target and owner");
  } else if (decision.binding.ownerEquipment)
    mismatch("/decision/binding/ownerEquipment", "owner profile differs from request");
  const ownStandingAdmission =
    !ownerEquipment &&
    (decision.binding.kind === "self_activate" || decision.binding.authorityBasis.facet === "use");
  if (
    ownStandingAdmission &&
    (!sameCanonical(decision.binding.actor, request.binding.requester) ||
      decision.binding.actor.id !== request.binding.target.agentInstanceId ||
      decision.binding.actor.agentClass !== request.binding.target.agentClass ||
      decision.binding.actor.templateDigest !== request.binding.target.templateDigest ||
      !sameCanonical(decision.binding.authorityBasis, request.binding.authorityBasis))
  ) {
    mismatch(
      "/decision/binding/actor",
      "standing admission must bind the exact requester, target and authority generation",
    );
  }
  if (
    !ownerEquipment &&
    !ownStandingAdmission &&
    actorIdentity(decision.binding.actor) === actorIdentity(request.binding.requester)
  ) {
    mismatch("/decision/binding/actor", "requester cannot decide its own request");
  }
  if (
    !ownerEquipment &&
    !ownStandingAdmission &&
    decision.binding.authorityChain.some(
      (link) =>
        link.issuer.kind === "agent" &&
        actorIdentity(link.issuer) === actorIdentity(request.binding.requester),
    )
  ) {
    mismatch("/decision/binding/authorityChain", "requester appears in approval ancestry");
  }
  if (
    decision.binding.authorityChain.some(
      (link) => Date.parse(link.issuedAt) > Date.parse(request.createdAt),
    )
  ) {
    mismatch("/decision/binding/authorityChain", "approval generation postdates the request");
  }
  if (lease) {
    if (
      lease.activationRequestId !== request.id ||
      lease.requestDigest !== request.requestDigest ||
      !sameCanonical(lease.binding, request.binding)
    ) {
      mismatch("/lease/requestDigest", "lease does not bind the request");
    }
    if (lease.decisionId !== decision.id || lease.decisionDigest !== decision.decisionDigest) {
      mismatch("/lease/decisionDigest", "lease does not bind the decision");
    }
  }
  return violations;
}
