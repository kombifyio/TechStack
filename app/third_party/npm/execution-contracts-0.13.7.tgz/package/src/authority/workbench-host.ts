import {
  canonicalAuthorityDigestV2,
  canonicalAuthorityJsonV2,
  parseCapabilityLeaseV2,
} from "./contract.js";
import type { AuthorityDigestV2, CapabilityLeaseV2, LegacyAuthorityResourceV2 } from "./types.js";

export const WORKBENCH_HOST_CAPABILITY_ID = "workbench.host.use" as const;
export const WORKBENCH_HOST_DISPATCH_ACTION = "workbench.host.dispatch" as const;
export const WORKBENCH_HOST_READ_ACTION = "workbench.host.read" as const;
export const WORKBENCH_HOST_AGENT_JOBS_PATH = "/api/kombify/workbench/agent-jobs" as const;

/** Personal Codex selection carried inside the existing signed T3 command. */
export interface CallGptWorkbenchBindingV1 {
  readonly schemaVersion: "kombify.callgpt-workbench-binding.v1";
  readonly providerInstanceId: string;
  readonly continuationDigest: AuthorityDigestV2;
  readonly accountEmail: string;
  readonly payer: "user-subscription";
}

/** Do not expose the provider's local home path in a delegated command. */
export function callGptProviderContinuationDigestV1(identity: {
  readonly driverKind: "codex";
  readonly continuationKey: string;
}): AuthorityDigestV2 {
  if (identity.driverKind !== "codex" || !nonempty(identity.continuationKey))
    throw new Error("Invalid personal Codex continuation.");
  return canonicalAuthorityDigestV2("kombify.callgpt-provider-continuation.digest.v1", identity);
}

export function parseCallGptWorkbenchBindingV1(value: unknown): CallGptWorkbenchBindingV1 {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new Error("Invalid personal Codex binding.");
  const binding = value as Record<string, unknown>;
  if (
    Object.keys(binding).some(
      (key) =>
        ![
          "schemaVersion",
          "providerInstanceId",
          "continuationDigest",
          "accountEmail",
          "payer",
        ].includes(key),
    ) ||
    binding.schemaVersion !== "kombify.callgpt-workbench-binding.v1" ||
    !nonempty(binding.providerInstanceId) ||
    binding.providerInstanceId.length > 128 ||
    typeof binding.continuationDigest !== "string" ||
    !/^sha256:[0-9a-f]{64}$/u.test(binding.continuationDigest) ||
    !nonempty(binding.accountEmail) ||
    binding.accountEmail.length > 320 ||
    binding.payer !== "user-subscription"
  )
    throw new Error("Invalid personal Codex selection.");
  return binding as unknown as CallGptWorkbenchBindingV1;
}

export interface CallGptJobReferenceV1 {
  readonly activationRequestId: string;
  readonly commandId: string;
  readonly runId: string;
}

/** Exact immutable request, command and run identities; this reference grants no authority. */
export function parseCallGptJobReferenceV1(value: unknown): CallGptJobReferenceV1 {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new Error("Invalid personal Codex job reference.");
  const job = value as Record<string, unknown>;
  if (Object.keys(job).length !== 3 || Object.keys(job).some((key) =>
    !["activationRequestId", "commandId", "runId"].includes(key)) ||
    !nonempty(job.activationRequestId) || job.activationRequestId.length > 128 ||
    !nonempty(job.commandId) || job.commandId.length > 128 ||
    !nonempty(job.runId) || job.runId.length > 256)
    throw new Error("Invalid personal Codex job reference.");
  return job as unknown as CallGptJobReferenceV1;
}

/** The existing T3 receipt is the durable cancellation marker for this exact original job. */
export function callGptJobCancellationCommandIdV1(reference: CallGptJobReferenceV1, threadId: string): string {
  const job = parseCallGptJobReferenceV1(reference);
  if (!nonempty(threadId) || threadId.length > 256) throw new Error("Invalid retained CallGPT thread.");
  return `callgpt-cancel:${canonicalAuthorityDigestV2("kombify.callgpt-job-cancellation.digest.v1", { runId: job.runId, threadId }).slice(7)}`;
}

/** Consumers must read the immutable admission and verify its current owner/resource binding. */
export function callGptJobReferenceFromCommandV1(command: unknown): CallGptJobReferenceV1 | undefined {
  if (command === null || typeof command !== "object" || Array.isArray(command))
    throw new Error("Invalid Workbench command.");
  const record = command as Record<string, unknown>;
  if (record.callGptJob === undefined) return undefined;
  const job = parseCallGptJobReferenceV1(record.callGptJob);
  if (!nonempty(record.commandId) || record.commandId.length > 128 || record.commandId === job.commandId ||
    !nonempty(record.threadId) || record.callGpt === undefined || record.bootstrap !== undefined ||
    (record.type !== "thread.turn.start" && record.type !== "thread.turn.interrupt"))
    throw new Error("Invalid personal Codex job reference.");
  return job;
}

/** Validate this profile without changing admission of generic Workbench jobs. */
export function callGptWorkbenchBindingFromCommandV1(
  command: unknown,
): CallGptWorkbenchBindingV1 | undefined {
  if (command === null || typeof command !== "object" || Array.isArray(command))
    throw new Error("Invalid Workbench command.");
  const record = command as Record<string, unknown>;
  if (record.callGpt === undefined) return undefined;
  const binding = parseCallGptWorkbenchBindingV1(record.callGpt);
  const job = callGptJobReferenceFromCommandV1(record);
  if (record.type === "thread.turn.interrupt" && (!job || typeof record.threadId !== "string" || record.commandId !== callGptJobCancellationCommandIdV1(job, record.threadId)))
    throw new Error("Personal Codex cancellation requires its exact retained job.");
  const selection = record.modelSelection as Record<string, unknown> | undefined;
  if (
    (record.type !== "thread.turn.start" && !(record.type === "thread.turn.interrupt" && job)) ||
    !selection ||
    selection.instanceId !== binding.providerInstanceId ||
    !nonempty(selection.model)
  )
    throw new Error("Personal Codex requires an explicit provider and model.");
  const bootstrap = record.bootstrap as
    | { createThread?: { modelSelection?: Record<string, unknown> } }
    | undefined;
  if (
    bootstrap?.createThread &&
    canonicalAuthorityJsonV2(bootstrap.createThread.modelSelection) !==
      canonicalAuthorityJsonV2(selection)
  )
    throw new Error("Personal Codex bootstrap selection mismatch.");
  return binding;
}

/** A profile of V2 resources[].bindings, not a new grant or lease family. */
export interface WorkbenchHostResourceBindingsV1 {
  readonly environmentId: string;
  readonly workspaceId: string;
  readonly hostGeneration: string;
  readonly profile: "full-environment";
  /** A user-selected personal provider, persisted through the existing equipment resource. */
  readonly callGpt?: string;
}

/** Resource bindings remain string-valued across the canonical TypeScript and Go contracts. */
export function callGptWorkbenchBindingFromResourceV1(
  bindings: WorkbenchHostResourceBindingsV1,
): CallGptWorkbenchBindingV1 | undefined {
  if (bindings.callGpt === undefined) return undefined;
  if (typeof bindings.callGpt !== "string") throw new Error("Invalid personal Codex resource.");
  const personal = parseCallGptWorkbenchBindingV1(JSON.parse(bindings.callGpt));
  if (canonicalAuthorityJsonV2(personal) !== bindings.callGpt)
    throw new Error("Noncanonical personal Codex resource.");
  return personal;
}

function nonempty(value: unknown): value is string {
  return (
    typeof value === "string" &&
    value.length > 0 &&
    value.trim() === value &&
    !Array.from(value).some(
      (character) => character.charCodeAt(0) < 32 || character.charCodeAt(0) === 127,
    )
  );
}

export function parseWorkbenchHostResourceV1(value: unknown): WorkbenchHostResourceBindingsV1 {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new Error("Invalid Workbench resource.");
  const resource = value as Record<string, unknown>;
  if (
    resource.definitionId !== WORKBENCH_HOST_CAPABILITY_ID ||
    resource.bindings === null ||
    typeof resource.bindings !== "object" ||
    Array.isArray(resource.bindings)
  )
    throw new Error("Invalid Workbench resource profile.");
  const bindings = resource.bindings as Record<string, unknown>;
  if (
    Object.keys(bindings).some(
      (key) =>
        !["environmentId", "workspaceId", "hostGeneration", "profile", "callGpt"].includes(key),
    ) ||
    !nonempty(bindings.environmentId) ||
    !nonempty(bindings.workspaceId) ||
    typeof bindings.hostGeneration !== "string" ||
    !/^[1-9][0-9]*$/u.test(bindings.hostGeneration) ||
    !Number.isSafeInteger(Number(bindings.hostGeneration)) ||
    bindings.profile !== "full-environment" ||
    resource.resource !== `environment:${bindings.environmentId}`
  )
    throw new Error("Invalid Workbench resource binding.");
  const parsed: WorkbenchHostResourceBindingsV1 = {
    environmentId: bindings.environmentId,
    workspaceId: bindings.workspaceId,
    hostGeneration: bindings.hostGeneration,
    profile: bindings.profile,
    ...(bindings.callGpt === undefined ? {} : { callGpt: bindings.callGpt as string }),
  };
  callGptWorkbenchBindingFromResourceV1(parsed);
  return parsed;
}

export function createWorkbenchHostResourceV1(
  bindings: WorkbenchHostResourceBindingsV1,
): LegacyAuthorityResourceV2 {
  const resource = {
    definitionId: WORKBENCH_HOST_CAPABILITY_ID,
    resource: `environment:${bindings.environmentId}`,
    bindings: { ...bindings },
  };
  parseWorkbenchHostResourceV1(resource);
  return resource;
}

/** Callers normalize the existing T3 command before binding the complete job. */
export function workbenchHostCommandDigestV1(job: {
  readonly runId: string;
  readonly workspaceId: string;
  readonly command: unknown;
}): AuthorityDigestV2 {
  if (!nonempty(job.runId) || !nonempty(job.workspaceId))
    throw new Error("Invalid Workbench job identity.");
  callGptWorkbenchBindingFromCommandV1(job.command);
  const original = callGptJobReferenceFromCommandV1(job.command);
  if (original && original.runId !== job.runId)
    throw new Error("Personal Codex continuation requires its original run.");
  return canonicalAuthorityDigestV2("kombify.workbench-host-command.digest.v1", {
    runId: job.runId,
    workspaceId: job.workspaceId,
    command: job.command,
  });
}

/** Distinct read admissions retain the original receipt identity without ambiguous separators. */
export function workbenchHostReadPermissionKeyV1(commandId: string, readId: string): string {
  if (!nonempty(commandId) || commandId.length > 128 || !/^[0-9a-f]{64}$/u.test(readId))
    throw new Error("Invalid Workbench read identity.");
  const key = canonicalAuthorityJsonV2({ commandId, readId });
  if (key.length > 256) throw new Error("Workbench read identity exceeds its bound.");
  return key;
}

export function parseWorkbenchHostReadPermissionKeyV1(key: string): {
  commandId: string;
  readId: string;
} {
  if (typeof key !== "string" || key.length > 256)
    throw new Error("Invalid Workbench read identity.");
  const value = JSON.parse(key) as { commandId?: unknown; readId?: unknown };
  if (
    !value ||
    typeof value.commandId !== "string" ||
    typeof value.readId !== "string" ||
    workbenchHostReadPermissionKeyV1(value.commandId, value.readId) !== key
  )
    throw new Error("Noncanonical Workbench read identity.");
  return { commandId: value.commandId, readId: value.readId };
}

/** Read permission cannot validate as a start command, even with the same original job. */
export function workbenchHostReadDigestV1(
  job: { readonly runId: string; readonly workspaceId: string; readonly command: unknown },
  key: string,
): AuthorityDigestV2 {
  const identity = parseWorkbenchHostReadPermissionKeyV1(key);
  const command = job.command as { commandId?: unknown } | null;
  if (!command || command.commandId !== identity.commandId)
    throw new Error("Workbench read receipt mismatch.");
  return canonicalAuthorityDigestV2("kombify.workbench-host-read.digest.v1", {
    runId: job.runId,
    workspaceId: job.workspaceId,
    commandId: identity.commandId,
    commandDigest: workbenchHostCommandDigestV1(job),
    readId: identity.readId,
  });
}

export function workbenchHostThreadIdV1(identity: {
  readonly subject: string;
  readonly tenantId: string;
  readonly agentInstanceId: string;
  readonly runId: string;
}): string {
  if (Object.values(identity).some((value) => !nonempty(value)))
    throw new Error("Invalid Workbench thread identity.");
  return `agent-job:${canonicalAuthorityDigestV2("kombify.workbench-host-thread.digest.v1", identity).slice(7)}`;
}

/** Offline immutable matching only. Current authority and signature checks remain with Gateway/host. */
export function validateWorkbenchHostLeaseV1(
  value: unknown,
  expected: {
    readonly bindings: WorkbenchHostResourceBindingsV1;
    readonly runId: string;
    readonly commandId: string;
    readonly command: unknown;
    readonly audience: string;
    readonly now: number;
  },
): CapabilityLeaseV2 {
  const lease = parseCapabilityLeaseV2(value);
  const resources = lease.binding.resources.filter(
    (resource) => resource.definitionId === WORKBENCH_HOST_CAPABILITY_ID,
  );
  const resource = resources[0];
  if (
    lease.binding.resources.length !== 1 ||
    resources.length !== 1 ||
    !resource ||
    canonicalAuthorityJsonV2(parseWorkbenchHostResourceV1(resource)) !==
      canonicalAuthorityJsonV2(expected.bindings) ||
    lease.binding.definitionIds.length !== 1 ||
    lease.binding.definitionIds[0] !== WORKBENCH_HOST_CAPABILITY_ID
  )
    throw new Error("Workbench lease resource mismatch.");
  if (
    expected.bindings.callGpt !== undefined &&
    canonicalAuthorityJsonV2(callGptWorkbenchBindingFromCommandV1(expected.command)) !==
      canonicalAuthorityJsonV2(callGptWorkbenchBindingFromResourceV1(expected.bindings))
  )
    throw new Error("Personal Codex command exceeds the selected equipment resource.");
  const intent = lease.binding.intent;
  if (
    lease.binding.requestedShape !== "short-ttl" ||
    lease.binding.authorityBasis.facet !== "use" ||
    lease.binding.requester.id !== lease.binding.target.agentInstanceId ||
    lease.binding.requester.agentClass !== lease.binding.target.agentClass ||
    lease.binding.requester.templateDigest !== lease.binding.target.templateDigest ||
    intent.intentId !== expected.runId ||
    intent.idempotencyKey !== expected.commandId ||
    intent.action !== WORKBENCH_HOST_DISPATCH_ACTION ||
    intent.intentDigest !==
      workbenchHostCommandDigestV1({
        runId: expected.runId,
        workspaceId: expected.bindings.workspaceId,
        command: expected.command,
      }) ||
    lease.binding.audience !== expected.audience
  )
    throw new Error("Workbench lease dispatch mismatch.");
  if (
    !Number.isFinite(expected.now) ||
    lease.status !== "active" ||
    !Number.isFinite(Date.parse(lease.issuedAt)) ||
    !Number.isFinite(Date.parse(lease.expiresAt)) ||
    !Number.isFinite(Date.parse(lease.binding.expiresAt)) ||
    Date.parse(lease.issuedAt) > expected.now ||
    Date.parse(lease.expiresAt) <= expected.now ||
    Date.parse(lease.binding.expiresAt) <= expected.now
  )
    throw new Error("Workbench lease is inactive.");
  return lease;
}
