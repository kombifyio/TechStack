export type AuthorityDigestV2 = `sha256:${string}`;
export type AuthorityFacetV2 =
  | "use"
  | "self_activate"
  | "issue"
  | "delegate"
  | "approve"
  | "revoke";

export interface AuthorityUserActorV2 {
  readonly kind: "user";
  readonly id: string;
}

export interface AuthorityServiceActorV2 {
  readonly kind: "service";
  readonly id: string;
}

export interface AuthorityAgentActorV2 {
  readonly kind: "agent";
  /** Exact authenticated agent instance id. */
  readonly id: string;
  readonly agentClass: string;
  readonly templateDigest: AuthorityDigestV2;
}

export type AuthorityActorV2 =
  | AuthorityUserActorV2
  | AuthorityAgentActorV2
  | AuthorityServiceActorV2;

export interface AuthorityBasisV2 {
  readonly grantId: string;
  readonly generation: number;
  readonly facet: AuthorityFacetV2;
  readonly grantDigest: AuthorityDigestV2;
}

export interface AuthorityChainLinkV2 {
  readonly basis: AuthorityBasisV2;
  readonly issuer: AuthorityActorV2;
  readonly grantee: AuthorityAgentActorV2;
  readonly issuedAt: string;
}

export interface LegacyAuthorityResourceV2 {
  readonly definitionId: string;
  readonly resource: string;
  readonly bindings: Readonly<Record<string, string>>;
}

export type WalletActionV1 =
  | "capture"
  | "rotate"
  | "brokered_use"
  | "delete"
  | "restore"
  | "reveal"
  | "export"
  | "process_injection"
  | "disconnect";
export type WalletDisclosureActionV1 = "reveal" | "export" | "process_injection";
export interface WalletIdentityV1 {
  readonly owner: string;
  readonly custodyNamespace: string;
  readonly itemId: string;
  readonly resourceType:
    | "generic_secret"
    | "oauth_connection"
    | "node_access_profile"
    | "ai_credential"
    | "device_key";
  readonly version: string;
}
export type WalletScopeV1 =
  | { readonly kind: "account" }
  | {
      readonly kind: "project_environment";
      readonly projectId: string;
      readonly environment: string;
    };
export type WalletCustodianV1 =
  | { readonly kind: "wallet_store"; readonly serviceId: string }
  | {
      readonly kind: "auth0_token_vault";
      readonly connectionId: string;
      readonly provider: string;
      readonly accountRef: string;
    }
  | { readonly kind: "product"; readonly serviceId: string; readonly custodyRef: string }
  | {
      readonly kind: "device";
      readonly installationId: string;
      readonly installationGeneration: number;
    };
export type WalletProtectionV1 =
  | { readonly kind: "service_managed" | "user_unlocked" | "product_native" | "non_exportable" }
  | { readonly kind: "custodian_managed"; readonly ownerPresence: "required" | "not_required" };
export type WalletDisclosureV1 =
  | { readonly kind: "use_only" }
  | { readonly kind: "owner_authorized"; readonly actions: readonly WalletDisclosureActionV1[] };
export interface WalletResourceV1 extends LegacyAuthorityResourceV2 {
  readonly schemaVersion: "kombify.wallet-resource.v1";
  readonly identity: WalletIdentityV1;
  readonly scope: WalletScopeV1;
  readonly custodian: WalletCustodianV1;
  readonly protection: WalletProtectionV1;
  readonly disclosure: WalletDisclosureV1;
  readonly supportedActions: readonly WalletActionV1[];
  readonly classification: "synthetic" | "real";
  readonly lifecycle: "pending" | "active" | "revoked" | "deleted" | "compromised";
  readonly metadataRevision: number;
}
export type WalletIdentityV2 = Omit<WalletIdentityV1, "version">;
export type WalletReferenceV1 = {
  readonly schemaVersion: "kombify.wallet-reference.v1";
  readonly kind: "secret" | "vault_ref";
  readonly vaultRef: string;
};
export type WalletVersionConstraintV1 =
  | { readonly kind: "item" }
  | { readonly kind: "exact"; readonly version: string };
export interface WalletResourceV2 extends Omit<
  WalletResourceV1,
  "schemaVersion" | "identity" | "lifecycle" | "metadataRevision"
> {
  readonly schemaVersion: "kombify.wallet-resource.v2";
  readonly identity: WalletIdentityV2;
  readonly reference: WalletReferenceV1;
  readonly versionConstraint: WalletVersionConstraintV1;
}
/** Wallet actions by right class: use, read, manage. See walletActionProfilesV3 in Core. */
export type WalletActionV3 =
  | "brokered_use"
  | "process_injection"
  | "mint_child_credential"
  | "sign"
  | "host_delivery"
  | "reveal"
  | "export"
  | "capture"
  | "rotate"
  | "delete"
  | "restore"
  | "revoke"
  | "configure"
  | "disconnect";
/** Using an item and reading its value are separate rights. */
export type WalletRightV3 = "use" | "read" | "manage";
export type WalletValueReleaseV3 = "brokered" | "disclosed" | "none";
export type WalletResourceTypeV3 =
  | "generic_secret"
  | "login"
  | "variable"
  | "configuration"
  | "oauth_connection"
  | "node_access_profile"
  | "parent_credential"
  | "ssh_ca"
  | "ai_credential"
  | "device_key";
export interface WalletActionProfileV3 {
  readonly right: WalletRightV3;
  readonly valueRelease: WalletValueReleaseV3;
  /** The operation carries a finalized compact JWE transfer binding. */
  readonly transfer: boolean;
}
export interface WalletItemTypeProfileV3 {
  readonly custodians: readonly WalletCustodianV1["kind"][];
  readonly actions: readonly WalletActionV3[];
}
export interface WalletIdentityV3 extends Omit<WalletIdentityV2, "resourceType"> {
  readonly resourceType: WalletResourceTypeV3;
}
export type WalletScopeV3 =
  | WalletScopeV1
  | { readonly kind: "project"; readonly projectId: string };
/** Replaces the fixed disclosure rule of v1 and v2. */
export interface WalletItemPolicyV3 {
  /** read_right_holders: a holder of the read right may receive the value. use_only: nobody does. */
  readonly valueAccess: "read_right_holders" | "use_only";
  /** Absent means none; absence and none are different spellings and are never normalized. */
  readonly ownerProof?: "none" | "fresh_owner_proof";
}
export interface WalletResourceV3 extends Omit<
  WalletResourceV2,
  "schemaVersion" | "identity" | "scope" | "disclosure" | "supportedActions"
> {
  readonly schemaVersion: "kombify.wallet-resource.v3";
  readonly identity: WalletIdentityV3;
  readonly scope: WalletScopeV3;
  readonly policy: WalletItemPolicyV3;
  readonly supportedActions: readonly WalletActionV3[];
  /** Grant-specific attenuation, a subset of the registered item's rights. */
  readonly rights: readonly WalletRightV3[];
}

export type AuthorityResourceV2 =
  | LegacyAuthorityResourceV2
  | WalletResourceV1
  | WalletResourceV2
  | WalletResourceV3;
export interface WalletRecipientV1 {
  readonly keyId: string;
  readonly keyGeneration: string;
  /** RFC 7638 SHA-256 JWK thumbprint, unpadded base64url, never a Core hex digest. */
  readonly recipientKeyThumbprint: string;
}
export type WalletExecutionContextV1 =
  | { readonly kind: "owner_client"; readonly clientSessionId: string }
  | { readonly kind: "agent_run"; readonly agentInstanceId: string; readonly runId: string }
  | {
      readonly kind: "owner_process";
      readonly workSessionId: string;
      readonly threadId: string;
      readonly projectId: string;
      readonly environment: string;
      readonly runtimeSessionId: string;
      readonly installationId: string;
      readonly installationGeneration: number;
      readonly providerSessionId: string;
    };
export interface WalletTransferBindingV1 {
  readonly schemaVersion: "kombify.wallet-transfer-binding.v1";
  /** SHA-256 of exact finalized compact JWE UTF-8 bytes. */
  readonly ciphertextDigest: AuthorityDigestV2;
  readonly serialization: "compact_jwe_utf8";
}
export interface WalletOperationBindingV1 {
  readonly operationId: string;
  readonly resource: WalletResourceV1;
  readonly executionTenantId: string;
  readonly subject: string;
  readonly actor: AuthorityActorV2;
  readonly authenticationProfile: "owner_interactive" | "delegated_user";
  readonly audience: string;
  readonly executor: { readonly id: string; readonly recipient: WalletRecipientV1 };
  readonly target: { readonly id: string; readonly revision: string };
  readonly argumentsDigest: AuthorityDigestV2;
  readonly transfer?: WalletTransferBindingV1;
  readonly context: WalletExecutionContextV1;
  readonly nonce: string;
  readonly expiresAt: string;
}

export interface CapabilityBudgetV2 {
  readonly tokens?: number;
  readonly maxActiveLeases?: number;
  readonly maxEquippedDefinitions?: number;
}

export interface AuthorityEnvelopeV2 {
  readonly definitionIds: readonly string[];
  readonly resources: readonly AuthorityResourceV2[];
  readonly shapes: readonly ("durable" | "short-ttl" | "one-shot")[];
  readonly maxTtlSeconds: number;
  readonly budget: CapabilityBudgetV2;
  readonly delegatedFacets?: readonly AuthorityFacetV2[];
  readonly maxDelegationDepth?: number;
  readonly maxChildren?: number;
}

export interface AgentAuthorityGrantBindingV2 {
  readonly schemaVersion: "kombify.agent-authority-binding.v2";
  readonly grantId: string;
  readonly generation: number;
  readonly tenantId: string;
  readonly subject: string;
  readonly grantee: AuthorityAgentActorV2;
  readonly facet: AuthorityFacetV2;
  readonly envelope: AuthorityEnvelopeV2;
  readonly issuer: AuthorityActorV2;
  readonly parentBasis?: AuthorityBasisV2;
  readonly policyRevision: AuthorityDigestV2;
  readonly issuedAt: string;
  readonly expiresAt?: string;
}

export interface AgentAuthorityGrantV2 {
  readonly schemaVersion: "kombify.agent-authority-grant.v2";
  readonly binding: AgentAuthorityGrantBindingV2;
  readonly grantDigest: AuthorityDigestV2;
  readonly status: "pending" | "active" | "revoking" | "revoked";
  readonly revokedAt?: string;
}

export interface ActivationPolicyV2 {
  readonly schemaVersion: "kombify.activation-policy.v2";
  readonly revision: AuthorityDigestV2;
  readonly mode: "agent";
}

export interface LegacyActivationIntentV2 {
  readonly intentId: string;
  readonly action: string;
  readonly intentDigest: AuthorityDigestV2;
  readonly idempotencyKey: string;
}
export interface WalletOperationIntentV1 extends LegacyActivationIntentV2 {
  readonly schemaVersion: "kombify.wallet-operation-intent.v1";
  readonly action: WalletActionV1;
  readonly operation: WalletOperationBindingV1;
}

export interface WalletOwnerApprovalProtectedHeaderV1 {
  readonly alg: "RS256";
  readonly typ: "kombify.wallet-owner-approval.v1+jwt";
  readonly kid: string;
}

/** Human intent proof only; never an agent grant, decision, or admission. */
export interface WalletOwnerApprovalReceiptV1 {
  readonly schemaVersion: "kombify.wallet-owner-approval-receipt.v1";
  readonly iss: "urn:kombify:wallet:owner-approval:cloud";
  readonly aud: "urn:kombify:wallet-store:owner-approval";
  readonly jti: string;
  readonly keyGeneration: string;
  readonly iat: number;
  readonly exp: number;
  readonly ownerPin: {
    readonly accountId: string;
    readonly issuer: string;
    readonly subject: string;
    readonly custodyNamespace: string;
  };
  readonly approval: {
    readonly id: string;
    readonly revision: number;
    readonly createdAt: string;
    readonly decidedAt: string;
  };
  readonly authentication: {
    readonly profile: "owner_interactive";
    readonly mfa: true;
    readonly authTime: number;
  };
  readonly audit: {
    readonly eventId: string;
    readonly eventDigest: AuthorityDigestV2;
    readonly confirmedAt: string;
  };
  readonly intent: WalletOperationIntentV1 & {
    readonly operation: WalletOperationBindingV1 & {
      readonly actor: AuthorityUserActorV2;
      readonly authenticationProfile: "owner_interactive";
      readonly context: Exclude<WalletExecutionContextV1, { readonly kind: "agent_run" }>;
    };
  };
}

/** Independently authenticated retained facts, never caller-supplied proof. */
export interface WalletOwnerApprovalTrustedFactsV1 {
  readonly protectedHeader: WalletOwnerApprovalProtectedHeaderV1;
  readonly signingKey: { readonly kid: string; readonly keyGeneration: string };
  readonly ownerPin: WalletOwnerApprovalReceiptV1["ownerPin"];
  readonly approval: WalletOwnerApprovalReceiptV1["approval"] & {
    readonly state: "approved";
    readonly intentDigest: AuthorityDigestV2;
  };
  readonly authentication: WalletOwnerApprovalReceiptV1["authentication"];
  readonly audit: WalletOwnerApprovalReceiptV1["audit"];
  readonly now: string;
}
export interface WalletOperationBindingV2 extends Omit<
  WalletOperationBindingV1,
  "resource" | "audience" | "executor"
> {
  readonly resource: WalletResourceV2;
  readonly admissionAudience: string;
  readonly executor: WalletOperationBindingV1["executor"] & { readonly audience: string };
  readonly version: string;
  readonly versionRef: string;
  readonly lifecycle: WalletResourceV1["lifecycle"];
  readonly metadataRevision: number;
}
export interface WalletOperationIntentV2 extends LegacyActivationIntentV2 {
  readonly schemaVersion: "kombify.wallet-operation-intent.v2";
  readonly action: WalletActionV1;
  readonly operation: WalletOperationBindingV2;
}
/** v3 adds the product_service context: a kombify product backend acting on the owner's standing assignment. */
export type WalletExecutionContextV3 =
  | WalletExecutionContextV1
  | {
      readonly kind: "product_service";
      readonly serviceId: string;
      readonly recipientGeneration: string;
    };
export interface WalletOperationBindingV3 extends Omit<
  WalletOperationBindingV2,
  "resource" | "context" | "authenticationProfile"
> {
  readonly resource: WalletResourceV3;
  readonly authenticationProfile: "owner_interactive" | "delegated_user" | "service_standing";
  readonly context: WalletExecutionContextV3;
}
export interface WalletOperationIntentV3 extends LegacyActivationIntentV2 {
  readonly schemaVersion: "kombify.wallet-operation-intent.v3";
  readonly action: WalletActionV3;
  readonly operation: WalletOperationBindingV3;
}
export type ActivationIntentV2 =
  | LegacyActivationIntentV2
  | WalletOperationIntentV1
  | WalletOperationIntentV2
  | WalletOperationIntentV3;

/**
 * Human intent proof for a v3 item with ownerProof fresh_owner_proof: the v1 receipt
 * rules over the full v3 intent. It binds owner contexts only.
 */
export interface WalletOwnerApprovalReceiptV2 extends Omit<
  WalletOwnerApprovalReceiptV1,
  "schemaVersion" | "intent"
> {
  readonly schemaVersion: "kombify.wallet-owner-approval-receipt.v2";
  readonly intent: WalletOperationIntentV3 & {
    readonly operation: WalletOperationBindingV3 & {
      readonly actor: AuthorityUserActorV2;
      readonly authenticationProfile: "owner_interactive";
      readonly context: Exclude<WalletExecutionContextV1, { readonly kind: "agent_run" }>;
    };
  };
}

export interface MonetaryReservationReferenceV2 {
  readonly allocationId: string;
  readonly reservationId: string;
  /** Commerce's immutable request_digest, encoded as sha256:<lowerhex>. */
  readonly reservationDigest: AuthorityDigestV2;
  readonly intentDigest: AuthorityDigestV2;
  readonly currency: string;
  readonly maximumMinor: string;
  readonly merchantRef: string;
  readonly purposeRef: string;
  readonly expiresAt: string;
}

export interface ActivationTargetV2 {
  readonly agentInstanceId: string;
  readonly agentClass: string;
  readonly templateDigest: AuthorityDigestV2;
}

export interface AgentActivationRequestBindingV2 {
  readonly ownerEquipment?: never;
  readonly schemaVersion: "kombify.activation-request-binding.v2";
  readonly tenantId: string;
  readonly subject: string;
  readonly requester: AuthorityAgentActorV2;
  readonly target: ActivationTargetV2;
  readonly definitionIds: readonly string[];
  readonly resources: readonly AuthorityResourceV2[];
  readonly requestedShape: "durable" | "short-ttl" | "one-shot";
  readonly officeScope?: string;
  /** Activation lineage only; never standing authority. */
  readonly parentLeaseId?: string;
  /** Optional attenuation to the current revision of an existing Paperwork task. */
  readonly taskRef?: {
    readonly schemaVersion: "kombify.task-ref.v1";
    readonly owner: "paperwork";
    readonly id: string;
    readonly revision: string;
  };
  readonly authorityBasis: AuthorityBasisV2 & { readonly facet: "use" | "self_activate" };
  readonly policy: ActivationPolicyV2;
  readonly budget: CapabilityBudgetV2;
  readonly catalogRevision: string;
  readonly audience: string;
  readonly intent: ActivationIntentV2;
  readonly monetaryReservation?: MonetaryReservationReferenceV2;
  readonly expiresAt: string;
}

export interface OwnerEquipmentV1 {
  readonly schemaVersion: "kombify.owner-equipment.v1";
  readonly sourceKind: "harness";
  readonly targetRevision: string;
  readonly targetSpecDigest: AuthorityDigestV2;
  readonly profileRevision: string;
  readonly resourceRevision: string;
}
export interface OwnerEquipmentPolicyV2 {
  readonly schemaVersion: "kombify.activation-policy.v2";
  readonly revision: AuthorityDigestV2;
  readonly mode: "owner_equipment";
}
export type OwnerEquipmentActorV2 = AuthorityUserActorV2 & {
  readonly agentClass?: never;
  readonly templateDigest?: never;
};
export type OwnerEquipmentRequestBindingV2 = Omit<
  AgentActivationRequestBindingV2,
  | "ownerEquipment"
  | "requester"
  | "policy"
  | "requestedShape"
  | "officeScope"
  | "parentLeaseId"
  | "taskRef"
  | "monetaryReservation"
  | "authorityBasis"
  | "intent"
> & {
  readonly ownerEquipment: OwnerEquipmentV1;
  readonly requester: OwnerEquipmentActorV2;
  readonly policy: OwnerEquipmentPolicyV2;
  readonly requestedShape: "durable";
  readonly officeScope?: never;
  readonly parentLeaseId?: never;
  readonly taskRef?: never;
  readonly monetaryReservation?: never;
  readonly authorityBasis: AuthorityBasisV2 & { readonly facet: "use" };
  readonly intent: LegacyActivationIntentV2 & { readonly action: "capability.equip" };
};
export type ActivationRequestBindingV2 =
  | AgentActivationRequestBindingV2
  | OwnerEquipmentRequestBindingV2;

export interface ActivationRequestV2 {
  readonly schemaVersion: "kombify.activation-request.v2";
  readonly id: string;
  readonly binding: ActivationRequestBindingV2;
  readonly requestDigest: AuthorityDigestV2;
  readonly state: "pending" | "approved" | "denied" | "expired" | "withdrawn";
  readonly createdAt: string;
  readonly decisionId?: string;
  readonly decisionDigest?: AuthorityDigestV2;
  readonly leaseId?: string;
}

export interface AgentActivationDecisionBindingV2 {
  readonly ownerEquipment?: never;
  readonly schemaVersion: "kombify.activation-decision-binding.v2";
  readonly requestId: string;
  readonly requestDigest: AuthorityDigestV2;
  readonly tenantId: string;
  readonly subject: string;
  readonly actor: AuthorityAgentActorV2;
  readonly kind: "agent" | "self_activate";
  readonly verdict: "approved" | "denied";
  readonly policy: ActivationPolicyV2;
  readonly authorityBasis: AuthorityBasisV2 & {
    readonly facet: "approve" | "self_activate" | "use";
  };
  readonly authorityChain: readonly AuthorityChainLinkV2[];
  readonly decidedAt: string;
  readonly intent: ActivationIntentV2;
  readonly monetaryReservation?: MonetaryReservationReferenceV2;
}

export type OwnerEquipmentDecisionBindingV2 = Omit<
  AgentActivationDecisionBindingV2,
  | "ownerEquipment"
  | "actor"
  | "kind"
  | "verdict"
  | "policy"
  | "authorityBasis"
  | "intent"
  | "monetaryReservation"
> & {
  readonly ownerEquipment: OwnerEquipmentV1;
  readonly actor: OwnerEquipmentActorV2;
  readonly kind: "owner_equip";
  readonly verdict: "approved";
  readonly policy: OwnerEquipmentPolicyV2;
  readonly authorityBasis: AuthorityBasisV2 & { readonly facet: "use" };
  readonly intent: LegacyActivationIntentV2 & { readonly action: "capability.equip" };
  readonly monetaryReservation?: never;
};
export type ActivationDecisionBindingV2 =
  | AgentActivationDecisionBindingV2
  | OwnerEquipmentDecisionBindingV2;

export interface ActivationDecisionV2 {
  readonly schemaVersion: "kombify.activation-decision.v2";
  readonly id: string;
  readonly binding: ActivationDecisionBindingV2;
  readonly decisionDigest: AuthorityDigestV2;
}

export interface CapabilityLeaseV2 {
  readonly schemaVersion: "kombify.capability-lease.v2";
  readonly id: string;
  readonly activationRequestId: string;
  readonly binding: ActivationRequestBindingV2;
  readonly requestDigest: AuthorityDigestV2;
  readonly decisionId: string;
  readonly decisionDigest: AuthorityDigestV2;
  readonly epoch: number;
  readonly status: "active" | "expired" | "revoked" | "consumed";
  readonly issuedAt: string;
  readonly expiresAt: string;
  readonly revokedAt?: string;
  readonly consumedAt?: string;
}

export interface AgentRoleEquipmentEntryV2 {
  readonly productId: string;
  readonly definitionIds: readonly string[];
  readonly resourceBinding?: { readonly dimension: string; readonly value: string };
}

export interface AgentRoleTemplateV2 {
  readonly schemaVersion: "kombify.agent-role-template.v2";
  readonly id: string;
  readonly version: string;
  readonly digest: AuthorityDigestV2;
  readonly lifecycle: "draft" | "preview" | "active" | "revoked";
  readonly trustClass: "catalog-verified" | "broker-listed" | "user-attached";
  readonly publisher: { readonly name: string; readonly firstParty: boolean };
  readonly factoryId: string;
  readonly officeDefinitionIds: readonly string[];
  readonly agentType: "permanent" | "expert" | "ad-hoc";
  readonly label: string;
  readonly description: string;
  readonly baseAgentId: string;
  readonly defaults: readonly AgentRoleEquipmentEntryV2[];
  readonly budget: CapabilityBudgetV2;
  readonly durableTtlSeconds: number;
  readonly maxTtlSeconds?: number;
  readonly knowledgeTier: "KT0" | "KT1" | "KT2" | "KT3";
  readonly spawnDepth: number;
  readonly maxChildren: number;
  readonly executionClass:
    | "kombify-generic-host"
    | "remote-environment"
    | "external-harness"
    | "execution-node";
  readonly authorityDefaults: Readonly<{
    use: readonly string[];
    selfActivate: readonly string[];
    issue: readonly string[];
    delegate: readonly string[];
    approve: readonly string[];
    revoke: readonly string[];
  }>;
}

/** Authored template content bound by the v2 digest; registry state is server-owned. */
export type AgentRoleTemplateAuthoredV2 = Omit<
  AgentRoleTemplateV2,
  "digest" | "lifecycle" | "trustClass"
>;

export type AuthorityDocumentV2 =
  | AgentAuthorityGrantV2
  | ActivationRequestV2
  | ActivationDecisionV2
  | CapabilityLeaseV2
  | AgentRoleTemplateV2;

export type AuthorityDocumentSchemaVersionV2 = AuthorityDocumentV2["schemaVersion"];

/** Protected header of the Gateway-signed Wallet lease; the verifier selects the key by kid. */
export interface WalletLeaseHeaderV1 {
  readonly alg: "ES256";
  readonly typ: "kombify.wallet-lease.v1";
  readonly kid: string;
}
/** One Wallet item operation. brokered_use is authorized only by a broker detail. */
export interface WalletLeaseItemDetailV1 {
  readonly type: "kombify_wallet_item";
  readonly custodyNamespace: string;
  readonly itemId: string;
  /** Absent: the item's current version at execution time, recorded in the audit event. */
  readonly version?: string;
  readonly action: Exclude<WalletActionV3, "brokered_use">;
  /** Key id of the enrolled recipient the result is sealed to. */
  readonly recipientRef: string;
  readonly recipientGeneration: string;
}
/** A brokered call on an exact host, method and whole-segment path prefix. */
export interface WalletLeaseBrokerDetailV1 {
  readonly type: "kombify_wallet_broker";
  readonly itemId: string;
  readonly host: string;
  readonly method: "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "DELETE";
  readonly pathPrefix: string;
}
/** An operation on a whole custody namespace. It never names an item and never releases a stored value. */
export interface WalletLeasePartitionDetailV1 {
  readonly type: "kombify_wallet_partition";
  readonly custodyNamespace: string;
  readonly operation: "list_items" | "capture_key" | "resolve_variables";
  /** Key id of the enrolled recipient the result is sealed to. */
  readonly recipientRef: string;
  readonly recipientGeneration: string;
}
export type WalletLeaseDetailV1 =
  | WalletLeaseItemDetailV1
  | WalletLeaseBrokerDetailV1
  | WalletLeasePartitionDetailV1;
export interface WalletLeaseClaimsV1 {
  readonly iss: "urn:kombify:wallet:lease:gateway";
  /** The Wallet owner. */
  readonly sub: string;
  /** The acting party: the agent instance id, or the owner's subject for a person. */
  readonly act: { readonly sub: string };
  /** The private executor audience. */
  readonly aud: string;
  readonly authorization_details: readonly WalletLeaseDetailV1[];
  readonly jti: string;
  readonly iat: number;
  /** After iat and at most 300 seconds later. */
  readonly exp: number;
  readonly grantGeneration: number;
  readonly taskRef?: NonNullable<ActivationRequestV2["binding"]["taskRef"]>;
  readonly projectRef?: { readonly id: string };
}
/** Decoded form of the compact JWS; carrying it grants nothing. */
export interface WalletLeaseV1 {
  readonly header: WalletLeaseHeaderV1;
  readonly claims: WalletLeaseClaimsV1;
}
/** Independently authenticated facts a verifier holds; never taken from the lease. */
export interface WalletLeaseTrustedFactsV1 {
  readonly signingKey: { readonly kid: string };
  readonly now: string;
  readonly currentGrantGeneration: number;
  readonly taskRef?: WalletLeaseClaimsV1["taskRef"];
  readonly projectRef?: WalletLeaseClaimsV1["projectRef"];
  /** When present, the lease must authorize exactly this item operation. */
  readonly intent?: WalletOperationIntentV3;
  /** Alternatively, the lease must authorize exactly this namespace operation. Not with intent. */
  readonly partition?: {
    readonly owner: string;
    readonly actor: string;
    readonly custodyNamespace: string;
    readonly operation: "list_items" | "capture_key" | "resolve_variables";
    readonly recipient: { readonly keyId: string; readonly keyGeneration: string };
    readonly executorAudience: string;
  };
  /** For brokered_use: the normalized call (host, method, path without query). */
  readonly normalizedArguments?: {
    readonly host: string;
    readonly method: string;
    readonly path: string;
  };
}

/** The closed Wallet member of AuditEventV2. No value, ciphertext, key or token. */
export interface WalletCustodyAuditV2 {
  readonly custodyNamespace: string;
  readonly itemId: string;
  readonly version?: string;
  readonly action: WalletActionV3;
  readonly recipientRef?: string;
  readonly valueReleased: WalletValueReleaseV3;
  readonly leaseJti?: string;
}
/** AuditEventV1 plus the wallet member. owner is subject_key, actor is actor_key. */
export interface WalletAuditEventV2 {
  readonly event_version: 2;
  readonly event_id: string;
  readonly occurred_at: string;
  readonly event_class: "security";
  readonly actor_key: string;
  readonly tenant_key: string;
  readonly subject_key: string;
  readonly action: string;
  readonly resource: string;
  readonly outcome: "success" | "failure" | "denied" | "error" | "pending" | "unknown";
  readonly source_service: string;
  readonly operation_id: string;
  readonly retention_class: "authority";
  readonly correlation_id?: string;
  readonly trace_id?: string;
  readonly client_class?: string;
  readonly ip_token?: string;
  readonly decision_id?: string;
  readonly grant_id?: string;
  readonly lease_id?: string;
  readonly wallet: WalletCustodyAuditV2;
}
