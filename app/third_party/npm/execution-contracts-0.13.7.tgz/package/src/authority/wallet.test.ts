import { expect, it } from "vitest";
import { agentAuthorityV2Conformance } from "./contract/conformance.generated.js";
import {
  activationRequestDigestV2,
  parseActivationRequestV2,
  parseCapabilityLeaseV2,
  parseWalletOperationIntentV1,
  parseWalletOperationIntentV2,
  parseWalletOwnerApprovalReceiptV1,
  parseWalletOwnerApprovalProtectedHeaderV1,
  parseAuthorityDocumentV2,
  validateWalletOwnerApprovalBindingsV1,
  hasWalletIntentMarker,
  hasWalletResourceMarker,
  AuthorityContractError,
  sameAuthorityResourceV2,
  walletOperationIntentDigestV1,
  walletOperationIntentDigestV2,
} from "./contract.js";
import type {
  ActivationRequestV2,
  CapabilityLeaseV2,
  WalletOperationIntentV1,
  WalletResourceV1,
  WalletOperationIntentV2,
  WalletResourceV2,
  WalletOwnerApprovalReceiptV1,
  WalletOwnerApprovalTrustedFactsV1,
} from "./types.js";

const vector = agentAuthorityV2Conformance as unknown as {
  request: ActivationRequestV2;
  lease: CapabilityLeaseV2;
  wallet: { resource: WalletResourceV1; intent: WalletOperationIntentV1 };
  walletOwnerApproval: {
    receipt: WalletOwnerApprovalReceiptV1;
    trusted: WalletOwnerApprovalTrustedFactsV1;
  };
  walletV2: {
    resource: WalletResourceV2;
    intent: WalletOperationIntentV2;
    request: ActivationRequestV2;
  };
};
type Mutable<T> = { -readonly [K in keyof T]: Mutable<T[K]> };

it("preserves stable Wallet eligibility while binding each v2 operation to its exact version and audiences", () => {
  const original = vector.walletV2;
  expect(parseActivationRequestV2(original.request).requestDigest).toBe(
    original.request.requestDigest,
  );
  expect(parseWalletOperationIntentV2(original.intent).intentDigest).toBe(
    original.intent.intentDigest,
  );
  const rotated = structuredClone(original.intent) as Mutable<WalletOperationIntentV2>;
  rotated.operation.version = "2";
  rotated.operation.versionRef = `${rotated.operation.resource.resource}/versions/2`;
  rotated.operation.metadataRevision++;
  rotated.intentDigest = walletOperationIntentDigestV2(rotated);
  const parsedRotation = parseWalletOperationIntentV2(rotated);
  expect(parsedRotation.operation.version).toBe("2");
  expect(sameAuthorityResourceV2(parsedRotation.operation.resource, original.resource)).toBe(true);
  expect(parsedRotation.intentDigest).not.toBe(original.intent.intentDigest);
  for (const mutate of [
    (value: Mutable<WalletOperationIntentV2>) => {
      value.operation.resource.versionConstraint = { kind: "exact", version: "1" };
    },
    (value: Mutable<WalletOperationIntentV2>) => {
      value.operation.resource.reference.vaultRef = "other-vault";
    },
    (value: Mutable<WalletOperationIntentV2>) => {
      value.operation.versionRef += "?latest";
    },
    (value: Mutable<WalletOperationIntentV2>) => {
      value.operation.executor.audience = value.operation.admissionAudience;
    },
    (value: Mutable<WalletOperationIntentV2>) => {
      value.operation.resource.classification = "real";
    },
  ]) {
    const changed = structuredClone(rotated);
    mutate(changed);
    changed.intentDigest = walletOperationIntentDigestV2(changed);
    expect(() => parseWalletOperationIntentV2(changed)).toThrow(AuthorityContractError);
  }
  for (const version of ["kombify.wallet-resource.v2", "kombify.wallet-resource.v99"]) {
    const changed = structuredClone(original.request) as Mutable<ActivationRequestV2>;
    Object.assign(changed.binding.resources[0]!, { schemaVersion: version });
    expect(hasWalletResourceMarker(changed.binding.resources[0])).toBe(true);
    if (version.endsWith("v99"))
      expect(() => parseActivationRequestV2(changed)).toThrow(AuthorityContractError);
  }
  const unknown = { ...original.intent, schemaVersion: "kombify.wallet-operation-intent.v99" };
  expect(hasWalletIntentMarker(unknown)).toBe(true);
  expect(() => parseWalletOperationIntentV2(unknown)).toThrow(AuthorityContractError);
  expect(() => parseWalletOperationIntentV1(original.intent)).toThrow(AuthorityContractError);
  const legacy = structuredClone(original.request) as Mutable<ActivationRequestV2>;
  legacy.binding.intent = structuredClone(vector.request.binding.intent);
  legacy.requestDigest = activationRequestDigestV2(legacy.binding);
  expect(() => parseActivationRequestV2(legacy)).toThrow(AuthorityContractError);
});

it("allows a narrower v2 operation while limiting the issued lease to both signed expiries", () => {
  const request = structuredClone(vector.walletV2.request) as Mutable<ActivationRequestV2>;
  request.binding.expiresAt = "2026-10-01T12:02:00Z";
  request.requestDigest = activationRequestDigestV2(request.binding);
  expect(parseActivationRequestV2(request).binding.expiresAt).toBe(request.binding.expiresAt);
  const lease = {
    ...structuredClone(vector.lease),
    binding: request.binding,
    activationRequestId: request.id,
    requestDigest: request.requestDigest,
    issuedAt: "2026-10-01T12:00:30Z",
    expiresAt: "2026-10-01T12:01:00Z",
  };
  expect(parseCapabilityLeaseV2(lease).expiresAt).toBe(lease.expiresAt);
  expect(() => parseCapabilityLeaseV2({ ...lease, expiresAt: "2026-10-01T12:01:01Z" })).toThrow(
    AuthorityContractError,
  );
  expect(() => parseCapabilityLeaseV2({ ...lease, issuedAt: lease.expiresAt })).toThrow(
    AuthorityContractError,
  );
  expect(() =>
    parseCapabilityLeaseV2({ ...lease, expiresAt: "2026-10-01T12:01:00.000000001Z" }),
  ).toThrow(AuthorityContractError);
  expect(() =>
    parseCapabilityLeaseV2({ ...lease, expiresAt: "2026-10-01T12:01:00.0000000000Z" }),
  ).toThrow(AuthorityContractError);
  const intent = request.binding.intent as Mutable<WalletOperationIntentV2>;
  request.binding.expiresAt = "2026-10-01T14:01:00.000000001+02:00";
  expect(
    parseActivationRequestV2({
      ...request,
      requestDigest: activationRequestDigestV2(request.binding),
    }).binding.expiresAt,
  ).toBe(request.binding.expiresAt);
  request.binding.expiresAt = "2026-10-01T12:01:00.000000000Z";
  intent.operation.expiresAt = "2026-10-01T12:01:00.000000001Z";
  intent.intentDigest = walletOperationIntentDigestV2(intent);
  request.requestDigest = activationRequestDigestV2(request.binding);
  expect(() => parseActivationRequestV2(request)).toThrow(AuthorityContractError);
  intent.operation.expiresAt = "2026-10-01T12:03:00Z";
  intent.intentDigest = walletOperationIntentDigestV2(intent);
  request.requestDigest = activationRequestDigestV2(request.binding);
  expect(() => parseActivationRequestV2(request)).toThrow(AuthorityContractError);
});
function walletRequest(): Mutable<ActivationRequestV2> {
  const request = structuredClone(vector.request) as Mutable<ActivationRequestV2>;
  if (request.binding.ownerEquipment || request.binding.requester.kind !== "agent")
    throw new Error("fixture requires agent request");
  const intent = structuredClone(vector.wallet.intent) as Mutable<WalletOperationIntentV1>;
  request.binding.resources = [structuredClone(intent.operation.resource)];
  request.binding.definitionIds = [intent.operation.resource.definitionId];
  request.binding.subject = intent.operation.subject;
  request.binding.tenantId = intent.operation.executionTenantId;
  if (intent.operation.actor.kind !== "agent") throw new Error("fixture requires agent actor");
  request.binding.requester = intent.operation.actor;
  request.binding.target = {
    agentInstanceId: request.binding.requester.id,
    agentClass: request.binding.requester.agentClass,
    templateDigest: request.binding.requester.templateDigest,
  };
  request.binding.audience = intent.operation.audience;
  request.binding.expiresAt = intent.operation.expiresAt;
  request.binding.intent = intent;
  request.requestDigest = activationRequestDigestV2(request.binding);
  return request;
}

it("binds Wallet intent to the exact owner, actor, tenant and full policy projection", () => {
  expect(parseWalletOperationIntentV1(vector.wallet.intent).intentDigest).toBe(
    vector.wallet.intent.intentDigest,
  );
  const valid = walletRequest();
  expect(() => parseActivationRequestV2(valid)).not.toThrow();
  const mutations: ((
    value: Mutable<ActivationRequestV2>,
    intent: Mutable<WalletOperationIntentV1>,
  ) => void)[] = [
    (r) => {
      r.binding.resources.push(structuredClone(vector.request.binding.resources[0]!));
    },
    (r) => {
      r.binding.intent = structuredClone(vector.request.binding.intent);
    },
    (r) => {
      const resource = r.binding.resources[0] as Mutable<WalletResourceV1>;
      resource.metadataRevision += 1;
    },
    (_, i) => {
      i.operation.subject = "auth0|foreign";
    },
    (r) => {
      r.binding.tenantId = "foreign-tenant";
    },
    (_, i) => {
      if (i.operation.context.kind === "agent_run")
        i.operation.context.agentInstanceId = "foreign-agent";
    },
    (_, i) => {
      i.operation.resource.supportedActions = ["delete"];
    },
    (_, i) => {
      i.operation.executor.recipient.recipientKeyThumbprint = `sha256:${"0".repeat(64)}`;
    },
    (_, i) => {
      i.operation.context = {
        kind: "agent_run",
        agentInstanceId: i.operation.actor.id,
        runId: "another-run",
      };
    },
  ];
  for (const [index, mutate] of mutations.entries()) {
    const changed = walletRequest();
    const intent = changed.binding.intent as Mutable<WalletOperationIntentV1>;
    mutate(changed, intent);
    // Re-sign the containing document: nested digest and semantic checks must
    // still detect substitution, even when a caller controls its outer digest.
    if (index !== mutations.length - 1 && changed.binding.intent === intent)
      intent.intentDigest = walletOperationIntentDigestV1(intent);
    changed.requestDigest = activationRequestDigestV2(changed.binding);
    expect(() => parseActivationRequestV2(changed), `wallet substitution ${index}`).toThrow();
  }
  const changed = structuredClone(vector.wallet.resource) as Mutable<WalletResourceV1>;
  changed.classification = "real";
  expect(sameAuthorityResourceV2(vector.wallet.resource, changed)).toBe(false);
});

it("binds human owner proof to retained facts without entering agent-only v2 approval", () => {
  const { receipt, trusted } = vector.walletOwnerApproval;
  expect(parseWalletOwnerApprovalReceiptV1(receipt)).toEqual(receipt);
  expect(parseWalletOwnerApprovalProtectedHeaderV1(trusted.protectedHeader)).toEqual(
    trusted.protectedHeader,
  );
  expect(validateWalletOwnerApprovalBindingsV1(receipt, trusted)).toEqual([]);
  expect(() => parseAuthorityDocumentV2(receipt)).toThrow(AuthorityContractError);
  for (const header of [
    { ...trusted.protectedHeader, alg: "HS256" },
    { ...trusted.protectedHeader, jku: "https://caller.example/keys" },
    { ...trusted.protectedHeader, typ: "JWT" },
  ])
    expect(() => parseWalletOwnerApprovalProtectedHeaderV1(header)).toThrow(AuthorityContractError);
  for (const mutate of [
    (r: Mutable<WalletOwnerApprovalReceiptV1>) => {
      r.exp = r.iat;
    },
    (r: Mutable<WalletOwnerApprovalReceiptV1>) => {
      r.exp = r.iat + 61;
      r.intent.operation.expiresAt = "2026-10-01T12:02:00Z";
      r.intent.intentDigest = walletOperationIntentDigestV1(r.intent);
    },
    (r: Mutable<WalletOwnerApprovalReceiptV1>) => {
      r.exp = r.iat + 56;
    },
    (r: Mutable<WalletOwnerApprovalReceiptV1>) => {
      r.ownerPin.custodyNamespace += ":other";
    },
    (r: Mutable<WalletOwnerApprovalReceiptV1>) => {
      r.authentication.authTime = 1790856000;
    },
    (r: Mutable<WalletOwnerApprovalReceiptV1>) => {
      r.approval.decidedAt = "2026-10-01T12:00:05.500000002Z";
    },
    (r: Mutable<WalletOwnerApprovalReceiptV1>) => {
      r.audit.confirmedAt = "2026-10-01T12:00:06Z";
    },
    (r: Mutable<WalletOwnerApprovalReceiptV1>) => {
      r.intent.operation.transfer!.ciphertextDigest = `sha256:${"0".repeat(64)}`;
    },
  ]) {
    const changed = structuredClone(receipt) as Mutable<WalletOwnerApprovalReceiptV1>;
    mutate(changed);
    expect(() => parseWalletOwnerApprovalReceiptV1(changed)).toThrow(AuthorityContractError);
  }
  const rollover = { ...receipt, iat: receipt.iat + 1 };
  expect(parseWalletOwnerApprovalReceiptV1(rollover).iat).toBe(rollover.iat);
  expect(
    validateWalletOwnerApprovalBindingsV1(rollover, {
      ...trusted,
      now: "2026-10-01T14:00:06+02:00",
    }),
  ).toEqual([]);
  const changedIntent = structuredClone(receipt) as Mutable<WalletOwnerApprovalReceiptV1>;
  changedIntent.intent.operation.transfer!.ciphertextDigest = `sha256:${"0".repeat(64)}`;
  changedIntent.intent.intentDigest = walletOperationIntentDigestV1(changedIntent.intent);
  expect(() => parseWalletOwnerApprovalReceiptV1(changedIntent)).not.toThrow();
  expect(validateWalletOwnerApprovalBindingsV1(changedIntent, trusted).length).toBeGreaterThan(0);
  for (const mutate of [
    (facts: Mutable<WalletOwnerApprovalTrustedFactsV1>) => {
      facts.signingKey.kid += "-other";
    },
    (facts: Mutable<WalletOwnerApprovalTrustedFactsV1>) => {
      facts.signingKey.keyGeneration = "2";
    },
    (facts: Mutable<WalletOwnerApprovalTrustedFactsV1>) => {
      facts.ownerPin.accountId += "-other";
    },
    (facts: Mutable<WalletOwnerApprovalTrustedFactsV1>) => {
      facts.approval.revision++;
    },
    (facts: Mutable<WalletOwnerApprovalTrustedFactsV1>) => {
      facts.authentication.authTime++;
    },
    (facts: Mutable<WalletOwnerApprovalTrustedFactsV1>) => {
      facts.audit.eventDigest = `sha256:${"0".repeat(64)}`;
    },
    (facts: Mutable<WalletOwnerApprovalTrustedFactsV1>) => {
      facts.now = "2026-10-01T12:00:05.500000000Z";
    },
    (facts: Mutable<WalletOwnerApprovalTrustedFactsV1>) => {
      facts.now = "2026-10-01T12:00:45Z";
    },
  ]) {
    const changed = structuredClone(trusted) as Mutable<WalletOwnerApprovalTrustedFactsV1>;
    mutate(changed);
    expect(validateWalletOwnerApprovalBindingsV1(receipt, changed).length).toBeGreaterThan(0);
  }
  const oldMfa = structuredClone(receipt) as Mutable<WalletOwnerApprovalReceiptV1>;
  oldMfa.approval.createdAt = "2026-10-01T11:50:00Z";
  oldMfa.authentication.authTime = oldMfa.iat - 299;
  const atLimit = {
    ...trusted,
    approval: { ...trusted.approval, ...oldMfa.approval },
    authentication: oldMfa.authentication,
    now: "2026-10-01T12:00:06Z",
  };
  expect(validateWalletOwnerApprovalBindingsV1(oldMfa, atLimit)).toEqual([]);
  expect(
    validateWalletOwnerApprovalBindingsV1(oldMfa, {
      ...atLimit,
      now: "2026-10-01T12:00:06.000000001Z",
    }).length,
  ).toBeGreaterThan(0);
  oldMfa.authentication.authTime--;
  expect(() => parseWalletOwnerApprovalReceiptV1(oldMfa)).toThrow(AuthorityContractError);
  const request = walletRequest();
  const intent = request.binding.intent as Mutable<WalletOperationIntentV1>;
  intent.action = "reveal";
  intent.operation.resource.disclosure = { kind: "owner_authorized", actions: ["reveal"] };
  intent.operation.resource.supportedActions = ["reveal"];
  intent.operation.actor = { kind: "user", id: intent.operation.subject };
  intent.operation.authenticationProfile = "owner_interactive";
  intent.operation.context = { kind: "owner_client", clientSessionId: "owner-session" };
  intent.operation.transfer = {
    schemaVersion: "kombify.wallet-transfer-binding.v1",
    ciphertextDigest: `sha256:${"0".repeat(64)}`,
    serialization: "compact_jwe_utf8",
  };
  intent.intentDigest = walletOperationIntentDigestV1(intent);
  expect(() => parseWalletOperationIntentV1(intent)).not.toThrow();
  request.binding.resources = [structuredClone(intent.operation.resource)];
  request.requestDigest = activationRequestDigestV2(request.binding);
  expect(() => parseActivationRequestV2(request)).toThrow();
  intent.operation.resource.disclosure = { kind: "owner_authorized", actions: ["export"] };
  intent.intentDigest = walletOperationIntentDigestV1(intent);
  expect(() => parseWalletOperationIntentV1(intent)).toThrow();
});
