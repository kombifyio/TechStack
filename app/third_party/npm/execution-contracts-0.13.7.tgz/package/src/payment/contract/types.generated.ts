// Generated from canonical Core payment source a13d332cc38ac48ee9a1ad837ebf25f1afc3c5db. Do not edit.
// Regenerate: node scripts/generate-payment-contract.mjs (KOMBIFY_PAYMENT_SOURCE_REPO points to workspace Git repository).

import type {
  AuthorityAgentActorV2,
  AuthorityDigestV2,
  MonetaryReservationReferenceV2,
} from "../../authority/types.js";

export type PaymentIntentV1 = {
  readonly schemaVersion: "kombify.payment-intent.v1";
  readonly intentId: string;
  readonly rail: "stripe_issuing";
  readonly actor: AuthorityAgentActorV2;
  readonly onBehalfOf: string;
  readonly tenantId: string;
  readonly runId: string;
  readonly leaseId: string;
  readonly merchantRef: string;
  readonly purposeRef: string;
  readonly currency: string;
  readonly maximumMinor: string;
  readonly expiresAt: string;
  readonly idempotencyKey: string;
  readonly policyVersion: string;
  readonly funding: {
    readonly kind: "platform_allocation";
    readonly allocationId: string;
  };
  readonly intentDigest: AuthorityDigestV2;
};

export type PaymentInstrumentV1 = {
  readonly schemaVersion: "kombify.payment-instrument.v1";
  readonly instrumentId: string;
  readonly intentId: string;
  readonly intentDigest: AuthorityDigestV2;
  readonly leaseId: string;
  readonly reservation: MonetaryReservationReferenceV2;
  readonly status: "issued" | "voided" | "outcome_unknown";
  readonly providerInstrumentRef?: string;
  readonly pendingOperation?: "issue" | "settle" | "void";
};

export type PaymentReceiptV1 = {
  readonly schemaVersion: "kombify.payment-receipt.v1";
  readonly receiptId: string;
  readonly intentId: string;
  readonly intentDigest: AuthorityDigestV2;
  readonly instrumentId: string;
  readonly providerInstrumentRef: string;
  readonly reservation: MonetaryReservationReferenceV2;
  readonly providerTransactionRef: string;
  readonly status: "settled";
  readonly actualMinor: string;
  readonly currency: string;
  readonly settledAt: string;
  readonly receiptDigest: AuthorityDigestV2;
};
