// Generated from canonical Core payment source a13d332cc38ac48ee9a1ad837ebf25f1afc3c5db. Do not edit.
// Regenerate: node scripts/generate-payment-contract.mjs (KOMBIFY_PAYMENT_SOURCE_REPO points to workspace Git repository).
// oxlint-disable unicorn/no-thenable -- JSON Schema keyword.

export const PAYMENT_CORE_COMMIT = "a13d332cc38ac48ee9a1ad837ebf25f1afc3c5db" as const;
export const paymentSchemaDocuments: Readonly<Record<string, unknown>> = {
  "payment.v1.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.com/payment.v1.schema.json",
    title: "First platform Stripe payment contracts v1",
    description:
      "Contract shape and binding only; never execution admission, provider evidence verification or monetary reservation authority.",
    oneOf: [
      {
        $ref: "#/$defs/intent",
      },
      {
        $ref: "#/$defs/instrument",
      },
      {
        $ref: "#/$defs/receipt",
      },
    ],
    $defs: {
      id: {
        type: "string",
        minLength: 1,
        maxLength: 512,
      },
      digest: {
        $ref: "agent-authority.v2.schema.json#/$defs/digest",
      },
      minor: {
        type: "string",
        pattern: "^[1-9][0-9]*$",
        description: "Exact positive integer minor units, never floating-point money.",
      },
      currency: {
        type: "string",
        pattern: "^[A-Z]{3}$",
      },
      instant: {
        type: "string",
        format: "date-time",
        pattern: "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}Z$",
        description: "UTC whole seconds for deterministic ordering in this version.",
      },
      funding: {
        type: "object",
        additionalProperties: false,
        required: ["kind", "allocationId"],
        properties: {
          kind: {
            const: "platform_allocation",
          },
          allocationId: {
            $ref: "#/$defs/id",
          },
        },
      },
      intent: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "intentId",
          "rail",
          "actor",
          "onBehalfOf",
          "tenantId",
          "runId",
          "leaseId",
          "merchantRef",
          "purposeRef",
          "currency",
          "maximumMinor",
          "expiresAt",
          "idempotencyKey",
          "policyVersion",
          "funding",
          "intentDigest",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.payment-intent.v1",
          },
          intentId: {
            $ref: "#/$defs/id",
          },
          rail: {
            const: "stripe_issuing",
          },
          actor: {
            $ref: "agent-authority.v2.schema.json#/$defs/agentActor",
          },
          onBehalfOf: {
            $ref: "#/$defs/id",
          },
          tenantId: {
            $ref: "#/$defs/id",
          },
          runId: {
            $ref: "#/$defs/id",
          },
          leaseId: {
            $ref: "#/$defs/id",
          },
          merchantRef: {
            $ref: "#/$defs/id",
          },
          purposeRef: {
            $ref: "#/$defs/id",
          },
          currency: {
            $ref: "#/$defs/currency",
          },
          maximumMinor: {
            $ref: "#/$defs/minor",
          },
          expiresAt: {
            $ref: "#/$defs/instant",
          },
          idempotencyKey: {
            $ref: "#/$defs/id",
          },
          policyVersion: {
            $ref: "#/$defs/id",
          },
          funding: {
            $ref: "#/$defs/funding",
          },
          intentDigest: {
            $ref: "#/$defs/digest",
          },
        },
      },
      reservation: {
        $ref: "agent-authority.v2.schema.json#/$defs/monetaryReservation",
      },
      instrument: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "instrumentId",
          "intentId",
          "intentDigest",
          "leaseId",
          "reservation",
          "status",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.payment-instrument.v1",
          },
          instrumentId: {
            $ref: "#/$defs/id",
          },
          intentId: {
            $ref: "#/$defs/id",
          },
          intentDigest: {
            $ref: "#/$defs/digest",
          },
          leaseId: {
            $ref: "#/$defs/id",
          },
          reservation: {
            $ref: "#/$defs/reservation",
          },
          status: {
            enum: ["issued", "voided", "outcome_unknown"],
          },
          providerInstrumentRef: {
            $ref: "#/$defs/id",
          },
          pendingOperation: {
            enum: ["issue", "settle", "void"],
          },
        },
        allOf: [
          {
            if: {
              properties: {
                status: {
                  const: "outcome_unknown",
                },
              },
              required: ["status"],
            },
            then: {
              required: ["pendingOperation"],
            },
            else: {
              required: ["providerInstrumentRef"],
              not: {
                required: ["pendingOperation"],
              },
            },
          },
        ],
      },
      receipt: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "receiptId",
          "intentId",
          "intentDigest",
          "instrumentId",
          "providerInstrumentRef",
          "reservation",
          "providerTransactionRef",
          "status",
          "actualMinor",
          "currency",
          "settledAt",
          "receiptDigest",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.payment-receipt.v1",
          },
          receiptId: {
            $ref: "#/$defs/id",
          },
          intentId: {
            $ref: "#/$defs/id",
          },
          intentDigest: {
            $ref: "#/$defs/digest",
          },
          instrumentId: {
            $ref: "#/$defs/id",
          },
          providerInstrumentRef: {
            $ref: "#/$defs/id",
          },
          reservation: {
            $ref: "#/$defs/reservation",
          },
          providerTransactionRef: {
            $ref: "#/$defs/id",
          },
          status: {
            const: "settled",
          },
          actualMinor: {
            $ref: "#/$defs/minor",
          },
          currency: {
            $ref: "#/$defs/currency",
          },
          settledAt: {
            $ref: "#/$defs/instant",
          },
          receiptDigest: {
            $ref: "#/$defs/digest",
          },
        },
      },
    },
  },
  "agent-authority.v2.schema.json": {
    $defs: {
      agentActor: {
        type: "object",
        additionalProperties: false,
        required: ["kind", "id", "agentClass", "templateDigest"],
        properties: {
          kind: {
            const: "agent",
          },
          id: {
            type: "string",
            minLength: 1,
            description:
              "The authenticated ai_agent_instances.id, never a shared class, client id, or OBO subject.",
          },
          agentClass: {
            type: "string",
            minLength: 1,
          },
          templateDigest: {
            $ref: "#/$defs/digest",
          },
        },
      },
      digest: {
        type: "string",
        pattern: "^sha256:[0-9a-f]{64}$",
      },
      monetaryReservation: {
        type: "object",
        additionalProperties: false,
        required: [
          "allocationId",
          "reservationId",
          "reservationDigest",
          "intentDigest",
          "currency",
          "maximumMinor",
          "merchantRef",
          "purposeRef",
          "expiresAt",
        ],
        properties: {
          allocationId: {
            type: "string",
            minLength: 1,
          },
          reservationId: {
            type: "string",
            minLength: 1,
          },
          reservationDigest: {
            $ref: "#/$defs/digest",
            description:
              "The immutable commerce reservation request_digest, exposed on the wire as reservationDigest; no second payment-proof digest is accepted.",
          },
          intentDigest: {
            $ref: "#/$defs/digest",
          },
          currency: {
            type: "string",
            pattern: "^[A-Z]{3}$",
          },
          maximumMinor: {
            type: "string",
            pattern: "^(0|[1-9][0-9]*)$",
          },
          merchantRef: {
            type: "string",
            minLength: 1,
          },
          purposeRef: {
            type: "string",
            minLength: 1,
          },
          expiresAt: {
            type: "string",
            format: "date-time",
          },
        },
      },
    },
  },
};
