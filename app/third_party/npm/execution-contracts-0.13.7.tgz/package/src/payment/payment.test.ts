import { expect, it } from "vitest";
import { parsePaymentBindingV1, paymentIntentDigestV1, paymentReceiptDigestV1 } from "../index.js";
import { paymentV1Conformance } from "./contract/conformance.generated.js";

it("preserves canonical payment funding and settled-receipt replay verdicts at the public package boundary", () => {
  for (const vector of paymentV1Conformance.cases) {
    if (vector.accepted) {
      const binding = parsePaymentBindingV1(vector.request);
      expect(paymentIntentDigestV1(binding.intent), vector.name).toBe(binding.intent.intentDigest);
      if (binding.receipt)
        expect(paymentReceiptDigestV1(binding.receipt), vector.name).toBe(
          binding.receipt.receiptDigest,
        );
    } else {
      expect(() => parsePaymentBindingV1(vector.request), vector.name).toThrow();
    }
  }
});
