/** A selector only; Gateway verifies its membership in the token's registration. */
export function isModelWorkload(value: unknown): value is string {
  return typeof value === "string" && /^[a-z][a-z0-9-]{0,63}$/.exec(value)?.[0] === value;
}
