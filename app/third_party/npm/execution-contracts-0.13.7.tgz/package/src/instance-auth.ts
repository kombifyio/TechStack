/**
 * Signed instance auth context — the per-instance handle the spawn admission
 * API (workbench orchestrator, slice C4) mints for the generic agent host
 * (`agent-host` Worker, slice C2) when it provisions a spawned agent instance.
 *
 * Shape (AI-CAPABILITY-PROVISIONING-TARGET.md §7, ADR 0008): the context names
 * the instance, the digest of the admitted spec, the lease ids the instance may
 * present, the parent instance (agent-initiated spawns), the owning principal
 * and an expiry that never outlives the instance (`exp = min(spec ttl,
 * earliest lease expiry)`). It carries no credential. Every Gateway call the
 * host makes presents the lease header under a delegated user token: the one
 * it exchanges itself, or a customer MCP, Paperwork MCP or AI token the
 * orchestrator exchanged, which the handle binds by digest only
 * (`customerTokenDigest`, `paperworkTokenDigest`, `aiTokenDigest`).
 *
 * Wire format: `v1.<base64url(payload json)>.<base64url(HMAC-SHA256(secret,
 * "v1\n" + encodedPayload))>` in the `x-kombify-instance-auth` header. One
 * shared secret (`AGENT_HOST_INSTANCE_AUTH_SECRET`) on both deployables; the
 * host may hold a comma-separated list to rotate.
 */

import { isModelWorkload } from "./model-workload.js";
export { isModelWorkload } from "./model-workload.js";

export const INSTANCE_AUTH_VERSION = "v1";
export const INSTANCE_AUTH_HEADER = "x-kombify-instance-auth";
export const INSTANCE_AUTH_SECRET_ENV = "AGENT_HOST_INSTANCE_AUTH_SECRET";
/** The owner's delegated customer MCP token, bound to the handle by `customerTokenDigest`. */
export const INSTANCE_CUSTOMER_TOKEN_HEADER = "x-kombify-instance-customer-token";
/** The owner's delegated Paperwork MCP token, bound to the handle by `paperworkTokenDigest`. */
export const INSTANCE_PAPERWORK_TOKEN_HEADER = "x-kombify-instance-paperwork-token";
/** The owner's delegated AI token, bound to the handle by `aiTokenDigest`. */
export const INSTANCE_AI_TOKEN_HEADER = "x-kombify-instance-ai-token";
/**
 * The run-scoped workflow delegation credential (`agent.workflow.run`), bound
 * to the handle by `workflowTokenDigest`. A workflow run has no owner bearer,
 * so a handle that carries this digest carries no other token digest.
 */
// The Gateway strips this header from every inbound request and sets it only from a
// workflow-run credential it has just admitted, so the host sees no caller-supplied value.
export const INSTANCE_WORKFLOW_TOKEN_HEADER = "x-kombify-agent-workflow-delegation";
const TOKEN_DIGEST_PATTERN = /^sha256:[0-9a-f]{64}$/u;
/** Tolerated clock skew for `iat` in the future (seconds). */
const MAX_IAT_SKEW_SECONDS = 300;
const MAX_LEASE_IDS = 64;

export interface InstanceAuthOwnerV1 {
  readonly subject: string;
  readonly tenantId?: string;
}

export interface InstanceAuthContextV1 {
  readonly instanceId: string;
  /** Digest of the admitted `AgentSpawnSpecV1`; the host refuses a spec that does not match. */
  readonly specDigest: string;
  /** Digest of the exact admitted role template carried by the provision body. */
  readonly templateDigest?: string;
  readonly leaseIds: readonly string[];
  readonly parentInstanceId?: string;
  /** Origin-accepted execution identity; the raw run body cannot override it. */
  readonly executionRunId?: string;
  readonly owner: InstanceAuthOwnerV1;
  /**
   * `sha256:<hex>` of the owner's delegated customer MCP token the
   * orchestrator handed this run over with (`INSTANCE_CUSTOMER_TOKEN_HEADER`).
   * The orchestrator is the only approved actor for that exchange; the host
   * accepts the token only when it matches this digest.
   */
  readonly customerTokenDigest?: string;
  /**
   * `sha256:<hex>` of the owner's delegated Paperwork MCP token, handed over
   * the same way (`INSTANCE_PAPERWORK_TOKEN_HEADER`) for an instance that
   * holds Paperwork equipment.
   */
  readonly paperworkTokenDigest?: string;
  /**
   * `sha256:<hex>` of the owner's delegated AI token (the Gateway's
   * `ai-transcript` target), handed over the same way
   * (`INSTANCE_AI_TOKEN_HEADER`) so the host runs the model exactly as the
   * orchestrator does.
   */
  readonly aiTokenDigest?: string;
  /**
   * `sha256:<hex>` of the run-scoped workflow delegation credential the
   * orchestrator handed over (`INSTANCE_WORKFLOW_TOKEN_HEADER`) for an
   * automation-invoked workflow run. The host refuses such a handle that also
   * binds a customer, Paperwork or AI token: `executionRunId` is the workflow run.
   */
  readonly workflowTokenDigest?: string;
  /** Optional model header selector bound to this exact delegated AI token; never a grant. */
  readonly aiModelWorkload?: string;
  /** Unix seconds. */
  readonly iat: number;
  /** Unix seconds; `min(spec ttl, earliest lease expiry)`. */
  readonly exp: number;
}

export type InstanceAuthDenialCode =
  | "missing_instance_auth"
  | "invalid_instance_auth"
  | "expired_instance_auth"
  | "instance_auth_unverified";

export type InstanceAuthOutcome =
  | { readonly ok: true; readonly context: InstanceAuthContextV1 }
  | {
      readonly ok: false;
      readonly status: 401 | 503;
      readonly code: InstanceAuthDenialCode;
      readonly message: string;
    };

const encoder = new TextEncoder();
const decoder = new TextDecoder();

function base64UrlEncode(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
}

function base64UrlDecode(segment: string): Uint8Array | undefined {
  if (!/^[A-Za-z0-9_-]*$/u.test(segment)) return undefined;
  const padded =
    segment.replaceAll("-", "+").replaceAll("_", "/") + "=".repeat((4 - (segment.length % 4)) % 4);
  try {
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    return bytes;
  } catch {
    return undefined;
  }
}

async function hmacBase64Url(secret: string, message: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(message));
  return base64UrlEncode(new Uint8Array(signature));
}

function timingSafeEqual(left: string, right: string): boolean {
  const a = encoder.encode(left);
  const b = encoder.encode(right);
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let index = 0; index < a.length; index += 1) diff |= (a[index] ?? 0) ^ (b[index] ?? 0);
  return diff === 0;
}

function signingInput(encodedPayload: string): string {
  return `${INSTANCE_AUTH_VERSION}\n${encodedPayload}`;
}

function nonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function isUnixSeconds(value: unknown): value is number {
  return typeof value === "number" && Number.isInteger(value) && value > 0;
}

function isOptionalTokenDigest(value: unknown): value is string | undefined {
  return value === undefined || (typeof value === "string" && TOKEN_DIGEST_PATTERN.test(value));
}

/** Returns the validated context or `undefined` when the payload is not an `InstanceAuthContextV1`. */
export function parseInstanceAuthContext(value: unknown): InstanceAuthContextV1 | undefined {
  if (!value || typeof value !== "object") return undefined;
  const record = value as Record<string, unknown>;
  const owner = record.owner as Record<string, unknown> | undefined;
  if (!nonEmptyString(record.instanceId) || !nonEmptyString(record.specDigest)) return undefined;
  if (record.templateDigest !== undefined && !nonEmptyString(record.templateDigest))
    return undefined;
  if (!Array.isArray(record.leaseIds) || record.leaseIds.length > MAX_LEASE_IDS) return undefined;
  if (!record.leaseIds.every(nonEmptyString)) return undefined;
  if (record.parentInstanceId !== undefined && !nonEmptyString(record.parentInstanceId))
    return undefined;
  if (
    record.executionRunId !== undefined &&
    (!nonEmptyString(record.executionRunId) ||
      record.executionRunId.trim() !== record.executionRunId ||
      Array.from(record.executionRunId).some(
        (character) => character.charCodeAt(0) < 32 || character.charCodeAt(0) === 127,
      ))
  )
    return undefined;
  if (!owner || typeof owner !== "object" || !nonEmptyString(owner.subject)) return undefined;
  if (owner.tenantId !== undefined && !nonEmptyString(owner.tenantId)) return undefined;
  const {
    customerTokenDigest,
    paperworkTokenDigest,
    aiTokenDigest,
    workflowTokenDigest,
    aiModelWorkload,
  } = record;
  if (
    !isOptionalTokenDigest(customerTokenDigest) ||
    !isOptionalTokenDigest(paperworkTokenDigest) ||
    !isOptionalTokenDigest(aiTokenDigest) ||
    !isOptionalTokenDigest(workflowTokenDigest)
  ) {
    return undefined;
  }
  if (
    Object.hasOwn(record, "aiModelWorkload") &&
    (!isModelWorkload(aiModelWorkload) || !aiTokenDigest)
  )
    return undefined;
  if (!isUnixSeconds(record.iat) || !isUnixSeconds(record.exp) || record.exp <= record.iat)
    return undefined;
  return {
    instanceId: record.instanceId,
    specDigest: record.specDigest,
    ...(record.templateDigest !== undefined ? { templateDigest: record.templateDigest } : {}),
    leaseIds: [...new Set(record.leaseIds as string[])],
    ...(record.parentInstanceId !== undefined ? { parentInstanceId: record.parentInstanceId } : {}),
    ...(record.executionRunId !== undefined ? { executionRunId: record.executionRunId } : {}),
    owner: {
      subject: owner.subject,
      ...(owner.tenantId !== undefined ? { tenantId: owner.tenantId } : {}),
    },
    ...(customerTokenDigest !== undefined ? { customerTokenDigest } : {}),
    ...(paperworkTokenDigest !== undefined ? { paperworkTokenDigest } : {}),
    ...(aiTokenDigest !== undefined ? { aiTokenDigest } : {}),
    ...(workflowTokenDigest !== undefined ? { workflowTokenDigest } : {}),
    ...(isModelWorkload(aiModelWorkload) ? { aiModelWorkload } : {}),
    iat: record.iat,
    exp: record.exp,
  };
}

/** `sha256:<hex>` of a bearer token, as `customerTokenDigest` binds it. */
export async function digestBearerToken(token: string): Promise<string> {
  const hash = await crypto.subtle.digest("SHA-256", encoder.encode(token.trim()));
  return `sha256:${[...new Uint8Array(hash)].map((byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}

/**
 * A delegated token handed over with a run, when the verified handle binds
 * exactly this token by `digest`; otherwise nothing. Constant-time on the
 * digest.
 */
export async function handedOverToken(
  digest: string | undefined,
  presented: string | null | undefined,
): Promise<string | undefined> {
  const token = presented?.trim();
  if (!token || !digest) return undefined;
  return timingSafeEqual(await digestBearerToken(token), digest) ? token : undefined;
}

/** Mint the signed handle. Rejects a malformed context instead of signing it. */
export async function signInstanceAuthContext(
  secret: string,
  context: InstanceAuthContextV1,
): Promise<string> {
  if (!nonEmptyString(secret)) {
    throw new Error(`${INSTANCE_AUTH_SECRET_ENV} is required to sign an instance auth context.`);
  }
  const validated = parseInstanceAuthContext(context);
  if (!validated) throw new Error("instance auth context is malformed");
  const encodedPayload = base64UrlEncode(encoder.encode(JSON.stringify(validated)));
  const signature = await hmacBase64Url(secret, signingInput(encodedPayload));
  return `${INSTANCE_AUTH_VERSION}.${encodedPayload}.${signature}`;
}

/**
 * Verify a handle against one or more secrets (rotation: the newest first).
 * `nowMs` is injectable for tests; the caller decides what to do with the
 * verified context (match the instance id in the path, check the spec digest).
 */
export async function verifyInstanceAuthContext(
  token: string | null | undefined,
  secrets: string | readonly string[] | undefined,
  nowMs: number = Date.now(),
): Promise<InstanceAuthOutcome> {
  const trimmed = token?.trim() ?? "";
  if (!trimmed) {
    return refuse(
      401,
      "missing_instance_auth",
      `This endpoint requires the signed instance auth context (${INSTANCE_AUTH_HEADER}).`,
    );
  }
  const candidates = (typeof secrets === "string" ? secrets.split(",") : (secrets ?? []))
    .map((secret) => secret.trim())
    .filter((secret) => secret.length > 0);
  if (candidates.length === 0) {
    return refuse(
      503,
      "instance_auth_unverified",
      `No instance auth secret configured (${INSTANCE_AUTH_SECRET_ENV}).`,
    );
  }
  const parts = trimmed.split(".");
  if (parts.length !== 3 || parts[0] !== INSTANCE_AUTH_VERSION || !parts[1] || !parts[2]) {
    return refuse(401, "invalid_instance_auth", "Instance auth context format is invalid.");
  }
  const encodedPayload = parts[1];
  const signature = parts[2];
  let verified = false;
  for (const secret of candidates) {
    const expected = await hmacBase64Url(secret, signingInput(encodedPayload));
    if (timingSafeEqual(signature, expected)) {
      verified = true;
      break;
    }
  }
  if (!verified)
    return refuse(401, "invalid_instance_auth", "Instance auth context signature is invalid.");
  const bytes = base64UrlDecode(encodedPayload);
  let payload: unknown;
  try {
    payload = bytes ? JSON.parse(decoder.decode(bytes)) : undefined;
  } catch {
    payload = undefined;
  }
  const context = parseInstanceAuthContext(payload);
  if (!context)
    return refuse(401, "invalid_instance_auth", "Instance auth context payload is not decodable.");
  const nowSeconds = Math.floor(nowMs / 1000);
  if (context.iat > nowSeconds + MAX_IAT_SKEW_SECONDS) {
    return refuse(401, "invalid_instance_auth", "Instance auth context is issued in the future.");
  }
  if (context.exp <= nowSeconds) {
    return refuse(
      401,
      "expired_instance_auth",
      "Instance auth context has expired; the instance must be re-admitted.",
    );
  }
  return { ok: true, context };
}

function refuse(
  status: 401 | 503,
  code: InstanceAuthDenialCode,
  message: string,
): InstanceAuthOutcome {
  return { ok: false, status, code, message };
}
