import { p256 } from "@noble/curves/nist";
import { sha256 } from "@noble/hashes/sha2";

const DPOP_PROOF_TYPE = "dpop+jwt";
const DPOP_SIGNING_ALGORITHM = "ES256";
const DEFAULT_DPOP_MAX_AGE_SECONDS = 300;
const CLOCK_SKEW_SECONDS = 5;

/** Public P-256 JWK carried in a DPoP proof header. */
export interface DpopPublicJwk {
  readonly kty: "EC";
  readonly crv: "P-256";
  readonly x: string;
  readonly y: string;
}

export type DpopVerificationResult =
  | {
      readonly ok: true;
      readonly thumbprint: string;
      readonly jti: string;
      readonly iat: number;
    }
  | {
      readonly ok: false;
      readonly reason: string;
    };

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function isBase64Url(value: string): boolean {
  return value.length % 4 !== 1 && /^[A-Za-z0-9_-]*$/u.test(value);
}

function base64UrlToBytes(value: string): Uint8Array {
  if (!isBase64Url(value)) {
    throw new Error("Invalid base64url value.");
  }
  const padded =
    value.replace(/-/gu, "+").replace(/_/gu, "/") + "=".repeat((4 - (value.length % 4)) % 4);
  const decoded = atob(padded);
  const bytes = new Uint8Array(decoded.length);
  for (let index = 0; index < decoded.length; index += 1) {
    bytes[index] = decoded.charCodeAt(index);
  }
  return bytes;
}

function base64UrlToJson(value: string): unknown {
  return JSON.parse(new TextDecoder().decode(base64UrlToBytes(value)));
}

function isPublicDpopJwk(value: unknown): value is DpopPublicJwk {
  if (!isRecord(value)) return false;
  return (
    value.kty === "EC" &&
    value.crv === "P-256" &&
    isNonEmptyString(value.x) &&
    isNonEmptyString(value.y) &&
    !Object.prototype.hasOwnProperty.call(value, "d")
  );
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isDpopHeader(
  value: unknown,
): value is { readonly typ: string; readonly alg: string; readonly jwk: DpopPublicJwk } {
  if (!isRecord(value)) return false;
  return (
    value.typ === DPOP_PROOF_TYPE &&
    value.alg === DPOP_SIGNING_ALGORITHM &&
    isPublicDpopJwk(value.jwk)
  );
}

function isDpopPayload(value: unknown): value is {
  readonly htm: string;
  readonly htu: string;
  readonly jti: string;
  readonly iat: number;
  readonly ath?: string;
} {
  if (!isRecord(value)) return false;
  return (
    isNonEmptyString(value.htm) &&
    isNonEmptyString(value.htu) &&
    isNonEmptyString(value.jti) &&
    typeof value.iat === "number" &&
    Number.isSafeInteger(value.iat) &&
    (value.ath === undefined || typeof value.ath === "string")
  );
}

function dpopThumbprintInput(jwk: DpopPublicJwk): string {
  // RFC 7638 requires these members in lexicographic order and no others.
  return JSON.stringify({ crv: jwk.crv, kty: jwk.kty, x: jwk.x, y: jwk.y });
}

/** Compute the RFC 7638 thumbprint used by DPoP cnf.jkt bindings. */
export function computeDpopJwkThumbprint(jwk: DpopPublicJwk): string {
  return bytesToBase64Url(sha256(new TextEncoder().encode(dpopThumbprintInput(jwk))));
}

/** Compute the RFC 9449 ath value for a DPoP-bound access token. */
export function computeDpopAccessTokenHash(accessToken: string): string {
  return bytesToBase64Url(sha256(new TextEncoder().encode(accessToken)));
}

function bytesToBase64Url(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/gu, "-").replace(/\//gu, "_").replace(/=+$/u, "");
}

/** Normalize a request URL according to the DPoP htu comparison rules. */
export function normalizeDpopHtu(rawUrl: string): string | null {
  try {
    const url = new URL(rawUrl);
    url.hash = "";
    url.search = "";
    return url.toString();
  } catch {
    return null;
  }
}

function publicKeyBytesFromJwk(jwk: DpopPublicJwk): Uint8Array {
  const x = base64UrlToBytes(jwk.x);
  const y = base64UrlToBytes(jwk.y);
  if (x.length !== 32 || y.length !== 32) {
    throw new Error("Invalid P-256 public key coordinate length.");
  }
  const publicKey = new Uint8Array(65);
  publicKey[0] = 0x04;
  publicKey.set(x, 1);
  publicKey.set(y, 33);
  return publicKey;
}

/**
 * Verify a compact ES256 DPoP proof at a request boundary.
 *
 * This intentionally has no product, identity-provider, or transport
 * knowledge. Callers provide the expected request binding and, when needed,
 * the access token and key thumbprint that the surrounding authority issued.
 */
export function verifyDpopProof(input: {
  readonly proof: string | null | undefined;
  readonly method: string;
  readonly url: string;
  readonly nowEpochSeconds: number;
  readonly expectedThumbprint?: string;
  readonly expectedAccessToken?: string;
  readonly maxAgeSeconds?: number;
}): DpopVerificationResult {
  if (!input.proof?.trim()) {
    return { ok: false, reason: "Missing DPoP proof." };
  }

  const parts = input.proof.split(".");
  if (parts.length !== 3) {
    return { ok: false, reason: "Invalid DPoP compact JWT." };
  }
  const [headerPart, payloadPart, signaturePart] = parts;
  if (
    headerPart === undefined ||
    payloadPart === undefined ||
    signaturePart === undefined ||
    !headerPart ||
    !payloadPart ||
    !signaturePart ||
    !isBase64Url(headerPart) ||
    !isBase64Url(payloadPart) ||
    !isBase64Url(signaturePart)
  ) {
    return { ok: false, reason: "Invalid DPoP compact JWT." };
  }

  try {
    const headerValue = base64UrlToJson(headerPart);
    const payloadValue = base64UrlToJson(payloadPart);
    if (!isDpopHeader(headerValue)) {
      return { ok: false, reason: "Invalid DPoP JWT header." };
    }
    if (!isDpopPayload(payloadValue)) {
      return { ok: false, reason: "Invalid DPoP JWT payload." };
    }

    const thumbprint = computeDpopJwkThumbprint(headerValue.jwk);
    if (input.expectedThumbprint && thumbprint !== input.expectedThumbprint) {
      return { ok: false, reason: "DPoP key thumbprint mismatch." };
    }
    if (payloadValue.htm.toUpperCase() !== input.method.toUpperCase()) {
      return { ok: false, reason: "DPoP method mismatch." };
    }
    const normalizedHtu = normalizeDpopHtu(input.url);
    if (normalizedHtu === null || payloadValue.htu !== normalizedHtu) {
      return { ok: false, reason: "DPoP URL mismatch." };
    }
    if (input.expectedAccessToken) {
      const expectedAth = computeDpopAccessTokenHash(input.expectedAccessToken);
      if (payloadValue.ath !== expectedAth) {
        return { ok: false, reason: "DPoP access token hash mismatch." };
      }
    }

    const maxAgeSeconds = input.maxAgeSeconds ?? DEFAULT_DPOP_MAX_AGE_SECONDS;
    if (
      !Number.isSafeInteger(input.nowEpochSeconds) ||
      !Number.isFinite(maxAgeSeconds) ||
      maxAgeSeconds < 0 ||
      payloadValue.iat > input.nowEpochSeconds + CLOCK_SKEW_SECONDS ||
      input.nowEpochSeconds - payloadValue.iat > maxAgeSeconds
    ) {
      return { ok: false, reason: "DPoP proof is outside the allowed time window." };
    }

    const signature = base64UrlToBytes(signaturePart);
    if (signature.length !== 64) {
      return { ok: false, reason: "Invalid DPoP signature." };
    }
    const signatureInputHash = sha256(new TextEncoder().encode(`${headerPart}.${payloadPart}`));
    const verified = p256.verify(
      signature,
      signatureInputHash,
      publicKeyBytesFromJwk(headerValue.jwk),
      { prehash: false, format: "compact" },
    );
    return verified
      ? {
          ok: true,
          thumbprint,
          jti: payloadValue.jti,
          iat: payloadValue.iat,
        }
      : { ok: false, reason: "Invalid DPoP signature." };
  } catch {
    return { ok: false, reason: "Invalid DPoP proof." };
  }
}
