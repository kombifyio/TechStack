/**
 * Host-side lease and fencing state for cloud-delegated sessions (Connect
 * contract v1 section 7, decision D6). Pure and clock-injected: the host feeds
 * it verified lease and event payloads and asks it before every RPC entry,
 * stream write and HTTP side-path request.
 */
import {
  CONNECT_LEASE_GRACE_MS,
  type ConnectGrantChangedEventV1,
  type ConnectLeaseGrantV1,
  type ConnectLeaseRequestV1,
  type ConnectLeaseV1,
  type ConnectMintClaimsV1,
  type ConnectRevokeEventV1,
  connectT3ScopesFor,
} from "./contract.js";

/** What a host records on a cloud-delegated environment session. */
export interface ConnectSessionDelegation {
  readonly installationId: string;
  readonly installationEpoch: number;
  readonly grantId: string;
  readonly grantRevision: number;
  readonly hostGeneration: number;
  /** Epoch seconds. */
  readonly sessionExpiresAt: number;
}

export type ConnectFenceReason =
  | "lease_missing"
  | "lease_expired"
  | "generation_superseded"
  | "generation_mismatch"
  | "grant_missing"
  | "grant_revision_stale"
  | "installation_epoch_stale"
  | "session_expired"
  | "host_state_stale"
  | "scope_mismatch";

export type ConnectAuthorization =
  | { readonly ok: true }
  | { readonly ok: false; readonly reason: ConnectFenceReason };

export type ConnectLeaseAcceptance =
  | { readonly accepted: true }
  | {
      readonly accepted: false;
      readonly reason:
        | "unknown_nonce"
        | "environment_mismatch"
        | "generation_mismatch"
        | "grant_version_regressed";
    };

export interface ConnectHostLeaseTracker {
  /** Build the next lease request; its send time is recorded for the nonce. */
  nextLeaseRequest(): ConnectLeaseRequestV1;
  acceptLease(lease: ConnectLeaseV1): ConnectLeaseAcceptance;
  /** Returns the grant ids whose sessions must be fenced now. */
  acceptRevoke(event: ConnectRevokeEventV1): readonly string[];
  acceptGrantChanged(event: ConnectGrantChangedEventV1): void;
  /** A newer generation registered elsewhere; this process never regains authority. */
  supersede(): void;
  /** Monotonic deadline (ms) of cloud-delegated authority, or null without a lease. */
  leaseDeadline(): number | null;
  authorizeSession(
    delegation: ConnectSessionDelegation,
    nowEpochSeconds: number,
  ): ConnectAuthorization;
  /** Checks a Gateway mint request before the host issues a bootstrap credential. */
  authorizeMint(claims: ConnectMintClaimsV1, nowEpochSeconds: number): ConnectAuthorization;
  readonly hostGeneration: number;
}

export function createConnectHostLeaseTracker(options: {
  readonly environmentId: string;
  readonly hostGeneration: number;
  /** Monotonic milliseconds, e.g. `performance.now()`. Wall-clock changes must not move it. */
  readonly monotonicNowMs: () => number;
  readonly randomNonce: () => string;
  readonly graceMs?: number;
}): ConnectHostLeaseTracker {
  const graceMs = Math.min(options.graceMs ?? CONNECT_LEASE_GRACE_MS, CONNECT_LEASE_GRACE_MS);
  const pending = new Map<string, number>();
  const revoked = new Set<string>();
  let seq = 0;
  let deadline: number | null = null;
  let grantVersion = 0;
  let grants = new Map<string, ConnectLeaseGrantV1>();
  let superseded = false;

  const leaseAlive = (): ConnectAuthorization => {
    if (superseded) return { ok: false, reason: "generation_superseded" };
    if (deadline === null) return { ok: false, reason: "lease_missing" };
    if (options.monotonicNowMs() > deadline) return { ok: false, reason: "lease_expired" };
    return { ok: true };
  };

  const grantCurrent = (
    grantId: string,
    grantRevision: number,
    installationEpoch: number,
  ): ConnectAuthorization => {
    const grant = revoked.has(grantId) ? undefined : grants.get(grantId);
    if (!grant) return { ok: false, reason: "grant_missing" };
    if (grant.grant_revision !== grantRevision)
      return { ok: false, reason: "grant_revision_stale" };
    if (grant.installation_epoch !== installationEpoch) {
      return { ok: false, reason: "installation_epoch_stale" };
    }
    return { ok: true };
  };

  return {
    hostGeneration: options.hostGeneration,
    nextLeaseRequest() {
      const now = options.monotonicNowMs();
      for (const [nonce, sentAt] of pending) {
        if (now - sentAt > graceMs) pending.delete(nonce);
      }
      const nonce = options.randomNonce();
      pending.set(nonce, now);
      seq += 1;
      return { type: "lease-request", nonce, host_generation: options.hostGeneration, seq };
    },
    acceptLease(lease) {
      const sentAt = pending.get(lease.nonce);
      if (sentAt === undefined) return { accepted: false, reason: "unknown_nonce" };
      if (lease.environment_id !== options.environmentId) {
        return { accepted: false, reason: "environment_mismatch" };
      }
      if (lease.host_generation !== options.hostGeneration) {
        return { accepted: false, reason: "generation_mismatch" };
      }
      if (lease.grant_version < grantVersion)
        return { accepted: false, reason: "grant_version_regressed" };
      // A nonce answers once; older outstanding nonces cannot extend the lease later.
      for (const [nonce, nonceSentAt] of pending) {
        if (nonceSentAt <= sentAt) pending.delete(nonce);
      }
      grantVersion = lease.grant_version;
      grants = new Map(
        lease.grants
          .filter((grant) => !revoked.has(grant.grant_id))
          .map((grant) => [grant.grant_id, grant]),
      );
      deadline = Math.max(deadline ?? Number.NEGATIVE_INFINITY, sentAt + graceMs);
      return { accepted: true };
    },
    acceptRevoke(event) {
      if (event.environment_id !== options.environmentId) return [];
      revoked.add(event.grant_id);
      grants.delete(event.grant_id);
      grantVersion = Math.max(grantVersion, event.grant_version);
      return [event.grant_id];
    },
    acceptGrantChanged(event) {
      if (event.environment_id !== options.environmentId) return;
      grantVersion = Math.max(grantVersion, event.grant_version);
    },
    supersede() {
      superseded = true;
      grants = new Map();
    },
    leaseDeadline() {
      return superseded ? null : deadline;
    },
    authorizeSession(delegation, nowEpochSeconds) {
      const alive = leaseAlive();
      if (!alive.ok) return alive;
      if (delegation.hostGeneration !== options.hostGeneration) {
        return { ok: false, reason: "generation_mismatch" };
      }
      if (nowEpochSeconds >= delegation.sessionExpiresAt)
        return { ok: false, reason: "session_expired" };
      return grantCurrent(
        delegation.grantId,
        delegation.grantRevision,
        delegation.installationEpoch,
      );
    },
    authorizeMint(claims, nowEpochSeconds) {
      const alive = leaseAlive();
      if (!alive.ok) return alive;
      if (claims.host_generation !== options.hostGeneration) {
        return { ok: false, reason: "generation_mismatch" };
      }
      if (claims.grant_version > grantVersion) return { ok: false, reason: "host_state_stale" };
      if (nowEpochSeconds >= claims.session_expires_at)
        return { ok: false, reason: "session_expired" };
      const current = grantCurrent(
        claims.grant_id,
        claims.grant_revision,
        claims.installation_epoch,
      );
      if (!current.ok) return current;
      const grant = grants.get(claims.grant_id);
      const expected = connectT3ScopesFor(claims.profile, grant?.capabilities ?? []);
      if (
        grant?.installation_id !== claims.installation_id ||
        grant.profile !== claims.profile ||
        expected.length !== claims.t3_scopes.length ||
        expected.some((scope) => !claims.t3_scopes.includes(scope))
      ) {
        return { ok: false, reason: "scope_mismatch" };
      }
      return { ok: true };
    },
  };
}
