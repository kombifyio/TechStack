/**
 * EdDSA (Ed25519) compact JWS for Connect host proofs, leases and events.
 * The Gateway signs leases and events with the Connect mint key; a host signs
 * its proofs with its environment key. ES256 DPoP stays in `../dpop.ts`.
 */
import { ed25519 } from "@noble/curves/ed25519";
import { sha256 } from "@noble/hashes/sha2";

import {
  CONNECT_CLOCK_SKEW_SECONDS,
  CONNECT_HOST_PROOF_MAX_LIFETIME_SECONDS,
  CONNECT_HOST_PROOF_TYPE,
  CONNECT_ISSUER,
  type ConnectHostProofClaimsV1,
} from "./contract.js";

export type ConnectJwsResult<T> =
  | { readonly ok: true; readonly header: Readonly<Record<string, unknown>>; readonly payload: T }
  | { readonly ok: false; readonly reason: string };

const textEncoder = new TextEncoder();
const SPKI_ED25519_PREFIX = Uint8Array.from([
  0x30, 0x2a, 0x30, 0x05, 0x06, 0x03, 0x2b, 0x65, 0x70, 0x03, 0x21, 0x00,
]);
const PKCS8_ED25519_PREFIX = Uint8Array.from([
  0x30, 0x2e, 0x02, 0x01, 0x00, 0x30, 0x05, 0x06, 0x03, 0x2b, 0x65, 0x70, 0x04, 0x22, 0x04, 0x20,
]);

export function bytesToBase64Url(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/gu, "-").replace(/\//gu, "_").replace(/=+$/u, "");
}

export function base64UrlToBytes(value: string): Uint8Array {
  if (value.length % 4 === 1 || !/^[A-Za-z0-9_-]*$/u.test(value)) {
    throw new Error("Invalid base64url value.");
  }
  const padded =
    value.replace(/-/gu, "+").replace(/_/gu, "/") + "=".repeat((4 - (value.length % 4)) % 4);
  const decoded = atob(padded);
  return Uint8Array.from(decoded, (character) => character.charCodeAt(0));
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function startsWith(bytes: Uint8Array, prefix: Uint8Array): boolean {
  return bytes.length >= prefix.length && prefix.every((byte, index) => bytes[index] === byte);
}

function pemBody(pem: string, label: string): Uint8Array {
  const match = new RegExp(
    `-----BEGIN ${label}-----([A-Za-z0-9+/=\\s]+)-----END ${label}-----`,
    "u",
  ).exec(pem);
  if (!match?.[1]) throw new Error(`Expected a ${label} PEM block.`);
  return base64UrlToBytes(
    match[1].replace(/\s+/gu, "").replace(/\+/gu, "-").replace(/\//gu, "_").replace(/=+$/u, ""),
  );
}

/** Raw 32-byte Ed25519 public key from an SPKI PEM (the format T3 hosts store). */
export function ed25519PublicKeyFromSpkiPem(pem: string): Uint8Array {
  const der = pemBody(pem, "PUBLIC KEY");
  if (der.length !== 44 || !startsWith(der, SPKI_ED25519_PREFIX)) {
    throw new Error("Not an Ed25519 SPKI public key.");
  }
  return der.slice(12);
}

export function ed25519PublicKeyToSpkiPem(publicKey: Uint8Array): string {
  if (publicKey.length !== 32) throw new Error("Ed25519 public keys are 32 bytes.");
  const der = new Uint8Array(44);
  der.set(SPKI_ED25519_PREFIX, 0);
  der.set(publicKey, 12);
  const base64 = btoa(String.fromCharCode(...der));
  return `-----BEGIN PUBLIC KEY-----\n${base64}\n-----END PUBLIC KEY-----\n`;
}

/** Raw 32-byte Ed25519 seed from a PKCS8 PEM private key. */
export function ed25519SeedFromPkcs8Pem(pem: string): Uint8Array {
  const der = pemBody(pem, "PRIVATE KEY");
  if (der.length !== 48 || !startsWith(der, PKCS8_ED25519_PREFIX)) {
    throw new Error("Not an Ed25519 PKCS8 private key.");
  }
  return der.slice(16);
}

export function ed25519PublicKeyFromSeed(seed: Uint8Array): Uint8Array {
  return ed25519.getPublicKey(seed);
}

export function signEdDsaJws(input: {
  readonly seed: Uint8Array;
  readonly typ: string;
  readonly kid?: string;
  readonly payload: Readonly<Record<string, unknown>>;
}): string {
  const header = { alg: "EdDSA", typ: input.typ, ...(input.kid ? { kid: input.kid } : {}) };
  const signingInput = `${bytesToBase64Url(textEncoder.encode(JSON.stringify(header)))}.${bytesToBase64Url(
    textEncoder.encode(JSON.stringify(input.payload)),
  )}`;
  const signature = ed25519.sign(textEncoder.encode(signingInput), input.seed);
  return `${signingInput}.${bytesToBase64Url(signature)}`;
}

/** Verify signature and `typ`; claim checks stay with the caller. */
export function verifyEdDsaJws<T = Record<string, unknown>>(input: {
  readonly token: string;
  readonly publicKey: Uint8Array;
  readonly typ: string;
}): ConnectJwsResult<T> {
  const parts = input.token.split(".");
  if (parts.length !== 3 || parts.some((part) => part.length === 0)) {
    return { ok: false, reason: "Invalid compact JWS." };
  }
  const [headerPart, payloadPart, signaturePart] = parts as [string, string, string];
  try {
    const header: unknown = JSON.parse(new TextDecoder().decode(base64UrlToBytes(headerPart)));
    if (!isRecord(header) || header.alg !== "EdDSA" || header.typ !== input.typ) {
      return { ok: false, reason: "Unexpected JWS header." };
    }
    const signature = base64UrlToBytes(signaturePart);
    if (signature.length !== 64) return { ok: false, reason: "Invalid EdDSA signature length." };
    if (
      !ed25519.verify(
        signature,
        textEncoder.encode(`${headerPart}.${payloadPart}`),
        input.publicKey,
      )
    ) {
      return { ok: false, reason: "Invalid EdDSA signature." };
    }
    const payload: unknown = JSON.parse(new TextDecoder().decode(base64UrlToBytes(payloadPart)));
    if (!isRecord(payload)) return { ok: false, reason: "Invalid JWS payload." };
    return { ok: true, header, payload: payload as T };
  } catch {
    return { ok: false, reason: "Invalid compact JWS." };
  }
}

function normalizeHtu(raw: string): string | null {
  try {
    const url = new URL(raw);
    url.hash = "";
    url.search = "";
    return url.toString();
  } catch {
    return null;
  }
}

export function connectBodyHash(body: Uint8Array | string): string {
  return bytesToBase64Url(sha256(typeof body === "string" ? textEncoder.encode(body) : body));
}

export function createConnectHostProof(input: {
  readonly seed: Uint8Array;
  readonly environmentId: string;
  readonly method: ConnectHostProofClaimsV1["htm"];
  readonly url: string;
  readonly nowEpochSeconds: number;
  readonly jti: string;
  readonly body?: Uint8Array | string;
  readonly lifetimeSeconds?: number;
}): string {
  const htu = normalizeHtu(input.url);
  if (!htu) throw new Error("Invalid host proof URL.");
  const lifetime = Math.min(input.lifetimeSeconds ?? 30, CONNECT_HOST_PROOF_MAX_LIFETIME_SECONDS);
  const claims: ConnectHostProofClaimsV1 = {
    iss: `t3-env:${input.environmentId}`,
    aud: CONNECT_ISSUER,
    htm: input.method,
    htu,
    iat: input.nowEpochSeconds,
    exp: input.nowEpochSeconds + lifetime,
    jti: input.jti,
    ...(input.body !== undefined ? { bdh: connectBodyHash(input.body) } : {}),
  };
  return signEdDsaJws({ seed: input.seed, typ: CONNECT_HOST_PROOF_TYPE, payload: { ...claims } });
}

/**
 * Verify a `KombifyHost` proof for one request. The caller enforces `jti`
 * single use with the returned claims.
 */
export function verifyConnectHostProof(input: {
  readonly token: string;
  readonly publicKey: Uint8Array;
  readonly environmentId: string;
  readonly method: string;
  readonly url: string;
  readonly nowEpochSeconds: number;
  readonly body?: Uint8Array | string;
}): ConnectJwsResult<ConnectHostProofClaimsV1> {
  const verified = verifyEdDsaJws<ConnectHostProofClaimsV1>({
    token: input.token,
    publicKey: input.publicKey,
    typ: CONNECT_HOST_PROOF_TYPE,
  });
  if (!verified.ok) return verified;
  const claims = verified.payload;
  const fail = (reason: string): ConnectJwsResult<ConnectHostProofClaimsV1> => ({
    ok: false,
    reason,
  });
  if (claims.iss !== `t3-env:${input.environmentId}` || claims.aud !== CONNECT_ISSUER) {
    return fail("Host proof issuer or audience mismatch.");
  }
  if (typeof claims.htm !== "string" || claims.htm !== input.method.toUpperCase()) {
    return fail("Host proof method mismatch.");
  }
  if (claims.htu !== normalizeHtu(input.url)) return fail("Host proof URL mismatch.");
  if (
    !Number.isSafeInteger(claims.iat) ||
    !Number.isSafeInteger(claims.exp) ||
    claims.exp <= claims.iat ||
    claims.exp - claims.iat > CONNECT_HOST_PROOF_MAX_LIFETIME_SECONDS ||
    claims.iat > input.nowEpochSeconds + CONNECT_CLOCK_SKEW_SECONDS ||
    claims.exp < input.nowEpochSeconds - CONNECT_CLOCK_SKEW_SECONDS
  ) {
    return fail("Host proof lifetime is invalid.");
  }
  if (typeof claims.jti !== "string" || !/^[A-Za-z0-9_-]{22,128}$/u.test(claims.jti)) {
    return fail("Host proof jti is invalid.");
  }
  if (input.body !== undefined || claims.bdh !== undefined) {
    if (input.body === undefined || claims.bdh !== connectBodyHash(input.body)) {
      return fail("Host proof body hash mismatch.");
    }
  }
  return verified;
}
