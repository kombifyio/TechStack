import * as NodeCrypto from "node:crypto";
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

import {
  CONNECT_ISSUER,
  buildConnectDenial,
  createConnectHostLeaseTracker,
  createConnectHostProof,
  ed25519PublicKeyFromSeed,
  ed25519PublicKeyFromSpkiPem,
  ed25519PublicKeyToSpkiPem,
  ed25519SeedFromPkcs8Pem,
  isConnectDocument,
  signEdDsaJws,
  validateConnectReference,
  verifyConnectHostProof,
  verifyEdDsaJws,
  type ConnectLeaseV1,
  type ConnectMintClaimsV1,
  type ConnectSemanticCheckName,
} from "./index.js";

const fixtureDir = fileURLToPath(new URL("./contract/fixtures", import.meta.url));

interface Fixture {
  readonly schema: string;
  readonly expect: "valid" | "invalid";
  readonly error_path?: string;
  readonly semantic?: ConnectSemanticCheckName;
  readonly document: unknown;
}

describe("Connect contract v1 fixtures (kombify-Core)", () => {
  const names = readdirSync(fixtureDir).filter((name) => name.endsWith(".json"));

  it.each(names)("%s", (name) => {
    const fixture = JSON.parse(readFileSync(join(fixtureDir, name), "utf8")) as Fixture;
    const violations = validateConnectReference(fixture.schema, fixture.document, fixture.semantic);
    if (fixture.expect === "valid") {
      expect(violations).toEqual([]);
    } else {
      expect(
        violations.some(
          (violation) =>
            violation.path === fixture.error_path ||
            violation.path.startsWith(`${fixture.error_path}/`),
        ),
      ).toBe(true);
    }
  });
});

describe("Connect denials", () => {
  it("take status and retryability from the registry", () => {
    const denial = buildConnectDenial("connect_host_offline", {
      title: "Environment offline",
      body: "The environment is not connected right now.",
      next_steps: ["Start the Workbench host and try again."],
    });
    expect(denial.status).toBe(503);
    expect(denial.body.retryable).toBe(true);
    expect(isConnectDocument("denial", denial.body)).toBe(true);
  });
});

function ed25519Seed(): Uint8Array {
  const { privateKey } = NodeCrypto.generateKeyPairSync("ed25519");
  return ed25519SeedFromPkcs8Pem(privateKey.export({ format: "pem", type: "pkcs8" }).toString());
}

describe("Connect host proofs", () => {
  const environmentId = "7c1f2d4e-9a3b-4c5d-8e6f-0a1b2c3d4e5f";
  const url = `${CONNECT_ISSUER}/v1/environments/${environmentId}/host-generations`;
  const body = JSON.stringify({ origin: { local_http_port: 13773 } });

  it("verify for the bound request and a Node-generated key", () => {
    const { privateKey, publicKey } = NodeCrypto.generateKeyPairSync("ed25519");
    const seed = ed25519SeedFromPkcs8Pem(
      privateKey.export({ format: "pem", type: "pkcs8" }).toString(),
    );
    const spki = publicKey.export({ format: "pem", type: "spki" }).toString();
    expect(ed25519PublicKeyFromSpkiPem(spki)).toEqual(ed25519PublicKeyFromSeed(seed));
    expect(ed25519PublicKeyToSpkiPem(ed25519PublicKeyFromSpkiPem(spki)).trim()).toBe(spki.trim());

    const proof = createConnectHostProof({
      seed,
      environmentId,
      method: "POST",
      url,
      nowEpochSeconds: 1_790_000_000,
      jti: "Xn4v8kQ2mZ7pT1sL9cW3bR",
      body,
    });
    const verified = verifyConnectHostProof({
      token: proof,
      publicKey: ed25519PublicKeyFromSpkiPem(spki),
      environmentId,
      method: "POST",
      url: `${url}?ignored=1`,
      nowEpochSeconds: 1_790_000_010,
      body,
    });
    expect(verified.ok).toBe(true);
  });

  it("refuse another environment, a changed body, a foreign key and an expired proof", () => {
    const seed = ed25519Seed();
    const publicKey = ed25519PublicKeyFromSeed(seed);
    const proof = createConnectHostProof({
      seed,
      environmentId,
      method: "POST",
      url,
      nowEpochSeconds: 1_790_000_000,
      jti: "Xn4v8kQ2mZ7pT1sL9cW3bR",
      body,
    });
    const base = {
      token: proof,
      publicKey,
      environmentId,
      method: "POST",
      url,
      nowEpochSeconds: 1_790_000_001,
      body,
    };
    expect(verifyConnectHostProof({ ...base, environmentId: "other-environment" }).ok).toBe(false);
    expect(verifyConnectHostProof({ ...base, body: `${body} ` }).ok).toBe(false);
    expect(
      verifyConnectHostProof({ ...base, publicKey: ed25519PublicKeyFromSeed(ed25519Seed()) }).ok,
    ).toBe(false);
    expect(verifyConnectHostProof({ ...base, nowEpochSeconds: 1_790_000_100 }).ok).toBe(false);
    expect(verifyConnectHostProof({ ...base, method: "DELETE" }).ok).toBe(false);
  });

  it("verify only the expected JWS type", () => {
    const seed = ed25519Seed();
    const token = signEdDsaJws({
      seed,
      typ: "kombify-connect-lease+jwt",
      payload: { type: "lease" },
    });
    const publicKey = ed25519PublicKeyFromSeed(seed);
    expect(verifyEdDsaJws({ token, publicKey, typ: "kombify-connect-lease+jwt" }).ok).toBe(true);
    expect(verifyEdDsaJws({ token, publicKey, typ: "kombify-connect-event+jwt" }).ok).toBe(false);
  });
});

describe("Connect host lease", () => {
  const environmentId = "7c1f2d4e-9a3b-4c5d-8e6f-0a1b2c3d4e5f";
  const grant = {
    grant_id: "grt_01J8ZK3Q4V7X9A2B3C4D5E6F7G",
    installation_id: "inst_01J8ZK3Q4V7X9A2B3C4D5E6F7H",
    installation_epoch: 1,
    grant_revision: 2,
    profile: "full-environment",
    capabilities: [],
  } as const;
  const delegation = {
    installationId: grant.installation_id,
    installationEpoch: 1,
    grantId: grant.grant_id,
    grantRevision: 2,
    hostGeneration: 4,
    sessionExpiresAt: 1_790_000_900,
  };

  function setup() {
    let now = 10_000;
    let counter = 0;
    const tracker = createConnectHostLeaseTracker({
      environmentId,
      hostGeneration: 4,
      monotonicNowMs: () => now,
      randomNonce: () => `nonce-${(counter += 1)}-aaaaaaaaaaaaaaaa`,
    });
    const leaseFor = (nonce: string, overrides: Partial<ConnectLeaseV1> = {}): ConnectLeaseV1 => ({
      type: "lease",
      iss: CONNECT_ISSUER,
      aud: `t3-env:${environmentId}`,
      iat: 1_790_000_000,
      exp: 1_790_000_005,
      nonce,
      environment_id: environmentId,
      host_generation: 4,
      grant_version: 3,
      grants: [grant],
      ...overrides,
    });
    return { tracker, leaseFor, advance: (ms: number) => (now += ms) };
  }

  it("authorizes a delegated session only while the lease from the request send time is fresh", () => {
    const { tracker, leaseFor, advance } = setup();
    expect(tracker.authorizeSession(delegation, 1_790_000_001)).toEqual({
      ok: false,
      reason: "lease_missing",
    });
    const request = tracker.nextLeaseRequest();
    advance(900); // slow answer: the deadline still starts at the send time
    expect(tracker.acceptLease(leaseFor(request.nonce)).accepted).toBe(true);
    expect(tracker.authorizeSession(delegation, 1_790_000_001)).toEqual({ ok: true });
    advance(2_101);
    expect(tracker.authorizeSession(delegation, 1_790_000_004)).toEqual({
      ok: false,
      reason: "lease_expired",
    });
  });

  it("fences a revoked grant at once and never revives it from a later lease", () => {
    const { tracker, leaseFor } = setup();
    tracker.acceptLease(leaseFor(tracker.nextLeaseRequest().nonce));
    tracker.acceptRevoke({
      type: "revoke",
      iss: CONNECT_ISSUER,
      aud: `t3-env:${environmentId}`,
      iat: 1_790_000_001,
      environment_id: environmentId,
      grant_id: grant.grant_id,
      installation_id: grant.installation_id,
      grant_version: 4,
      reason: "grant_revoked",
    });
    expect(tracker.authorizeSession(delegation, 1_790_000_001)).toEqual({
      ok: false,
      reason: "grant_missing",
    });
    expect(
      tracker.acceptLease(leaseFor(tracker.nextLeaseRequest().nonce, { grant_version: 3 }))
        .accepted,
    ).toBe(false);
    tracker.acceptLease(leaseFor(tracker.nextLeaseRequest().nonce, { grant_version: 4 }));
    expect(tracker.authorizeSession(delegation, 1_790_000_001)).toEqual({
      ok: false,
      reason: "grant_missing",
    });
  });

  it("refuses replayed or foreign lease answers and stale counters", () => {
    const { tracker, leaseFor } = setup();
    const request = tracker.nextLeaseRequest();
    expect(tracker.acceptLease(leaseFor(request.nonce, { host_generation: 3 })).accepted).toBe(
      false,
    );
    expect(tracker.acceptLease(leaseFor(request.nonce)).accepted).toBe(true);
    expect(tracker.acceptLease(leaseFor(request.nonce)).accepted).toBe(false);
    tracker.acceptLease(leaseFor(tracker.nextLeaseRequest().nonce));
    expect(
      tracker.authorizeSession({ ...delegation, installationEpoch: 0 }, 1_790_000_001),
    ).toEqual({
      ok: false,
      reason: "installation_epoch_stale",
    });
    expect(tracker.authorizeSession({ ...delegation, hostGeneration: 3 }, 1_790_000_001)).toEqual({
      ok: false,
      reason: "generation_mismatch",
    });
    tracker.supersede();
    expect(tracker.authorizeSession(delegation, 1_790_000_001)).toEqual({
      ok: false,
      reason: "generation_superseded",
    });
  });

  it("mints only for the lease's grant, scopes and a known grant version", () => {
    const { tracker, leaseFor } = setup();
    tracker.acceptLease(leaseFor(tracker.nextLeaseRequest().nonce));
    const claims: ConnectMintClaimsV1 = {
      installation_id: grant.installation_id,
      installation_epoch: 1,
      grant_id: grant.grant_id,
      grant_revision: 2,
      grant_version: 3,
      host_generation: 4,
      profile: "full-environment",
      capabilities: [],
      t3_scopes: ["orchestration:read", "orchestration:operate", "review:write", "relay:read"],
      session_expires_at: 1_790_000_900,
    };
    expect(tracker.authorizeMint(claims, 1_790_000_001)).toEqual({ ok: true });
    expect(
      tracker.authorizeMint(
        {
          ...claims,
          capabilities: ["terminal"],
          t3_scopes: [...claims.t3_scopes, "terminal:operate"],
        },
        1_790_000_001,
      ),
    ).toEqual({ ok: false, reason: "scope_mismatch" });
    expect(tracker.authorizeMint({ ...claims, grant_version: 5 }, 1_790_000_001)).toEqual({
      ok: false,
      reason: "host_state_stale",
    });
  });
});
