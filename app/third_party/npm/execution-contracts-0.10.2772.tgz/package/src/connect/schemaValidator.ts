import { validateSchemaDocuments, type SchemaViolation } from "../schemaValidator.js";
import { connectSchemaDocuments } from "./contract/schemas.generated.js";

export type ConnectSchemaViolation = SchemaViolation;

/** Validate a value against a pinned Connect v1 schema reference. */
export function validateConnectSchema(
  ref: string,
  value: unknown,
): readonly ConnectSchemaViolation[] {
  return validateSchemaDocuments(connectSchemaDocuments, "Connect", ref, value);
}
