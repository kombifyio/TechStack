/**
 * kombify Connect contract v1 (kombify-Core/standards/CONNECT-CONTRACT-STANDARD.md).
 *
 * Wire documents are snake_case JSON. Timestamps are ISO-8601 strings in API
 * documents and epoch seconds inside signed JWT payloads.
 */
import { connectReasonCodeRegistry, type ConnectReasonCode } from "./contract/schemas.generated.js";
import { validateConnectSchema, type ConnectSchemaViolation } from "./schemaValidator.js";

export type { ConnectReasonCode } from "./contract/schemas.generated.js";
export type { ConnectSchemaViolation } from "./schemaValidator.js";

export const CONNECT_CONTRACT = "kombify-connect.v1" as const;
export const CONNECT_ISSUER = "https://connect.kombify.io" as const;
export const CONNECT_DISCOVERY_PATH = "/.well-known/kombify-connect" as const;
export const CONNECT_HOST_PROOF_TYPE = "kombify-connect-host+jwt" as const;
export const CONNECT_LEASE_TYPE = "kombify-connect-lease+jwt" as const;
export const CONNECT_EVENT_TYPE = "kombify-connect-event+jwt" as const;
export const CONNECT_HOST_AUTHORIZATION_SCHEME = "KombifyHost" as const;
/** Host-side T3 mint request type the Gateway signs. */
export const CONNECT_T3_MINT_REQUEST_TYPE = "t3-cloud-mint+jwt" as const;
export const CONNECT_T3_MINT_RESPONSE_TYPE = "t3-env-mint+jwt" as const;
export const CONNECT_T3_LINK_PROOF_TYPE = "t3-env-link+jwt" as const;

export const CONNECT_PAIRING_MAX_LIFETIME_SECONDS = 600 as const;
export const CONNECT_LINK_CHALLENGE_MAX_LIFETIME_SECONDS = 600 as const;
export const CONNECT_INSTALLATION_CHALLENGE_MAX_LIFETIME_SECONDS = 120 as const;
export const CONNECT_SESSION_MAX_LIFETIME_SECONDS = 900 as const;
export const CONNECT_MINT_REQUEST_MAX_LIFETIME_SECONDS = 120 as const;
export const CONNECT_HOST_PROOF_MAX_LIFETIME_SECONDS = 60 as const;
export const CONNECT_LEASE_MAX_LIFETIME_SECONDS = 5 as const;
export const CONNECT_LEASE_REQUEST_INTERVAL_MS = 1000 as const;
export const CONNECT_LEASE_GRACE_MS = 3000 as const;
export const CONNECT_CLOCK_SKEW_SECONDS = 5 as const;

export const CONNECT_CLOSE_UNLINKED = 4001 as const;
export const CONNECT_CLOSE_PROTOCOL_VIOLATION = 4008 as const;
export const CONNECT_CLOSE_GENERATION_SUPERSEDED = 4009 as const;

export type ConnectAppId =
  | "workbench-desktop"
  | "workbench-mobile"
  | "companion"
  | "techstack-windows"
  | "speechkit-desktop";
export type ConnectPlatform = "windows" | "macos" | "linux" | "android" | "ios";
export type ConnectCustodyClass = "hardware" | "os-protected" | "software";
export type ConnectInstallationStatus = "pending" | "active" | "revoked";
export type ConnectProfile = "full-environment";
export type ConnectCapability = "terminal";
export type ConnectT3Scope =
  | "orchestration:read"
  | "orchestration:operate"
  | "terminal:operate"
  | "review:write"
  | "relay:read";

export interface ConnectEndpointV1 {
  readonly http_base_url: string;
  readonly ws_base_url: string;
  readonly provider_kind: "cloudflare_tunnel";
}

export interface ConnectEd25519PublicJwk {
  readonly kty: "OKP";
  readonly crv: "Ed25519";
  readonly x: string;
  readonly kid: string;
}

export interface ConnectDiscoveryV1 {
  readonly version: "1";
  readonly contract: typeof CONNECT_CONTRACT;
  readonly instance_id: string;
  readonly connect_origin: string;
  readonly api_base_url: string;
  readonly dpop_signing_alg_values_supported: readonly ["ES256"];
  readonly host_proof_alg_values_supported: readonly ["EdDSA"];
  readonly mint_keys: readonly {
    readonly status: "active" | "next" | "retiring";
    readonly jwk: ConnectEd25519PublicJwk;
  }[];
  readonly custody_classes: readonly ConnectCustodyClass[];
  readonly profiles: readonly ConnectProfile[];
  readonly capabilities: readonly ConnectCapability[];
  readonly limits: {
    readonly pairing_max_lifetime_seconds: number;
    readonly session_max_lifetime_seconds: number;
    readonly lease_request_interval_ms: number;
    readonly lease_grace_ms: number;
  };
}

export interface ConnectChallengeV1 {
  readonly challenge: string;
  readonly expires_at: string;
}

export interface ConnectInstallationRegistrationV1 {
  readonly challenge: string;
  readonly app_id: ConnectAppId;
  readonly platform: ConnectPlatform;
  readonly custody_class: ConnectCustodyClass;
  readonly display_name: string;
  readonly app_version: string;
  /** Display-only machine grouping (contract section 2); never an authority. */
  readonly device_ref?: string;
}

export interface ConnectInstallationV1 {
  readonly installation_id: string;
  readonly org_id: string;
  readonly subject_id: string;
  readonly oauth_client_id: string;
  readonly app_id: ConnectAppId;
  readonly platform: ConnectPlatform;
  readonly custody_class: ConnectCustodyClass;
  readonly display_name: string;
  readonly app_version: string;
  readonly dpop_jkt: string;
  readonly status: ConnectInstallationStatus;
  readonly installation_epoch: number;
  readonly created_at: string;
  readonly confirmed_at?: string;
  readonly revoked_at?: string;
  readonly last_seen_at?: string;
  readonly device_ref?: string;
}

/** One environment an installation holds an active grant on (contract section 9.1). */
export interface ConnectDeviceEnvironmentV1 {
  readonly environment_id: string;
  readonly label: string;
  readonly role: "owner" | "grantee";
  readonly status: "linked" | "unlinked";
}

export interface ConnectDeviceInstallationV1 {
  readonly installation_id: string;
  readonly app_id: ConnectAppId;
  readonly platform: ConnectPlatform;
  readonly custody_class: ConnectCustodyClass;
  readonly display_name: string;
  readonly app_version: string;
  readonly status: ConnectInstallationStatus;
  readonly created_at: string;
  readonly last_seen_at?: string;
  readonly environments: readonly ConnectDeviceEnvironmentV1[];
}

export interface ConnectDeviceV1 {
  /** The `device_ref`, or the installation id of an ungrouped installation. */
  readonly device_id: string;
  readonly grouping: "device_ref" | "installation";
  readonly display_name: string;
  readonly platform: ConnectPlatform;
  readonly last_seen_at?: string;
  readonly installations: readonly ConnectDeviceInstallationV1[];
}

/** `GET https://api.kombify.io/v1/connect/devices` (contract section 9.1). */
export interface ConnectDeviceListV1 {
  readonly devices: readonly ConnectDeviceV1[];
  readonly scope: "subject";
  readonly generated_at: string;
}

export interface ConnectGrantV1 {
  readonly grant_id: string;
  readonly environment_id: string;
  readonly installation_id: string;
  readonly subject_id: string;
  readonly org_id: string;
  readonly profile: ConnectProfile;
  readonly capabilities: readonly ConnectCapability[];
  readonly status: "active" | "revoked";
  readonly grant_revision: number;
  readonly created_at: string;
  readonly created_by_installation_id: string;
  readonly revoked_at?: string;
}

export interface ConnectLeaseGrantV1 {
  readonly grant_id: string;
  readonly installation_id: string;
  readonly installation_epoch: number;
  readonly grant_revision: number;
  readonly profile: ConnectProfile;
  readonly capabilities: readonly ConnectCapability[];
}

export interface ConnectLinkChallengeRequestV1 {
  readonly environment_id: string;
}

export interface ConnectLinkChallengeV1 extends ConnectChallengeV1 {
  readonly endpoint: ConnectEndpointV1;
}

export interface ConnectLinkRequestV1 {
  readonly proof: string;
  readonly label: string;
}

export interface ConnectHostRuntimeV1 {
  readonly provider_kind: "cloudflare_tunnel";
  readonly connector_token: string;
  readonly tunnel_id: string;
  readonly tunnel_name: string;
}

export interface ConnectHostConfigV1 {
  readonly issuer: typeof CONNECT_ISSUER;
  readonly owner_subject_id: string;
  readonly mint_public_key_pem: string;
  readonly mint_key_id: string;
  readonly host_runtime: ConnectHostRuntimeV1;
}

export interface ConnectEnvironmentV1 {
  readonly environment_id: string;
  readonly host_id: string;
  readonly label: string;
  readonly endpoint: ConnectEndpointV1;
  readonly linked_at: string;
  readonly status: "linked" | "unlinked";
}

export interface ConnectEnvironmentLinkV1 {
  readonly environment: ConnectEnvironmentV1;
  readonly grant: ConnectGrantV1;
  readonly installation: ConnectInstallationV1;
  readonly host_config: ConnectHostConfigV1;
}

export interface ConnectEnvironmentSummaryV1 {
  readonly environment_id: string;
  readonly label: string;
  readonly endpoint: ConnectEndpointV1;
  readonly linked_at: string;
  readonly role: "owner" | "grantee";
  readonly grant_id: string;
  readonly host_online: boolean;
}

export interface ConnectEnvironmentCredentialRequestV1 {
  readonly client_key_thumbprint: string;
}

export interface ConnectEnvironmentCredentialV1 {
  readonly environment_id: string;
  readonly endpoint: ConnectEndpointV1;
  readonly credential: string;
  readonly expires_at: string;
  readonly session_expires_at: string;
  readonly grant_id: string;
  readonly host_generation: number;
}

/** Value of the `kombify_connect` claim in the Gateway-signed T3 mint request. */
export interface ConnectMintClaimsV1 {
  readonly installation_id: string;
  readonly installation_epoch: number;
  readonly grant_id: string;
  readonly grant_revision: number;
  readonly grant_version: number;
  readonly host_generation: number;
  readonly profile: ConnectProfile;
  readonly capabilities: readonly ConnectCapability[];
  readonly t3_scopes: readonly ConnectT3Scope[];
  /** Epoch seconds. */
  readonly session_expires_at: number;
}

export interface ConnectHostGenerationRequestV1 {
  readonly origin: { readonly local_http_port: number };
  readonly host_custody_class: ConnectCustodyClass;
  readonly server_version: string;
}

export interface ConnectHostGenerationV1 {
  readonly environment_id: string;
  readonly host_generation: number;
  readonly grant_version: number;
  readonly socket_url: string;
  readonly lease: { readonly request_interval_ms: number; readonly grace_ms: number };
  readonly host_runtime: ConnectHostRuntimeV1;
}

export interface ConnectLeaseRequestV1 {
  readonly type: "lease-request";
  readonly nonce: string;
  readonly host_generation: number;
  readonly seq: number;
}

export interface ConnectSignedMessageV1 {
  readonly type: "signed";
  readonly jws: string;
}

export interface ConnectLeaseV1 {
  readonly type: "lease";
  readonly iss: typeof CONNECT_ISSUER;
  readonly aud: string;
  readonly iat: number;
  readonly exp: number;
  readonly nonce: string;
  readonly environment_id: string;
  readonly host_generation: number;
  readonly grant_version: number;
  readonly grants: readonly ConnectLeaseGrantV1[];
}

export interface ConnectRevokeEventV1 {
  readonly type: "revoke";
  readonly iss: typeof CONNECT_ISSUER;
  readonly aud: string;
  readonly iat: number;
  readonly environment_id: string;
  readonly grant_id: string;
  readonly installation_id: string;
  readonly grant_version: number;
  readonly reason: "grant_revoked" | "installation_revoked" | "environment_unlinked";
}

export interface ConnectGrantChangedEventV1 {
  readonly type: "grant-changed";
  readonly iss: typeof CONNECT_ISSUER;
  readonly aud: string;
  readonly iat: number;
  readonly environment_id: string;
  readonly grant_version: number;
}

export interface ConnectHostProofClaimsV1 {
  readonly iss: string;
  readonly aud: typeof CONNECT_ISSUER;
  readonly htm: "GET" | "POST" | "DELETE";
  readonly htu: string;
  readonly iat: number;
  readonly exp: number;
  readonly jti: string;
  readonly bdh?: string;
}

export interface ConnectPairingEnvelopeV1 {
  readonly version: "1";
  readonly endpoint: string;
  readonly instance_id: string;
  readonly tls_fingerprint_sha256: string;
  readonly one_time_code: string;
  readonly issued_at: string;
  readonly expires_at: string;
}

export interface ConnectPairingOfferRequestV1 {
  readonly environment_ids: readonly string[];
  readonly profile: ConnectProfile;
  readonly capabilities: readonly ConnectCapability[];
}

export interface ConnectPairingOfferV1 {
  readonly offer_id: string;
  readonly pairing: ConnectPairingEnvelopeV1;
}

export interface ConnectPairingRedeemRequestV1 {
  readonly one_time_code: string;
}

export interface ConnectPairingRedeemResultV1 {
  readonly installation: ConnectInstallationV1;
  readonly grants: readonly ConnectGrantV1[];
}

export interface ConnectDenialV1 {
  readonly error: ConnectReasonCode;
  readonly error_code: ConnectReasonCode;
  readonly reason_code: ConnectReasonCode;
  readonly retryable: boolean;
  readonly user_guidance: {
    readonly title: string;
    readonly body: string;
    readonly next_steps: readonly string[];
  };
  readonly details?: {
    readonly environment_id?: string;
    readonly installation_id?: string;
    readonly grant_id?: string;
    readonly host_generation?: number;
    readonly retry_after_ms?: number;
    readonly request_id?: string;
  };
}

/** Every Connect wire document, keyed by its contract name. */
export interface ConnectDocuments {
  readonly discovery: ConnectDiscoveryV1;
  readonly installationChallenge: ConnectChallengeV1;
  readonly installationRegistration: ConnectInstallationRegistrationV1;
  readonly installation: ConnectInstallationV1;
  readonly installationList: { readonly installations: readonly ConnectInstallationV1[] };
  readonly deviceList: ConnectDeviceListV1;
  readonly linkChallengeRequest: ConnectLinkChallengeRequestV1;
  readonly linkChallenge: ConnectLinkChallengeV1;
  readonly linkRequest: ConnectLinkRequestV1;
  readonly environmentLink: ConnectEnvironmentLinkV1;
  readonly environmentList: { readonly environments: readonly ConnectEnvironmentSummaryV1[] };
  readonly grant: ConnectGrantV1;
  readonly grantList: {
    readonly environment_id: string;
    readonly grant_version: number;
    readonly grants: readonly ConnectGrantV1[];
  };
  readonly credentialRequest: ConnectEnvironmentCredentialRequestV1;
  readonly credential: ConnectEnvironmentCredentialV1;
  readonly mintClaims: ConnectMintClaimsV1;
  readonly hostGenerationRequest: ConnectHostGenerationRequestV1;
  readonly hostGeneration: ConnectHostGenerationV1;
  readonly leaseRequest: ConnectLeaseRequestV1;
  readonly signedMessage: ConnectSignedMessageV1;
  readonly lease: ConnectLeaseV1;
  readonly revokeEvent: ConnectRevokeEventV1;
  readonly grantChangedEvent: ConnectGrantChangedEventV1;
  readonly hostProof: ConnectHostProofClaimsV1;
  readonly pairingOfferRequest: ConnectPairingOfferRequestV1;
  readonly pairingOffer: ConnectPairingOfferV1;
  readonly pairingRedeemRequest: ConnectPairingRedeemRequestV1;
  readonly pairingRedeemResult: ConnectPairingRedeemResultV1;
  readonly denial: ConnectDenialV1;
}

export type ConnectDocumentKind = keyof ConnectDocuments;

type SemanticCheck = (value: never) => readonly ConnectSchemaViolation[];

const BASE_T3_SCOPES: readonly ConnectT3Scope[] = [
  "orchestration:read",
  "orchestration:operate",
  "review:write",
  "relay:read",
];

const FORBIDDEN_KEY = /(secret|token|password|credential|privatekey|private_key|apikey|api_key)/iu;

function forbiddenKeys(value: unknown, at = ""): ConnectSchemaViolation[] {
  if (value === null || typeof value !== "object") return [];
  return Object.entries(value).flatMap(([key, child]) => [
    ...(FORBIDDEN_KEY.test(key)
      ? [{ path: `${at}/${key}`, message: "secret-like key is forbidden" }]
      : []),
    ...forbiddenKeys(child, `${at}/${key}`),
  ]);
}

/** T3 environment scopes a Connect grant delegates. `access:*` and `relay:write` are never delegated. */
export function connectT3ScopesFor(
  profile: ConnectProfile,
  capabilities: readonly ConnectCapability[],
): readonly ConnectT3Scope[] {
  if (profile !== "full-environment") return [];
  return capabilities.includes("terminal")
    ? [...BASE_T3_SCOPES, "terminal:operate"]
    : BASE_T3_SCOPES;
}

/** Semantic rules the JSON Schemas cannot express; named as in the Core fixtures. */
export const connectSemanticChecks = {
  discovery: (value: ConnectDiscoveryV1) => forbiddenKeys(value),
  scope_mapping: (value: ConnectMintClaimsV1) => {
    const expected = new Set<string>(connectT3ScopesFor(value.profile, value.capabilities ?? []));
    const actual = new Set<string>(value.t3_scopes ?? []);
    const violations: ConnectSchemaViolation[] = [];
    if (BASE_T3_SCOPES.some((scope) => !actual.has(scope))) {
      violations.push({ path: "/t3_scopes", message: "full-environment requires the base scopes" });
    }
    if (actual.has("terminal:operate") !== expected.has("terminal:operate")) {
      violations.push({
        path: "/t3_scopes",
        message: "terminal:operate requires exactly the terminal capability",
      });
    }
    return violations;
  },
  credential_lifetime: (value: ConnectEnvironmentCredentialV1) => {
    const session = Date.parse(value.session_expires_at);
    const bootstrap = Date.parse(value.expires_at);
    return session - bootstrap > CONNECT_SESSION_MAX_LIFETIME_SECONDS * 1000 ||
      session <= bootstrap - CONNECT_MINT_REQUEST_MAX_LIFETIME_SECONDS * 1000
      ? [
          {
            path: "/session_expires_at",
            message: "session must end within 900 s of the bootstrap credential",
          },
        ]
      : [];
  },
  lease_lifetime: (value: ConnectLeaseV1) =>
    value.exp - value.iat < 1 || value.exp - value.iat > CONNECT_LEASE_MAX_LIFETIME_SECONDS
      ? [{ path: "/exp", message: "lease lifetime must be 1-5 s" }]
      : [],
  host_proof_lifetime: (value: ConnectHostProofClaimsV1) =>
    value.exp - value.iat < 1 || value.exp - value.iat > CONNECT_HOST_PROOF_MAX_LIFETIME_SECONDS
      ? [{ path: "/exp", message: "host proof lifetime must be 1-60 s" }]
      : [],
  pairing_lifetime: (value: ConnectPairingOfferV1) => {
    const span = Date.parse(value.pairing?.expires_at) - Date.parse(value.pairing?.issued_at);
    return span > 0 && span <= CONNECT_PAIRING_MAX_LIFETIME_SECONDS * 1000
      ? []
      : [{ path: "/pairing/expires_at", message: "pairing lifetime must be at most 600 s" }];
  },
  denial_registry: (value: ConnectDenialV1) => {
    const entry = (connectReasonCodeRegistry as Readonly<Record<string, { retryable: boolean }>>)[
      value.reason_code
    ];
    if (!entry) return [{ path: "/reason_code", message: "reason code is not registered" }];
    const violations: ConnectSchemaViolation[] = [];
    if (value.error_code !== value.reason_code || value.error !== value.reason_code) {
      violations.push({
        path: "/error_code",
        message: "error, error_code and reason_code must agree",
      });
    }
    if (value.retryable !== entry.retryable) {
      violations.push({ path: "/retryable", message: "retryable differs from registry" });
    }
    return [...violations, ...forbiddenKeys(value)];
  },
} satisfies Readonly<Record<string, SemanticCheck>>;

export type ConnectSemanticCheckName = keyof typeof connectSemanticChecks;

const DOCUMENTS: Readonly<
  Record<
    ConnectDocumentKind,
    { readonly ref: string; readonly semantic?: ConnectSemanticCheckName }
  >
> = {
  discovery: { ref: "connect-discovery.v1.schema.json", semantic: "discovery" },
  installationChallenge: { ref: "connect-installation.v1.schema.json#/$defs/challenge" },
  installationRegistration: { ref: "connect-installation.v1.schema.json#/$defs/registration" },
  installation: { ref: "connect-installation.v1.schema.json#/$defs/installation" },
  installationList: { ref: "connect-installation.v1.schema.json#/$defs/installation_list" },
  deviceList: { ref: "connect-installation.v1.schema.json#/$defs/device_list" },
  linkChallengeRequest: { ref: "connect-environment.v1.schema.json#/$defs/link_challenge_request" },
  linkChallenge: { ref: "connect-environment.v1.schema.json#/$defs/link_challenge" },
  linkRequest: { ref: "connect-environment.v1.schema.json#/$defs/link_request" },
  environmentLink: { ref: "connect-environment.v1.schema.json#/$defs/link" },
  environmentList: { ref: "connect-environment.v1.schema.json#/$defs/environment_list" },
  grant: { ref: "connect-grant.v1.schema.json#/$defs/grant" },
  grantList: { ref: "connect-grant.v1.schema.json#/$defs/grant_list" },
  credentialRequest: { ref: "connect-credential.v1.schema.json#/$defs/request" },
  credential: {
    ref: "connect-credential.v1.schema.json#/$defs/credential",
    semantic: "credential_lifetime",
  },
  mintClaims: {
    ref: "connect-credential.v1.schema.json#/$defs/mint_claims",
    semantic: "scope_mapping",
  },
  hostGenerationRequest: { ref: "connect-host-control.v1.schema.json#/$defs/generation_request" },
  hostGeneration: { ref: "connect-host-control.v1.schema.json#/$defs/generation" },
  leaseRequest: { ref: "connect-host-control.v1.schema.json#/$defs/lease_request" },
  signedMessage: { ref: "connect-host-control.v1.schema.json#/$defs/signed_message" },
  lease: { ref: "connect-host-control.v1.schema.json#/$defs/lease", semantic: "lease_lifetime" },
  revokeEvent: { ref: "connect-host-control.v1.schema.json#/$defs/revoke_event" },
  grantChangedEvent: { ref: "connect-host-control.v1.schema.json#/$defs/grant_changed_event" },
  hostProof: {
    ref: "connect-host-control.v1.schema.json#/$defs/host_proof",
    semantic: "host_proof_lifetime",
  },
  pairingOfferRequest: { ref: "connect-pairing.v1.schema.json#/$defs/offer_request" },
  pairingOffer: {
    ref: "connect-pairing.v1.schema.json#/$defs/offer",
    semantic: "pairing_lifetime",
  },
  pairingRedeemRequest: { ref: "connect-pairing.v1.schema.json#/$defs/redeem_request" },
  pairingRedeemResult: { ref: "connect-pairing.v1.schema.json#/$defs/redeem_result" },
  denial: { ref: "connect-denial.v1.schema.json", semantic: "denial_registry" },
};

/** Validate a document against a schema reference and an optional named semantic check. */
export function validateConnectReference(
  ref: string,
  value: unknown,
  semantic?: ConnectSemanticCheckName,
): readonly ConnectSchemaViolation[] {
  const violations = validateConnectSchema(ref, value);
  if (!semantic || violations.length > 0) return violations;
  return (connectSemanticChecks[semantic] as (input: unknown) => readonly ConnectSchemaViolation[])(
    value,
  );
}

export function validateConnectDocument<K extends ConnectDocumentKind>(
  kind: K,
  value: unknown,
): readonly ConnectSchemaViolation[] {
  const { ref, semantic } = DOCUMENTS[kind];
  return validateConnectReference(ref, value, semantic);
}

export function isConnectDocument<K extends ConnectDocumentKind>(
  kind: K,
  value: unknown,
): value is ConnectDocuments[K] {
  return validateConnectDocument(kind, value).length === 0;
}

/** Build a registry-conformant denial; status and retryability come from the registry. */
export function buildConnectDenial(
  reason: ConnectReasonCode,
  guidance: ConnectDenialV1["user_guidance"],
  details?: ConnectDenialV1["details"],
): { readonly status: number; readonly body: ConnectDenialV1 } {
  const entry = connectReasonCodeRegistry[reason];
  return {
    status: entry.status,
    body: {
      error: reason,
      error_code: reason,
      reason_code: reason,
      retryable: entry.retryable,
      user_guidance: guidance,
      ...(details ? { details } : {}),
    },
  };
}

export { connectReasonCodeRegistry };
