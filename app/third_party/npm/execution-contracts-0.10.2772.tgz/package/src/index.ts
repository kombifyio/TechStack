/** Version carried by every persisted execution session and receipt. */
export const EXECUTION_CONTRACT_VERSION = "v1" as const;

export * from "./authority/index.js";

export type ScopeV1 =
  | "workspace.read"
  | "workspace.write"
  | "terminal.exec"
  | "network.egress"
  | "browser.control"
  | "server.dispatch"
  | "payment.authorize"
  | "artifact.publish";

export type PermissionModeV1 = "supervised" | "edit-enabled" | "autonomous" | "full-local";

export type ExecutionEnvironmentKindV1 = "local-node" | "kombify-cloud" | "cloudflare";
export type ExecutionEnvironmentAvailabilityV1 = "available" | "degraded" | "unavailable";
export type ExecutionEnvironmentResidencyV1 = "local" | "kombify-cloud" | "cloudflare-edge";

export interface ExecutionEnvironmentV1 {
  readonly id: string;
  readonly kind: ExecutionEnvironmentKindV1;
  readonly displayName: string;
  readonly capabilities: readonly string[];
  readonly availability: ExecutionEnvironmentAvailabilityV1;
  readonly dataResidency: ExecutionEnvironmentResidencyV1;
}

export type ExecutionCommandKindV1 = "start-run" | "send-input" | "approve" | "cancel" | "replay";

export interface ExecutionCommandV1 {
  readonly commandId: string;
  readonly idempotencyKey: string;
  readonly environmentId: ExecutionEnvironmentV1["id"];
  readonly kind: ExecutionCommandKindV1;
  readonly issuedAt: string;
  readonly permissionMode: PermissionModeV1;
  readonly grantedScopes: readonly ScopeV1[];
  readonly payload?: Readonly<Record<string, unknown>>;
}

export type ExecutionEventKindV1 =
  | "receipt"
  | "run-started"
  | "run-completed"
  | "progress"
  | "output"
  | "tool-call"
  | "approval-required"
  | "approval-resolved"
  | "checkpoint"
  | "artifact"
  | "state"
  | "cancelled"
  | "replayed"
  | "failed";

export interface ExecutionEventV1 {
  readonly eventId: string;
  readonly environmentId: ExecutionEnvironmentV1["id"];
  readonly kind: ExecutionEventKindV1;
  readonly sequence: number;
  readonly occurredAt: string;
  readonly commandId?: ExecutionCommandV1["commandId"];
  readonly runId?: string;
  readonly receiptId?: string;
  readonly payload?: Readonly<Record<string, unknown>>;
}

export type ExecutionSessionStatusV1 = "active" | "closed";
export type ExecutionRunStateV1 =
  | "idle"
  | "running"
  | "waiting_approval"
  | "completed"
  | "failed"
  | "cancelled";

export interface ExecutionSessionV1 {
  readonly version: typeof EXECUTION_CONTRACT_VERSION;
  readonly sessionId: string;
  readonly orgId: string;
  readonly ownerId: string;
  readonly runId?: string;
  readonly environment: ExecutionEnvironmentV1;
  readonly status: ExecutionSessionStatusV1;
  readonly runState: ExecutionRunStateV1;
  readonly createdAt: string;
  readonly updatedAt: string;
  readonly nextSequence: number;
}

export interface ExecutionReceiptV1 {
  readonly version: typeof EXECUTION_CONTRACT_VERSION;
  readonly receiptId: string;
  readonly idempotencyKey: string;
  readonly commandId: ExecutionCommandV1["commandId"];
  readonly event: ExecutionEventV1;
}

export interface ExecutionReasonEnvelopeV1 {
  readonly error_code: string;
  readonly reason_code: string;
  readonly retryable: boolean;
  readonly user_guidance: string;
}

export interface ApprovalRequestV1 {
  readonly approvalId: string;
  readonly harnessId: string;
  readonly requestedScopes: readonly ScopeV1[];
  readonly summary: string;
  readonly requestedAt: string;
  readonly expiresAt: string;
  readonly reason: ExecutionReasonEnvelopeV1;
}

export const EXECUTION_SCOPES: readonly ScopeV1[] = [
  "workspace.read",
  "workspace.write",
  "terminal.exec",
  "network.egress",
  "browser.control",
  "server.dispatch",
  "payment.authorize",
  "artifact.publish",
];

export const EXECUTION_COMMAND_KINDS: readonly ExecutionCommandKindV1[] = [
  "start-run",
  "send-input",
  "approve",
  "cancel",
  "replay",
];

export const EXECUTION_EVENT_KINDS: readonly ExecutionEventKindV1[] = [
  "receipt",
  "run-started",
  "run-completed",
  "progress",
  "output",
  "tool-call",
  "approval-required",
  "approval-resolved",
  "checkpoint",
  "artifact",
  "state",
  "cancelled",
  "replayed",
  "failed",
];

export const EXECUTION_PERMISSION_MODES: readonly PermissionModeV1[] = [
  "supervised",
  "edit-enabled",
  "autonomous",
  "full-local",
];

export function isExecutionScope(value: unknown): value is ScopeV1 {
  return typeof value === "string" && (EXECUTION_SCOPES as readonly string[]).includes(value);
}

export function isExecutionCommandKind(value: unknown): value is ExecutionCommandKindV1 {
  return (
    typeof value === "string" && (EXECUTION_COMMAND_KINDS as readonly string[]).includes(value)
  );
}

export function isExecutionEventKind(value: unknown): value is ExecutionEventKindV1 {
  return typeof value === "string" && (EXECUTION_EVENT_KINDS as readonly string[]).includes(value);
}

export function isPermissionMode(value: unknown): value is PermissionModeV1 {
  return (
    typeof value === "string" && (EXECUTION_PERMISSION_MODES as readonly string[]).includes(value)
  );
}

export function isExecutionEnvironment(value: unknown): value is ExecutionEnvironmentV1 {
  if (!isRecord(value)) return false;
  return (
    typeof value.id === "string" &&
    value.id.trim().length > 0 &&
    (value.kind === "local-node" ||
      value.kind === "kombify-cloud" ||
      value.kind === "cloudflare") &&
    typeof value.displayName === "string" &&
    value.displayName.trim().length > 0 &&
    Array.isArray(value.capabilities) &&
    value.capabilities.every((entry) => typeof entry === "string") &&
    (value.availability === "available" ||
      value.availability === "degraded" ||
      value.availability === "unavailable") &&
    (value.dataResidency === "local" ||
      value.dataResidency === "kombify-cloud" ||
      value.dataResidency === "cloudflare-edge")
  );
}

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Stable JSON for replay/conflict comparisons, independent of object key order. */
export function canonicalJson(value: unknown): string {
  if (value === undefined) return "undefined";
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map((entry) => canonicalJson(entry)).join(",")}]`;
  const record = value as Record<string, unknown>;
  return `{${Object.keys(record)
    .sort()
    .map((key) => `${JSON.stringify(key)}:${canonicalJson(record[key])}`)
    .join(",")}}`;
}

/** Provider credentials must never cross the public execution wire. */
export function containsProviderCredentialKey(value: unknown): boolean {
  if (Array.isArray(value)) return value.some(containsProviderCredentialKey);
  if (!isRecord(value)) return false;
  for (const [key, nested] of Object.entries(value)) {
    const normalizedKey = key.replace(/[^a-z0-9]/gi, "").toLowerCase();
    const credentialKey = [
      "apikey",
      "accesstoken",
      "refreshtoken",
      "clientsecret",
      "bearertoken",
      "privatekey",
      "secret",
      "password",
      "authorization",
      "credential",
      "token",
    ].some((needle) =>
      needle === "token"
        ? normalizedKey === needle || normalizedKey.endsWith(needle)
        : normalizedKey.includes(needle),
    );
    if (credentialKey || containsProviderCredentialKey(nested)) return true;
  }
  return false;
}

/**
 * A short-lived grant for one connected desktop execution client.
 *
 * This is the decoded, product-neutral contract. It is deliberately not an
 * access-token shape and contains no provider credential. Gateway and client
 * authorities bind the grant to a DPoP key, audience, environment, methods,
 * scopes, and a bounded lifetime before using it.
 */
export interface DesktopExecutionTicketV1 {
  readonly version: typeof EXECUTION_CONTRACT_VERSION;
  readonly ticketId: string;
  readonly orgId: string;
  readonly subjectId: string;
  readonly deviceId: string;
  readonly environmentId: ExecutionEnvironmentV1["id"];
  readonly audience: string;
  readonly dpopThumbprint: string;
  readonly allowedMethods: readonly string[];
  readonly scopes: readonly ScopeV1[];
  /** Unix epoch seconds, matching DPoP iat/exp comparisons. */
  readonly issuedAt: number;
  readonly expiresAt: number;
}

export const DESKTOP_EXECUTION_TICKET_MAX_LIFETIME_SECONDS = 300 as const;
export const DESKTOP_EXECUTION_TICKET_CLOCK_SKEW_SECONDS = 5 as const;

export interface DesktopExecutionTicketAllowlistInputV1 {
  readonly expectedAudience: string;
  readonly expectedOrgId: string;
  readonly expectedSubjectId: string;
  readonly expectedDeviceId: string;
  readonly expectedEnvironmentId: string;
  /** RPC method identifiers are case-sensitive and must match exactly. */
  readonly method: string;
  readonly nowEpochSeconds: number;
  /** Supplying this is mandatory at runtime; omission fails closed. */
  readonly expectedDpopThumbprint?: string;
  readonly requiredScopes?: readonly ScopeV1[];
  readonly maxLifetimeSeconds?: number;
}

export type DesktopExecutionTicketValidationResultV1 =
  | {
      readonly ok: true;
      readonly ticket: DesktopExecutionTicketV1;
    }
  | {
      readonly ok: false;
      readonly reason: string;
    };

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function isEpochSeconds(value: unknown): value is number {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}

/** Validate the wire shape without authorizing it for a request. */
export function isDesktopExecutionTicketV1(value: unknown): value is DesktopExecutionTicketV1 {
  if (!isRecord(value)) return false;
  if (containsProviderCredentialKey(value)) return false;
  if (
    value.version !== EXECUTION_CONTRACT_VERSION ||
    !isNonEmptyString(value.ticketId) ||
    !isNonEmptyString(value.orgId) ||
    !isNonEmptyString(value.subjectId) ||
    !isNonEmptyString(value.deviceId) ||
    !isNonEmptyString(value.environmentId) ||
    !isNonEmptyString(value.audience) ||
    !isNonEmptyString(value.dpopThumbprint) ||
    !Array.isArray(value.allowedMethods) ||
    value.allowedMethods.length === 0 ||
    !value.allowedMethods.every(isNonEmptyString) ||
    !Array.isArray(value.scopes) ||
    value.scopes.length === 0 ||
    !value.scopes.every(isExecutionScope) ||
    !isEpochSeconds(value.issuedAt) ||
    !isEpochSeconds(value.expiresAt) ||
    value.expiresAt <= value.issuedAt
  ) {
    return false;
  }

  return (
    new Set(value.allowedMethods).size === value.allowedMethods.length &&
    new Set(value.scopes).size === value.scopes.length
  );
}

/**
 * Check a ticket at the method boundary. Every comparison is explicit and
 * deny-by-default so a valid socket or a ticket without a DPoP binding cannot
 * grant ambient execution authority.
 */
export function validateDesktopExecutionTicket(
  value: unknown,
  input: DesktopExecutionTicketAllowlistInputV1,
): DesktopExecutionTicketValidationResultV1 {
  if (!isDesktopExecutionTicketV1(value)) {
    return { ok: false, reason: "Invalid desktop execution ticket." };
  }
  if (!isNonEmptyString(input.expectedAudience) || value.audience !== input.expectedAudience) {
    return { ok: false, reason: "Desktop execution ticket audience mismatch." };
  }
  if (
    !isNonEmptyString(input.expectedOrgId) ||
    value.orgId !== input.expectedOrgId ||
    !isNonEmptyString(input.expectedSubjectId) ||
    value.subjectId !== input.expectedSubjectId ||
    !isNonEmptyString(input.expectedDeviceId) ||
    value.deviceId !== input.expectedDeviceId ||
    !isNonEmptyString(input.expectedEnvironmentId) ||
    value.environmentId !== input.expectedEnvironmentId
  ) {
    return { ok: false, reason: "Desktop execution ticket identity mismatch." };
  }
  if (!isNonEmptyString(input.method) || !value.allowedMethods.includes(input.method)) {
    return { ok: false, reason: "Desktop execution ticket method is not allowed." };
  }
  if (
    !isEpochSeconds(input.nowEpochSeconds) ||
    value.issuedAt > input.nowEpochSeconds + DESKTOP_EXECUTION_TICKET_CLOCK_SKEW_SECONDS ||
    value.expiresAt <= input.nowEpochSeconds
  ) {
    return { ok: false, reason: "Desktop execution ticket is outside its time window." };
  }

  const maxLifetimeSeconds =
    input.maxLifetimeSeconds ?? DESKTOP_EXECUTION_TICKET_MAX_LIFETIME_SECONDS;
  if (
    !Number.isSafeInteger(maxLifetimeSeconds) ||
    maxLifetimeSeconds < 0 ||
    value.expiresAt - value.issuedAt > maxLifetimeSeconds
  ) {
    return { ok: false, reason: "Desktop execution ticket lifetime is too long." };
  }
  if (
    !isNonEmptyString(input.expectedDpopThumbprint) ||
    value.dpopThumbprint !== input.expectedDpopThumbprint
  ) {
    return { ok: false, reason: "Desktop execution ticket DPoP binding mismatch." };
  }

  const requiredScopes = input.requiredScopes ?? [];
  if (!requiredScopes.every(isExecutionScope)) {
    return { ok: false, reason: "Desktop execution ticket requested an unknown scope." };
  }
  if (!requiredScopes.every((scope) => value.scopes.includes(scope))) {
    return { ok: false, reason: "Desktop execution ticket scope is not allowed." };
  }

  return { ok: true, ticket: value };
}

/** Boolean convenience helper for HTTP/RPC guards that only need allow/deny. */
export function isDesktopExecutionTicketAllowed(
  value: unknown,
  input: DesktopExecutionTicketAllowlistInputV1,
): value is DesktopExecutionTicketV1 {
  return validateDesktopExecutionTicket(value, input).ok;
}

export {
  computeDpopAccessTokenHash,
  computeDpopJwkThumbprint,
  normalizeDpopHtu,
  verifyDpopProof,
  type DpopPublicJwk,
  type DpopVerificationResult,
} from "./dpop.js";
