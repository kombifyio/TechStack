import * as NodeCrypto from "node:crypto";

import { describe, expect, it } from "vitest";

import {
  computeDpopAccessTokenHash,
  computeDpopJwkThumbprint,
  isDesktopExecutionTicketAllowed,
  validateDesktopExecutionTicket,
  verifyDpopProof,
  type DesktopExecutionTicketV1,
  type DpopPublicJwk,
} from "./index.js";

function signDpopProof(input: {
  readonly method: string;
  readonly url: string;
  readonly iat: number;
  readonly privateKey: NodeCrypto.KeyObject;
  readonly publicJwk: DpopPublicJwk;
  readonly accessToken?: string;
}): string {
  const header = Buffer.from(
    JSON.stringify({ typ: "dpop+jwt", alg: "ES256", jwk: input.publicJwk }),
  ).toString("base64url");
  const payload = Buffer.from(
    JSON.stringify({
      htm: input.method,
      htu: input.url,
      jti: "proof-1",
      iat: input.iat,
      ...(input.accessToken ? { ath: computeDpopAccessTokenHash(input.accessToken) } : {}),
    }),
  ).toString("base64url");
  const signature = NodeCrypto.sign("sha256", Buffer.from(`${header}.${payload}`), {
    key: input.privateKey,
    dsaEncoding: "ieee-p1363",
  }).toString("base64url");
  return `${header}.${payload}.${signature}`;
}

describe("execution-contracts DPoP boundary", () => {
  it("accepts a correctly bound ES256 proof and rejects a request mismatch", () => {
    const { privateKey, publicKey } = NodeCrypto.generateKeyPairSync("ec", {
      namedCurve: "P-256",
    });
    const publicJwk = publicKey.export({ format: "jwk" }) as DpopPublicJwk;
    const proof = signDpopProof({
      method: "POST",
      url: "https://example.com/v1/execution",
      iat: 100,
      privateKey,
      publicJwk,
      accessToken: "short-lived-access-token",
    });
    const thumbprint = computeDpopJwkThumbprint(publicJwk);

    const accepted = verifyDpopProof({
      proof,
      method: "POST",
      url: "https://example.com/v1/execution?ignored=query",
      nowEpochSeconds: 101,
      expectedThumbprint: thumbprint,
      expectedAccessToken: "short-lived-access-token",
    });
    expect(accepted).toMatchObject({ ok: true, thumbprint, jti: "proof-1", iat: 100 });

    const rejected = verifyDpopProof({
      proof,
      method: "GET",
      url: "https://example.com/v1/execution",
      nowEpochSeconds: 101,
      expectedThumbprint: thumbprint,
    });
    expect(rejected.ok).toBe(false);
  });

  it("rejects a proof that exposes a private JWK key or has a tampered signature", () => {
    const { privateKey, publicKey } = NodeCrypto.generateKeyPairSync("ec", {
      namedCurve: "P-256",
    });
    const publicJwk = publicKey.export({ format: "jwk" }) as DpopPublicJwk;
    const proof = signDpopProof({
      method: "POST",
      url: "https://example.com/v1/execution",
      iat: 100,
      privateKey,
      publicJwk,
    });
    const [header, payload, signature] = proof.split(".");
    expect(header && payload && signature).toBeTruthy();
    if (!header || !payload || !signature) return;

    const privateHeader = Buffer.from(
      JSON.stringify({ typ: "dpop+jwt", alg: "ES256", jwk: { ...publicJwk, d: "private" } }),
    ).toString("base64url");
    expect(
      verifyDpopProof({
        proof: `${privateHeader}.${payload}.${signature}`,
        method: "POST",
        url: "https://example.com/v1/execution",
        nowEpochSeconds: 101,
      }).ok,
    ).toBe(false);

    const tamperedSignature = `${signature.startsWith("A") ? "B" : "A"}${signature.slice(1)}`;
    expect(
      verifyDpopProof({
        proof: `${header}.${payload}.${tamperedSignature}`,
        method: "POST",
        url: "https://example.com/v1/execution",
        nowEpochSeconds: 101,
      }).ok,
    ).toBe(false);
  });
});

describe("desktop execution ticket boundary", () => {
  const ticket: DesktopExecutionTicketV1 = {
    version: "v1",
    ticketId: "ticket-1",
    orgId: "org-1",
    subjectId: "user-1",
    deviceId: "device-1",
    environmentId: "environment-1",
    audience: "desktop-execution",
    dpopThumbprint: "thumbprint-1",
    allowedMethods: ["execution.start"],
    scopes: ["workspace.read"],
    issuedAt: 100,
    expiresAt: 200,
  };

  it("authorizes only the requested audience, method, scope, binding, and lifetime", () => {
    const input = {
      expectedAudience: "desktop-execution",
      expectedOrgId: "org-1",
      expectedSubjectId: "user-1",
      expectedDeviceId: "device-1",
      expectedEnvironmentId: "environment-1",
      method: "execution.start",
      nowEpochSeconds: 101,
      expectedDpopThumbprint: "thumbprint-1",
      requiredScopes: ["workspace.read"] as const,
    };
    expect(isDesktopExecutionTicketAllowed(ticket, input)).toBe(true);
    expect(isDesktopExecutionTicketAllowed(ticket, { ...input, method: "execution.cancel" })).toBe(
      false,
    );
    expect(
      isDesktopExecutionTicketAllowed(ticket, { ...input, expectedDpopThumbprint: "other-key" }),
    ).toBe(false);
    expect(isDesktopExecutionTicketAllowed(ticket, { ...input, expectedOrgId: "other-org" })).toBe(
      false,
    );
    expect(isDesktopExecutionTicketAllowed(ticket, { ...input, nowEpochSeconds: 200 })).toBe(false);
  });

  it("fails closed for malformed tickets and omitted DPoP binding", () => {
    const input = {
      expectedAudience: "desktop-execution",
      expectedOrgId: "org-1",
      expectedSubjectId: "user-1",
      expectedDeviceId: "device-1",
      expectedEnvironmentId: "environment-1",
      method: "execution.start",
      nowEpochSeconds: 101,
      expectedDpopThumbprint: "thumbprint-1",
    };
    expect(validateDesktopExecutionTicket({ ...ticket, scopes: ["unknown.scope"] }, input).ok).toBe(
      false,
    );
    expect(
      validateDesktopExecutionTicket({ ...ticket, accessToken: "not-a-ticket-field" }, input).ok,
    ).toBe(false);
    expect(
      validateDesktopExecutionTicket(ticket, { ...input, expectedDpopThumbprint: undefined }).ok,
    ).toBe(false);
  });
});
