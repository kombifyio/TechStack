/**
 * First-party agent model catalog: the three type profiles, the four roles,
 * one Factory binding per Factory and the eight Office profiles
 * (`DECISION-RECORD-2026-09-25-agent-model-type-role-factory-office.md`,
 * `AGENT-CAPABILITY-PROVISIONING-STANDARD.md` §3c).
 *
 * The JSON files next to this module mirror the kombify-workspace contract
 * fixtures in `internal/standards-enforcement/agent-model-fixtures/`, which
 * stay the source of truth; refresh them by copying byte for byte, never by
 * editing here. Loading this module recomputes every digest, refuses a
 * record whose carried digest differs, parses each record with the agent
 * model mappers and checks references between records. Any failure throws at
 * import: a partially valid catalog would offer roles it cannot explain.
 *
 * Kept out of the `authority` entry so importing the contracts alone does not
 * pay for loading and verifying the catalog.
 */

import {
  allowedAgentTypes,
  composeAgentAuthority,
  mapAgentRoleV3,
  mapAgentTypeProfileV1,
  mapFactoryRoleBindingV1,
  mapOfficeProfileV1,
  offeredRoles,
  type AgentRoleV3,
  type AgentTypeProfileV1,
  type ComposedAgentAuthorityV1,
  type FactoryRoleBindingV1,
  type OfficeProfileV1,
} from "../agent-model.js";
import {
  agentModelDocumentDigestV1,
  type AgentModelDocumentV1,
  type AgentModelSchemaVersionV1,
} from "../agent-model-digest.js";

import drafterRole from "./agent-role.drafter.json";
import managerRole from "./agent-role.manager.json";
import researcherRole from "./agent-role.researcher.json";
import specialistRole from "./agent-role.specialist.json";
import adHocType from "./agent-type-profile.ad-hoc.json";
import expertType from "./agent-type-profile.expert.json";
import permanentType from "./agent-type-profile.permanent.json";
import buildFactoryBinding from "./factory-role-binding.build-factory.json";
import expertsFactoryBinding from "./factory-role-binding.experts-factory.json";
import paperworkBinding from "./factory-role-binding.paperwork.json";
import rilOpsBinding from "./factory-role-binding.ril-ops.json";
import workbenchBinding from "./factory-role-binding.workbench.json";
import appsOffice from "./office-profile.build-factory.apps.json";
import slidesOffice from "./office-profile.build-factory.slides.json";
import topicArtifactsOffice from "./office-profile.build-factory.topic-artifacts.json";
import websiteOffice from "./office-profile.build-factory.website.json";
import documentsOffice from "./office-profile.paperwork.documents.json";
import mailOffice from "./office-profile.paperwork.mail.json";
import meetingsOffice from "./office-profile.paperwork.meetings.json";
import serverOffice from "./office-profile.ril-ops.server.json";

export interface AgentModelCatalogV1 {
  readonly typeProfiles: readonly AgentTypeProfileV1[];
  readonly roles: readonly AgentRoleV3[];
  readonly bindings: readonly FactoryRoleBindingV1[];
  readonly offices: readonly OfficeProfileV1[];
}

/** Recompute the digest first, so a mapper never sees a record that lies about itself. */
function verified<T>(document: unknown, map: (raw: unknown) => T): T {
  const carried =
    document && typeof document === "object" && "digest" in document
      ? (document as { digest: unknown }).digest
      : undefined;
  const computed = agentModelDocumentDigestV1(
    document as AgentModelDocumentV1<AgentModelSchemaVersionV1>,
  );
  if (carried !== computed) {
    const id = (document as { id?: unknown }).id;
    throw new TypeError(`${String(id)}: digest ${String(carried)} does not match ${computed}.`);
  }
  return map(document);
}

function unique(ids: readonly string[], shape: string): void {
  const seen = new Set<string>();
  for (const id of ids) {
    if (seen.has(id)) throw new TypeError(`${shape} ${id} is declared twice.`);
    seen.add(id);
  }
}

/** Check what no single mapper can: references between records. */
function checkReferences(catalog: AgentModelCatalogV1): void {
  unique(
    catalog.typeProfiles.map((type) => type.agentType),
    "Agent type",
  );
  unique(
    catalog.roles.map((role) => role.roleId),
    "Role",
  );
  unique(
    catalog.bindings.map((binding) => binding.factoryId),
    "Factory binding",
  );
  unique(
    catalog.offices.map((office) => `${office.factoryId}.${office.officeId}`),
    "Office profile",
  );
  for (const office of catalog.offices) {
    const binding = catalog.bindings.find((entry) => entry.factoryId === office.factoryId);
    if (!binding) throw new TypeError(`${office.id} has no Factory binding.`);
    const classified = new Set(Object.values(binding.classes).flat());
    const deviceIds = new Set(office.device?.definitions.map((definition) => definition.id) ?? []);
    // Office tools are classified through the binding and device definitions
    // carry their own class; anything else could never pass the role filter.
    const unclassified = [
      ...office.tools.flatMap((tool) => tool.definitionIds),
      ...office.preselect.filter((definitionId) => !deviceIds.has(definitionId)),
    ].find((definitionId) => !classified.has(definitionId));
    if (unclassified) {
      throw new TypeError(
        `${office.id} names ${unclassified}, which ${binding.id} does not classify.`,
      );
    }
    // A device definition classifies itself; the binding must not classify it too.
    const doublyClassified = [...deviceIds].find((definitionId) => classified.has(definitionId));
    if (doublyClassified) {
      throw new TypeError(
        `${office.id} device definition ${doublyClassified} is also classified by ${binding.id}.`,
      );
    }
  }
}

function buildAgentModelCatalog(documents: {
  readonly [Shape in keyof AgentModelCatalogV1]: readonly unknown[];
}): AgentModelCatalogV1 {
  const catalog: AgentModelCatalogV1 = Object.freeze({
    typeProfiles: Object.freeze(
      documents.typeProfiles.map((doc) => verified(doc, mapAgentTypeProfileV1)),
    ),
    roles: Object.freeze(documents.roles.map((doc) => verified(doc, mapAgentRoleV3))),
    bindings: Object.freeze(
      documents.bindings.map((doc) => verified(doc, mapFactoryRoleBindingV1)),
    ),
    offices: Object.freeze(documents.offices.map((doc) => verified(doc, mapOfficeProfileV1))),
  });
  checkReferences(catalog);
  return catalog;
}

/** The shipped first-party catalog, parsed and verified at module load. */
export const FIRST_PARTY_AGENT_MODEL: AgentModelCatalogV1 = buildAgentModelCatalog({
  typeProfiles: [permanentType, expertType, adHocType],
  roles: [researcherRole, drafterRole, specialistRole, managerRole],
  bindings: [
    rilOpsBinding,
    paperworkBinding,
    buildFactoryBinding,
    workbenchBinding,
    expertsFactoryBinding,
  ],
  offices: [
    serverOffice,
    mailOffice,
    documentsOffice,
    meetingsOffice,
    websiteOffice,
    slidesOffice,
    topicArtifactsOffice,
    appsOffice,
  ],
});

/** A role seen from one Factory (and Office): the "What this agent can do" view. */
export interface AgentRoleInFactoryV1 {
  /** Whether the Factory offers the role at all (standard §3c, `offeredRoles`). */
  offered: boolean;
  authority: ComposedAgentAuthorityV1;
  /** The type profiles the role may run as. */
  allowedTypes: AgentTypeProfileV1[];
}

/**
 * Describe a first-party role in a Factory and, optionally, one of its
 * Offices. Throws on an id the catalog does not know.
 */
export function describeRoleInFactory(
  roleId: string,
  factoryId: string,
  officeId?: string,
): AgentRoleInFactoryV1 {
  const catalog = FIRST_PARTY_AGENT_MODEL;
  const role = catalog.roles.find((entry) => entry.roleId === roleId);
  if (!role) throw new TypeError(`Unknown agent role ${roleId}.`);
  const binding = catalog.bindings.find((entry) => entry.factoryId === factoryId);
  if (!binding) throw new TypeError(`Unknown Factory ${factoryId}.`);
  let office: OfficeProfileV1 | undefined;
  if (officeId !== undefined) {
    office = catalog.offices.find(
      (entry) => entry.factoryId === factoryId && entry.officeId === officeId,
    );
    if (!office) throw new TypeError(`Factory ${factoryId} has no Office ${officeId}.`);
  }
  return {
    offered: offeredRoles(binding, [role]).length > 0,
    authority: composeAgentAuthority(role, binding, office),
    allowedTypes: allowedAgentTypes(role, catalog.typeProfiles),
  };
}
