import { sha256 } from "@noble/hashes/sha2";

import { validateSchemaDocuments, type SchemaViolation } from "../schemaValidator.js";
import { agentAuthoritySchemaDocuments } from "./contract/schemas.generated.js";
import type {
  ActivationDecisionV2,
  ActivationRequestV2,
  AgentAuthorityGrantV2,
  AgentRoleTemplateAuthoredV2,
  AgentRoleTemplateV2,
  AuthorityActorV2,
  AuthorityDigestV2,
  AuthorityDocumentSchemaVersionV2,
  AuthorityDocumentV2,
  CapabilityLeaseV2,
} from "./types.js";

export const AGENT_AUTHORITY_GRANT_DIGEST_DOMAIN_V2 =
  "kombify.agent-authority-grant.digest.v2" as const;
export const ACTIVATION_REQUEST_DIGEST_DOMAIN_V2 = "kombify.activation-request.digest.v2" as const;
export const ACTIVATION_DECISION_DIGEST_DOMAIN_V2 =
  "kombify.activation-decision.digest.v2" as const;
export const AGENT_ROLE_TEMPLATE_DIGEST_DOMAIN_V2 =
  "kombify.agent-role-template.digest.v2" as const;

export type AuthorityDigestDomainV2 =
  | typeof AGENT_AUTHORITY_GRANT_DIGEST_DOMAIN_V2
  | typeof ACTIVATION_REQUEST_DIGEST_DOMAIN_V2
  | typeof ACTIVATION_DECISION_DIGEST_DOMAIN_V2
  | typeof AGENT_ROLE_TEMPLATE_DIGEST_DOMAIN_V2;

export interface AuthorityContractViolation extends SchemaViolation {
  readonly code: "invalid_json_value" | "schema_invalid" | "digest_mismatch" | "binding_mismatch";
}

export class AuthorityContractError extends Error {
  readonly violations: readonly AuthorityContractViolation[];

  constructor(message: string, violations: readonly AuthorityContractViolation[]) {
    super(message);
    this.name = "AuthorityContractError";
    this.violations = violations;
  }
}

const textEncoder = new TextEncoder();

function wellFormedString(value: string, path: string): string {
  for (let index = 0; index < value.length; index += 1) {
    const unit = value.charCodeAt(index);
    if (unit >= 0xd800 && unit <= 0xdbff) {
      const next = value.charCodeAt(index + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) {
        throw new AuthorityContractError("Authority JSON contains invalid Unicode.", [
          { code: "invalid_json_value", path, message: "lone high surrogate" },
        ]);
      }
      index += 1;
    } else if (unit >= 0xdc00 && unit <= 0xdfff) {
      throw new AuthorityContractError("Authority JSON contains invalid Unicode.", [
        { code: "invalid_json_value", path, message: "lone low surrogate" },
      ]);
    }
  }
  return value;
}

function pointer(path: string, segment: string | number): string {
  const escaped = String(segment).replaceAll("~", "~0").replaceAll("/", "~1");
  return `${path}/${escaped}`;
}

function canonicalize(value: unknown, path: string, ancestors: Set<object>): string {
  if (value === null || typeof value === "boolean") return JSON.stringify(value);
  if (typeof value === "string") return JSON.stringify(wellFormedString(value, path || "/"));
  if (typeof value === "number") {
    if (!Number.isSafeInteger(value)) {
      throw new AuthorityContractError("Authority JSON accepts safe integers only.", [
        { code: "invalid_json_value", path: path || "/", message: "not a safe integer" },
      ]);
    }
    return JSON.stringify(value);
  }
  if (typeof value !== "object" || value === undefined) {
    throw new AuthorityContractError("Authority value is not JSON.", [
      { code: "invalid_json_value", path: path || "/", message: "not a JSON value" },
    ]);
  }
  if (ancestors.has(value)) {
    throw new AuthorityContractError("Authority JSON cannot contain cycles.", [
      { code: "invalid_json_value", path: path || "/", message: "cyclic value" },
    ]);
  }
  ancestors.add(value);
  try {
    if (Array.isArray(value)) {
      return `[${Array.from(value, (entry, index) =>
        canonicalize(entry, pointer(path, index), ancestors),
      ).join(",")}]`;
    }
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record)
      // Object.keys returns a fresh array; UTF-16 ordering is required by RFC 8785.
      // oxlint-disable-next-line unicorn/no-array-sort
      .sort()
      .map((key) => {
        const childPath = pointer(path, key);
        return `${JSON.stringify(wellFormedString(key, childPath))}:${canonicalize(record[key], childPath, ancestors)}`;
      })
      .join(",")}}`;
  } finally {
    ancestors.delete(value);
  }
}

/** RFC 8785-compatible canonical JSON for schema-bounded authority values. */
export function canonicalAuthorityJsonV2(value: unknown): string {
  return canonicalize(value, "", new Set());
}

function bytesToLowerHex(bytes: Uint8Array): string {
  let result = "";
  for (const byte of bytes) result += byte.toString(16).padStart(2, "0");
  return result;
}

/** SHA-256 of `<domain>\\n<canonical JSON>\\n`. */
export function canonicalAuthorityDigestV2(domain: string, binding: unknown): AuthorityDigestV2 {
  wellFormedString(domain, "/domain");
  if (domain.length === 0 || domain.includes("\n") || domain.includes("\r")) {
    throw new AuthorityContractError("Authority digest domain is invalid.", [
      { code: "invalid_json_value", path: "/domain", message: "invalid digest domain" },
    ]);
  }
  const bytes = textEncoder.encode(`${domain}\n${canonicalAuthorityJsonV2(binding)}\n`);
  return `sha256:${bytesToLowerHex(sha256(bytes))}`;
}

export function agentAuthorityGrantDigestV2(
  binding: AgentAuthorityGrantV2["binding"],
): AuthorityDigestV2 {
  return canonicalAuthorityDigestV2(AGENT_AUTHORITY_GRANT_DIGEST_DOMAIN_V2, binding);
}

export function activationRequestDigestV2(
  binding: ActivationRequestV2["binding"],
): AuthorityDigestV2 {
  return canonicalAuthorityDigestV2(ACTIVATION_REQUEST_DIGEST_DOMAIN_V2, binding);
}

export function activationDecisionDigestV2(
  binding: ActivationDecisionV2["binding"],
): AuthorityDigestV2 {
  return canonicalAuthorityDigestV2(ACTIVATION_DECISION_DIGEST_DOMAIN_V2, binding);
}

/** Remove self-referential and server-owned registry facts from a v2 template. */
export function agentRoleTemplateAuthoredProjectionV2(
  template: AgentRoleTemplateV2,
): AgentRoleTemplateAuthoredV2 {
  const { digest: _digest, lifecycle: _lifecycle, trustClass: _trustClass, ...authored } = template;
  return authored;
}

export function agentRoleTemplateDigestV2(
  authored: AgentRoleTemplateAuthoredV2,
): AuthorityDigestV2 {
  return canonicalAuthorityDigestV2(AGENT_ROLE_TEMPLATE_DIGEST_DOMAIN_V2, authored);
}

const SCHEMA_BY_VERSION = {
  "kombify.agent-authority-grant.v2": "agent-authority.v2.schema.json",
  "kombify.activation-request.v2": "activation-request.v2.schema.json",
  "kombify.activation-decision.v2": "activation-decision.v2.schema.json",
  "kombify.capability-lease.v2": "capability-lease.v2.schema.json",
  "kombify.agent-role-template.v2": "agent-role-template.v2.schema.json",
} as const satisfies Record<AuthorityDocumentSchemaVersionV2, string>;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function schemaVersion(value: unknown): AuthorityDocumentSchemaVersionV2 | null {
  if (
    !isRecord(value) ||
    !Object.hasOwn(value, "schemaVersion") ||
    typeof value.schemaVersion !== "string"
  )
    return null;
  return Object.hasOwn(SCHEMA_BY_VERSION, value.schemaVersion)
    ? (value.schemaVersion as AuthorityDocumentSchemaVersionV2)
    : null;
}

function schemaViolations(version: AuthorityDocumentSchemaVersionV2, value: unknown) {
  return validateSchemaDocuments(
    agentAuthoritySchemaDocuments,
    "agent authority v2",
    SCHEMA_BY_VERSION[version],
    value,
  ).map((violation) => ({
    code: "schema_invalid" as const,
    path: violation.path,
    message: violation.message,
  }));
}

function sameCanonical(left: unknown, right: unknown): boolean {
  if (left === undefined || right === undefined) return left === right;
  return canonicalAuthorityJsonV2(left) === canonicalAuthorityJsonV2(right);
}

function actorIdentity(actor: AuthorityActorV2): string {
  return `${actor.kind}:${actor.id}`;
}

function immutableViolations(document: AuthorityDocumentV2): AuthorityContractViolation[] {
  const violations: AuthorityContractViolation[] = [];
  const mismatch = (path: string, message: string) =>
    violations.push({ code: "binding_mismatch", path, message });
  if (document.schemaVersion === "kombify.agent-authority-grant.v2") {
    if (document.grantDigest !== agentAuthorityGrantDigestV2(document.binding)) {
      violations.push({
        code: "digest_mismatch",
        path: "/grantDigest",
        message: "grant digest mismatch",
      });
    }
  } else if (document.schemaVersion === "kombify.activation-request.v2") {
    if (document.requestDigest !== activationRequestDigestV2(document.binding)) {
      violations.push({
        code: "digest_mismatch",
        path: "/requestDigest",
        message: "request digest mismatch",
      });
    }
  } else if (document.schemaVersion === "kombify.activation-decision.v2") {
    if (document.decisionDigest !== activationDecisionDigestV2(document.binding)) {
      violations.push({
        code: "digest_mismatch",
        path: "/decisionDigest",
        message: "decision digest mismatch",
      });
    }
    const leaf = document.binding.authorityChain.at(-1);
    if (!leaf || !sameCanonical(leaf.basis, document.binding.authorityBasis)) {
      mismatch("/binding/authorityChain", "authority basis is not the chain leaf");
    }
    if (!leaf || !sameCanonical(leaf.grantee, document.binding.actor)) {
      mismatch("/binding/actor", "decision actor is not the chain leaf grantee");
    }
    for (let index = 1; index < document.binding.authorityChain.length; index += 1) {
      const previous = document.binding.authorityChain[index - 1];
      const current = document.binding.authorityChain[index];
      if (previous && current && !sameCanonical(current.issuer, previous.grantee)) {
        mismatch(
          `/binding/authorityChain/${index}/issuer`,
          "authority chain is not ordered root to leaf",
        );
      }
    }
    const generations = new Set<string>();
    const agentIdentities = new Set<string>();
    for (const [index, link] of document.binding.authorityChain.entries()) {
      const generation = `${link.basis.grantId}:${link.basis.generation}`;
      if (generations.has(generation)) {
        mismatch(`/binding/authorityChain/${index}/basis`, "authority generation is repeated");
      }
      generations.add(generation);
      if (index === 0 && link.issuer.kind === "agent") {
        agentIdentities.add(actorIdentity(link.issuer));
      }
      const grantee = actorIdentity(link.grantee);
      if (agentIdentities.has(grantee)) {
        mismatch(
          `/binding/authorityChain/${index}/grantee`,
          "agent identity cycle in authority chain",
        );
      }
      agentIdentities.add(grantee);
    }
  } else if (document.schemaVersion === "kombify.capability-lease.v2") {
    if (document.requestDigest !== activationRequestDigestV2(document.binding)) {
      violations.push({
        code: "digest_mismatch",
        path: "/requestDigest",
        message: "lease request digest mismatch",
      });
    }
  } else if (document.schemaVersion === "kombify.agent-role-template.v2") {
    if (
      document.digest !== agentRoleTemplateDigestV2(agentRoleTemplateAuthoredProjectionV2(document))
    ) {
      violations.push({
        code: "digest_mismatch",
        path: "/digest",
        message: "role-template digest mismatch",
      });
    }
  }
  return violations;
}

/**
 * Validate schema and immutable digests only. Success is not proof that a Cloud
 * grant is active or that its FGA tuple is current.
 */
export function validateAuthorityDocumentV2(value: unknown): readonly AuthorityContractViolation[] {
  try {
    canonicalAuthorityJsonV2(value);
  } catch (error) {
    if (error instanceof AuthorityContractError) return error.violations;
    throw error;
  }
  const version = schemaVersion(value);
  if (!version) {
    return [
      {
        code: "schema_invalid",
        path: "/schemaVersion",
        message: "unsupported authority schema version",
      },
    ];
  }
  const violations = schemaViolations(version, value);
  if (violations.length > 0) return violations;
  if (version === "kombify.activation-request.v2" || version === "kombify.capability-lease.v2") {
    const task = (value as ActivationRequestV2 | CapabilityLeaseV2).binding.taskRef;
    if (task && BigInt(task.revision) > 9223372036854775807n) {
      return [
        {
          code: "schema_invalid",
          path: "/binding/taskRef/revision",
          message: "task revision exceeds signed bigint",
        },
      ];
    }
  }
  return immutableViolations(value as AuthorityDocumentV2);
}

export function parseAuthorityDocumentV2(value: unknown): AuthorityDocumentV2 {
  const violations = validateAuthorityDocumentV2(value);
  if (violations.length > 0) {
    throw new AuthorityContractError("Invalid agent authority v2 document.", violations);
  }
  return value as AuthorityDocumentV2;
}

export function parseAuthorityJsonV2(json: string): AuthorityDocumentV2 {
  let value: unknown;
  try {
    value = JSON.parse(wellFormedString(json, "/"));
  } catch (error) {
    if (error instanceof AuthorityContractError) throw error;
    throw new AuthorityContractError("Invalid authority JSON text.", [
      { code: "invalid_json_value", path: "/", message: "invalid JSON text" },
    ]);
  }
  return parseAuthorityDocumentV2(value);
}

function parseVersion<T extends AuthorityDocumentV2>(
  value: unknown,
  version: T["schemaVersion"],
): T {
  const document = parseAuthorityDocumentV2(value);
  if (document.schemaVersion !== version) {
    throw new AuthorityContractError("Unexpected agent authority document version.", [
      { code: "schema_invalid", path: "/schemaVersion", message: `expected ${version}` },
    ]);
  }
  return document as T;
}

export const parseAgentAuthorityGrantV2 = (value: unknown): AgentAuthorityGrantV2 =>
  parseVersion<AgentAuthorityGrantV2>(value, "kombify.agent-authority-grant.v2");
export const parseActivationRequestV2 = (value: unknown): ActivationRequestV2 =>
  parseVersion<ActivationRequestV2>(value, "kombify.activation-request.v2");
export const parseActivationDecisionV2 = (value: unknown): ActivationDecisionV2 =>
  parseVersion<ActivationDecisionV2>(value, "kombify.activation-decision.v2");
export const parseCapabilityLeaseV2 = (value: unknown): CapabilityLeaseV2 =>
  parseVersion<CapabilityLeaseV2>(value, "kombify.capability-lease.v2");
export const parseAgentRoleTemplateV2 = (value: unknown): AgentRoleTemplateV2 =>
  parseVersion<AgentRoleTemplateV2>(value, "kombify.agent-role-template.v2");

/** Verify cross-record immutable references without evaluating online authority. */
export function validateAuthorityBindingSetV2(input: {
  readonly request: ActivationRequestV2;
  readonly decision: ActivationDecisionV2;
  readonly lease?: CapabilityLeaseV2;
}): readonly AuthorityContractViolation[] {
  const violations: AuthorityContractViolation[] = [];
  const mismatch = (path: string, message: string) =>
    violations.push({ code: "binding_mismatch", path, message });
  const { request, decision, lease } = input;
  if (
    decision.binding.requestId !== request.id ||
    decision.binding.requestDigest !== request.requestDigest
  ) {
    mismatch("/decision/binding/requestDigest", "decision does not bind the request");
  }
  if (
    decision.binding.tenantId !== request.binding.tenantId ||
    decision.binding.subject !== request.binding.subject
  ) {
    mismatch("/decision/binding/subject", "decision tenant or subject differs from the request");
  }
  if (!sameCanonical(decision.binding.policy, request.binding.policy)) {
    mismatch("/decision/binding/policy", "decision policy differs from the request");
  }
  if (!sameCanonical(decision.binding.intent, request.binding.intent)) {
    mismatch("/decision/binding/intent", "decision intent differs from the request");
  }
  if (!sameCanonical(decision.binding.monetaryReservation, request.binding.monetaryReservation)) {
    mismatch(
      "/decision/binding/monetaryReservation",
      "decision monetary reference differs from the request",
    );
  }
  if (actorIdentity(decision.binding.actor) === actorIdentity(request.binding.requester)) {
    mismatch("/decision/binding/actor", "requester cannot decide its own request");
  }
  if (
    decision.binding.authorityChain.some(
      (link) =>
        link.issuer.kind === "agent" &&
        actorIdentity(link.issuer) === actorIdentity(request.binding.requester),
    )
  ) {
    mismatch("/decision/binding/authorityChain", "requester appears in approval ancestry");
  }
  if (
    decision.binding.authorityChain.some(
      (link) => Date.parse(link.issuedAt) > Date.parse(request.createdAt),
    )
  ) {
    mismatch("/decision/binding/authorityChain", "approval generation postdates the request");
  }
  if (lease) {
    if (
      lease.activationRequestId !== request.id ||
      lease.requestDigest !== request.requestDigest ||
      !sameCanonical(lease.binding, request.binding)
    ) {
      mismatch("/lease/requestDigest", "lease does not bind the request");
    }
    if (lease.decisionId !== decision.id || lease.decisionDigest !== decision.decisionDigest) {
      mismatch("/lease/decisionDigest", "lease does not bind the decision");
    }
  }
  return violations;
}
