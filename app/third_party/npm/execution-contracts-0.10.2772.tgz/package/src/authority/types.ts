export type AuthorityDigestV2 = `sha256:${string}`;
export type AuthorityFacetV2 =
  | "use"
  | "self_activate"
  | "issue"
  | "delegate"
  | "approve"
  | "revoke";

export interface AuthorityUserActorV2 {
  readonly kind: "user";
  readonly id: string;
}

export interface AuthorityServiceActorV2 {
  readonly kind: "service";
  readonly id: string;
}

export interface AuthorityAgentActorV2 {
  readonly kind: "agent";
  /** Exact authenticated agent instance id. */
  readonly id: string;
  readonly agentClass: string;
  readonly templateDigest: AuthorityDigestV2;
}

export type AuthorityActorV2 =
  | AuthorityUserActorV2
  | AuthorityAgentActorV2
  | AuthorityServiceActorV2;

export interface AuthorityBasisV2 {
  readonly grantId: string;
  readonly generation: number;
  readonly facet: AuthorityFacetV2;
  readonly grantDigest: AuthorityDigestV2;
}

export interface AuthorityChainLinkV2 {
  readonly basis: AuthorityBasisV2;
  readonly issuer: AuthorityActorV2;
  readonly grantee: AuthorityAgentActorV2;
  readonly issuedAt: string;
}

export interface AuthorityResourceV2 {
  readonly definitionId: string;
  readonly resource: string;
  readonly bindings: Readonly<Record<string, string>>;
}

export interface CapabilityBudgetV2 {
  readonly tokens?: number;
  readonly maxActiveLeases?: number;
  readonly maxEquippedDefinitions?: number;
}

export interface AuthorityEnvelopeV2 {
  readonly definitionIds: readonly string[];
  readonly resources: readonly AuthorityResourceV2[];
  readonly shapes: readonly ("durable" | "short-ttl" | "one-shot")[];
  readonly maxTtlSeconds: number;
  readonly budget: CapabilityBudgetV2;
  readonly delegatedFacets?: readonly AuthorityFacetV2[];
  readonly maxDelegationDepth?: number;
  readonly maxChildren?: number;
}

export interface AgentAuthorityGrantBindingV2 {
  readonly schemaVersion: "kombify.agent-authority-binding.v2";
  readonly grantId: string;
  readonly generation: number;
  readonly tenantId: string;
  readonly subject: string;
  readonly grantee: AuthorityAgentActorV2;
  readonly facet: AuthorityFacetV2;
  readonly envelope: AuthorityEnvelopeV2;
  readonly issuer: AuthorityActorV2;
  readonly parentBasis?: AuthorityBasisV2;
  readonly policyRevision: AuthorityDigestV2;
  readonly issuedAt: string;
  readonly expiresAt?: string;
}

export interface AgentAuthorityGrantV2 {
  readonly schemaVersion: "kombify.agent-authority-grant.v2";
  readonly binding: AgentAuthorityGrantBindingV2;
  readonly grantDigest: AuthorityDigestV2;
  readonly status: "pending" | "active" | "revoking" | "revoked";
  readonly revokedAt?: string;
}

export interface ActivationPolicyV2 {
  readonly schemaVersion: "kombify.activation-policy.v2";
  readonly revision: AuthorityDigestV2;
  readonly mode: "agent";
}

export interface ActivationIntentV2 {
  readonly intentId: string;
  readonly action: string;
  readonly intentDigest: AuthorityDigestV2;
  readonly idempotencyKey: string;
}

export interface MonetaryReservationReferenceV2 {
  readonly allocationId: string;
  readonly reservationId: string;
  /** Commerce's immutable request_digest, encoded as sha256:<lowerhex>. */
  readonly reservationDigest: AuthorityDigestV2;
  readonly intentDigest: AuthorityDigestV2;
  readonly currency: string;
  readonly maximumMinor: string;
  readonly merchantRef: string;
  readonly purposeRef: string;
  readonly expiresAt: string;
}

export interface ActivationTargetV2 {
  readonly agentInstanceId: string;
  readonly agentClass: string;
  readonly templateDigest: AuthorityDigestV2;
}

export interface ActivationRequestBindingV2 {
  readonly schemaVersion: "kombify.activation-request-binding.v2";
  readonly tenantId: string;
  readonly subject: string;
  readonly requester: AuthorityAgentActorV2;
  readonly target: ActivationTargetV2;
  readonly definitionIds: readonly string[];
  readonly resources: readonly AuthorityResourceV2[];
  readonly requestedShape: "durable" | "short-ttl" | "one-shot";
  readonly officeScope?: string;
  /** Activation lineage only; never standing authority. */
  readonly parentLeaseId?: string;
  /** Optional attenuation to the current revision of an existing Paperwork task. */
  readonly taskRef?: {
    readonly schemaVersion: "kombify.task-ref.v1";
    readonly owner: "paperwork";
    readonly id: string;
    readonly revision: string;
  };
  readonly authorityBasis: AuthorityBasisV2 & { readonly facet: "use" | "self_activate" };
  readonly policy: ActivationPolicyV2;
  readonly budget: CapabilityBudgetV2;
  readonly catalogRevision: string;
  readonly audience: string;
  readonly intent: ActivationIntentV2;
  readonly monetaryReservation?: MonetaryReservationReferenceV2;
  readonly expiresAt: string;
}

export interface ActivationRequestV2 {
  readonly schemaVersion: "kombify.activation-request.v2";
  readonly id: string;
  readonly binding: ActivationRequestBindingV2;
  readonly requestDigest: AuthorityDigestV2;
  readonly state: "pending" | "approved" | "denied" | "expired" | "withdrawn";
  readonly createdAt: string;
  readonly decisionId?: string;
  readonly decisionDigest?: AuthorityDigestV2;
  readonly leaseId?: string;
}

export interface ActivationDecisionBindingV2 {
  readonly schemaVersion: "kombify.activation-decision-binding.v2";
  readonly requestId: string;
  readonly requestDigest: AuthorityDigestV2;
  readonly tenantId: string;
  readonly subject: string;
  readonly actor: AuthorityAgentActorV2;
  readonly kind: "agent";
  readonly verdict: "approved" | "denied";
  readonly policy: ActivationPolicyV2;
  readonly authorityBasis: AuthorityBasisV2 & { readonly facet: "approve" };
  readonly authorityChain: readonly AuthorityChainLinkV2[];
  readonly decidedAt: string;
  readonly intent: ActivationIntentV2;
  readonly monetaryReservation?: MonetaryReservationReferenceV2;
}

export interface ActivationDecisionV2 {
  readonly schemaVersion: "kombify.activation-decision.v2";
  readonly id: string;
  readonly binding: ActivationDecisionBindingV2;
  readonly decisionDigest: AuthorityDigestV2;
}

export interface CapabilityLeaseV2 {
  readonly schemaVersion: "kombify.capability-lease.v2";
  readonly id: string;
  readonly activationRequestId: string;
  readonly binding: ActivationRequestBindingV2;
  readonly requestDigest: AuthorityDigestV2;
  readonly decisionId: string;
  readonly decisionDigest: AuthorityDigestV2;
  readonly epoch: number;
  readonly status: "active" | "expired" | "revoked" | "consumed";
  readonly issuedAt: string;
  readonly expiresAt: string;
  readonly revokedAt?: string;
  readonly consumedAt?: string;
}

export interface AgentRoleEquipmentEntryV2 {
  readonly productId: string;
  readonly definitionIds: readonly string[];
  readonly resourceBinding?: { readonly dimension: string; readonly value: string };
}

export interface AgentRoleTemplateV2 {
  readonly schemaVersion: "kombify.agent-role-template.v2";
  readonly id: string;
  readonly version: string;
  readonly digest: AuthorityDigestV2;
  readonly lifecycle: "draft" | "preview" | "active" | "revoked";
  readonly trustClass: "catalog-verified" | "broker-listed" | "user-attached";
  readonly publisher: { readonly name: string; readonly firstParty: boolean };
  readonly factoryId: string;
  readonly officeDefinitionIds: readonly string[];
  readonly agentType: "permanent" | "expert" | "ad-hoc";
  readonly label: string;
  readonly description: string;
  readonly baseAgentId: string;
  readonly defaults: readonly AgentRoleEquipmentEntryV2[];
  readonly budget: CapabilityBudgetV2;
  readonly durableTtlSeconds: number;
  readonly maxTtlSeconds?: number;
  readonly knowledgeTier: "KT0" | "KT1" | "KT2" | "KT3";
  readonly spawnDepth: number;
  readonly maxChildren: number;
  readonly executionClass:
    | "kombify-generic-host"
    | "remote-environment"
    | "external-harness"
    | "execution-node";
  readonly authorityDefaults: Readonly<{
    use: readonly string[];
    selfActivate: readonly string[];
    issue: readonly string[];
    delegate: readonly string[];
    approve: readonly string[];
    revoke: readonly string[];
  }>;
}

/** Authored template content bound by the v2 digest; registry state is server-owned. */
export type AgentRoleTemplateAuthoredV2 = Omit<
  AgentRoleTemplateV2,
  "digest" | "lifecycle" | "trustClass"
>;

export type AuthorityDocumentV2 =
  | AgentAuthorityGrantV2
  | ActivationRequestV2
  | ActivationDecisionV2
  | CapabilityLeaseV2
  | AgentRoleTemplateV2;

export type AuthorityDocumentSchemaVersionV2 = AuthorityDocumentV2["schemaVersion"];
