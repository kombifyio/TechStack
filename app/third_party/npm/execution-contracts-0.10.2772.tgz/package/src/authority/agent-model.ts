/**
 * Agent model: type, role, Factory binding and Office profile.
 *
 * Decision: workspace `DECISION-RECORD-2026-09-25-agent-model-type-role-factory-office.md`.
 * Shapes and composition: `kombify-Core/standards/AGENT-CAPABILITY-PROVISIONING-STANDARD.md`
 * §3c and the `agent-type-profile.v1`, `agent-role.v3`, `factory-role-binding.v1`
 * and `office-profile.v1` schemas beside it. Each layer decides one thing:
 *
 * - the type (`AgentTypeProfileV1`) decides lifetime and infrastructure;
 * - the role (`AgentRoleV3`) decides permissions over capability classes plus
 *   scope and quota, and never names a concrete tool;
 * - the Factory binding (`FactoryRoleBindingV1`) fills each capability class
 *   with concrete definitions and suggests products per role;
 * - the Office profile (`OfficeProfileV1`) names the resource instance and the
 *   Office equipment, which the role's classes still filter.
 *
 * This model governs durable agents admitted through the Supply Dock only.
 * Ephemeral in-run subagents inherit their parent's grants and carry no role,
 * binding or Office profile.
 *
 * This module is the one implementation: `services/agents` imports it from
 * here, and `@kombiverselabs/ai-sdk` re-exports it for clients. Digests live in
 * `agent-model-digest.ts`.
 *
 * Mappers fail closed like the V2 role-template parser: an unknown enum member,
 * a malformed digest or a `release` class in any role facet rejects the whole
 * document. Unknown fields are dropped, never passed through.
 */

// Pure: no runtime import, so clients (the ai-sdk re-export) bundle only this file.
import type { AgentRoleTemplateV2 } from "./types.js";

type AgentRoleTemplateLifecycleV1 = AgentRoleTemplateV2["lifecycle"];
type SupplyDockTrustClassV1 = AgentRoleTemplateV2["trustClass"];
type CreatableAgentTypeV1 = AgentRoleTemplateV2["agentType"];

export interface AgentModelPublisherV1 {
  name: string;
  firstParty: boolean;
}

/** A product with the definitions requested from it; same shape as a spawn spec's equipment entry. */
export interface AgentModelEquipmentEntryV1 {
  productId: string;
  definitionIds: string[];
  resourceBinding?: { dimension: string; value: string };
}

export const AGENT_TYPE_PROFILE_SCHEMA_VERSION = "kombify.agent-type-profile.v1";
export const AGENT_ROLE_SCHEMA_VERSION_V3 = "kombify.agent-role.v3";
export const FACTORY_ROLE_BINDING_SCHEMA_VERSION = "kombify.factory-role-binding.v1";
export const OFFICE_PROFILE_SCHEMA_VERSION = "kombify.office-profile.v1";

// ── Vocabulary ─────────────────────────────────────────────────────────────

/** Closed capability class vocabulary (`agent-capability-class.v1`). */
export const CAPABILITY_CLASSES = ["observe", "research", "draft", "act", "release"] as const;
export type CapabilityClassV1 = (typeof CAPABILITY_CLASSES)[number];

/** `release` (send, publish, invite) is never part of a role; a person adds it deliberately. */
export type RoleCapabilityClassV1 = Exclude<CapabilityClassV1, "release">;
export const ROLE_CAPABILITY_CLASSES: readonly RoleCapabilityClassV1[] = [
  "observe",
  "research",
  "draft",
  "act",
];

/** What a type offers a role; a role's `requires` draws from the same vocabulary. */
export const AGENT_TYPE_PROVISIONS = [
  "persistent-identity",
  "reachability",
  "job-memory",
  "helpers",
  "sandbox",
] as const;
export type AgentTypeProvisionV1 = (typeof AGENT_TYPE_PROVISIONS)[number];

export const AGENT_ROLE_IDS = ["researcher", "drafter", "specialist", "manager"] as const;
export type AgentRoleIdV3 = (typeof AGENT_ROLE_IDS)[number];

/** Symbolic `approve` scope: observe requests of the agent's own helpers. */
export const AGENT_ROLE_APPROVE_SCOPES = ["helper-observe-requests"] as const;
/** Symbolic `revoke` scope: what the agent issued itself. */
export const AGENT_ROLE_REVOKE_SCOPES = ["issued-by-self"] as const;
export type AgentRoleApproveScopeV3 =
  | RoleCapabilityClassV1
  | (typeof AGENT_ROLE_APPROVE_SCOPES)[number];
export type AgentRoleRevokeScopeV3 =
  | RoleCapabilityClassV1
  | (typeof AGENT_ROLE_REVOKE_SCOPES)[number];

/**
 * Equipment every agent already has. It is never a Factory suggestion, so a
 * binding that lists it is rejected.
 */
export const AGENT_BASELINE_PRODUCT_IDS = [
  "plugin:kombify",
  "integration:kombify-knowledge",
  "knowledge-pack:knowledge.platform",
] as const;

/** The Office computer (ALC); the only device an Office profile carries. */
export const OFFICE_DEVICE_PRODUCT_ID = "device:linux-mobile";

/**
 * What each Office facility serves (standard §3c). A role's classes apply
 * uniformly: `observe` reads or searches, `draft` posts or proposes. Their
 * `act` members (promote, publish, add sources) come from no role and are
 * added by the person, so they are absent here; knowledge has no draft member.
 */
export const OFFICE_FACILITY_ROLE_CLASSES = {
  space: ["observe", "draft"],
  wiki: ["observe", "draft"],
  knowledge: ["observe"],
} as const satisfies Record<string, readonly RoleCapabilityClassV1[]>;

export const OFFICE_CUBI_TEMPLATE_IDS = ["website", "slide-deck", "topic", "app"] as const;
export const OFFICE_CUBI_SITE_TYPES = ["web", "deck", "topic-artifact", "app"] as const;

// ── Shapes ─────────────────────────────────────────────────────────────────

export interface LocalizedTextV1 {
  en: string;
  de: string;
}

/** Catalog envelope shared with `AgentRoleTemplateV2`. */
interface AgentModelCatalogEnvelopeV1<SchemaVersion extends string> {
  schemaVersion: SchemaVersion;
  id: string;
  version: string;
  /** `sha256:<64 hex>`, domain-separated, over the record without digest, lifecycle and trust class. */
  digest: string;
  lifecycle: AgentRoleTemplateLifecycleV1;
  trustClass: SupplyDockTrustClassV1;
  publisher: AgentModelPublisherV1;
}

export type AgentTypeLifetimeV1 =
  | { kind: "until-retired" }
  | { kind: "until-project-deleted" }
  | { kind: "session-bound" }
  | { kind: "bounded"; maxTtlSeconds: number };

export type AgentTypeIdentityV1 = "persistent" | "per-job" | "session-scoped" | "disposable";
export type AgentTypeMemoryV1 = "persistent" | "job-scoped" | "session-scoped" | "none";
export type AgentTypePlacementV1 = "always-on" | "on-demand-job" | "on-demand-task";
export type AgentTypeReachabilityV1 = "default" | "on-request" | "none";
export type AgentTypeQuotaTimeBasisV1 = "month" | "project" | "task";

/** Time and infrastructure of one creatable agent type; `id` equals `agentType`. */
export interface AgentTypeProfileV1 extends AgentModelCatalogEnvelopeV1<
  typeof AGENT_TYPE_PROFILE_SCHEMA_VERSION
> {
  agentType: CreatableAgentTypeV1;
  label: LocalizedTextV1;
  lifetime: AgentTypeLifetimeV1;
  identity: AgentTypeIdentityV1;
  memory: AgentTypeMemoryV1;
  placement: AgentTypePlacementV1;
  reachability: AgentTypeReachabilityV1;
  /** Durable lease horizon for routine reads; `null` binds it to the task. */
  routineReadLeaseSeconds: number | null;
  quotaTimeBasis: AgentTypeQuotaTimeBasisV1;
  childrenOutliveParent: false;
  provides: AgentTypeProvisionV1[];
}

/** Six independent facets; no facet implies another. */
export interface AgentRoleAuthorityV3 {
  use: RoleCapabilityClassV1[];
  selfActivate: RoleCapabilityClassV1[];
  issue: RoleCapabilityClassV1[];
  delegate: RoleCapabilityClassV1[];
  approve: AgentRoleApproveScopeV3[];
  revoke: AgentRoleRevokeScopeV3[];
}

export type AgentRoleScopeV3 =
  | "handed-items-or-office-read"
  | "office"
  | "office-with-helper-handout";

export interface AgentRoleQuotaV3 {
  /** Equipped definitions at once (`budget.maxEquippedDefinitions`). */
  loadoutCapacity: number;
  /** Active leases at once (`budget.maxActiveLeases`). */
  concurrentLeases: number;
  /** Tokens per the type's `quotaTimeBasis` (`budget.tokens`). */
  tokenBudget: number;
  /** Concurrent helper agents (`maxChildren`). */
  helpers: number;
}

/** Factory-independent archetype: permissions over capability classes and resources. */
export interface AgentRoleV3 extends AgentModelCatalogEnvelopeV1<
  typeof AGENT_ROLE_SCHEMA_VERSION_V3
> {
  roleId: AgentRoleIdV3;
  label: LocalizedTextV1;
  description: LocalizedTextV1;
  authority: AgentRoleAuthorityV3;
  scope: AgentRoleScopeV3;
  quota: AgentRoleQuotaV3;
  /** Allowed types are derived: a type qualifies when its `provides` covers this. */
  requires: AgentTypeProvisionV1[];
}

export type FactoryCapabilityClassesV1 = Record<CapabilityClassV1, string[]>;

export interface FactoryRoleOverrideV1 {
  /** Classes of the role's `use` that may stay empty in this Factory without hiding the role. */
  offerWithEmptyClasses: RoleCapabilityClassV1[];
}

/** Concrete definitions per capability class for one Factory, plus per-role suggestions. */
export interface FactoryRoleBindingV1 extends AgentModelCatalogEnvelopeV1<
  typeof FACTORY_ROLE_BINDING_SCHEMA_VERSION
> {
  factoryId: string;
  /** An empty array leaves the class unfilled; `release` is listed only so it can be classified. */
  classes: FactoryCapabilityClassesV1;
  suggested: Partial<Record<AgentRoleIdV3, AgentModelEquipmentEntryV1[]>>;
  roleOverrides?: Partial<Record<AgentRoleIdV3, FactoryRoleOverrideV1>>;
}

export interface OfficeResourceV1 {
  dimension: string;
  binding: "office-context";
}

export interface OfficeToolV1 {
  productId: string;
  definitionIds: string[];
  boundTo: "office-resource";
}

/** A device definition with the class the Office record gives it. */
export const OFFICE_PROFILE_DEVICE_CLASSES = ["observe", "act"] as const;
export type OfficeProfileDeviceClassV1 = (typeof OFFICE_PROFILE_DEVICE_CLASSES)[number];

export interface OfficeProfileDeviceDefinitionV1 {
  id: string;
  class: OfficeProfileDeviceClassV1;
}

export interface OfficeDeviceEquipmentV1 {
  productId: typeof OFFICE_DEVICE_PRODUCT_ID;
  definitions: OfficeProfileDeviceDefinitionV1[];
}

export interface OfficeCubiV1 {
  templateId: (typeof OFFICE_CUBI_TEMPLATE_IDS)[number];
  siteType: (typeof OFFICE_CUBI_SITE_TYPES)[number];
}

/** Where exactly, and the equipment every agent placed in the Office receives. */
export interface OfficeProfileV1 extends AgentModelCatalogEnvelopeV1<
  typeof OFFICE_PROFILE_SCHEMA_VERSION
> {
  factoryId: string;
  officeId: string;
  resource: OfficeResourceV1;
  tools: OfficeToolV1[];
  device: OfficeDeviceEquipmentV1 | null;
  space: boolean;
  wiki: boolean;
  knowledge: boolean;
  preselect: string[];
  /** kombify Sites template and SiteType; build-factory Offices only. */
  cubi?: OfficeCubiV1;
}

// ── Fail-closed mappers ────────────────────────────────────────────────────

const LIFECYCLES: ReadonlySet<string> = new Set(["draft", "preview", "active", "revoked"]);
const TRUST_CLASSES: ReadonlySet<string> = new Set([
  "catalog-verified",
  "broker-listed",
  "user-attached",
]);
const DIGEST = /^sha256:[0-9a-f]{64}$/;
/** Supply Dock product id: `<category>:<name>`. */
const DEVICE_DEFINITION = /^device\..+$/;
const PRODUCT_ID = /^(plugin|skill|integration|knowledge-pack|device|template):.+$/;
const CREATABLE_TYPES: readonly CreatableAgentTypeV1[] = ["permanent", "expert", "ad-hoc"];

function invalid(shape: string, reason: string): never {
  throw new TypeError(`${shape} is invalid: ${reason}`);
}

function record(value: unknown): Record<string, unknown> | undefined {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : undefined;
}

/**
 * An object with no field outside `allowed`. The Core schemas are closed
 * (`additionalProperties: false`) and §4.2b rejects unknown fields before
 * hashing, so a field this build cannot name fails the document.
 */
function closed(
  value: unknown,
  shape: string,
  path: string,
  allowed: readonly string[],
): Record<string, unknown> {
  const item = record(value);
  if (!item) invalid(shape, `${path} must be an object`);
  const unknown = Object.keys(item).find((key) => !allowed.includes(key));
  if (unknown !== undefined) invalid(shape, `${path} has unknown field ${unknown}`);
  return item;
}

function text(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() !== "" ? value : undefined;
}

function integer(value: unknown, minimum: number): number | undefined {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= minimum
    ? value
    : undefined;
}

function oneOf<T extends string>(value: unknown, members: readonly T[]): T | undefined {
  return typeof value === "string" && (members as readonly string[]).includes(value)
    ? (value as T)
    : undefined;
}

/** A duplicate-free array of `members`, or of non-empty strings when `members` is absent. */
function uniqueList<T extends string>(
  value: unknown,
  shape: string,
  path: string,
  options: { members?: readonly T[]; minItems?: number; pattern?: RegExp } = {},
): T[] {
  if (!Array.isArray(value)) invalid(shape, `${path} must be an array`);
  if (value.length < (options.minItems ?? 0)) invalid(shape, `${path} is too short`);
  const out: T[] = [];
  for (const entry of value) {
    const member = options.members ? oneOf(entry, options.members) : (text(entry) as T | undefined);
    if (member === undefined || (options.pattern && !options.pattern.test(member))) {
      invalid(shape, `${path} has an invalid member`);
    }
    if (out.includes(member)) invalid(shape, `${path} repeats ${member}`);
    out.push(member);
  }
  return out;
}

function mapEquipmentEntry(raw: unknown, shape: string, path: string): AgentModelEquipmentEntryV1 {
  const entry = closed(raw, shape, path, ["productId", "definitionIds", "resourceBinding"]);
  const productId = text(entry.productId);
  if (!productId || !PRODUCT_ID.test(productId)) invalid(shape, `${path}.productId`);
  const definitionIds = uniqueList(entry.definitionIds, shape, `${path}.definitionIds`);
  if (entry.resourceBinding === undefined) return { productId, definitionIds };
  const binding = closed(entry.resourceBinding, shape, `${path}.resourceBinding`, [
    "dimension",
    "value",
  ]);
  const dimension = text(binding.dimension);
  const value = text(binding.value);
  if (!dimension || !value) invalid(shape, `${path}.resourceBinding`);
  return { productId, definitionIds, resourceBinding: { dimension, value } };
}

function localized(value: unknown, shape: string, path: string): LocalizedTextV1 {
  const item = closed(value, shape, path, ["en", "de"]);
  const en = text(item.en);
  const de = text(item.de);
  if (!en || !de) invalid(shape, `${path} needs en and de`);
  return { en, de };
}

const ENVELOPE_FIELDS = [
  "schemaVersion",
  "id",
  "version",
  "digest",
  "lifecycle",
  "trustClass",
  "publisher",
] as const;

function envelope<SchemaVersion extends string>(
  raw: unknown,
  schemaVersion: SchemaVersion,
  shape: string,
  bodyFields: readonly string[],
): { item: Record<string, unknown>; head: AgentModelCatalogEnvelopeV1<SchemaVersion> } {
  const item = closed(raw, shape, "document", [...ENVELOPE_FIELDS, ...bodyFields]);
  if (item.schemaVersion !== schemaVersion) invalid(shape, "schemaVersion");
  const id = text(item.id);
  const version = text(item.version);
  const digest = text(item.digest);
  const lifecycle = text(item.lifecycle);
  const trustClass = text(item.trustClass);
  const publisher = closed(item.publisher, shape, "publisher", ["name", "firstParty"]);
  const publisherName = text(publisher.name);
  const firstParty = publisher.firstParty;
  if (!id) invalid(shape, "id");
  if (!version) invalid(shape, "version");
  if (!digest || !DIGEST.test(digest)) invalid(shape, "digest");
  if (!lifecycle || !LIFECYCLES.has(lifecycle)) invalid(shape, "lifecycle");
  if (!trustClass || !TRUST_CLASSES.has(trustClass)) invalid(shape, "trustClass");
  if (!publisherName || typeof firstParty !== "boolean") invalid(shape, "publisher");
  return {
    item,
    head: {
      schemaVersion,
      id,
      version,
      digest,
      lifecycle: lifecycle as AgentRoleTemplateLifecycleV1,
      trustClass: trustClass as SupplyDockTrustClassV1,
      publisher: { name: publisherName, firstParty },
    },
  };
}

export function mapAgentTypeProfileV1(raw: unknown): AgentTypeProfileV1 {
  const shape = "AgentTypeProfileV1";
  const { item, head } = envelope(raw, AGENT_TYPE_PROFILE_SCHEMA_VERSION, shape, [
    "agentType",
    "label",
    "lifetime",
    "identity",
    "memory",
    "placement",
    "reachability",
    "routineReadLeaseSeconds",
    "quotaTimeBasis",
    "childrenOutliveParent",
    "provides",
  ]);
  const agentType = oneOf(item.agentType, CREATABLE_TYPES);
  if (!agentType) invalid(shape, "agentType");
  const lifetimeRaw = closed(item.lifetime, shape, "lifetime", ["kind", "maxTtlSeconds"]);
  const maxTtlSeconds = integer(lifetimeRaw.maxTtlSeconds, 1);
  let lifetime: AgentTypeLifetimeV1;
  if (
    (lifetimeRaw.kind === "until-retired" ||
      lifetimeRaw.kind === "until-project-deleted" ||
      lifetimeRaw.kind === "session-bound") &&
    lifetimeRaw.maxTtlSeconds === undefined
  ) {
    lifetime = { kind: lifetimeRaw.kind };
  } else if (lifetimeRaw.kind === "bounded" && maxTtlSeconds !== undefined) {
    lifetime = { kind: "bounded", maxTtlSeconds };
  } else {
    invalid(shape, "lifetime");
  }
  const identity = oneOf(item.identity, [
    "persistent",
    "per-job",
    "session-scoped",
    "disposable",
  ] as const);
  const memory = oneOf(item.memory, [
    "persistent",
    "job-scoped",
    "session-scoped",
    "none",
  ] as const);
  const placement = oneOf(item.placement, [
    "always-on",
    "on-demand-job",
    "on-demand-task",
  ] as const);
  const reachability = oneOf(item.reachability, ["default", "on-request", "none"] as const);
  const quotaTimeBasis = oneOf(item.quotaTimeBasis, ["month", "project", "task"] as const);
  const lease =
    item.routineReadLeaseSeconds === null ? null : integer(item.routineReadLeaseSeconds, 1);
  if (!identity) invalid(shape, "identity");
  if (!memory) invalid(shape, "memory");
  if (!placement) invalid(shape, "placement");
  if (!reachability) invalid(shape, "reachability");
  if (!quotaTimeBasis) invalid(shape, "quotaTimeBasis");
  if (lease === undefined) invalid(shape, "routineReadLeaseSeconds");
  if (item.childrenOutliveParent !== false) invalid(shape, "childrenOutliveParent");
  return {
    ...head,
    agentType,
    label: localized(item.label, shape, "label"),
    lifetime,
    identity,
    memory,
    placement,
    reachability,
    routineReadLeaseSeconds: lease,
    quotaTimeBasis,
    childrenOutliveParent: false,
    provides: uniqueList(item.provides, shape, "provides", { members: AGENT_TYPE_PROVISIONS }),
  };
}

export function mapAgentRoleV3(raw: unknown): AgentRoleV3 {
  const shape = "AgentRoleV3";
  const { item, head } = envelope(raw, AGENT_ROLE_SCHEMA_VERSION_V3, shape, [
    "roleId",
    "label",
    "description",
    "authority",
    "scope",
    "quota",
    "requires",
  ]);
  const roleId = oneOf(item.roleId, AGENT_ROLE_IDS);
  if (!roleId) invalid(shape, "roleId");
  // `release` is neither a facet nor a member of any facet vocabulary, so a
  // role carrying it in either place fails here.
  const facets = closed(item.authority, shape, "authority", [
    "use",
    "selfActivate",
    "issue",
    "delegate",
    "approve",
    "revoke",
  ]);
  const classes = { members: ROLE_CAPABILITY_CLASSES };
  const authority: AgentRoleAuthorityV3 = {
    use: uniqueList(facets.use, shape, "authority.use", classes),
    selfActivate: uniqueList(facets.selfActivate, shape, "authority.selfActivate", classes),
    issue: uniqueList(facets.issue, shape, "authority.issue", classes),
    delegate: uniqueList(facets.delegate, shape, "authority.delegate", classes),
    approve: uniqueList(facets.approve, shape, "authority.approve", {
      members: [...ROLE_CAPABILITY_CLASSES, ...AGENT_ROLE_APPROVE_SCOPES],
    }),
    revoke: uniqueList(facets.revoke, shape, "authority.revoke", {
      members: [...ROLE_CAPABILITY_CLASSES, ...AGENT_ROLE_REVOKE_SCOPES],
    }),
  };
  const scope = oneOf(item.scope, [
    "handed-items-or-office-read",
    "office",
    "office-with-helper-handout",
  ] as const);
  if (!scope) invalid(shape, "scope");
  const quotaRaw = closed(item.quota, shape, "quota", [
    "loadoutCapacity",
    "concurrentLeases",
    "tokenBudget",
    "helpers",
  ]);
  const loadoutCapacity = integer(quotaRaw.loadoutCapacity, 0);
  const concurrentLeases = integer(quotaRaw.concurrentLeases, 0);
  const tokenBudget = integer(quotaRaw.tokenBudget, 0);
  const helpers = integer(quotaRaw.helpers, 0);
  if (
    loadoutCapacity === undefined ||
    concurrentLeases === undefined ||
    tokenBudget === undefined ||
    helpers === undefined
  ) {
    invalid(shape, "quota");
  }
  return {
    ...head,
    roleId,
    label: localized(item.label, shape, "label"),
    description: localized(item.description, shape, "description"),
    authority,
    scope,
    quota: { loadoutCapacity, concurrentLeases, tokenBudget, helpers },
    requires: uniqueList(item.requires, shape, "requires", { members: AGENT_TYPE_PROVISIONS }),
  };
}

function roleKeyed<T>(
  value: unknown,
  shape: string,
  path: string,
  map: (entry: unknown, key: AgentRoleIdV3) => T,
): Partial<Record<AgentRoleIdV3, T>> {
  const raw = record(value);
  if (!raw) invalid(shape, path);
  const out: Partial<Record<AgentRoleIdV3, T>> = {};
  for (const [key, entry] of Object.entries(raw)) {
    const roleId = oneOf(key, AGENT_ROLE_IDS);
    if (!roleId) invalid(shape, `${path}.${key} is not a role`);
    out[roleId] = map(entry, roleId);
  }
  return out;
}

export function mapFactoryRoleBindingV1(raw: unknown): FactoryRoleBindingV1 {
  const shape = "FactoryRoleBindingV1";
  const { item, head } = envelope(raw, FACTORY_ROLE_BINDING_SCHEMA_VERSION, shape, [
    "factoryId",
    "classes",
    "suggested",
    "roleOverrides",
  ]);
  const factoryId = text(item.factoryId);
  if (!factoryId) invalid(shape, "factoryId");
  const classesRaw = closed(item.classes, shape, "classes", CAPABILITY_CLASSES);
  const classes = {} as FactoryCapabilityClassesV1;
  const classified = new Set<string>();
  for (const cls of CAPABILITY_CLASSES) {
    classes[cls] = uniqueList(classesRaw[cls], shape, `classes.${cls}`);
    for (const definitionId of classes[cls]) {
      // One class per definition, or the role filter would be ambiguous.
      if (classified.has(definitionId)) invalid(shape, `${definitionId} is in two classes`);
      classified.add(definitionId);
    }
  }
  const suggested = roleKeyed(item.suggested, shape, "suggested", (entries, roleId) => {
    if (!Array.isArray(entries)) invalid(shape, `suggested.${roleId}`);
    return entries.map((entry) => {
      const mapped = mapEquipmentEntry(entry, shape, `suggested.${roleId}`);
      if ((AGENT_BASELINE_PRODUCT_IDS as readonly string[]).includes(mapped.productId)) {
        invalid(shape, `suggested.${roleId} lists baseline ${mapped.productId}`);
      }
      return mapped;
    });
  });
  const roleOverrides =
    item.roleOverrides === undefined
      ? undefined
      : roleKeyed(item.roleOverrides, shape, "roleOverrides", (entry, roleId) => ({
          offerWithEmptyClasses: uniqueList(
            closed(entry, shape, `roleOverrides.${roleId}`, ["offerWithEmptyClasses"])
              .offerWithEmptyClasses,
            shape,
            `roleOverrides.${roleId}.offerWithEmptyClasses`,
            { members: ROLE_CAPABILITY_CLASSES, minItems: 1 },
          ),
        }));
  return {
    ...head,
    factoryId,
    classes,
    suggested,
    ...(roleOverrides ? { roleOverrides } : {}),
  };
}

export function mapOfficeProfileV1(raw: unknown): OfficeProfileV1 {
  const shape = "OfficeProfileV1";
  const { item, head } = envelope(raw, OFFICE_PROFILE_SCHEMA_VERSION, shape, [
    "factoryId",
    "officeId",
    "resource",
    "tools",
    "device",
    "space",
    "wiki",
    "knowledge",
    "preselect",
    "cubi",
  ]);
  const factoryId = text(item.factoryId);
  const officeId = text(item.officeId);
  if (!factoryId) invalid(shape, "factoryId");
  if (!officeId) invalid(shape, "officeId");
  const resourceRaw = closed(item.resource, shape, "resource", ["dimension", "binding"]);
  const dimension = text(resourceRaw.dimension);
  if (!dimension || resourceRaw.binding !== "office-context") invalid(shape, "resource");
  if (!Array.isArray(item.tools)) invalid(shape, "tools");
  const tools = item.tools.map((entry, index): OfficeToolV1 => {
    const tool = closed(entry, shape, `tools[${index}]`, ["productId", "definitionIds", "boundTo"]);
    const productId = text(tool.productId);
    if (!productId || !PRODUCT_ID.test(productId) || tool.boundTo !== "office-resource") {
      invalid(shape, `tools[${index}]`);
    }
    return {
      productId,
      definitionIds: uniqueList(tool.definitionIds, shape, `tools[${index}].definitionIds`, {
        minItems: 1,
      }),
      boundTo: "office-resource",
    };
  });
  let device: OfficeDeviceEquipmentV1 | null = null;
  if (item.device !== null) {
    const deviceRaw = closed(item.device, shape, "device", ["productId", "definitions"]);
    if (deviceRaw.productId !== OFFICE_DEVICE_PRODUCT_ID) invalid(shape, "device.productId");
    if (!Array.isArray(deviceRaw.definitions) || deviceRaw.definitions.length === 0) {
      invalid(shape, "device.definitions");
    }
    const definitions = deviceRaw.definitions.map(
      (entry, index): OfficeProfileDeviceDefinitionV1 => {
        const definition = closed(entry, shape, `device.definitions[${index}]`, ["id", "class"]);
        const id = text(definition.id);
        const cls = oneOf(definition.class, OFFICE_PROFILE_DEVICE_CLASSES);
        if (!id || !DEVICE_DEFINITION.test(id) || !cls)
          invalid(shape, `device.definitions[${index}]`);
        return { id, class: cls };
      },
    );
    // Duplicate ids would give one definition two classes.
    uniqueList(
      definitions.map((definition) => definition.id),
      shape,
      "device.definitions",
    );
    device = { productId: OFFICE_DEVICE_PRODUCT_ID, definitions };
  }
  if (
    typeof item.space !== "boolean" ||
    typeof item.wiki !== "boolean" ||
    typeof item.knowledge !== "boolean"
  ) {
    invalid(shape, "space, wiki and knowledge must be booleans");
  }
  let cubi: OfficeCubiV1 | undefined;
  if (item.cubi !== undefined) {
    const cubiRaw = closed(item.cubi, shape, "cubi", ["templateId", "siteType"]);
    const templateId = oneOf(cubiRaw.templateId, OFFICE_CUBI_TEMPLATE_IDS);
    const siteType = oneOf(cubiRaw.siteType, OFFICE_CUBI_SITE_TYPES);
    if (!templateId || !siteType) invalid(shape, "cubi");
    cubi = { templateId, siteType };
  }
  return {
    ...head,
    factoryId,
    officeId,
    resource: { dimension, binding: "office-context" },
    tools,
    device,
    space: item.space,
    wiki: item.wiki,
    knowledge: item.knowledge,
    preselect: uniqueList(item.preselect, shape, "preselect"),
    ...(cubi ? { cubi } : {}),
  };
}

// ── Composition (standard §3c) ─────────────────────────────────────────────

/** One suggested loadout entry and where it comes from. Requests, never grants. */
export interface AgentLoadoutSuggestionV1 extends AgentModelEquipmentEntryV1 {
  source: "suggested" | "office-tool" | "office-device";
  /** Present for Office equipment: admission binds it to the Office's resource instance. */
  boundTo?: "office-resource";
}

export interface ComposedOfficeEquipmentV1 {
  officeId: string;
  resourceDimension: string;
  /** Classes the role holds on the Office space, wiki and knowledge; empty when absent. */
  space: RoleCapabilityClassV1[];
  wiki: RoleCapabilityClassV1[];
  knowledge: RoleCapabilityClassV1[];
}

/**
 * What a role may do in one Factory (and Office), as concrete definition ids.
 * Feeds the "What this agent can do" view. Admission, not this helper, adds
 * baseline, owner reach and off-role recording.
 */
export interface ComposedAgentAuthorityV1 {
  roleId: AgentRoleIdV3;
  factoryId: string;
  /** Sorted definition ids per resolved facet. */
  use: string[];
  selfActivate: string[];
  issue: string[];
  /** Governance facets stay symbolic: they scope other agents' requests, not tools. */
  delegate: RoleCapabilityClassV1[];
  approve: AgentRoleApproveScopeV3[];
  revoke: AgentRoleRevokeScopeV3[];
  /** Class of every definition the binding and Office classify, `release` included. */
  classOf: ReadonlyMap<string, CapabilityClassV1>;
  office: ComposedOfficeEquipmentV1 | null;
  /** `binding.suggested[role]` plus Office tools and device, each filtered to the role's `use`. */
  loadout: AgentLoadoutSuggestionV1[];
  /** The Office preselection inside the role's `use`. */
  preselect: string[];
  /**
   * Whether the role may run code in a sandbox (`act` in its `use`). Whether
   * a sandbox exists is the type's `provides: sandbox`, decided at admission.
   */
  sandboxAllowed: boolean;
}

function facilityClasses(
  present: boolean,
  role: AgentRoleV3,
  serves: readonly RoleCapabilityClassV1[],
): RoleCapabilityClassV1[] {
  return present ? role.authority.use.filter((cls) => serves.includes(cls)) : [];
}

/**
 * Compose a role with a Factory binding and, optionally, an Office profile.
 * Throws when the Office belongs to another Factory or names a tool the
 * binding does not classify: an unclassifiable item could not be filtered by
 * the role, so it must not be offered at all.
 */
export function composeAgentAuthority(
  role: AgentRoleV3,
  binding: FactoryRoleBindingV1,
  office?: OfficeProfileV1,
): ComposedAgentAuthorityV1 {
  const classOf = new Map<string, CapabilityClassV1>();
  for (const cls of CAPABILITY_CLASSES) {
    for (const definitionId of binding.classes[cls]) classOf.set(definitionId, cls);
  }
  if (office) {
    if (office.factoryId !== binding.factoryId) {
      throw new TypeError(`Office ${office.id} belongs to Factory ${office.factoryId}`);
    }
    for (const definitionId of office.tools.flatMap((tool) => tool.definitionIds)) {
      if (!classOf.has(definitionId)) {
        throw new TypeError(`${definitionId} is not classified by Factory ${binding.factoryId}`);
      }
    }
    for (const definition of office.device?.definitions ?? []) {
      // A device definition classifies itself; one the binding already
      // classifies would get a second, conflicting class.
      if (classOf.has(definition.id)) {
        throw new TypeError(
          `Office device definition ${definition.id} is already classified by Factory ${binding.factoryId}`,
        );
      }
      classOf.set(definition.id, definition.class);
    }
  }
  // Office equipment joins a facet through its class, like a Factory tool.
  const officeDefinitions = office
    ? [
        ...office.tools.flatMap((tool) => tool.definitionIds),
        ...(office.device?.definitions.map((definition) => definition.id) ?? []),
      ]
    : [];
  const resolve = (classes: readonly RoleCapabilityClassV1[]): string[] => {
    const inFacet = (definitionId: string) => {
      const cls = classOf.get(definitionId);
      return cls !== undefined && cls !== "release" && classes.includes(cls);
    };
    const ids = new Set([
      ...classes.flatMap((cls) => binding.classes[cls]),
      ...officeDefinitions.filter(inFacet),
    ]);
    const sorted = [...ids];
    // Sets are sorted by value (standard §4.2b); the ES2022 lib has no toSorted.
    // oxlint-disable-next-line unicorn/no-array-sort
    sorted.sort();
    return sorted;
  };
  const use = resolve(role.authority.use);

  // Functional equipment is an editable default, independent of the role use facet.
  const loadout: AgentLoadoutSuggestionV1[] = [];
  for (const entry of binding.suggested[role.roleId] ?? []) {
    const definitionIds = [...entry.definitionIds];
    if (entry.definitionIds.length > 0 && definitionIds.length === 0) continue;
    const suggestion: AgentLoadoutSuggestionV1 = {
      productId: entry.productId,
      definitionIds,
      source: "suggested",
    };
    if (entry.resourceBinding) suggestion.resourceBinding = { ...entry.resourceBinding };
    loadout.push(suggestion);
  }
  let composedOffice: ComposedOfficeEquipmentV1 | null = null;
  let preselect: string[] = [];
  if (office) {
    for (const tool of office.tools) {
      const definitionIds = [...tool.definitionIds];
      if (definitionIds.length > 0) {
        loadout.push({
          productId: tool.productId,
          definitionIds,
          source: "office-tool",
          boundTo: "office-resource",
        });
      }
    }
    const deviceIds = office.device?.definitions.map((definition) => definition.id) ?? [];
    if (office.device && deviceIds.length > 0) {
      loadout.push({
        productId: office.device.productId,
        definitionIds: deviceIds,
        source: "office-device",
        boundTo: "office-resource",
      });
    }
    composedOffice = {
      officeId: office.officeId,
      resourceDimension: office.resource.dimension,
      space: facilityClasses(office.space, role, OFFICE_FACILITY_ROLE_CLASSES.space),
      wiki: facilityClasses(office.wiki, role, OFFICE_FACILITY_ROLE_CLASSES.wiki),
      knowledge: facilityClasses(office.knowledge, role, OFFICE_FACILITY_ROLE_CLASSES.knowledge),
    };
    preselect = [...office.preselect];
  }
  return {
    roleId: role.roleId,
    factoryId: binding.factoryId,
    use,
    selfActivate: resolve(role.authority.selfActivate),
    issue: resolve(role.authority.issue),
    delegate: [...role.authority.delegate],
    approve: [...role.authority.approve],
    revoke: [...role.authority.revoke],
    classOf,
    office: composedOffice,
    loadout,
    preselect,
    sandboxAllowed: role.authority.use.includes("act"),
  };
}

/** The types a role may run as: those whose `provides` covers the role's `requires`. */
export function allowedAgentTypes(
  role: AgentRoleV3,
  typeProfiles: readonly AgentTypeProfileV1[],
): AgentTypeProfileV1[] {
  return typeProfiles.filter((type) =>
    role.requires.every((provision) => type.provides.includes(provision)),
  );
}

/**
 * The roles a Factory offers: every class in the role's `use` is filled, or
 * the binding's `roleOverrides` lets that class stay empty for the role
 * (Homelab offers Drafter, Specialist and Manager with an empty `draft`).
 */
export function offeredRoles(
  binding: FactoryRoleBindingV1,
  roles: readonly AgentRoleV3[],
): AgentRoleV3[] {
  return roles.filter((role) => {
    const emptyAllowed = binding.roleOverrides?.[role.roleId]?.offerWithEmptyClasses ?? [];
    return role.authority.use.every(
      (cls) => binding.classes[cls].length > 0 || emptyAllowed.includes(cls),
    );
  });
}
