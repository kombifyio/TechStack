/**
 * Digests of the agent model catalog shapes (type profile, role, Factory
 * binding, Office profile). Same construction as the v2 role-template digest:
 * SHA-256 over `<domain>\n<canonical JSON>\n` of the authored projection,
 * which drops the self-referential digest and the registry-owned lifecycle
 * and trust class. The domain strings match the kombify-Core standard §4.2b.
 */

import { AuthorityContractError, canonicalAuthorityDigestV2 } from "./contract.js";
import type { AuthorityDigestV2 } from "./types.js";

const DOMAIN_BY_SCHEMA_VERSION = {
  "kombify.agent-type-profile.v1": "kombify.agent-type-profile.digest.v1",
  "kombify.agent-role.v3": "kombify.agent-role.digest.v3",
  "kombify.factory-role-binding.v1": "kombify.factory-role-binding.digest.v1",
  "kombify.office-profile.v1": "kombify.office-profile.digest.v1",
} as const;

export type AgentModelSchemaVersionV1 = keyof typeof DOMAIN_BY_SCHEMA_VERSION;

/** Any agent model document, authored or registered; the digest ignores registry facts. */
export interface AgentModelDocumentV1<SchemaVersion extends AgentModelSchemaVersionV1> {
  readonly schemaVersion: SchemaVersion;
}

/** Digest of an agent model document under the domain of its schema version. */
export function agentModelDocumentDigestV1(
  document: AgentModelDocumentV1<AgentModelSchemaVersionV1>,
): AuthorityDigestV2 {
  if (!Object.hasOwn(DOMAIN_BY_SCHEMA_VERSION, document.schemaVersion)) {
    throw new AuthorityContractError("Unsupported agent model schema version.", [
      { code: "schema_invalid", path: "/schemaVersion", message: "unsupported schema version" },
    ]);
  }
  const {
    digest: _digest,
    lifecycle: _lifecycle,
    trustClass: _trustClass,
    ...authored
  } = document as AgentModelDocumentV1<AgentModelSchemaVersionV1> & {
    digest?: unknown;
    lifecycle?: unknown;
    trustClass?: unknown;
  };
  return canonicalAuthorityDigestV2(DOMAIN_BY_SCHEMA_VERSION[document.schemaVersion], authored);
}
