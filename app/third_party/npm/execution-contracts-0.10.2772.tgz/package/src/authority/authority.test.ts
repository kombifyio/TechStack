import { describe, expect, it } from "vitest";

import {
  AGENT_ROLE_TEMPLATE_DIGEST_DOMAIN_V2,
  ACTIVATION_REQUEST_DIGEST_DOMAIN_V2,
  activationDecisionDigestV2,
  activationRequestDigestV2,
  agentAuthorityGrantDigestV2,
  agentRoleTemplateAuthoredProjectionV2,
  agentRoleTemplateDigestV2,
  canonicalAuthorityDigestV2,
  canonicalAuthorityJsonV2,
  parseActivationDecisionV2,
  parseActivationRequestV2,
  parseAgentAuthorityGrantV2,
  parseAgentRoleTemplateV2,
  parseAuthorityDocumentV2,
  parseCapabilityLeaseV2,
  validateAuthorityBindingSetV2,
  validateAuthorityDocumentV2,
  type ActivationDecisionV2,
  type ActivationRequestV2,
  type AgentAuthorityGrantV2,
  type AgentRoleTemplateV2,
  type CapabilityLeaseV2,
} from "./index.js";
import { agentAuthorityV2Conformance } from "./contract/conformance.generated.js";

interface ConformanceVector {
  readonly taskReference: {
    readonly value: NonNullable<ActivationRequestV2["binding"]["taskRef"]>;
    readonly requestDigest: string;
  };
  readonly grant: AgentAuthorityGrantV2;
  readonly request: ActivationRequestV2;
  readonly decision: ActivationDecisionV2;
  readonly lease: CapabilityLeaseV2;
  readonly roleTemplate: AgentRoleTemplateV2;
  readonly roleTemplateDigest: {
    readonly domain: string;
    readonly projection: Omit<AgentRoleTemplateV2, "digest" | "lifecycle" | "trustClass">;
    readonly canonical: string;
    readonly digest: string;
  };
  readonly canonicalization: {
    readonly domain: string;
    readonly value: unknown;
    readonly canonical: string;
    readonly digest: string;
  };
}

const vector = agentAuthorityV2Conformance as unknown as ConformanceVector;
type Mutable<T> = { -readonly [K in keyof T]: Mutable<T[K]> };

describe("agent authority v2 signed contract", () => {
  it("binds self-activation separately from tool use and refuses unrelated authority facets", () => {
    const request = structuredClone(vector.request) as Mutable<ActivationRequestV2>;
    request.binding.authorityBasis.facet = "self_activate";
    request.requestDigest = activationRequestDigestV2(request.binding);
    expect(parseActivationRequestV2(request).binding.authorityBasis.facet).toBe("self_activate");
    request.binding.authorityBasis.facet = "use";
    expect(() => parseActivationRequestV2(request)).toThrow();
    request.requestDigest = activationRequestDigestV2(request.binding);
    expect(() => parseActivationRequestV2(request)).not.toThrow();
    const issuance = {
      ...request,
      binding: {
        ...request.binding,
        authorityBasis: { ...request.binding.authorityBasis, facet: "issue" },
      },
    };
    const raw = {
      ...issuance,
      requestDigest: canonicalAuthorityDigestV2(
        ACTIVATION_REQUEST_DIGEST_DOMAIN_V2,
        issuance.binding,
      ),
    };
    expect(() => parseActivationRequestV2(raw)).toThrow();
  });
  it("binds an optional task revision without authorizing it through an older decision", () => {
    const request = structuredClone(vector.request) as Mutable<ActivationRequestV2>;
    request.binding.taskRef = structuredClone(vector.taskReference.value);
    request.requestDigest = activationRequestDigestV2(request.binding);
    expect(request.requestDigest).toBe(vector.taskReference.requestDigest);
    expect(parseActivationRequestV2(request)).toEqual(request);
    expect(
      validateAuthorityBindingSetV2({ request, decision: vector.decision }).length,
    ).toBeGreaterThan(0);
    request.binding.taskRef.revision = "8";
    expect(() => parseActivationRequestV2(request)).toThrow();
    request.binding.taskRef.revision = "9223372036854775808";
    request.requestDigest = activationRequestDigestV2(request.binding);
    expect(() => parseActivationRequestV2(request)).toThrow();
  });
  it("consumes the Core schema and canonical digest vectors", () => {
    expect(parseAgentAuthorityGrantV2(vector.grant)).toEqual(vector.grant);
    expect(parseActivationRequestV2(vector.request)).toEqual(vector.request);
    expect(parseActivationDecisionV2(vector.decision)).toEqual(vector.decision);
    expect(parseCapabilityLeaseV2(vector.lease)).toEqual(vector.lease);
    expect(parseAgentRoleTemplateV2(vector.roleTemplate)).toEqual(vector.roleTemplate);
    expect(vector.roleTemplateDigest.domain).toBe(AGENT_ROLE_TEMPLATE_DIGEST_DOMAIN_V2);
    expect(agentRoleTemplateAuthoredProjectionV2(vector.roleTemplate)).toEqual(
      vector.roleTemplateDigest.projection,
    );
    expect(canonicalAuthorityJsonV2(vector.roleTemplateDigest.projection)).toBe(
      vector.roleTemplateDigest.canonical,
    );
    expect(agentRoleTemplateDigestV2(vector.roleTemplateDigest.projection)).toBe(
      vector.roleTemplate.digest,
    );
    expect(agentAuthorityGrantDigestV2(vector.grant.binding)).toBe(vector.grant.grantDigest);
    expect(activationRequestDigestV2(vector.request.binding)).toBe(vector.request.requestDigest);
    expect(activationDecisionDigestV2(vector.decision.binding)).toBe(
      vector.decision.decisionDigest,
    );
    expect(canonicalAuthorityJsonV2(vector.canonicalization.value)).toBe(
      vector.canonicalization.canonical,
    );
    expect(
      canonicalAuthorityDigestV2(vector.canonicalization.domain, vector.canonicalization.value),
    ).toBe(vector.canonicalization.digest);
    expect(
      validateAuthorityBindingSetV2({
        request: vector.request,
        decision: vector.decision,
        lease: vector.lease,
      }),
    ).toEqual([]);
  });

  it("rejects unbound data while treating schema success as no online authority claim", () => {
    const pending = { ...vector.grant, status: "pending" as const };
    expect(parseAgentAuthorityGrantV2(pending).status).toBe("pending");

    const unknown = structuredClone(vector.request) as ActivationRequestV2 & {
      unverifiedAuthority?: boolean;
    };
    unknown.unverifiedAuthority = true;
    expect(validateAuthorityDocumentV2(unknown)).not.toEqual([]);

    const unsafe = structuredClone(vector.grant) as Mutable<AgentAuthorityGrantV2>;
    unsafe.binding.generation = Number.MAX_SAFE_INTEGER + 1;
    expect(validateAuthorityDocumentV2(unsafe)).not.toEqual([]);

    const invalidUnicode = structuredClone(vector.request) as Mutable<ActivationRequestV2>;
    invalidUnicode.binding.subject = "\ud800";
    expect(validateAuthorityDocumentV2(invalidUnicode)).not.toEqual([]);

    const wrongDomain = {
      ...vector.grant,
      grantDigest: canonicalAuthorityDigestV2(
        ACTIVATION_REQUEST_DIGEST_DOMAIN_V2,
        vector.grant.binding,
      ),
    };
    expect(validateAuthorityDocumentV2(wrongDomain)).not.toEqual([]);

    for (const facet of [
      "use",
      "selfActivate",
      "issue",
      "delegate",
      "approve",
      "revoke",
    ] as const) {
      const changedDefault = structuredClone(vector.roleTemplate) as Mutable<AgentRoleTemplateV2>;
      changedDefault.authorityDefaults[facet].push(`changed-${facet}`);
      expect(() => parseAgentRoleTemplateV2(changedDefault)).toThrow();
    }

    const changedRegistryFacts = structuredClone(
      vector.roleTemplate,
    ) as Mutable<AgentRoleTemplateV2>;
    changedRegistryFacts.lifecycle = "preview";
    changedRegistryFacts.trustClass = "broker-listed";
    expect(parseAgentRoleTemplateV2(changedRegistryFacts)).toEqual(changedRegistryFacts);

    const unknownVersion = { ...vector.request, schemaVersion: "kombify.activation-request.v3" };
    expect(() => parseAuthorityDocumentV2(unknownVersion)).toThrow();

    const inconsistent = structuredClone(vector.decision) as Mutable<ActivationDecisionV2>;
    inconsistent.binding.authorityChain[0]!.basis.generation += 1;
    inconsistent.decisionDigest = activationDecisionDigestV2(inconsistent.binding);
    expect(() => parseActivationDecisionV2(inconsistent)).toThrow();

    const changedActor = structuredClone(vector.decision) as Mutable<ActivationDecisionV2>;
    changedActor.binding.actor.agentClass += "-changed";
    changedActor.decisionDigest = activationDecisionDigestV2(changedActor.binding);
    expect(() => parseActivationDecisionV2(changedActor)).toThrow();

    const cyclic = structuredClone(vector.decision) as Mutable<ActivationDecisionV2>;
    const first = cyclic.binding.authorityChain[0]!;
    const repeatedActor = structuredClone(first);
    repeatedActor.basis.grantId = "grant-approve-cycle";
    repeatedActor.basis.generation += 1;
    repeatedActor.issuer = structuredClone(first.grantee);
    cyclic.binding.authorityChain.push(repeatedActor);
    cyclic.binding.authorityBasis = structuredClone(repeatedActor.basis) as Mutable<
      ActivationDecisionV2["binding"]["authorityBasis"]
    >;
    cyclic.decisionDigest = activationDecisionDigestV2(cyclic.binding);
    expect(() => parseActivationDecisionV2(cyclic)).toThrow();

    const changedIntent = structuredClone(vector.decision) as Mutable<ActivationDecisionV2>;
    changedIntent.binding.intent.intentId = "another-intent";
    changedIntent.decisionDigest = activationDecisionDigestV2(changedIntent.binding);
    const parsed = parseActivationDecisionV2(changedIntent);
    expect(
      validateAuthorityBindingSetV2({ request: vector.request, decision: parsed }),
    ).not.toEqual([]);
  });
});
