import { describe, expect, it } from "vitest";
import { mapAgentRoleV3, mapAgentTypeProfileV1 } from "./agent-model.js";
import task from "./agent-model-catalog/agent-type-profile.ad-hoc.json";

const researcher = {
  schemaVersion: "kombify.agent-role.v3",
  id: "researcher",
  version: "1.0.0",
  digest: `sha256:${"0".repeat(64)}`,
  lifecycle: "active",
  trustClass: "catalog-verified",
  publisher: { name: "kombify", firstParty: true },
  roleId: "researcher",
  label: { en: "Researcher", de: "Rechercheur" },
  description: { en: "Reads and reports.", de: "Liest und berichtet." },
  authority: {
    use: ["observe", "research"],
    selfActivate: ["observe", "research"],
    issue: [] as string[],
    delegate: [] as string[],
    approve: [] as string[],
    revoke: [] as string[],
  },
  scope: "handed-items-or-office-read",
  quota: { loadoutCapacity: 4, concurrentLeases: 4, tokenBudget: 40000, helpers: 0 },
  requires: [] as string[],
};

describe("agent model role mapper", () => {
  it("accepts a retained session definition without accepting a definition TTL on it", () => {
    const profile = {
      ...task,
      lifetime: { kind: "session-bound" },
      identity: "session-scoped",
      memory: "session-scoped",
    };
    expect(mapAgentTypeProfileV1(profile).lifetime).toEqual({ kind: "session-bound" });
    expect(() =>
      mapAgentTypeProfileV1({
        ...profile,
        lifetime: { kind: "session-bound", maxTtlSeconds: 3600 },
      }),
    ).toThrow(TypeError);
  });
  it("rejects a role that carries release in any authority facet or as a facet", () => {
    expect(mapAgentRoleV3(researcher).roleId).toBe("researcher");
    for (const facet of Object.keys(
      researcher.authority,
    ) as (keyof typeof researcher.authority)[]) {
      const withRelease = structuredClone(researcher);
      withRelease.authority[facet] = [...withRelease.authority[facet], "release"];
      expect(() => mapAgentRoleV3(withRelease)).toThrow(TypeError);
    }
    const releaseFacet = structuredClone(researcher) as typeof researcher & {
      authority: { release?: string[] };
    };
    releaseFacet.authority.release = ["release"];
    expect(() => mapAgentRoleV3(releaseFacet)).toThrow(TypeError);
  });
});
