// Generated from kombify-Core authority contract merge 540de7ac4e490c2e79829b491447fe1abc0c7543. Do not edit.
// Reviewed source: kombify-workspace PR #1039.
// oxlint-disable unicorn/no-thenable -- `then` is a JSON Schema keyword.

export const AGENT_AUTHORITY_CORE_COMMIT = "540de7ac4e490c2e79829b491447fe1abc0c7543" as const;

export const agentAuthoritySchemaDocuments: Readonly<Record<string, unknown>> = {
  "agent-authority.v2.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v2/agent-authority.schema.json",
    title: "Kombify AgentAuthorityGrantV2",
    description:
      "One append-only Cloud-owned standing-grant generation. Current Cloud status and the matching FGA tuple are both required; this document alone grants nothing.",
    type: "object",
    additionalProperties: false,
    required: ["schemaVersion", "binding", "grantDigest", "status"],
    properties: {
      schemaVersion: {
        const: "kombify.agent-authority-grant.v2",
      },
      binding: {
        $ref: "#/$defs/grantBinding",
      },
      grantDigest: {
        $ref: "#/$defs/digest",
      },
      status: {
        enum: ["pending", "active", "revoking", "revoked"],
      },
      revokedAt: {
        type: "string",
        format: "date-time",
      },
    },
    allOf: [
      {
        if: {
          properties: {
            status: {
              const: "revoked",
            },
          },
          required: ["status"],
        },
        then: {
          required: ["revokedAt"],
        },
      },
    ],
    $defs: {
      digest: {
        type: "string",
        pattern: "^sha256:[0-9a-f]{64}$",
      },
      actor: {
        oneOf: [
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "id"],
            properties: {
              kind: {
                const: "user",
              },
              id: {
                type: "string",
                minLength: 1,
              },
            },
          },
          {
            $ref: "#/$defs/agentActor",
          },
          {
            type: "object",
            additionalProperties: false,
            required: ["kind", "id"],
            properties: {
              kind: {
                const: "service",
              },
              id: {
                type: "string",
                minLength: 1,
              },
            },
          },
        ],
      },
      agentActor: {
        type: "object",
        additionalProperties: false,
        required: ["kind", "id", "agentClass", "templateDigest"],
        properties: {
          kind: {
            const: "agent",
          },
          id: {
            type: "string",
            minLength: 1,
            description:
              "The authenticated ai_agent_instances.id, never a shared class, client id, or OBO subject.",
          },
          agentClass: {
            type: "string",
            minLength: 1,
          },
          templateDigest: {
            $ref: "#/$defs/digest",
          },
        },
      },
      facet: {
        enum: ["use", "self_activate", "issue", "delegate", "approve", "revoke"],
      },
      basis: {
        type: "object",
        additionalProperties: false,
        required: ["grantId", "generation", "facet", "grantDigest"],
        properties: {
          grantId: {
            type: "string",
            minLength: 1,
          },
          generation: {
            type: "integer",
            minimum: 1,
            maximum: 9007199254740991,
          },
          facet: {
            $ref: "#/$defs/facet",
          },
          grantDigest: {
            $ref: "#/$defs/digest",
          },
        },
        description:
          "A leaf reference only. Consumers resolve the exact active Cloud generation and matching FGA tuple before relying on it.",
      },
      authorityChainLink: {
        type: "object",
        additionalProperties: false,
        required: ["basis", "issuer", "grantee", "issuedAt"],
        properties: {
          basis: {
            $ref: "#/$defs/basis",
          },
          issuer: {
            $ref: "#/$defs/actor",
          },
          grantee: {
            $ref: "#/$defs/agentActor",
          },
          issuedAt: {
            type: "string",
            format: "date-time",
          },
        },
      },
      resource: {
        type: "object",
        additionalProperties: false,
        required: ["definitionId", "resource", "bindings"],
        properties: {
          definitionId: {
            type: "string",
            minLength: 1,
          },
          resource: {
            type: "string",
            minLength: 1,
          },
          bindings: {
            type: "object",
            additionalProperties: {
              type: "string",
              minLength: 1,
            },
          },
        },
      },
      envelope: {
        type: "object",
        additionalProperties: false,
        required: ["definitionIds", "resources", "shapes", "maxTtlSeconds", "budget"],
        properties: {
          definitionIds: {
            type: "array",
            items: {
              type: "string",
              minLength: 1,
            },
            minItems: 1,
            uniqueItems: true,
          },
          resources: {
            type: "array",
            items: {
              $ref: "#/$defs/resource",
            },
            minItems: 1,
            uniqueItems: true,
          },
          shapes: {
            type: "array",
            items: {
              enum: ["durable", "short-ttl", "one-shot"],
            },
            minItems: 1,
            uniqueItems: true,
          },
          maxTtlSeconds: {
            type: "integer",
            minimum: 1,
            maximum: 9007199254740991,
          },
          budget: {
            $ref: "activation-request.v1.schema.json#/$defs/capabilityBudget",
          },
          delegatedFacets: {
            type: "array",
            items: {
              $ref: "#/$defs/facet",
            },
            uniqueItems: true,
          },
          maxDelegationDepth: {
            type: "integer",
            minimum: 0,
            maximum: 9007199254740991,
          },
          maxChildren: {
            type: "integer",
            minimum: 0,
            maximum: 9007199254740991,
          },
        },
      },
      grantBinding: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "grantId",
          "generation",
          "tenantId",
          "subject",
          "grantee",
          "facet",
          "envelope",
          "issuer",
          "policyRevision",
          "issuedAt",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.agent-authority-binding.v2",
          },
          grantId: {
            type: "string",
            minLength: 1,
          },
          generation: {
            type: "integer",
            minimum: 1,
            maximum: 9007199254740991,
          },
          tenantId: {
            type: "string",
            minLength: 1,
          },
          subject: {
            type: "string",
            minLength: 1,
          },
          grantee: {
            $ref: "#/$defs/agentActor",
          },
          facet: {
            $ref: "#/$defs/facet",
          },
          envelope: {
            $ref: "#/$defs/envelope",
          },
          issuer: {
            $ref: "#/$defs/actor",
          },
          parentBasis: {
            $ref: "#/$defs/basis",
          },
          policyRevision: {
            $ref: "#/$defs/digest",
          },
          issuedAt: {
            type: "string",
            format: "date-time",
            description:
              "Immutable creation time of this exact generation, included in grantDigest.",
          },
          expiresAt: {
            type: "string",
            format: "date-time",
          },
        },
        allOf: [
          {
            if: {
              properties: {
                facet: {
                  const: "delegate",
                },
              },
              required: ["facet"],
            },
            then: {
              properties: {
                envelope: {
                  required: ["delegatedFacets", "maxDelegationDepth", "maxChildren"],
                },
              },
            },
          },
        ],
      },
      policy: {
        type: "object",
        additionalProperties: false,
        required: ["schemaVersion", "revision", "mode"],
        properties: {
          schemaVersion: {
            const: "kombify.activation-policy.v2",
          },
          revision: {
            $ref: "#/$defs/digest",
          },
          mode: {
            const: "agent",
            description:
              "The only v2 decision mode admitted by this contract. Legacy human, step-up, two-person, and operator policies remain on v1.",
          },
        },
      },
      intent: {
        type: "object",
        additionalProperties: false,
        required: ["intentId", "action", "intentDigest", "idempotencyKey"],
        properties: {
          intentId: {
            type: "string",
            minLength: 1,
          },
          action: {
            type: "string",
            minLength: 1,
          },
          intentDigest: {
            $ref: "#/$defs/digest",
          },
          idempotencyKey: {
            type: "string",
            minLength: 1,
          },
        },
      },
      monetaryReservation: {
        type: "object",
        additionalProperties: false,
        required: [
          "allocationId",
          "reservationId",
          "reservationDigest",
          "intentDigest",
          "currency",
          "maximumMinor",
          "merchantRef",
          "purposeRef",
          "expiresAt",
        ],
        properties: {
          allocationId: {
            type: "string",
            minLength: 1,
          },
          reservationId: {
            type: "string",
            minLength: 1,
          },
          reservationDigest: {
            $ref: "#/$defs/digest",
            description:
              "The immutable commerce reservation request_digest, exposed on the wire as reservationDigest; no second payment-proof digest is accepted.",
          },
          intentDigest: {
            $ref: "#/$defs/digest",
          },
          currency: {
            type: "string",
            pattern: "^[A-Z]{3}$",
          },
          maximumMinor: {
            type: "string",
            pattern: "^(0|[1-9][0-9]*)$",
          },
          merchantRef: {
            type: "string",
            minLength: 1,
          },
          purposeRef: {
            type: "string",
            minLength: 1,
          },
          expiresAt: {
            type: "string",
            format: "date-time",
          },
        },
      },
    },
  },
  "activation-request.v2.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v2/activation-request.schema.json",
    title: "Kombify ActivationRequestV2",
    description:
      "An agent-filed request for an independently authorized agent decision. Human-reserved policies remain on v1.",
    type: "object",
    additionalProperties: false,
    required: ["schemaVersion", "id", "binding", "requestDigest", "state", "createdAt"],
    properties: {
      schemaVersion: {
        const: "kombify.activation-request.v2",
      },
      id: {
        type: "string",
        minLength: 1,
      },
      binding: {
        $ref: "#/$defs/binding",
      },
      requestDigest: {
        $ref: "agent-authority.v2.schema.json#/$defs/digest",
      },
      state: {
        enum: ["pending", "approved", "denied", "expired", "withdrawn"],
      },
      createdAt: {
        type: "string",
        format: "date-time",
      },
      decisionId: {
        type: "string",
        minLength: 1,
      },
      decisionDigest: {
        $ref: "agent-authority.v2.schema.json#/$defs/digest",
      },
      leaseId: {
        type: "string",
        minLength: 1,
      },
    },
    allOf: [
      {
        if: {
          properties: {
            state: {
              const: "approved",
            },
          },
          required: ["state"],
        },
        then: {
          required: ["decisionId", "decisionDigest", "leaseId"],
        },
      },
      {
        if: {
          properties: {
            state: {
              const: "denied",
            },
          },
          required: ["state"],
        },
        then: {
          required: ["decisionId", "decisionDigest"],
        },
      },
    ],
    $defs: {
      taskRef: {
        type: "object",
        additionalProperties: false,
        required: ["schemaVersion", "owner", "id", "revision"],
        properties: {
          schemaVersion: {
            const: "kombify.task-ref.v1",
          },
          owner: {
            const: "paperwork",
          },
          id: {
            type: "string",
            minLength: 1,
            maxLength: 256,
            pattern: "^[A-Za-z0-9._:-]{1,256}$",
          },
          revision: {
            type: "string",
            pattern: "^[1-9][0-9]{0,18}$",
            description:
              "Positive decimal Paperwork row_version, without ETag quoting. Runtime rejects values above PostgreSQL signed bigint maximum.",
          },
        },
      },
      target: {
        type: "object",
        additionalProperties: false,
        required: ["agentInstanceId", "agentClass", "templateDigest"],
        properties: {
          agentInstanceId: {
            type: "string",
            minLength: 1,
          },
          agentClass: {
            type: "string",
            minLength: 1,
          },
          templateDigest: {
            $ref: "agent-authority.v2.schema.json#/$defs/digest",
          },
        },
      },
      binding: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "tenantId",
          "subject",
          "requester",
          "target",
          "definitionIds",
          "resources",
          "requestedShape",
          "authorityBasis",
          "policy",
          "budget",
          "catalogRevision",
          "audience",
          "intent",
          "expiresAt",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.activation-request-binding.v2",
          },
          tenantId: {
            type: "string",
            minLength: 1,
          },
          subject: {
            type: "string",
            minLength: 1,
          },
          requester: {
            $ref: "agent-authority.v2.schema.json#/$defs/agentActor",
          },
          target: {
            $ref: "#/$defs/target",
          },
          definitionIds: {
            type: "array",
            items: {
              type: "string",
              minLength: 1,
            },
            minItems: 1,
            uniqueItems: true,
          },
          resources: {
            type: "array",
            items: {
              $ref: "agent-authority.v2.schema.json#/$defs/resource",
            },
            minItems: 1,
            uniqueItems: true,
          },
          requestedShape: {
            enum: ["durable", "short-ttl", "one-shot"],
          },
          officeScope: {
            type: "string",
            minLength: 1,
          },
          taskRef: {
            $ref: "#/$defs/taskRef",
          },
          parentLeaseId: {
            type: "string",
            minLength: 1,
            description: "Activation lineage only; never a standing-authority basis.",
          },
          authorityBasis: {
            allOf: [
              {
                $ref: "agent-authority.v2.schema.json#/$defs/basis",
              },
              {
                properties: {
                  facet: {
                    enum: ["use", "self_activate"],
                  },
                },
              },
            ],
          },
          policy: {
            $ref: "agent-authority.v2.schema.json#/$defs/policy",
          },
          budget: {
            $ref: "activation-request.v1.schema.json#/$defs/capabilityBudget",
          },
          catalogRevision: {
            type: "string",
            minLength: 1,
          },
          audience: {
            type: "string",
            minLength: 1,
          },
          intent: {
            $ref: "agent-authority.v2.schema.json#/$defs/intent",
          },
          monetaryReservation: {
            $ref: "agent-authority.v2.schema.json#/$defs/monetaryReservation",
          },
          expiresAt: {
            type: "string",
            format: "date-time",
          },
        },
      },
    },
  },
  "activation-decision.v2.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v2/activation-decision.schema.json",
    title: "Kombify ActivationDecisionV2",
    description:
      "An independent agent decision. Every authority-chain link is Cloud-resolved evidence; the chain is never itself grant authority.",
    type: "object",
    additionalProperties: false,
    required: ["schemaVersion", "id", "binding", "decisionDigest"],
    properties: {
      schemaVersion: {
        const: "kombify.activation-decision.v2",
      },
      id: {
        type: "string",
        minLength: 1,
      },
      binding: {
        type: "object",
        additionalProperties: false,
        required: [
          "schemaVersion",
          "requestId",
          "requestDigest",
          "tenantId",
          "subject",
          "actor",
          "kind",
          "verdict",
          "policy",
          "authorityBasis",
          "authorityChain",
          "decidedAt",
          "intent",
        ],
        properties: {
          schemaVersion: {
            const: "kombify.activation-decision-binding.v2",
          },
          requestId: {
            type: "string",
            minLength: 1,
          },
          requestDigest: {
            $ref: "agent-authority.v2.schema.json#/$defs/digest",
          },
          tenantId: {
            type: "string",
            minLength: 1,
          },
          subject: {
            type: "string",
            minLength: 1,
          },
          actor: {
            $ref: "agent-authority.v2.schema.json#/$defs/agentActor",
          },
          kind: {
            const: "agent",
          },
          verdict: {
            enum: ["approved", "denied"],
          },
          policy: {
            $ref: "agent-authority.v2.schema.json#/$defs/policy",
          },
          authorityBasis: {
            allOf: [
              {
                $ref: "agent-authority.v2.schema.json#/$defs/basis",
              },
              {
                properties: {
                  facet: {
                    const: "approve",
                  },
                },
              },
            ],
          },
          authorityChain: {
            type: "array",
            items: {
              $ref: "agent-authority.v2.schema.json#/$defs/authorityChainLink",
            },
            minItems: 1,
            uniqueItems: true,
            description:
              "Complete root-to-leaf Cloud-resolved evidence. The last basis equals authorityBasis and its grantee equals actor.",
          },
          decidedAt: {
            type: "string",
            format: "date-time",
          },
          intent: {
            $ref: "agent-authority.v2.schema.json#/$defs/intent",
          },
          monetaryReservation: {
            $ref: "agent-authority.v2.schema.json#/$defs/monetaryReservation",
          },
        },
      },
      decisionDigest: {
        $ref: "agent-authority.v2.schema.json#/$defs/digest",
      },
    },
  },
  "capability-lease.v2.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v2/capability-lease.schema.json",
    title: "Kombify CapabilityLeaseV2",
    description:
      "AI-owned activation record. Gateway JWS typ kombify.capability-lease.v2 binds this request and decision; v1 verifiers reject it.",
    type: "object",
    additionalProperties: false,
    required: [
      "schemaVersion",
      "id",
      "activationRequestId",
      "binding",
      "requestDigest",
      "decisionId",
      "decisionDigest",
      "epoch",
      "status",
      "issuedAt",
      "expiresAt",
    ],
    properties: {
      schemaVersion: {
        const: "kombify.capability-lease.v2",
      },
      id: {
        type: "string",
        minLength: 1,
      },
      activationRequestId: {
        type: "string",
        minLength: 1,
      },
      binding: {
        $ref: "activation-request.v2.schema.json#/$defs/binding",
      },
      requestDigest: {
        $ref: "agent-authority.v2.schema.json#/$defs/digest",
      },
      decisionId: {
        type: "string",
        minLength: 1,
      },
      decisionDigest: {
        $ref: "agent-authority.v2.schema.json#/$defs/digest",
      },
      epoch: {
        type: "integer",
        minimum: 0,
        maximum: 9007199254740991,
      },
      status: {
        enum: ["active", "expired", "revoked", "consumed"],
      },
      issuedAt: {
        type: "string",
        format: "date-time",
      },
      expiresAt: {
        type: "string",
        format: "date-time",
      },
      revokedAt: {
        type: "string",
        format: "date-time",
      },
      consumedAt: {
        type: "string",
        format: "date-time",
      },
    },
    allOf: [
      {
        if: {
          properties: {
            status: {
              const: "revoked",
            },
          },
          required: ["status"],
        },
        then: {
          required: ["revokedAt"],
        },
      },
      {
        if: {
          properties: {
            status: {
              const: "consumed",
            },
          },
          required: ["status"],
        },
        then: {
          required: ["consumedAt"],
          properties: {
            binding: {
              properties: {
                requestedShape: {
                  const: "one-shot",
                },
              },
            },
          },
        },
      },
    ],
  },
  "agent-role-template.v2.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v2/agent-role-template.schema.json",
    title: "Kombify AgentRoleTemplate v2",
    description:
      "Curated Factory equipment and authority defaults. Enrollment resolves these defaults against current owner eligibility and exact resources through Cloud; catalog contents never grant authority by themselves.",
    type: "object",
    additionalProperties: false,
    required: [
      "schemaVersion",
      "id",
      "version",
      "digest",
      "lifecycle",
      "trustClass",
      "publisher",
      "factoryId",
      "officeDefinitionIds",
      "agentType",
      "label",
      "description",
      "baseAgentId",
      "defaults",
      "budget",
      "durableTtlSeconds",
      "knowledgeTier",
      "spawnDepth",
      "maxChildren",
      "executionClass",
      "authorityDefaults",
    ],
    properties: {
      schemaVersion: {
        const: "kombify.agent-role-template.v2",
      },
      id: {
        type: "string",
        minLength: 1,
        description:
          "The template id. The Supply Dock sells the role under the same id as its template product.",
      },
      version: {
        type: "string",
        minLength: 1,
      },
      digest: {
        type: "string",
        pattern: "^sha256:[0-9a-f]{64}$",
        description:
          "SHA-256 under the kombify.agent-role-template.digest.v2 domain over the canonical authored projection defined by AGENT-CAPABILITY-PROVISIONING-STANDARD.md section 4.2b. The projection excludes digest, lifecycle and trustClass; a spec names the digest it was composed against, so authored changes cannot silently redefine a pending spawn.",
      },
      lifecycle: {
        enum: ["draft", "preview", "active", "revoked"],
        description:
          "The plugin registry's lifecycle, because a template is catalog content. Customers are listed active records only; preview is staff.",
      },
      trustClass: {
        type: "string",
        enum: ["catalog-verified", "broker-listed", "user-attached"],
        description:
          "What Kombify vouches for, not who published it. An unrecognised claim reads as user-attached (SUPPLY-DOCK-SHOP-STANDARD.md section 2a), never as the most convenient class.",
      },
      publisher: {
        type: "object",
        additionalProperties: false,
        required: ["name", "firstParty"],
        properties: {
          name: {
            type: "string",
            minLength: 1,
          },
          firstParty: {
            type: "boolean",
          },
        },
      },
      factoryId: {
        type: "string",
        minLength: 1,
        description: "The provided Factory in which this role runs.",
      },
      officeDefinitionIds: {
        type: "array",
        uniqueItems: true,
        items: {
          type: "string",
          minLength: 1,
        },
        description:
          "Office definitions of that Factory the role may be assigned to. Empty means any office of the Factory, never no office.",
      },
      agentType: {
        $ref: "agent-spawn-spec.v1.schema.json#/$defs/creatableAgentType",
      },
      label: {
        type: "string",
        minLength: 1,
      },
      description: {
        type: "string",
      },
      baseAgentId: {
        type: "string",
        minLength: 1,
        description:
          "The registered runtime agent class used by this role; never an independently authenticated instance.",
      },
      defaults: {
        type: "array",
        items: {
          $ref: "agent-spawn-spec.v1.schema.json#/$defs/equipmentEntry",
        },
        description:
          "Pre-selected equipment at spawn. A person may deselect from it or add beyond it within their own reach; the divergence is recorded, not refused.",
      },
      budget: {
        $ref: "activation-request.v1.schema.json#/$defs/capabilityBudget",
        description:
          "Default resource budget narrowed by enrollment and current grants. It is not a monetary allocation.",
      },
      durableTtlSeconds: {
        type: "integer",
        minimum: 0,
        description:
          "The durable lease TTL for this role (standard section 4.1). The origin's per-agent-type fallback applies only until a template owns the value, and is then deleted rather than re-tuned.",
      },
      maxTtlSeconds: {
        type: "integer",
        minimum: 0,
        description:
          "Upper bound for an ad-hoc instance's lifetime. Absent for standing roles; a spec's ttlSeconds never exceeds it and never exceeds the parent's remainder.",
      },
      knowledgeTier: {
        enum: ["KT0", "KT1", "KT2", "KT3"],
        description:
          "The knowledge capability profile sold with the role. A profile selector, never a knowledge grant of its own.",
      },
      spawnDepth: {
        type: "integer",
        minimum: 0,
        description:
          "How deep this role may spawn: 0 for a leaf, 1 for a parent. A role-template budget property; launch ships depth 1.",
      },
      maxChildren: {
        type: "integer",
        minimum: 0,
        description:
          "Concurrent children an instance of this role may hold. Enforced at admission, not at use.",
      },
      executionClass: {
        enum: ["kombify-generic-host", "remote-environment", "external-harness", "execution-node"],
        description:
          "Where an instance of this role runs. A Supply Dock class, not ExecutionEnvironmentV1.kind (target section 7): the generic host is the agent-host Worker, a remote environment is a K1 sandbox, an external harness is equipped by lease issuance only, and an execution node is post-v1.",
      },
      authorityDefaults: {
        type: "object",
        additionalProperties: false,
        required: ["use", "selfActivate", "issue", "delegate", "approve", "revoke"],
        properties: {
          use: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
          selfActivate: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
          issue: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
          delegate: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
          approve: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
          revoke: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
          },
        },
        description:
          "Six independent definition-set proposals at enrollment. Empty means no default grant for that facet. A role default never grants authority or caps an owner's explicit grant, and no facet implies another.",
      },
    },
  },
  "activation-request.v1.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v1/activation-request.schema.json",
    title: "Kombify ActivationRequest v1",
    description:
      "A request to activate capabilities. Never itself an authorization. Shapes are owned by kombify-Core/standards/AGENT-CAPABILITY-PROVISIONING-STANDARD.md section 3; decisions by AI-CAPABILITY-PROVISIONING-TARGET.md.",
    type: "object",
    additionalProperties: false,
    required: [
      "schemaVersion",
      "id",
      "requester",
      "definitionIds",
      "requestedShape",
      "state",
      "createdAt",
    ],
    properties: {
      schemaVersion: {
        const: "kombify.activation-request.v1",
      },
      id: {
        type: "string",
        minLength: 1,
      },
      tenantId: {
        type: "string",
        description:
          "The organization. Derived from the authenticated envelope, never from the request body.",
      },
      requester: {
        type: "object",
        additionalProperties: false,
        required: ["subject", "principal", "agentInstanceId", "agentType"],
        description:
          "subject is the user whose authority is delegated and caps eligibility. principal is the authenticated actor that filed the request: the agent instance for agent-initiated and equip flows. The approver must differ from principal, not from subject.",
        properties: {
          subject: {
            type: "string",
            minLength: 1,
          },
          principal: {
            type: "string",
            minLength: 1,
          },
          agentInstanceId: {
            type: "string",
            minLength: 1,
          },
          agentType: {
            enum: ["companion", "orchestrator", "permanent", "expert", "ad-hoc"],
            description:
              "Governance ceiling, never inferred from a name. orchestrator is the primary may_issue holder and is never resolved to permanent.",
          },
        },
      },
      definitionIds: {
        type: "array",
        minItems: 1,
        uniqueItems: true,
        items: {
          type: "string",
          minLength: 1,
        },
        description:
          "Catalog definition ids. Never inline policy: the signed catalog is the only definition authority.",
      },
      resourceScope: {
        type: "object",
        description:
          "Definition-specific narrowing. Persisted and bound into the lease token; instance-level enforcement arrives with the resourceBinding contract.",
      },
      requestedShape: {
        enum: ["durable", "short-ttl", "one-shot"],
      },
      approvalRequirement: {
        enum: ["none", "step_up", "human", "two_person", "operator"],
        description:
          "The approval class the minting Gateway read from the signed catalog. Absent or unknown reads as operator, so a catalog gap can only make an activation stricter.",
      },
      officeScope: {
        type: "string",
        description:
          "Pure attenuation. An office never widens anything and is never a synthetic job label.",
      },
      parentLeaseId: {
        type: "string",
        description:
          "Lineage and revocation anchor, never capability subsetting: a child is bounded by its parent's issuance envelope and its own eligibility.",
      },
      budget: {
        $ref: "#/$defs/capabilityBudget",
      },
      justification: {
        type: "string",
      },
      state: {
        enum: ["pending", "self_activated", "approved", "denied", "expired"],
        description:
          "self_activated is policy-auto-approval inside the eligibility ceiling: no principal decides it, so decidedBy stays absent.",
      },
      createdAt: {
        type: "string",
        format: "date-time",
      },
      decidedAt: {
        type: "string",
        format: "date-time",
      },
      decidedBy: {
        type: "string",
        description:
          "MUST differ from requester.principal when state is approved. Absent for self_activated.",
      },
    },
    allOf: [
      {
        if: {
          properties: {
            state: {
              const: "approved",
            },
          },
          required: ["state"],
        },
        then: {
          required: ["decidedBy"],
        },
      },
      {
        if: {
          properties: {
            state: {
              const: "self_activated",
            },
          },
          required: ["state"],
        },
        then: {
          not: {
            required: ["decidedBy"],
          },
        },
      },
    ],
    $defs: {
      capabilityBudget: {
        type: "object",
        additionalProperties: false,
        description:
          "The granted envelope, enforced at minting and never widened at runtime. Zero means the minting Gateway did not bound that dimension.",
        properties: {
          tokens: {
            type: "integer",
            minimum: 0,
          },
          maxActiveLeases: {
            type: "integer",
            minimum: 0,
          },
          maxEquippedDefinitions: {
            type: "integer",
            minimum: 0,
            description:
              "The loadout budget: the cap on simultaneously equipped definitions, and thereby on the projected tool surface.",
          },
        },
      },
    },
  },
  "agent-spawn-spec.v1.schema.json": {
    $schema: "https://json-schema.org/draft/2020-12/schema",
    $id: "https://schemas.kombify.dev/capability/v1/agent-spawn-spec.schema.json",
    title: "Kombify AgentSpawnSpec v1",
    description:
      "One instantiation of a role template. A request for admission, never an admission: admission meets the spec against the template and the granting principal's own reach and refuses with a structured denial rather than silently narrowing it. Shapes are owned by kombify-Core/standards/AGENT-CAPABILITY-PROVISIONING-STANDARD.md section 3a; decisions by AI-CAPABILITY-PROVISIONING-TARGET.md.",
    type: "object",
    additionalProperties: false,
    required: [
      "schemaVersion",
      "templateId",
      "displayName",
      "agentType",
      "factoryId",
      "officeId",
      "equipment",
      "budget",
    ],
    properties: {
      schemaVersion: {
        const: "kombify.agent-spawn-spec.v1",
      },
      templateId: {
        type: "string",
        minLength: 1,
        description:
          "The role template this spec instantiates. The template supplies the defaults and the two ceilings; it is never the cap on the granting human.",
      },
      templateDigest: {
        type: "string",
        pattern: "^sha256:[0-9a-f]{64}$",
        description:
          "The template document the spec was composed against. Admission refuses a stale digest rather than spawning against a template nobody read.",
      },
      displayName: {
        type: "string",
        minLength: 1,
        description:
          "What the owner calls this agent. A label, never an identity: the instance id and agentId are the identity.",
      },
      agentType: {
        $ref: "#/$defs/creatableAgentType",
      },
      factoryId: {
        type: "string",
        minLength: 1,
        description:
          "The Factory (harness id) the instance is employed in. It matches the template's Factory; a spec never moves a role to another one.",
      },
      officeId: {
        type: "string",
        minLength: 1,
        description:
          "The Office the instance is employed in. Mandatory: factory children always carry an office (standard section 6). Pure attenuation, and always a real office, never a synthetic job label.",
      },
      projectId: {
        type: "string",
        minLength: 1,
        description:
          "Owned project for a Project agent; admission verifies its accountable Office.",
      },
      sessionId: {
        type: "string",
        minLength: 1,
        description: "Owned complete task session, retained through archive/resume.",
      },
      sessionSource: {
        enum: ["ai", "workbench"],
        description: "Owning session API; never infer ownership from an opaque identifier.",
      },
      task: {
        type: "string",
        description:
          "The one job of an ad-hoc instance, in the owner's words. Prose for the run, never a capability and never read as one.",
      },
      equipment: {
        type: "array",
        items: {
          $ref: "#/$defs/equipmentEntry",
        },
        description:
          "What the spec asks to be equipped with, product by product. Requests, never grants: every definition still passes per-definition admission.",
      },
      excludedDefinitionIds: {
        type: "array",
        uniqueItems: true,
        items: {
          type: "string",
          minLength: 1,
        },
        description:
          "Suggested functional equipment deliberately omitted by the owner in role-based creation. Admission validates against the composed suggestions and retains this choice for audit. Technical runtime prerequisites stay separate.",
      },
      budget: {
        $ref: "activation-request.v1.schema.json#/$defs/capabilityBudget",
        description:
          "Carved from the granting principal's remainder at admission. Enforced at minting, never widened at runtime.",
      },
      ttlSeconds: {
        type: "integer",
        minimum: 0,
        description:
          "Legacy definition deadline input. Scope-bound Project/Task definitions retain identity; bounded execution leases and runtime invocation deadlines are separate.",
      },
      parentInstanceId: {
        type: "string",
        minLength: 1,
        description:
          "Set when an agent spawns a child. Lineage and revocation anchor, never capability subsetting: the child is bounded by the parent's issuance envelope and its own eligibility.",
      },
    },
    $defs: {
      creatableAgentType: {
        enum: ["permanent", "expert", "ad-hoc"],
        description:
          "Technical scope and lifecycle profile, independent of role defaults and current grants.",
      },
      equipmentResourceBinding: {
        type: "object",
        additionalProperties: false,
        required: ["dimension", "value"],
        description:
          "Narrows one entry to a single resource: the Office cursor's dimension and the exact instance id (techstack.server with a server id, paperwork.mailbox with an account id). Enforced through the lease's resourceBinding (standard section 4.2b). Absent means the product's whole scope, never a wildcard a client invented.",
        properties: {
          dimension: {
            type: "string",
            minLength: 1,
          },
          value: {
            type: "string",
            minLength: 1,
          },
        },
      },
      equipmentEntry: {
        type: "object",
        additionalProperties: false,
        required: ["productId", "definitionIds"],
        description:
          "One product with the definitions the agent asks for from it. The same shape a project's equipment list carries, so a spawn can request a project default without translation. Requests, never grants.",
        properties: {
          productId: {
            type: "string",
            pattern: "^(plugin|skill|integration|knowledge-pack|device|template):.+$",
            description:
              "A Supply Dock product id (SUPPLY-DOCK-SHOP-STANDARD.md section 3), not a capability id: a capability is what a product requests.",
          },
          definitionIds: {
            type: "array",
            uniqueItems: true,
            items: {
              type: "string",
              minLength: 1,
            },
            description:
              "Catalog definition ids drawn from that product's own requests. Never inline policy: the signed capability catalog is the only definition authority.",
          },
          resourceBinding: {
            $ref: "#/$defs/equipmentResourceBinding",
          },
        },
      },
    },
  },
};
