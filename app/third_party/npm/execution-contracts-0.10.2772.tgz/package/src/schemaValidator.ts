/** Validator for the pinned Core JSON Schema 2020-12 subset. */
export interface SchemaViolation {
  /** JSON pointer of the offending value, `/` for the root. */
  readonly path: string;
  readonly message: string;
}

type SchemaNode = Readonly<Record<string, unknown>>;

const SUPPORTED_KEYWORDS = new Set([
  "$schema",
  "$id",
  "$comment",
  "$defs",
  "title",
  "description",
  "$ref",
  "type",
  "const",
  "enum",
  "properties",
  "required",
  "additionalProperties",
  "items",
  "minItems",
  "maxItems",
  "uniqueItems",
  "minLength",
  "maxLength",
  "pattern",
  "minimum",
  "maximum",
  "format",
  "allOf",
  "anyOf",
  "oneOf",
  "not",
  "if",
  "then",
  "else",
]);

const DATE_TIME = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})$/u;

const patternCache = new Map<string, RegExp>();

function compiledPattern(pattern: string): RegExp {
  let compiled = patternCache.get(pattern);
  if (!compiled) {
    compiled = new RegExp(pattern, "u");
    patternCache.set(pattern, compiled);
  }
  return compiled;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function resolveRef(
  documents: Readonly<Record<string, unknown>>,
  contractName: string,
  ref: string,
  baseFile: string,
): { schema: SchemaNode; file: string } {
  const [filePart, pointer = ""] = ref.split("#");
  const file = filePart ? filePart.replace(/^\.\//u, "") : baseFile;
  let node: unknown = documents[file];
  for (const segment of pointer.split("/").filter(Boolean)) {
    node = isRecord(node) ? node[segment.replaceAll("~1", "/").replaceAll("~0", "~")] : undefined;
  }
  if (!isRecord(node)) {
    throw new Error(`Unresolvable ${contractName} schema reference ${ref} from ${baseFile}.`);
  }
  return { schema: node, file };
}

function typeOf(value: unknown): string {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  if (Number.isInteger(value)) return "integer";
  return typeof value;
}

function typeMatches(expected: unknown, value: unknown): boolean {
  const actual = typeOf(value);
  return expected === "number" ? actual === "integer" || actual === "number" : expected === actual;
}

// `URL.canParse` is missing on older mobile JavaScript engines.
function isParsableUrl(value: string): boolean {
  try {
    return new URL(value) instanceof URL;
  } catch {
    return false;
  }
}

function sameJson(left: unknown, right: unknown): boolean {
  return JSON.stringify(left) === JSON.stringify(right);
}

function check(
  documents: Readonly<Record<string, unknown>>,
  contractName: string,
  schema: SchemaNode,
  value: unknown,
  at: string,
  file: string,
  errors: SchemaViolation[],
): void {
  for (const key of Object.keys(schema)) {
    if (!SUPPORTED_KEYWORDS.has(key)) {
      throw new Error(`Unsupported schema keyword ${key} in ${file}.`);
    }
  }
  const fail = (message: string) => errors.push({ path: at || "/", message });
  if (typeof schema.$ref === "string") {
    const target = resolveRef(documents, contractName, schema.$ref, file);
    check(documents, contractName, target.schema, value, at, target.file, errors);
  }
  const matches = (branch: SchemaNode): boolean => {
    const branchErrors: SchemaViolation[] = [];
    check(documents, contractName, branch, value, at, file, branchErrors);
    return branchErrors.length === 0;
  };
  if (Array.isArray(schema.allOf)) {
    for (const branch of schema.allOf) {
      if (isRecord(branch)) check(documents, contractName, branch, value, at, file, errors);
    }
  }
  if (
    Array.isArray(schema.anyOf) &&
    !schema.anyOf.some((branch) => isRecord(branch) && matches(branch))
  ) {
    fail("no anyOf branch matched");
  }
  if (
    Array.isArray(schema.oneOf) &&
    schema.oneOf.filter((branch) => isRecord(branch) && matches(branch)).length !== 1
  ) {
    fail("expected one matching oneOf branch");
  }
  if (isRecord(schema.not) && matches(schema.not)) fail("prohibited schema matched");
  if (isRecord(schema.if)) {
    const branch = matches(schema.if) ? schema.then : schema.else;
    if (isRecord(branch)) check(documents, contractName, branch, value, at, file, errors);
  }
  if (schema.type !== undefined) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type];
    if (!types.some((type) => typeMatches(type, value))) {
      fail(`expected ${types.join("|")}`);
      return;
    }
  }
  if ("const" in schema && !sameJson(schema.const, value)) fail("const mismatch");
  if (Array.isArray(schema.enum) && !schema.enum.some((option) => sameJson(option, value))) {
    fail("not in enum");
  }
  if (typeof value === "string") {
    const length = [...value].length;
    if (typeof schema.minLength === "number" && length < schema.minLength)
      fail("shorter than minLength");
    if (typeof schema.maxLength === "number" && length > schema.maxLength)
      fail("longer than maxLength");
    if (typeof schema.pattern === "string" && !compiledPattern(schema.pattern).test(value)) {
      fail("pattern mismatch");
    }
    if (
      schema.format === "date-time" &&
      (!DATE_TIME.test(value) || Number.isNaN(Date.parse(value)))
    ) {
      fail("invalid date-time");
    }
    if (schema.format === "uri" && !isParsableUrl(value)) fail("invalid uri");
  }
  if (typeof value === "number") {
    if (typeof schema.minimum === "number" && value < schema.minimum) fail("below minimum");
    if (typeof schema.maximum === "number" && value > schema.maximum) fail("above maximum");
  }
  if (Array.isArray(value)) {
    if (typeof schema.minItems === "number" && value.length < schema.minItems)
      fail("fewer than minItems");
    if (typeof schema.maxItems === "number" && value.length > schema.maxItems)
      fail("more than maxItems");
    if (
      schema.uniqueItems === true &&
      new Set(value.map((item) => JSON.stringify(item))).size !== value.length
    ) {
      fail("items not unique");
    }
    if (isRecord(schema.items)) {
      const items = schema.items;
      value.forEach((item, index) =>
        check(documents, contractName, items, item, `${at}/${index}`, file, errors),
      );
    }
  }
  if (isRecord(value)) {
    const required = Array.isArray(schema.required) ? schema.required : [];
    for (const key of required) {
      if (typeof key === "string" && !Object.hasOwn(value, key)) {
        errors.push({ path: `${at}/${key}`, message: "required property missing" });
      }
    }
    const properties = isRecord(schema.properties) ? schema.properties : {};
    for (const [key, child] of Object.entries(value)) {
      const propertySchema = properties[key];
      if (isRecord(propertySchema)) {
        check(documents, contractName, propertySchema, child, `${at}/${key}`, file, errors);
      } else if (schema.additionalProperties === false) {
        errors.push({ path: `${at}/${key}`, message: "additional property not allowed" });
      } else if (isRecord(schema.additionalProperties)) {
        check(
          documents,
          contractName,
          schema.additionalProperties,
          child,
          `${at}/${key}`,
          file,
          errors,
        );
      }
    }
  }
}

/** Validate against an explicitly pinned schema registry. */
export function validateSchemaDocuments(
  documents: Readonly<Record<string, unknown>>,
  contractName: string,
  ref: string,
  value: unknown,
): readonly SchemaViolation[] {
  const errors: SchemaViolation[] = [];
  const { schema, file } = resolveRef(documents, contractName, ref, "");
  check(documents, contractName, schema, value, "", file, errors);
  return errors;
}
