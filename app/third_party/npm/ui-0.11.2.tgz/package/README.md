# @kombiverselabs/ui

Shared UI component library for the kombify platform. Provides shell components (navigation, footers, theme toggle) and the Stack Identity system.

## Modules

### Saved checklist inspection (`@kombiverselabs/ui/onboarding`)

`GettingStarted` accepts `inspection` and bindable `open` for Settings replay.
Pass the original resolved journey, including its saved status, and set the
bound `open` value to `true` at the checklist transition. Inspection retains
completed and blocked rows and the owner's progress; navigation remains usable.
Resume, manual completion, journey dismissal, tip dismissal and minimization
controls are suppressed. Closing updates only the bound presentation state.
Explicit inspection focuses Close; Close and Escape return focus to the
connected invoking control. Navigation and outside clicks keep their own focus.
Both props default to the existing navigation-widget behavior.

Inspection requires the matching `@kombiverselabs/onboarding-core` release with
`presentGettingStarted(..., { inspection: true })` support. Publish and adopt
the core and UI changes together through their existing Delivery workflows;
the older valid peer range alone does not establish inspection support. With
an older presenter, dismissed inspection stays hidden and never offers Resume.
The UI Lab `/onboarding` page demonstrates the API with **Inspect saved checklist**.

### Entity cards (`@kombiverselabs/ui/entity`)

Devices, people and agents, Offices and Factories share one card family and
one size scale: `mark` (logo only), `tile`, `row` (the smallest service card)
and `card`. `DeviceCard`, `ActorCard` (person or agent) and `WorkplaceCard`
(office or factory) map domain props onto `EntityCard`; `EntityCollection`
renders a list at one size with a view switch.

```svelte
<script lang="ts">
  import { ActorCard, DeviceCard, EntityCollection } from '@kombiverselabs/ui/entity';
</script>

<DeviceCard size="row" name="Pixel" formFactor="phone" platform="Android 17" presence="online" />
<ActorCard size="mark" kind="agent" name="Mail Researcher" agentType="expert" presence="busy" />
<EntityCollection items={devices} key={(d) => d.id} label="Devices" bind:view>
  {#snippet item(device, size)}<DeviceCard {size} {...device} />{/snippet}
</EntityCollection>
```

The host owns facts, presence and localized labels. `unknown` presence never
reads as offline. Actions are capability-driven (`EntityAction`).

`ApplicationCard` shows an application a person opens, in sizes `s` (the app
icon alone, opens the app), `m` (a 52 px line) and `l` (74 px, the size of a
compact service card). Logos render as app icons (squircle, light surface,
thin inset); an unstacked application is muted. `m` and `l` show up to two
quick `actions` and a "…" `menu`, and a click on the card calls `onDetails`.

`EntityDetailSheet` is the detail view of every card: facts, host content,
outside links (vendor, documentation, website, source, licence), a highlighted
support block for donations or paid editions, downloads and footer actions.

```svelte
<ApplicationCard size="l" name="Immich" logoUrl="/logos/immich.svg" status={{ tone: 'ok' }}
  management="stacked" placement="local" meta="photos.example.org" href="https://photos.example.org"
  actions={[restart, backup]} menu={[logs, update, docs]} onDetails={() => (open = true)} />
<EntityDetailSheet {open} onclose={() => (open = false)} kind="application" name="Immich" appIcon
  imageUrl="/logos/immich.svg" links={[{ kind: 'support', href: 'https://buy.immich.app' }]} />
```

### Application logos (`@kombiverselabs/ui/applications`)

`ApplicationCluster` is the shared application-package composition. `layout` is
`cloud` by default; `stack` and `fan` are explicit per-surface alternatives.
It accepts any number of applications and sizes `sm`, `md`, and `lg`.

```svelte
<script lang="ts">
  import { ApplicationCluster, type ApplicationClusterItem } from '@kombiverselabs/ui/applications';
  const apps: ApplicationClusterItem[] = [
    { id: 'immich', name: 'Immich', logoUrl: '/logos/immich.svg' },
    { id: 'jellyfin', name: 'Jellyfin', logoUrl: '/logos/jellyfin.svg', muted: true, statusLabel: 'Paused' }
  ];
</script>

<ApplicationCluster items={apps} label="Applications on this server" />
<ApplicationCluster items={apps} layout="fan" size="sm" />
```

Import the shared design CSS in the host as usual. Tiles and tooltips inherit its
`plate` and `menu-plate` recipes; the component owns only composition and geometry.
Catalog/runtime adapters, localised labels and logo provenance belong to the host.
The `logo` snippet receives an item and can reuse a curated logo renderer; custom
renderers own their own image fallback. Otherwise a missing/failed URL becomes
`monogram` or name initials, including images that failed before hydration.

- Stable `id` values are deduplicated in source order; first occurrence wins.
- `maxVisible` includes the `+N` overflow mark. Omit it to show all; zero renders
  nothing. `overflowLabel(count)` provides a localised label; hidden names remain
  in its accessible name. Supply `onoverflow` to open details or expand the list;
  the host restores focus when expansion replaces the overflow button.
- `onselect(item)` opts into native buttons; `selected` provides `aria-pressed`
  and a visible ring. Passive marks have accessible names; no dead buttons.
- `muted: true` requires an explicit `statusLabel`. Grayscale is accompanied by
  a minus badge. The component never infers installed, available or healthy state.
- Set `decorative` only when surrounding content already names the applications;
  it disables callbacks and removes duplicate screen-reader output.
- Layout and visible items are deterministic during SSR. CSS wraps on narrow
  surfaces, reserves image dimensions and leaves logo artwork upright. There is
  no measurement, random placement or automatic motion.

UI Lab: `/kombify-ui/applications` exercises the three layouts, 0–15 items,
overflow, selection, muted states and broken-image fallback.

### Shell (`@kombiverselabs/ui/shell`)

Layout and navigation primitives for consistent app shells.

| Component | Description |
|-----------|-------------|
| `SidebarNav` | Controlled, collapsible and drag-resizable primary rail with resize handle, compact collapse control, optional standard brand, active states and snippets |
| `AppRail` | Self-contained product rail with the same resize handle, collapse control and brand; remembers width and fold itself via `preferenceKey` |
| `BrandMark` | The kombify rosette (and rainbow wordmark): on the start page a click cycles it through the product colours and unfolds a collapsed rail; elsewhere it is a plain link |
| `RailResizeHandle`, `RailCollapseToggle` | The rail parts both rails share, for a product that builds its own rail |
| `InlineTabNav` | Horizontal tab-style navigation |
| `FooterModern` | Full-featured footer with `'full'` and `'compact'` variants, social links, legal links, dark mode logo |
| `FooterCompact` | Simple prop-driven footer (logo + copyright + custom links) |
| `ThemeToggle` | Dark/light mode toggle with localStorage persistence |

```svelte
<script>
  import { SidebarNav, FooterModern, ThemeToggle } from '@kombiverselabs/ui/shell';
</script>

<SidebarNav
  items={navItems}
  currentPath={$page.url.pathname}
  collapsed={railCollapsed}
  onCollapsedChange={(collapsed) => (railCollapsed = collapsed)}
  width={railWidth}
  onResize={(width) => persistRailWidth(width)}
  resizeControls="app-content"
/>
<FooterModern variant="compact" />
<ThemeToggle />
```

Every rail carries a thin drag handle centred on its inline-end edge (a short
rounded line with a wider invisible hit area, `cursor: col-resize`). It is a
focusable `role="separator"`: arrow keys resize, Enter and Home fold or unfold,
Shift takes the large step. Dragging 36 px beyond the expanded minimum collapses
the rail; dragging a compact rail 36 px back toward content expands it and
restores the consumer-owned width. The collapse control is a compact ghost
button beside the brand (a chip on the seam, revealed on hover or focus, while
folded). Products persist width and fold state per device — `readRailPreference`
and `writeRailPreference` are the shared helper, `AppRail` takes a
`preferenceKey` — and supply localized `collapseLabel`, `expandLabel`,
`resizeLabel`, and `collapsedValueLabel` strings. Mobile navigation remains a
separate primitive.

The brand follows one rule: pass the current-route-is-start-page boolean as
`isStartPage` and nothing else. On the start page a pointer click on the brand
cycles its colour and unfolds a collapsed rail; on every other route it stays a
link to `brandHref`. `SidebarNav` renders the standard brand with `showBrand`; a
custom `header` snippet is handed `{ collapsed, isStartPage, expand }` to wire
`<BrandMark {isStartPage} onExpand={expand} iconOnly={collapsed} />` itself.

### Identity (`@kombiverselabs/ui/identity`)

The Stack Identity system lets users personalize their kombify instance with a character, name, animation style, and glow color.

| Export | Type | Description |
|--------|------|-------------|
| `StackIdentityIcon` | Component | Renders the character emoji/SVG with glow and animation |
| `StackIdentityName` | Component | Displays the identity name with themed styling |
| `StackIdentityDisplay` | Component | Icon + name combined |
| `StackIdentityBadge` | Component | Compact badge for headers/sidebars |
| `StackIdentityCard` | Component | Full identity card with all details |
| `StackIdentityEditor` | Component | Interactive editor for choosing character, name, colors |
| `StackIdentityAvatar` | Component | Avatar-sized identity display |
| `StackIdentityGreeting` | Component | Welcome message with identity |
| `StackIdentityHeader` | Component | Header bar with identity branding |
| `StackIdentityWatermark` | Component | Background watermark effect |
| `resolveIdentityTheme` | Function | Resolves `StackIdentity` into CSS tokens and classes |
| `normalizeStackIdentity` | Function | Normalizes partial identity (e.g. from localStorage) |
| `characters` | Constant | Full character catalog |
| `getCharacter` | Function | Lookup character by ID |

```svelte
<script>
  import { StackIdentityDisplay, resolveIdentityTheme } from '@kombiverselabs/ui/identity';

  const theme = resolveIdentityTheme(userIdentity);
</script>

<StackIdentityDisplay identity={userIdentity} />
<div style={themeCssVarsString(theme)}>Themed content</div>
```

## Exports Map

| Subpath | Contents |
|---------|----------|
| `@kombiverselabs/ui` | Everything (shell + identity) |
| `@kombiverselabs/ui/shell` | Shell components + NavItem type |
| `@kombiverselabs/ui/identity` | Identity components, catalog, types |
| `@kombiverselabs/ui/styles.css` | Base styles |
| `@kombiverselabs/ui/identity.css` | Identity animation styles |

## Requirements

- Svelte 5 (runes)
- TailwindCSS 4
- `lucide-svelte` (peer icons)

## License

MIT
# React onboarding

`@kombiverselabs/ui/onboarding/react` exports React `Introduction` and
`GettingStarted` adapters. It requires React 19, React DOM 19 and Lucide React
and uses the same framework-neutral presenters and browser runtimes as the
Svelte adapters; its import graph does not load Svelte.
The package retains its existing Svelte peer for its other entries. Both
Introduction adapters load the shared layout CSS and use the host's
`@kombiverselabs/design` roles, appearance and product accent.

Pass `open`, an immutable `stops` list and the product's `resolveMessage`.
The existing optional `navigate`, `onComplete`, `onDismiss` and
`anchorTimeoutMs` props are supported. `navigate` may also accept an optional
second argument with an `AbortSignal`; route results are ignored after a stop
change even when an older host does not support cancellation. Close `open` in
the completion/dismiss callbacks; change it from false to true to replay.
Equivalent fresh descriptor arrays preserve the cursor and dismissal. Changing
any descriptor field starts a new session when the controlled `open` is true.

Mount the overlay alongside the application's existing content and dialogs,
without replacing that content. Stops describe actual chrome, not checklist
steps. The adapter stores no setup, journey, introduction acknowledgement or
reward progress; automatic eligibility and durable replay entry points belong
to the host. React Strict Mode cleanup emits no completion or dismissal.

`GettingStarted` takes the same resolved `journey`, `resolveMessage` and action
callbacks as Svelte. It portals its panel without replacing application content.
Use `inspection` and change `open` from false to true to inspect saved tasks,
including dismissed and completed journeys. Inspection offers navigation and
Introduction replay but no completion, resume, minimization or dismissal writes.
`onOpenChange` reports local opening and closing; retain that value when the host
also controls `open`. Closing does not change saved progress.

Both GettingStarted adapters pass `onNavigate(step, event)` for task links and
`onNavigateTip(tip, event)` for tip links. Call
`event.preventDefault()` synchronously when routing inside an existing host;
check the modifier keys when preserving new-tab behavior. Otherwise the real
step href keeps normal browser navigation. Existing one-argument callbacks
remain valid. Eligibility, module admission, progress, persistence and navigation
remain product responsibilities; the shared adapter never invents completed work.
