# @kombiverselabs/ui Changelog

> **How versions here relate to the registry.** Headings in this file are the
> authored *lines* (`0.8`, `0.9`). Delivery v2 derives the published patch from
> `.kombify/VERSION` plus the first-parent commit count since that file last
> changed, so the registry carries `0.9.0`, `0.9.1`, … within a line. A new
> heading therefore means "the line moved", and the entries under it cover
> everything published on the previous line since the previous heading.

## 0.10.0

### 2026-10-15 — one use-case module for Cloud and Techstack

- **Paintings ship in the package.** `UseCaseArt` and `useCaseArtSrc()`
  draw the day and night painting of every use case (photos, files, vault,
  media, smart-home, dev, mail, game) or its glyph. `UseCaseCardCompact`
  and `UseCaseSetupCard` take `art` and `dark`, so hosts no longer copy the
  images.
- **The setup is built here.** `setupFlowFromCatalog()` builds the guided
  setup from the StackKits release catalog (catalog types and
  `catalogViewsFromResponse` moved here from Techstack), with hardware hints,
  `setupChanges()` and `setupAnswersFor()`. Cloud and Techstack ask the same
  questions, so answers handed from Cloud resolve identically in Techstack.
- **One wording in six languages.** `useCaseSetupLabels(locale)`,
  `useCaseLabels(locale)` and the question texts speak en, de, es, zh-Hans,
  hi and ar; a changed sentence changes on every surface.
- **Detail levels.** `UseCaseGuidedSetup` and `UseCaseSetupCard` take
  `level` (1 hands-off … 5 expert) and show the remaining questions behind
  "More settings"; hidden questions keep their recommendation.

### 2026-10-12 — one app-icon frame on application and service cards

- **App icons: 23 % squircle, 10 % inset.** `EntityAvatar`'s app-icon frame
  (application cards, all sizes) moves from 22.5 %/8 % to the agreed
  23 %/10 %.
- **Service cards show logos as app icons.** `ServiceCard` and
  `ServiceCardCompact` draw a logo in the same frame through the new
  `KfGlyph` `appIcon` prop, so an application L and the smallest service
  card read as one family. Without a logo the status-tinted glyph stays.

### 2026-10-11 — entity cards react to a click again

- **`onselect` works.** The full-card hit target of `EntityCard` (and so
  `ActorCard`, `WorkplaceCard`, `DeviceCard`) lost to the shell rule that
  lifts every child to `position: relative`, collapsed to 0×0 and could not
  be clicked. It now spans the card like `ApplicationCard`'s hit target.

### 2026-10-10 — entity cards: app icons, Techstack heights, one detail sheet

Follows the owner review of the Techstack application cards.

- **Application logos are app icons** in the iOS/Android launcher format: a
  squircle (22.5 %) with a light surface, a hairline ring and a soft shadow;
  the logo keeps one thin, even 8 % inset (`EntityAvatar` `appIcon`). An
  unstacked application fades part of the way (`muted`), never to grey.
- **Techstack heights.** `ApplicationCard` `s` is the app icon alone (64 px,
  opens the app), `m` a 52 px line, `l` 74 px. The entity `row` grows from
  58 px to the same 74 px grid unit (avatar 44 px).
- **`m` and `l` carry more.** Stacked/Unstacked plus a compact Local, Cloud or
  Managed indicator (`placement`), up to two quick actions (`actions`, e.g.
  Restart and Backup) and a "…" menu (`menu`, e.g. Logs, Update,
  Documentation) in `EntityActionMenu`, which opens in the top layer so the
  card never clips it. `EntityAction` gains `href` and `external` for link
  actions. A click on an `m` or `l` card opens its details.
- **`EntityDetailSheet`**, the one detail view of every entity card (device,
  person, agent, Office, Factory, application, service): identity and status
  chips, facts (flat or grouped), host content, outside links (vendor,
  documentation, website, source, community, licence), a highlighted
  "support the developers" block for donations, sponsoring and paid editions,
  downloads, and a footer action bar.

### 2026-10-10 — entity cards: devices, people and agents, Offices and Factories

New subpath `@kombiverselabs/ui/entity` (also on the root export). One card
family for every entity that is not a service, composed from the existing
card shell, so finishes and the Beacon light apply unchanged.

- **One size scale for every entity.** `mark` (72 px, avatar or logo only, the
  mobile logo view), `tile` (168 × 152 px), `row` (58 px, the footprint of
  `ServiceCardCompact` and `ServerCardCompact`) and `card` (at least 280 px,
  the footprint of the detailed service and server cards).
- **`ApplicationCard`** for applications a person opens (Immich, Hermes, a
  kombify tool), presentation only: name, logo, status, address, size. `s` is
  the logo alone at mark size (a click opens the app, or its details without an
  address) with a corner lamp, `m` one 42 px line with lamp, name,
  Stacked/Unstacked, Open and Details, `l` the row footprint with the address
  and the status in words, so a large application card is exactly a compact
  service card. The logo fills its area edge to edge. An unknown status is a
  hollow lamp; Open without an address stays disabled with its reason.
- **`DeviceCard`** for mobile and desktop devices (phone, tablet, watch,
  laptop, desktop, TV, server), with model, platform, last seen, installed
  kombify apps and owner. `deviceFormFactorFromPlatform` maps kombify Connect
  platform strings.
- **`ActorCard`** for people and agents in one list: a person is a circle with
  a role, an agent a squircle with the spark badge, its type, role, Office,
  Factory, model and the person it acts for.
- **`WorkplaceCard`** for Offices and Factories, with the resource an Office is
  about, counts and a member avatar stack.
- **`EntityCollection`** renders a list at one size with a view switch
  (Logos, Tiles, List, Cards); bind `view` to remember it.
- **Presence is honest.** `unknown` is its own state (dashed ring, "Status
  unknown") and never reads as offline; idle is a ring, the rest filled dots.
  At mark size the accessible name carries name, kind and presence.
- Actions are capability-driven `EntityAction`s with host-localized labels:
  none at mark, one at tile, two at row, four at card. All labels are
  overridable through `labels`.

UI Lab: `/kombify-ui/entity`.

### 2026-10-10 — use-case cards: guided setup and a one-card modal

Additive to `@kombiverselabs/ui/usecase`; existing cards are unchanged.

- **`resolveSetup` and the flow schema** (`UseCaseSetupFlow`). A use case
  declares a few questions in the operator's words; each choice maps onto the
  StackKits catalog's capability and setting ids. Questions can depend on
  earlier answers, unanswered questions use the recommended default, a hidden
  question contributes nothing, and later answers win. The result carries the
  selection, the chosen tools, a summary line and the choices the release only
  records.
- **`UseCaseGuidedSetup`.** One question per step, a step rail, a closing
  review with "Change" per answer, and "Use our recommendation" on every step,
  so the standard needs no answers. The step-by-step replacement for a flat
  Advanced drawer on use cases with real choices.
- **`UseCaseSetupCard`.** One use case as a self-contained unit: the enhanced
  card with the guided setup in its details. `presentation="inline"` for the
  creation grid, `"open"` for a modal or detail page. The tool strip follows
  the answers.
- **`UseCaseCardModal`.** Shows exactly one card in a native dialog, e.g.
  after "+ Add photos" on a dashboard; focus returns to the opener.
- UI Lab: `/kombify-ui/usecase/setup` with Private AI and Photos flows.

### 2026-10-09 — notifications SDK under its new name

`@kombify/notifications` now resolves to `@kombiverselabs/cloud-notifications`
(same code, published by kombify-Cloud). `@kombiverselabs/notifications` is
deprecated; imports are unchanged because the alias stays.

### 2026-10-09 — the Feed: sections, Needs you, digest and household cards

The notification center becomes the **Feed** (Companion Feed contract v1,
`DECISION-RECORD-2026-10-09-companion-feed.md` section 2). Additive; every Feed
call is optional on the transport, so a host with an older
`@kombiverselabs/notifications` keeps the plain list.

- **Center.** Titled "Feed" in all six locales. Section chips (All, Household,
  Homelab, Paperwork, Agents, System) with unread dots from the engine's
  counts; the Needs-you lane on top (actionable and unresolved, folds past three
  entries); the unread daily digest pinned on top of Today, then Today,
  Yesterday, This week, Older. Renderers for the detail kinds `digest`
  (rows, metrics with tones, pointers; one row in a section view),
  `attention` (red or amber lamp, the catalog subject only: the web never
  resolves mail text), `share` (avatar, text, album, folder or link target;
  a thumbnail only when the target's own https URL is an image), `forward`
  (quoted original and note) and `user_notification` (smart-home notice).
  Reactions on household items, an item menu (topic modes "only in the digest",
  "no push", "mute", hidden for locked and decision topics, with Undo; Forward
  only for forwardable items), the tuning suggestion card and a per-section
  "mark all read". The view "Inbox" is now "Active"; the lane is "Needs you".
- **Bell.** Stays the quick-access popover (Needs you, then the latest
  entries), titled "Feed", draws the new kinds read-only and links to the Feed
  page.
- **Preferences.** `NotificationPreferences` is "Feed & Push": per-section
  in-feed and push modes, the daily digest (on or off, time, push) and the
  per-topic channel matrix grouped by section under "Details". Quiet hours stay
  with the host.
- **Needs you is the contract's rule.** `needsAction` is now `actionable` and
  unresolved, like the engine's `needs_you` count; an urgent unread item that
  is not actionable stays in the timeline with a red lamp.
- **Host wiring (once `@kombiverselabs/notifications` carries the Feed
  calls).** Nothing changes for a host that passes the default or a
  `FeedTransport` from the new notify-client: `getCounts`, `fetchFeed({ sections })`,
  `markAllRead({ sections })`, `react`, `putTopicMode`, `get/putSectionPreferences`,
  `get/putDigestPreferences`, `getSuggestions` and `dismissSuggestion` are found on
  the transport and the Feed lights up. Forward needs the host's household
  service: pass `forwarding={{ available, forward({ item, note }) }}` (hidden
  without it). Pass `bind:section` (Svelte) or `section` and `onSection` (React)
  to keep `?section=` in the URL. Label overrides go in the `feed` group of the
  center, bell and preferences labels. New exports: `FeedAwareTransport`,
  `FeedForwarding`, `FeedSectionId`, `isFeedSection`, `NotificationFeedLabels`.

### 2026-10-09 — card lifetimes, React entries, live by default, batches

- **Interaction Card lifetimes follow the contract.** Option kinds are now
  `allow_once`, `allow_task`, `allow_project`, `allow_always`, `deny`, `never`,
  `choose`, `submit`, `reply`, `snooze`, `open`, `send_to`. `allow_run`, `allow_ttl`
  and `scope.ttl` are gone (an unknown kind is dropped, never drawn as an allow);
  `scope.taskRef { id, revision }` and `scope.projectRef { id }` are new, and a
  task or project answer without its reference is not offered. Task, project and
  permanent answers are never offered (nor rendered if present) on
  `cost_bearing`, `destructive` or `disclosure` cards. The primary answer stays
  "Allow once" beside an equally sized "Deny"; "More options" holds this task,
  this project, always, never for this agent and send to; the scope chip reads
  once / this task / this project / always. All six locales updated. Breaking
  for hosts that sent `allow_run` or `allow_ttl`.
- **React entries.** `@kombiverselabs/ui/interaction/react`
  (`InteractionCard`, `InteractionBatchCard`) and
  `@kombiverselabs/ui/notifications/react` (`NotificationBell`,
  `NotificationCenter`, `NotificationDetail`) for React 18 and 19 hosts. They are
  thin renderers over the same model (`interaction/view.ts`), feed controller
  (`notifications/controller.ts`), labels, sanitizing, transport and
  stylesheets as the Svelte components; the Svelte card and notification
  styles moved from component `<style>` blocks into plain stylesheets both
  renderers import. React props use `onAnswer` / `className` where Svelte uses
  `onanswer` / `class`.
- **Live by default.** Pass `getToken` (Gateway-direct) or `liveUrl` (same-origin)
  to the bell or the center and they open `wss://…/v1/notifications/live` with
  the `kombify.notifications.v1` subprotocol themselves: reconnect with backoff,
  SSE fallback, pause while hidden. An event updates the unread count and the
  list, and a card answered on another surface collapses. While the socket is
  not open the components keep polling (bell 30 s, center 60 s when live is
  configured; both stretch to five minutes while live flows). `live` still takes
  an explicit source.
- **Answers through a transport.** `decisions` (a `DecisionTransport`, e.g.
  `decisionClient({ getToken })`, `POST /v1/decisions/{id}/answer`) lets the
  bell and the center answer cards themselves with a fresh idempotency key and
  the intent digest; `onInteractionAnswer` still takes over for hosts that raise
  their own passkey step.
- **Batches.** Pending cards sharing a `collapseKey` render as one
  `InteractionBatchCard` in the bell's and the center's "Needs action" section
  (`Allow selected`, `Deny all`, one answer call per item). Cards that spend,
  delete, reveal a secret or need a passkey never join.

### 2026-10-04 — logos load from the Cloudflare asset host

- The shell brand assets (`brand-assets.ts`) now build their logo URLs on
  `https://assets.kombify.io/brand/logos` (Cloudflare R2 `kombify-public-assets`)
  instead of the CMO origin. The key layout and the `?v=` versions are
  unchanged, so only the origin moves. Patch-level, no API change.

### 2026-10-03 — rail handle, drag-to-collapse, brand expands

- Every rail (`SidebarNav`, `AppRail`) carries the same `RailResizeHandle`: a
  short thin grip centred on the inline-end edge with a wider hit area, a
  focusable `role="separator"` (arrows resize, Enter/Home fold). The drag logic
  is shared; the two copies in the rails are gone. `AppRail` shows it without
  `onResize` too and keeps its own width, optionally persisted via
  `preferenceKey`.
- The collapse control is a compact ghost button (`RailCollapseToggle`), not a
  32 px bubble: a quiet glyph beside the brand while expanded, a small chip on
  the seam shown on hover or focus while folded.
- `isStartPage` on `SidebarNav`, `AppRail` and `PlatformHeader`: a pointer click
  on the brand on the start page unfolds a folded rail instead of navigating;
  elsewhere the brand stays a link. `SidebarNav` gains `showBrand`, `brandHref`,
  `brandLabel`, `productLabel`; its `header` snippet is handed
  `{ collapsed, isStartPage, expand }`.
- `BrandMark`: the kombify rosette and rainbow wordmark. On the start page each
  pointer click advances one product colour (kombify, cloud, techstack,
  stackkits, simulate, companion-studio, sites, paperwork, speechkit, workbench,
  back) with a short spring turn and cross-fade; reduced motion swaps instantly.
  The position is in memory only, shared across the app. Keyboard activation
  never cycles. `AppRail` and `PlatformHeader` render it when no `logoSrc` /
  `brandLogoSrc` is given.
- `railKeyAction`, `clampRailWidth`, `readRailPreference` and
  `writeRailPreference` are exported from `/shell`.

### 2026-10-02 — cards carry light; update and Stack it

- The card shell (server, service and device cards) gains light layers driven
  by `--kf-card-*` tokens: a spotlight and an edge flashlight that follow the
  pointer, a resting sheen or grain, a leading status rail, the brand corner
  brackets and an orbiting rim. Each finish shapes them; the card decides
  nothing (KOMBIFY-DESIGN-SYSTEM-STANDARD §7, seventh ruling).
- Tokens carry mix amounts (`--kf-card-tone`, `--kf-card-wash-mix`,
  `--kf-card-spot-mix`, `--kf-card-ring-mix`, `--kf-card-glow-mix`,
  `--kf-card-glyph-mix`) instead of colours that reference the card-local
  accent, which never resolves on the document root where finishes declare.
- `ServiceActionId` gains `update` and `adopt` ("Stack it"). `ServiceCard`
  shows an available `update` whatever the status, with the Update action on
  its strip, and offers Stack it on its own strip; a displaced action falls
  back into the icon row.
- `ServiceCard` and `ServiceCardCompact` take `logoSrc` (icon fallback on a
  load error); `ServiceCard` takes `version`.
- `backdrop-filter` is declared after its `-webkit-` twin: a CSS minifier that
  folds the pair keeps the last declaration, and only the unprefixed one paints
  in Chromium, so production glass rendered flat in Chrome and Edge.

### 2026-10-01 — interaction cards

- New `@kombiverselabs/ui/interaction`: `InteractionCard`, the one card an agent
  asks the owner anything with (permission, confirm_spend, choice, input,
  review, schedule, handoff, ack, info) and `InteractionBatchCard` for
  low-risk groups. It renders `InteractionCardV1`
  (AI-AGUI-RENDERING-CONTRACT.md "Interaction Cards").
- Events only: the card emits `onanswer({ optionId, payload? })`; proof,
  idempotency key and the Gateway call stay with the host, which feeds the
  result back through `card.state`.
- The authority zone is a fixed component with the shield glyph, risk badge,
  full recipient or domain (look-alike characters marked) and cost; the agent
  note is quoted, plain text, at most 280 characters, and dropped when it
  carries a link or markup. Always allow and delegation never render for
  destructive, cost-bearing or disclosure requests, nothing is preselected, and
  L2 options restate what the passkey confirms before they emit.
- `parseInteractionCard` rebuilds a card from untrusted input and ignores one it
  cannot read. Catalogs for en, de, es, zh-Hans, hi and ar (`locale` prop, RTL).
- Notification Center and bell render a feed item whose `detail.kind` is
  `interaction` as the card (`onInteractionAnswer`, `interactionMessage`);
  the `approval` kind stays.

### 2026-09-30 — notification center: inbox with a detail pane

- `NotificationCenter` is the three-column inbox the owner chose ("1",
  2026-09-30): views and a product filter on the left, the grouped list
  (Needs action / Earlier, folded repeats) with search in the middle, and
  the opened notification on the right.
- Opening never navigates. The detail pane shows status, product, group
  position, the full text, every action, Archive and one explicit
  `Open in <source>` link, then the facts the feed carries (priority, first
  and last seen, occurrences, topic, tags, reference, resolution) and the
  other members of its group.
- New `detail` snippet: a product renders its own kind-specific record under
  the text. New `selectedId` (bindable) and `onSelect` let a host keep
  `?item=<id>` in the URL; `settingsHref` adds the settings link.
- ↑/↓ (or j/k) move through the list, Esc closes the detail. Below 48rem
  list and detail take turns with a back button.
- The center's default `dismiss` label reads "Archive", which is where a
  dismissed notification goes.

### 2026-09-30 — the bell panel groups, filters and opens in place

- `NotificationBell` panel is the grouped popover (owner choice "A",
  2026-09-30): a header with the unread pill, a filter switch (All / Needs
  action / Unread), a **Needs action** section above **Earlier**, and a
  footer link to the notification center. The panel is 384px wide and up to
  560px tall.
- Repeats of one producer family (same `source_app` and `group_key`, else
  `topic_key`) fold into one row ("4× gave up after retries") that expands to
  its members, with "Mark these read" and "Dismiss these".
- **Opening a notification no longer navigates.** A click expands the row in
  place: full text, time, source and occurrence count, the approved quick
  actions, and one explicit `Open in <source>` link (`deep_link`, else
  `link_url`). Opening marks the item read.
- Unread is a dot and a heavier subject; the `selection` fill on unread rows
  is gone.
- New `NotificationBellLabels` keys for the filters, sections, group rows
  and the source link; `viewAll` now reads "Open notification center".

### 2026-09-30 — the rail's collapse bubble no longer jumps or vanishes

- `SidebarNav` centres its seam toggle with `top` instead of
  `transform: translateY(-50%)`. The finish hover recipes (liquid lift,
  expressive grow) set their own `transform`, which replaced the centring
  and dropped the bubble by half its height on hover.
- The seam toggle of `SidebarNav` and `AppRail` carries `data-rail-seam`,
  which `@kombiverselabs/design` keeps an opaque disc in every state; at rest
  the navigation's quiet control rule had made it transparent, so only the
  hover state showed the circle.

### 2026-09-26 — closing a rail preview no longer removes the rail foot

- `NavFlyout` portals ONE node per open card (`.kx-nav-flyout-layer`,
  `display: contents`) instead of the scrim and the host separately. The
  block started with the tether `{#if}` anchor, which stayed in the rail,
  and ended with the host, which was moved to `<body>`; Svelte removes a
  block by walking siblings from its first node to its last, never met the
  end, and removed every later rail sibling. Since the navigation preview
  shapes (#410) the first preview a user closed took the whole rail foot
  (onboarding, notifications, account pill) with it.

### 2026-09-25 — navigation preview shapes in the tab bar

- `InlineTabNav` (the embedded top bar) opens its preview in the same
  `navFlyout` shape as the rail, turned a quarter: the flag hangs from the
  bar's bottom edge with its radii running left and right along it, the
  overlap reaches a few pixels over the bar, the tether line runs down from
  the tab. `createNavFlyout(leaveMs, side)` takes the side; `NavFlyoutPanel`
  takes `attach` (`start` | `top`).
- The overlap reaches back 6px instead of 48px, so it never covers a label.

### 2026-09-25 — navigation preview shapes

- `SidebarNav` opens its hover preview in the device's `navFlyout` shape
  (`@kombiverselabs/design`): `flag` hangs off the rail edge with outward
  radii and joins the entry that opened it (the default for the `kombify` and
  `expressive` finishes), `overlap` slides over the rail edge with an accent
  notch, `tether` floats free with a line back to its entry and quiets the
  page, and `float` is the free card (the default for `liquid`, `frost` and
  `aurora`). A product needs no change: the choice is read from
  `data-nav-flyout-shape` and the nearest `data-finish` when a card opens.
- `createNavFlyout().open()` takes the rail element as an optional third
  argument and exposes `target`, `edge` and `shape`; `NavFlyoutPanel` takes
  `shape`. The tab bar and `AppRail` keep the free card.
- Fixed: the controller kept the open item in a deep `$state` proxy, so
  `aria-expanded` never matched the entry that opened the card.

### 2026-09-20 — localized onboarding denial guidance

- `GettingStarted` resolves the canonical onboarding guidance message IDs with
  typed parameters and renders the required English title, body, and next-step
  fallbacks when a catalog reference is absent or cannot be formatted.

### 2026-09-20 — advanced use-case settings tabs

- `UseCaseAdvanced` has an opt-in tabs presentation for one-at-a-time advanced
  settings groups. It keeps the outer progressive disclosure, supports concise
  group orientation, and follows the tab keyboard pattern while preserving the
  existing accordion API by default.

### 2026-09-17 — FAQ blocks

- New `@kombiverselabs/ui/faq`: `FaqSection` (featured questions at the bottom
  of a landing or product page, `variant="inline"` beside billing or settings
  views, renders nothing without items), `FaqItem` (native disclosure with
  `id={slug}`; `#slug` opens it on load and on hash changes), `FaqLinks`,
  `FaqGroups` (full FAQ page: topic rail and one section per topic, filtered by
  search words and product) and `FaqFilter` (search plus product chips). The
  props mirror the public FAQ read API (`/v1/content/faq`), so a site passes
  the payload straight through; strings arrive through `labels`.
- Helpers `filterFaqItems`, `visibleFaqGroups`, `faqPlainText` and `faqJsonLd`
  (schema.org FAQPage JSON with every `<` escaped). Styling comes from
  `@kombiverselabs/design/editorial.css`.

### 2026-09-16 — Stack Identity preview shows the text effect again

- `StackIdentitySettings`: the preview name renders through
  `StackIdentityName`, so it carries the character's text effect and glow
  (the settings rows had dropped both).

### 2026-09-16 — Stack Identity as settings, clearer picture tiles

- `StackIdentitySettings` (identity): every Stack Identity choice as settings
  rows — preview, name, character, icon style, glow, animation — with Save and
  Reset under the values. No collapsed card and no "Customize" step. Labels
  come from the consumer's catalog.
- `OptionTiles`: the checked tile carries a solid accent ring in every finish
  (its state must read the same everywhere), hint text follows the tile's own
  colour so it stays legible on an accent-filled selection.
- `SettingsRow` with `align="start"` gives its control the whole value column,
  so wide pickers line up with every other value instead of stacking under the
  label.
- `StudioTile`: a tile with a single row no longer repeats its title as the
  row label.

### 2026-09-16 — settings rows keep label and value together

`SettingsRow` puts the control directly beside a fixed label column
(`--kx-settings-label-width`, default 16rem) instead of flush right, and a row
stops at a readable measure (`--kx-settings-row-max`, default 56rem). Owner
review of the live Cloud settings: a label on the far left and its value on
the far right of a wide page forced the eye across the whole screen for every
row. Stacked rows (tiles) keep the full width.

### 2026-09-16 — settings structure and the Design Studio view

`@kombiverselabs/ui/settings` is the settings page structure every product
composes (SETTINGS-STANDARD): `SettingsShell` (page header + tab strip +
body), `SettingsTabs` (shared tabs first in the fixed order, tool tabs after,
exact slug match, no plate, no flyout), `SettingsSection` (heading + lead +
rows; `tone="danger"` for the section that owns destructive actions),
`SettingsRow` (label and description left, control right, stacks under
40rem), `OptionTiles` (a picture radio — one tile per option, only the chosen
one carries `selection`; an unavailable option stays visible with its
guidance), `RecipeSwatch` (the real plate and selection recipes at half
scale in a `data-design-scope` subtree, lifted from Techstack's finish
swatch) and `ThumbFrame` (the fixed-aspect frame a product draws its own
layout thumbnail into, lifted from Paperwork's settings previews). A settings
page carries no `plate` outside dialogs and object rows.

`@kombiverselabs/ui/studio` is the Svelte view of the Design Studio over
`@kombiverselabs/design/studio`: `DesignCanvas` (draft state, stage tablist,
measured leads, Apply/Discard bar, conflict notice; rebases when the
baseline moves), `StudioTile` (`menu-plate` with segment / switch / tiles /
note / action / preview rows) and `Stage`. A product supplies the adapter,
the stages and the tiles with its own message ids. The boundary test pins
the contract: nothing reaches the adapter before Apply, then one account
write with only the changed keys.

### 2026-09-08 — Stack Identity catalog source

`@kombiverselabs/ui/identity` reads characters, glow presets, and icon styles
from `@kombiverselabs/design/stack-identity`. Theme resolution stays in this
package because it emits CSS class names for `identity.css`.

Identity surfaces take closed design roles: the badge is `tag` with catalog
`--kx-accent` tokens, the card is `plate`, and the editor's rows are
`control` / `control selection`. Author-supplied glow overrides never reach
`--kx-accent`. `identity.css` keeps animation hues on `var(--glow-color)`
instead of hex literals.

### 2026-09-05 — the account menu

- `AccountMenu` (shell): one account pane for every shell, after the Companion
  Studio's user pane. The identity card (rail foot) or the avatar alone
  (top bar, folded rail) is the trigger; the panel opens as a portaled fixed
  `menu-plate` with an identity hero on top — name, email, labels as tags —
  then the product's entries (`AccountMenuItem[]`: Settings, Domains,
  Billing, Docs), an `extra` slot (appearance switch, version line) and Sign
  out last. Settings and account entries leave the main navigation for this
  pane (owner direction 2026-09-05).

### 2026-09-05 — the current rail entry is the most specific match

- `SidebarNav` lights only the longest matching href: an overview entry
  whose href is a prefix of every other route no longer reads as current on
  those routes (kombify Cloud: Overview and Settings were both selected), and
  a prefix only matches at a path segment boundary.

### 2026-09-05 — two kinds of rail entry, compact labels, groups

- `NavItem.kicker`: a quiet line above the label in the expanded rail ("run your"
  over "Techstack"); an entry without one stays icon and label. Two kinds
  of main entry, decided per item (owner direction 2026-09-05, the kombify
  Cloud navigation).
- `SidebarNav collapsedLabels`: the folded rail shows `NavItem.compactLabel`
  (or the label) under each icon — "run", "find", "Home" — so it reads
  without a tooltip.
- `SidebarNav groups`: named sections (`NavGroup`) read as small headings
  expanded and fold to a short inset rule collapsed. `items` stays the
  single-group form.

### 2026-09-05 — styles.css answers to data-appearance

- The generated palette keys dark mode on `:is(.dark, [data-appearance="dark"])`
  and the Tailwind `dark:` variant on either form, so a consumer stamps
  `data-appearance` once and the utilities, the product themes and the design
  package's material agree. The `.dark` class keeps working through the
  transition.
- The neutral ramp is the kombify tile ramp the design package paints on its
  roles (see the design changelog): `bg-background`, `bg-card`, `bg-muted`,
  `text-foreground`, `text-muted-foreground` and the sidebar family shift by a
  few units toward what `plate` and `app` already showed, and the same value
  now reaches a utility and a role.
- `theme-cmo` is emitted here as a web theme (it lived in the design
  package's product.css); `theme-stack` dark no longer carries the StackKits
  accent.

Minor, not patch — the shell components' visual contract changes: navigation
chrome stops painting its own opaque background and renders the design
package's plate material instead (owner decision 2026-08-19,
KOMBIFY-DESIGN-SYSTEM-STANDARD §7). Pairs with `@kombiverselabs/design` 0.10,
which ships the `--plate-*` effect seam.

### Changed

- **The large use-case card selects like the tile.** With `onToggle`, the
  pitch is the click target and a checkbox mark sits top-right (plus = not in
  the kit, check on the accent = in the kit); clicks on controls inside the
  card never toggle it, and the mark carries the keyboard handling. The former
  add/remove CTA is gone. New props: `selectable`, `infoHref`/`infoLabel` (an
  info affordance that opens the use case's guide), and `decisions`/
  `decisionsLabel` (the operator's current choices summarised on the pitch —
  level two of the depth model; the drawer is where they change).
- **The use-case card's advanced drawer spans the whole card.** `UseCaseAdvanced`
  gains `variant: 'boxed' | 'band'`. In the split layout `UseCaseCard` renders the
  drawer as a flush band under both columns, on the card's own hairline, and an
  open drawer lays its groups out as tiles in an auto-fit grid — side by side on
  a wide card, stacked on a narrow one. The dossier layout keeps the boxed panel.
  Below the split's own 640px container query the stacked card also tightens its
  insets, because stacked is its compact face: the same card two abreast in a
  wizard grid (owner direction 2026-09-05).
- **Embedded tabs drop the bottom underline and the full-height tile.**
  `InlineTabNav` keeps header geometry only: a compact 32px chip. The
  `kombify` header recipe owns the leading hairline, so the component no
  longer paints a second accent under the active tab.
- **Sidebar navigation now owns the shared `navigation` role.** Dark rails keep
  a distinct translucent ground and readable inactive controls while preserving
  the fixed flyout behavior and the package's compact 76px rail.
- **Server severity no longer conflates reachability with warnings.** The shared
  `ServerCard` renders `degraded` with warning semantics and reserves the
  destructive treatment for `offline`; pending and unknown states remain
  neutral. The shared status badge vocabulary now includes `degraded`.
- **Service cards expose product navigation and access evidence.** Consumers can
  provide a keyboard-accessible `detailsHref` for the card body independently
  from action buttons, plus either an address or an honest unavailability reason
  directly below the service display name.
- **Installer contract follows the authored 0.10 line.** The package metadata
  now requires `@kombiverselabs/design` `^0.10.0` and reports source version
  `0.10.0`, matching `.kombify/VERSION` and the Design package. The first 0.10
  deliveries accidentally retained the authored 0.9 peer even though the
  changelog and runtime recipes had already moved together; consumers must not
  combine UI 0.10 with Design 0.8/0.9.
- **Shell nav chrome follows the PlatformHeader pattern.** `SidebarNav` drops
  `bg-sidebar`/`border-sidebar-border`/`hover:bg-sidebar-accent` and the
  active row's `bg-primary/10` (the `selection` role paints it); `InlineTabNav`
  drops `bg-background`/`border-border` and is promoted to
  `data-kx="header plate"`; `FooterCompact` drops `bg-background/95` and gains
  `data-kx="footer plate"`. Components keep geometry only: edge components
  square their radius and keep a single rim hairline in scoped CSS. In a
  consumer with the design layer loaded the nav now reads as translucent
  glass — the utility-vs-role specificity coin flip that rendered the same nav
  opaque in Techstack and glass in CMO is gone.
- **Card Beacon signature is finish-adaptive.** `ServerCard`, `ServiceCard`
  and `ServiceCardCompact` keep their signature (accent wash, top hairline,
  hover glow/lift, glyph glow) as the card family's own default standard —
  §7 sanctions cards as the accent surface — but every effect now reads a
  `--kf-card-*` custom property (`wash`, `hairline`, `hover-border`,
  `hover-glow`, `hover-lift`, `selected-border`, `selected-glow`,
  `glyph-glow`) whose fallback is the shipped kombify baseline. A finish
  adapts the signature by overriding the inherited properties; rendered
  output is unchanged while nothing overrides. `prefers-reduced-motion` now
  also stills the glyph scale/rotate answer in the detailed cards.

### Added

- **`styles.css` ships zero-specificity shell fallbacks**: `:where()` rules
  give `plate`/`header`/`footer`/`menu-plate` carriers a plain opaque surface
  in consumers that have not loaded `@kombiverselabs/design`, and lose to
  every role recipe the moment it loads.
- **Rail foot owns onboarding, notifications, and account.** `SidebarNav`
  stacks those three in one foot with a dedicated `notifications` snippet;
  collapsed controls are 40px and centred. Compact getting-started uses the
  same horizontal progress recipe as the detailed row, and compacting is
  reversible (`onboarding.ui.getting_started.expand`). The `NotificationBell`
  glyph matches that 40px square instead of sitting off-centre against the
  avatar.

## 0.9.0

Minor, not patch — this release *removes* published tokens. Under 0.x SemVer a
removal is signalled by the minor position, which is the whole reason the line
moved (see "Removed" below and the versioning note at the end).

### Removed

- **Retired unused tokens from `styles.css`**: `--chart-1` … `--chart-5` and
  their Tailwind `@theme` mappings, `--corner-color-light`, and
  `--btn-secondary-shadow`. Verified unused before removal — zero utility uses
  and zero component reads across the Administration, Cloud, Techstack, cmo and
  ui-lab trees; each of Cloud, Techstack and ui-lab already defines its own
  `chart-*` values locally in `app.css`, so nothing resolved these through this
  package.
- These bytes physically left the package in the derived patch `0.8.83`, which
  understated the change. `0.9.0` is the correction, and it is being made
  *before* any consumer bumps: at the time of writing no repository outside
  kombify-Brand had resolved `0.8.83`, so no caret range ever picked up a silent
  removal. A consumer that did define one of these names locally is unaffected;
  a consumer that read them from here must define them itself.

### Changed

- **BREAKING for installers — the `@kombiverselabs/design` peer moved to
  `^0.9.0`** (was `^0.8.0`). A caret range on a 0.x version pins the minor, so
  this is not satisfied by `0.8.x`; the design and ui packages ship as one line
  and are bumped together.
- **Primary CTAs are now roles, not local accent CSS.** `Button` emits
  `data-kx="control"` plus `data-variant="primary"` for the primary variant only
  (the other three stay plain controls — `primary` is the sole variant the design
  contract defines). `ServiceCard`'s Open CTA carries the same pair. The local
  accent recipes those elements used to own — fill, glow, hover, brightness — are
  gone; `@kombiverselabs/design` ≥ 0.9.0 owns them.
  - `.kx-button--primary` keeps a **token floor** on purpose: `@kombiverselabs/design`
    is a peer, not a hard dependency, and a primary action must never be invisible
    when only `styles.css` is loaded. It cannot compete with the recipe — Svelte 5
    scopes with `:where()`, so the floor stays at specificity 0,1,0 against the
    recipe's 0,2,0.
  - The `brightness(.96)` hover now excludes the primary variant, where the
    recipe's accent glow answers instead.
- **`styles.css` is a generated artifact**, emitted from `tokens/colors_and_type.css`
  with a source SHA-256 receipt; `mise run tokens:check` fails on drift. It is no
  longer hand-maintained, which is what made the retirements above provable.

### Added

- **Token extras promoted into the generated source** and therefore into the
  published surface: the sidebar family (`SidebarNav`/`AppRail`, Techstack's
  `bg-sidebar` utilities), the corner/glow and button effect tokens
  (Administration's `style-kombify-line`, Cloud's `style-kombify-gradient`), the
  legacy `showcase`/`stack`/`admin` themes, and `--kf-system-card-radius`.
- `--corner-line-length` now has a definition. Every `style-kombify-line` alert
  rule read it and nothing defined it, so that accent rendered zero-width.
- Design roles adopted across the shipped components — service and server cards,
  `ServiceStatusBadge` (closed status vocabulary), `PlacementPath`, `StatusState`.

### Previously published on the 0.8 line

These shipped as derived `0.8.x` patches and had no heading of their own:

- Canonical service and server cards are square by default through the shared
  `--kf-system-card-radius` token, with a `data-system-card-shape="app"` opt-in for
  the normal app/window radius and a persistent `selected` state with stronger
  full-edge hover/focus illumination.
- `ServiceCard` and `ServiceCardCompact` gained unknown and pending runtime
  states, optional consumer labels, neutral status details, and a detailed-card
  footer, so products can adapt their data without a second service-card renderer.
- `ServerCard` gained optional labeled product facts, keeping runtime evidence
  inside the shared card instead of requiring a product-local renderer.
- The design peer was realigned from an impossible `0.1` range onto the published
  `0.8` line.

## 0.8.0

### Added

- **New `./server` export: `ServerCard`** (Beacon design server card; status badge mapping, facts line, metrics chips, consumer-owned actions snippet)
  - Status model: `healthy | degraded | offline | pending | unknown`, mapped onto the shared `ServiceStatusBadge` with per-state labels and a `statusLabel` override
  - Mono facts line: `address · domain (+N) · kit`, each segment optional
  - Up to 3 `.kf-metric` chips (e.g. CPU/RAM/Disk) and an optional tone-able note strip (`info | warning | error`)
  - `actions` snippet renders a consumer-owned action row after a separator — no hardcoded buttons
  - `detailsHref` links the header identity block; HTML attribute passthrough on the root element
  - Showcase: ui-lab `/kombify-ui/server`

## 0.5.1

### Patch Changes

- Warnungs-Cleanup und Release-Härtung:

  - reduziert Svelte-Warnings in `ui-lab` (A11y, veraltete dynamische Komponenten, implizite DOM-Schließung, reaktive Initialisierung)
  - reduziert Svelte-Warnings in `@kombiverselabs/ui` und `@kombify/auth`
  - stabilisiert UI-Lab-Demos ohne blockierende Typecheck-Fehler
  - bereitet Workspace-Packages für den nächsten Versions-Release vor

## 0.6.0 (unreleased)

### Breaking Changes

- **Removed `./auth` export** — Auth components (`LoginCloud`, `LoginSelfHosted`) moved to `@kombify/auth`. Import from `@kombify/auth` instead.

### Added

- **New `./service` export — ecosystem-wide Service Cards (Beacon design):**
  - `ServiceCard` — detailed card with status badge, placement path, metrics row, status strips (migration/update/frozen/error) and on-demand action callbacks
  - `ServiceCardCompact` — wide compact density for drag & drop boards (grip, path widget, quick actions, HTML attribute passthrough for `draggable`)
  - `ServiceStatusBadge`, `PlacementPath` — shared building blocks
  - Status model: `running | stopped | migrating | update | frozen | error`; placements `local | cloud | serverless`
  - Tool theming via existing `--primary` token (theme-stack/sim/cloud/stackkits), semantic states stay stable; uses `--frozen` token with built-in fallback
  - Showcase: ui-lab `/kombify-ui/service`

### Changed

- **Migrated to `@lucide/svelte`** — Replaced `lucide-svelte` with the official `@lucide/svelte` package (^0.562.0).
- **TypeScript** — Aligned to `^5.8.0` across all kombify packages.

## 0.5.0

### Components

- Shell: `SidebarNav`, `FooterModern`, `FooterCompact`, `InlineTabNav`, `ThemeToggle`
- Identity: `StackIdentityIcon`, `StackIdentityName`, `StackIdentityDisplay`, `StackIdentityBadge`, `StackIdentityCard`, `StackIdentityEditor`, `StackIdentityWatermark`, `StackIdentityGreeting`, `StackIdentityHeader`, `StackIdentityAvatar`
- Auth: `LoginCloud`, `LoginSelfHosted` (deprecated — moved to `@kombify/auth`)
- Character catalog with 16 characters (10 playful, 6 futuristic)
- OKLch-based glow color presets
- `resolveIdentityTheme()` API for cross-tool reuse
