# @kombiverselabs/design

Kombify materials, surface recipes, and generated diagram themes. Binding rules
live in `KOMBIFY-DESIGN-SYSTEM-STANDARD.md` in the workspace.

## Use it

Diagram renderers import the generated engine projections from the same package:

```js
import { DIAGRAM_THEMES } from "@kombiverselabs/design/diagram-themes";
const theme = DIAGRAM_THEMES.themes.dark.ai;
```

The typed contract covers `light`/`dark` and the renderer selectors `cloud`, `ai`, `sim`, `stackkits`, `techstack`, `umbrella` (Cloud's default hue). Palette and font derive from `tokens/colors_and_type.css`; Mermaid gets RGB hex variables (no OKLCH support), D2 the complete `themeOverrides` palette through its render API. Engine mappings belong in the token generator, never in a consumer's inline palette; no font assets are exported.

Pin an exact published version and lockfile integrity; never import a sibling checkout or fetch Brand `main` in a build. Use `DIAGRAM_THEMES.version` in SVG cache keys (it hashes the source receipt and engine mappings); the package receipt also hashes the generated module; `mise run tokens:check` detects drift.

```js
import "@kombiverselabs/design/index.css";
```

`index.css` is the generated palette (`tokens.css`: semantic colours, dark mode, product themes, the Tailwind mapping shared with `@kombiverselabs/ui/styles.css`), the generated material, then the role recipes; a consumer loading the design package alone has every token the recipes read.

Then stamp the axes on the document root and give your elements roles:

```html
<html data-appearance="dark" data-finish="aurora">
  <div data-kx="plate">…</div>
  <div data-kx="menu-plate">…</div>
  <aside data-kx="navigation">…</aside>
  <button data-kx="control">…</button>
  <button data-kx="control selection">…</button>
  <button data-kx="run-toggle" aria-pressed="true">Web</button>
  <div data-kx="protected">Approve this tool call?</div>
  <span data-kx="tag" style="--kx-accent: var(--kombify-stackkits)">Tool Definition</span>
  <span data-kx="status" data-status="ok">Enabled</span>
  <button data-kx="menu-item" data-danger>Delete block</button>
</html>
```

The `style` above is shorthand: real consumers set `--kx-accent` in their stylesheet, only to a generated token (no runtime inline style, no literal values; standard §5.4, §5.1). A consumer assigns roles and nothing else: no material values, no finish-specific rule for its own elements (§3, §6).

## Stamp the axes once, from the runtime

The package resolves and stamps the design axes so a product does not write
its own precedence, storage reader, embed parameter parser or pre-paint
script (each of which three products had re-implemented, with the same trap
documented three times):

```js
import {
  applyDesign, designBootstrapScript, readDeviceDesign, readHostDesignParams,
  resolveDesignAxes, hostDesignMessage, isHostDesignMessage,
} from "@kombiverselabs/design/runtime";

// app.html, before first paint (a plain script body, no imports):
//   <script>${designBootstrapScript({ defaults: { appearance: "system", finish: "kombify" } })}</script>

// after mount, with the account tier fetched fail-soft from /v1/ai/settings:
const resolved = resolveDesignAxes({
  host: readHostDesignParams(location.search),   // §4 tier 1, this embedding only
  device: readDeviceDesign(localStorage),         // tier 2, the device's own choice
  account: parseCentralDesign(settingsPayload),   // tier 3, from ./preferences
  prefersDark: matchMedia("(prefers-color-scheme: dark)").matches,
});
applyDesign(document.documentElement, resolved);

// a host tells its embeds when it changes (closed enums at the boundary, §5.2):
iframe.contentWindow.postMessage(hostDesignMessage({ appearance, finish }), origin);
// and an embed accepts only that:
addEventListener("message", (e) => { if (isHostDesignMessage(e.data)) applyDesign(root, resolveDesignAxes({ host: e.data, device, account })); });
```

`data-appearance` is the one required stamp; the generated palette and the Tailwind mapping answer to it as well as to the transitional `.dark` class. Storage keys, the account transport and change events stay product parameters. `src/runtime.test.mjs` proves the precedence and that an unknown value (valid CSS fragments included) never passes.

## Roles

Per-finish element lists (726 lines in the Workbench, twelve edit sites per new element) failed silently: an element nobody added followed no finish. A role costs zero edits, and an element without one is visibly unstyled. Deliberate choices:

- **`run-toggle`** and **`status`** do not vary by finish: an on/off state is not a selection and the hue is the state (`data-status="ok|running|warn|error|off"`, `running` pulses and stands still under reduced motion).
- **`menu-plate`** is not a plate with more alpha: a popover styled as a plate inherits the glass finishes' ~5 % fill and turns see-through over text (shipped twice before the role).
- **`navigation`** is not a vertical `plate`: a calm translucent fill without sheen or backdrop blur, so the page stays visible without swallowing inactive controls or fixed flyouts.
- **`tag`** is the signature label (tinted fill, same-hue border, accent type); hue via `--kx-accent` set only to a generated token; an interactive chip composes `data-kx="control tag"`.
- **`menu-item`** rows are quiet at rest; the checked row composes `selection`, destructive rows carry `data-danger`.

## Security

`protected` marks security-critical UI (approvals, consent prompts, scope-switch confirmation). The design layer may give it colour, radius, typography, border and shadow, never geometry or visibility (§5.3); `scripts/check-design-roles.mjs` (`mise run design:check`) parses the shipped CSS and proves the absence (and that the scan matched something). Individualization is selection, never authoring (§5.1): a preset is an id from a closed set whose values ship here; no user, tenant or host supplies colours or CSS, which keeps UI redressing and CSS exfiltration out of tool approvals.

## Finishes

Each of the five finishes owns a vocabulary over seven dimensions (shape, optic, selection, hover, press, motion, scene; `KOMBIFY-DESIGN-SYSTEM-STANDARD` §7): `kombify` flat tile; `liquid` lens (capsules, specular rim, swelling press); `frost` visible pane (grain, etched small-cap kickers); `expressive` tonal Material 3 Expressive (published springs, shape morph); `aurora` moving light (curtain scene, drifting spectral rim). All lands through the roles; motion through the finish's `--finish-*` tokens, with springs in `product.css` sampled by `scripts/spring-easing.mjs` from the physics.

## Material is generated, never hand-written

`src/generated/material.css` is emitted by
`scripts/generate-platform-tokens.mjs` from `tokens/material.css` and carries
the source SHA-256 as its receipt. `mise run tokens:check` fails on drift.

Hand-written values had drifted (`finish=aurora` border `0.14` in the Workbench, `0.16` in the embedded panel; KOMBIFY-DESIGN-SYSTEM-STANDARD.md §8.4 as amended 2026-08-08).

## Test

```sh
pnpm run --dir packages/design test
```

## Stack Identity catalog

Stack Identity facts live here so Svelte, React, and Compose share one
catalog. Import the JS module, or load the JSON snapshot for a native
renderer. Kubi and Spark are Companion launcher ids in
`COMPANION_APPEARANCES`; they are not Stack Identity characters.

```js
import {
  CHARACTERS,
  COMPANION_APPEARANCES,
  STACK_IDENTITY_RENDER_FIXTURES,
  validateRenderFixture,
} from "@kombiverselabs/design/stack-identity";
```

```js
import catalog from "@kombiverselabs/design/stack-identity/catalog.json" with { type: "json" };
import fixtures from "@kombiverselabs/design/stack-identity/fixtures" with { type: "json" };
```
